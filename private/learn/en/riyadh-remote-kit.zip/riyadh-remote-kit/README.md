# The Riyadh Remote Kit

by Omnya Lab

This is the real code behind our tower remote: a big screen (a computer, a TV or a projector) shows a photoreal flight around a tower, and a phone on the same Wi-Fi drives it. You swipe to orbit the building, pinch to zoom, tap a view and the screen flies there, and drag a slider to take the tower from sunrise to night.

Everything runs on your own computer with a small Python server, so there is nothing to install apart from Python, no account and no cloud. The demo clips are included at 720p, so it works the moment you unzip it, and then you swap in your own clips and names in one file, `config.json`.

## What's inside

| File | What it is |
| --- | --- |
| `Start.command` | Mac: double-click to start |
| `start.bat` | Windows: double-click to start |
| `server.py` | The server, about 280 lines of standard Python, nothing to install |
| `monitor.html` | The big screen |
| `remote.html` | The phone remote (it also works from a tablet or another computer) |
| `config.json` | The one file you edit: clips, view names, title, subtitle, accent colour |
| `clips/` | The three demo clips at 720p and the poster |
| `thumbs/` | The view cards and the small day frames the phone shows |
| `tools/prepare_clips.py` | Turns your own clips into everything the kit needs (uses ffmpeg) |
| `LICENSE.md` | What you can do with the kit |

## What you need

- **Python 3.7 or newer.**
  - Mac: open Terminal and type `python3 --version`. If the Mac offers to install the command line tools, accept, it takes a few minutes. Or install Python from [python.org](https://www.python.org/downloads/).
  - Windows: install Python from [python.org](https://www.python.org/downloads/) and tick **Add python.exe to PATH** on the first screen of the installer.
- **A recent browser** on the big screen: Chrome, Edge or Safari. Chrome or Edge is the smoothest for video scrubbing.
- **A phone on the same Wi-Fi** as the computer. Any recent iPhone or Android works, there is no app to install.
- **Internet is optional.** It is used only for the title font and to draw the QR code. Offline, the title falls back to a system serif and the phone link is shown in large text instead of the QR.

## Start it in one minute

1. Unzip the folder anywhere, for example on your Desktop.
2. Start the server:
   - **Mac:** double-click `Start.command`. The first time macOS may say it cannot verify the developer: right-click `Start.command`, choose **Open**, then **Open** again. You only do this once.
   - **Windows:** double-click `start.bat`.
   - **Any system, from a terminal:** go into the folder and run `python3 server.py` (on Windows `py server.py`).
3. A terminal window opens and stays open, and your browser opens the big screen at `http://localhost:5377/`. Keep the terminal window open while you use the kit, closing it stops everything.
4. On the big screen press **F** for full screen. To show it on a TV, either connect the TV to the computer as a second screen and drag the browser window onto it, or open the same address from the browser of another computer that is plugged into the TV (see below).

## Connect the phone

1. Make sure the phone is on **the same Wi-Fi** as the computer that runs the server.
2. Scan the QR code in the bottom right corner of the big screen with the phone camera and open the link. It looks like `http://192.168.1.20:5377/remote`, and it is also printed in the terminal window.
3. The phone shows **Live** with a green dot, and the QR code fades away on the big screen. Press **Q** on the big screen to bring it back for a second phone. Any number of phones can be connected at the same time, and the last command wins.

The first time, the computer may ask whether Python can accept incoming network connections. Say **Allow**, otherwise the phone cannot reach it (see Troubleshooting).

**Big screen on another computer or a smart TV browser:** open `http://<the address in the terminal>:5377/` there, the same address as the phone but without `/remote`. The server only needs to run on one computer.

**Remote from a computer instead of a phone:** open the phone link in any browser, or `http://localhost:5377/remote` on the computer that runs the server. With a mouse you drag on the big picture to orbit and use the wheel or a trackpad pinch to zoom.

## Using the remote

- **The big picture (pad):** drag with one finger to orbit, the camera keeps going a little and slows down when you let go. Pinch with two fingers to zoom, move two fingers together to pan while zoomed. Double tap to go back to the full view.
- **Views:** tap a card and the big screen flies there along the drone path. If you tap another card during the flight, it goes there as soon as it lands.
- **Light:** drag the knob from Sunrise to Night, or tap a word. This happens on the home view, so if you are elsewhere the screen first flies home.
- **Floors:** shortcuts to two levels of the tower. From the Sky pool an **Enter** button appears (into the lounge), then **Go out**, then **View the tower**.

On the home view, orbiting is the 360 orbit with the day passing, so the light changes as you turn. If you stop close to night, the scene settles on night by itself and the drone tour is back. On the other views, dragging moves the camera a little backwards and forwards along the flight.

Keyboard shortcuts:

| Where | Keys |
| --- | --- |
| Big screen | `F` full screen, `Q` show or hide the QR, `H` hide the title, `0` to `9` go to a view without the phone |
| Remote on a computer | arrows orbit, `+` `-` zoom, `0` full view, `1` to `9` views, `S` `D` `T` `N` sunrise, day, sunset, night |

Big screen address options: `http://localhost:5377/?format=16x9` keeps the picture 16:9 with black bars on an ultra-wide screen, `?qr=0` never shows the QR, `?zmax=3` allows more zoom.

## How it works, in short

The scene is not 3D, it is video. The big screen holds three clips in memory and moves through them frame by frame:

- **tour**: one continuous drone flight that passes through every view, played forwards.
- **tourReverse**: the same flight reversed, so flying backwards is as smooth as flying forwards.
- **day**: a 360 orbit around the tower in which the light goes night, sunrise, day, sunset and back to night.

Each view is simply a frame number in the tour clip. Tapping a view plays the tour (or the reversed tour, whichever way is shorter) from where the camera is to that frame and stops exactly on it, speeding up to 3x on long flights. The phone sends small messages over a WebSocket, and the big screen sends its state back so the phone can light up the right card, move the slider and show a preview of what is on screen.

## Use your own clips

You need two clips from any source: Kling, Runway, Blender, a real drone, anything that gives you an MP4.

**1. The tour clip.** One continuous camera move that passes through every place you want as a view: for example a slow approach, a pass along the pool, into the lounge, out to the city, up to the crown. Rules that make it look seamless:
- **Frame 0 is the home view** (the full building). The kit treats the first view as home, and it is where the light slider and the 360 orbit work.
- **The last frame should match the first frame**, so the tour loops without a jump. If you generate clips one at a time, start each clip on the last frame of the previous one and end the final clip on the very first frame, then join them.
- Keep the camera moving steadily. Pauses are fine, because the kit stops on any frame you choose.

**2. The day clip.** A 360 orbit around the building at the same framing as the home view, with the light changing:
- **Frame 0 and the last frame are night**, and they look the same as frame 0 of the tour clip. That is why switching between the tour and the light has no visible cut.
- Somewhere early on the sun comes up: that frame is `sunriseFrame` in `config.json`.
- Then day, sunset, and night again at the end.

If you do not have a day clip, you can use a copy of your tour clip for now: everything works, only the light slider will move the camera instead of the light.

**3. Prepare them.** Install ffmpeg (Mac: `brew install ffmpeg`, Windows: `winget install ffmpeg`), then from the kit folder run:

```
python3 tools/prepare_clips.py --tour path/to/my_tour.mp4 --day path/to/my_day.mp4
```

It writes `clips/tour.mp4`, builds `clips/tour_reverse.mp4`, writes `clips/day360.mp4` and the poster, all at 720p with a short keyframe interval so scrubbing is smooth, and then saves the view cards and the day preview frames. At the end it prints how many frames your tour has. Add `--height 1080` for 1080p on a large TV (files about twice as big), or `--crf 23` for higher quality.

Doing it by hand instead? Any H.264 MP4 works, but for smooth scrubbing encode with a keyframe every 6 to 12 frames, for example `ffmpeg -i in.mp4 -an -vf scale=-2:720 -c:v libx264 -crf 28 -g 12 -bf 0 -movflags +faststart tour.mp4`, and make the reverse with `-vf reverse`.

**4. Find the view frames.** Open the tour clip in any player that shows frame numbers (QuickTime with the timecode set to frames, VLC, DaVinci Resolve, Premiere), and note the frame of each stop. Frame = seconds x fps, so a stop at 4 seconds in a 24 fps clip is frame 96.

**5. Edit `config.json`** (next section), then run `python3 tools/prepare_clips.py` again **without** `--tour` and `--day`: it only refreshes the view cards at your new frames.

**6. Restart** the server (close the terminal window and start it again) and reload the big screen and the phone.

## config.json, line by line

```
"title": "Burj Al Ballur",              big title on the screen and on the phone
"subtitle": "Riyadh, Saudi Arabia",     small line under the title
"accent": "#9D5CFF",                    accent colour: selected cards, buttons, dots. Any hex colour
"titleFont": "El Messiri",              any Google Fonts family with a bold weight, or "" for the system serif
"fps": 24,                              frame rate of your clips

"clips": {
  "tour": "clips/tour.mp4",
  "tourReverse": "clips/tour_reverse.mp4",
  "day": "clips/day360.mp4",
  "poster": "clips/poster.jpg"          shown while the clips load
},

"views": [                              2 to 10 views, the first one is home and must be frame 0
  { "name": "Tower view",               card title
    "sub": "640 m · Riyadh",            small line shown on the phone
    "frame": 0,                         frame of the tour clip where this view stops
    "thumb": "thumbs/views/view0.jpg" } card picture
],

"light": {
  "sunriseFrame": 22,                   frame of the day clip where the slider's left end (Sunrise) sits
  "stops": [                            the words under the slider, at = position from 0 (left) to 1 (right)
    { "name": "Sunrise", "at": 0, "icon": "sunrise" }, ...   icon: sunrise, day, sunset or night
  ],
  "previewFrames": { "folder": "thumbs/day", "prefix": "d", "count": 65 }
},

"floors": {                             the Floors tab. Set "rows": [] to hide the tab
  "towerHeight": 640,                   used to place the dots on the little tower outline
  "rows": [ { "name": "Sky pool", "label": "L93 · 372 m", "view": 1, "height": 372, "activeIn": [1, 2, 3] } ],
                                        view = where the row flies, activeIn = views where the row is highlighted
  "actions": [ { "at": 1, "label": "Enter", "goTo": 2, "icon": "enter" } ]
                                        a button that appears while you are on view "at" and flies to "goTo"
                                        icon: enter, exit or eye
},

"maxZoom": 2,                           how far the pinch can zoom in
"zoomCenter": [0.5, 0.42],              where the zoom is centred, as a fraction of width and height
"port": 5377                            the server port
```

JSON is strict: keep the double quotes, the commas between items and no comma after the last item of a list. If the big screen shows "Could not read config.json", paste the file into any online JSON validator to find the typo.

## How the day and night slider maps to the video

The slider is a straight line over the day clip. Its left end is `sunriseFrame` and its right end is the last frame of the day clip (night). A slider position from 0 to 1 becomes a time in the clip:

```
time = sunrise + position x (end - sunrise)
```

With the demo clip (385 frames at 24 fps, `sunriseFrame` 22): position 0 is 0.9 s (Sunrise), 0.4 is about 7 s (Day), 0.8 is about 13 s (Sunset), 1 is 16 s (Night). The stop words only decide the label and where a tap sends the knob: change their `at` values to match where day and sunset really are in your clip. The label switches halfway between two stops.

Frames 0 to `sunriseFrame` are the night before sunrise. You reach them only by orbiting with the finger, which scrubs the same clip, 4 seconds of clip per width of the pad. When you let go close to night, the big screen settles on night and hands back to the tour.

The phone preview while orbiting comes from `thumbs/day`: 65 small frames spread evenly over the day clip. `prepare_clips.py` makes them for you.

## Size and quality

The demo clips are 720p, about 20 MB in total, so the download stays small. For a large TV, re-encode at 1080p with `--height 1080`. Above 1080p, scrubbing gets heavy on most computers, and phones are not affected because they never load the videos, only small pictures.

The big screen loads each clip fully into memory before it starts, so the clips should stay under about 150 MB each.

## Troubleshooting

**The phone does not open the page or stays on "Connecting".**
- Phone and computer must be on the same Wi-Fi network. Guest networks and some office or hotel Wi-Fi block devices from seeing each other: use your phone's hotspot, connect the computer to it, and open the new address the terminal prints after a restart.
- Turn off mobile data on the phone for a moment, or the phone might try to reach the address over 4G.
- Use the address the terminal prints, starting with `http://` and not `https://`.
- If the computer has a VPN on, turn it off: the printed address can be the VPN's.

**Firewall.**
- Mac: System Settings > Network > Firewall > Options, and allow incoming connections for python3. If you clicked Deny at the first start, remove python3 from the list and start again.
- Windows: the first time, Windows Defender Firewall asks whether Python can communicate on networks: tick **Private networks** and click Allow. If you missed it: Control Panel > Windows Defender Firewall > Allow an app through firewall > Python, tick Private.
- Your Wi-Fi must be set as a private (home) network on Windows, not public.

**Port in use.** If 5377 is busy, the server takes the next free port by itself and prints the new address. To choose one: `python3 server.py --port 6000`, or change `"port"` in `config.json`.

**The phone says "No screen".** The phone reached the server but the big screen is not open. Open `http://localhost:5377/` on the computer.

**The big screen is black or stuck on the poster.** Check the terminal for errors, check that the clip paths in `config.json` match the files in `clips/`, and that the clips are H.264 MP4 (the most common kind). HEVC or ProRes files may not play in every browser: run them through `prepare_clips.py`.

**Flights stop at the wrong place.** The `frame` values in `config.json` do not match your tour clip, or `fps` is wrong. Run `python3 tools/prepare_clips.py --probe` to see frames and fps.

**Scrubbing is jerky.** Re-encode with `prepare_clips.py`: clips straight out of a generator usually have a keyframe every few seconds, which makes jumping to a frame slow.

**Double-clicking `monitor.html` shows an error.** The pages must be opened through the server (`http://localhost:5377/`), not as files.

**Start.command does nothing on a Mac.** Right-click it, choose Open. If it still does not run, open Terminal, type `cd ` (with a space), drag the kit folder onto the window, press Enter, then type `python3 server.py`.

**Stop the kit:** close the terminal window, or press Ctrl+C in it.

## Privacy

The server runs only on your computer and listens on your local network. Nothing is uploaded and nothing is tracked. The pages load two things from the internet when it is available: the title font from Google Fonts and the QR code library from cdnjs.

---

Made by Omnya Lab · [omnyalab.com](https://omnyalab.com)
