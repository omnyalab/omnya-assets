# Solo per le foto ultra realistiche (Nico 25/11): la scena del film resta com'è, qui si aggiunge su una copia
# quello che in una foto vera si nota. Si attiva con «foto» negli argomenti di costruisci.py.
#  - terrazza del Tempio del Divo Claudio: arcate di travertino su due ordini e contrafforti al posto del muro liscio,
#    ninfeo di Nerone (nicchie, vasca e acqua) sul lato verso il Colosseo, piante che pendono dall'alto
#  - Terme di Tito: finestroni ad arco, cupole basse
#  - orizzonte: colline vere (Colli Albani a SE, Tiburtini e Prenestini a E, Sabini a NE) al posto della striscia grigia
#  - strade e piazza sporche (polvere, paglia, macchie), vestiti di tutti i colori
import bpy, math, random
import numpy as np
from mathutils import Vector
from geo import Builder
import roma, materiali


def _bx(b, mat, x0, x1, y0, y1, z0, z1):
    b.raw(mat, [(x, y, z) for z in (z0, z1) for x, y in ((x0, y0), (x1, y0), (x1, y1), (x0, y1))],
          [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)])


def _arco_quad(b, mat, P0, P1, n_out, g, h_imp, r, seg=10):
    """apertura ad arco piatta poco fuori dalla parete: P0-P1 larghezza sul piano, da g fino all'imposta e poi il semicerchio"""
    P0 = np.array(P0); P1 = np.array(P1); c = (P0 + P1) / 2; u = (P1 - P0) / np.linalg.norm(P1 - P0)
    pts = [(P0, g), (P1, g), (P1, h_imp)]
    for k in range(1, seg):
        a = math.pi * k / seg
        pts.append((c + u * r * math.cos(a), h_imp + r * math.sin(a)))
    pts.append((P0, h_imp))
    V = [(float(p[0] + n_out[0] * 0.06), float(p[1] + n_out[1] * 0.06), float(z)) for p, z in pts]
    b.raw(mat, V, [tuple(range(len(V)))])


def _facciata_arcate(b, A, B_, n_out, ztop, passo=6.0, ninfeo=False, rnd=None):
    """lungo il muro da A a B (verso esterno n_out): contrafforti, due ordini di arcate, cornice, piante che pendono"""
    A = np.array(A, float); B_ = np.array(B_, float); L = np.linalg.norm(B_ - A); u = (B_ - A) / L
    n = int(L / passo)
    for i in range(n + 1):
        p = A + u * (i * L / n)
        g = roma.quota(*p) - 0.5
        q0 = p - u * 0.6; q1 = p + u * 0.6; o = np.array(n_out) * 0.9
        V = [(q0[0], q0[1]), (q1[0], q1[1]), (q1[0] + o[0], q1[1] + o[1]), (q0[0] + o[0], q0[1] + o[1])]
        b.raw('trav2', [(x, y, z) for z in (g - 2, ztop - 0.5) for x, y in V], [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)])
    for i in range(n):
        a = A + u * (i * L / n + 1.0); c = A + u * ((i + 1) * L / n - 1.0)
        g = min(roma.quota(*a), roma.quota(*c))
        H = ztop - g
        if H < 3.0:
            continue
        r = np.linalg.norm(c - a) / 2
        if H > 9.0:                                   # due ordini
            z_mid = g + H * 0.52
            _arco_quad(b, 'buio', a, c, n_out, g, z_mid - r - 0.8, r)
            _arco_quad(b, 'buio', a + u * 0.6, c - u * 0.6, n_out, z_mid + 0.6, ztop - r - 1.4, r - 0.6)
            p0 = a - u * 1.0; p1 = c + u * 1.0
            b.raw('trav2', [(p0[0] + n_out[0] * 0.95, p0[1] + n_out[1] * 0.95, z_mid), (p1[0] + n_out[0] * 0.95, p1[1] + n_out[1] * 0.95, z_mid),
                            (p1[0] + n_out[0] * 0.95, p1[1] + n_out[1] * 0.95, z_mid + 0.5), (p0[0] + n_out[0] * 0.95, p0[1] + n_out[1] * 0.95, z_mid + 0.5)], [(0, 1, 2, 3)])
        else:
            _arco_quad(b, 'buio', a, c, n_out, g, min(ztop - r - 1.0, g + H * 0.6), r)
        if ninfeo and i % 2 == 0:                     # ninfeo: vasca e acqua che scende dalla nicchia
            m = (a + c) / 2; no = np.array(n_out)
            _bx(b, 'trav2', *sorted((m[0] - 2.4, m[0] + 2.4)), *sorted((m[1] + no[1] * 0.2, m[1] + no[1] * 2.6)), g - 0.5, g + 0.7) if abs(no[0]) < 0.5 else None
            w0 = m - u * 0.5; w1 = m + u * 0.5
            b.raw('acqua', [(w0[0] + no[0] * 0.1, w0[1] + no[1] * 0.1, g + 0.7), (w1[0] + no[0] * 0.1, w1[1] + no[1] * 0.1, g + 0.7),
                            (w1[0] + no[0] * 0.1, w1[1] + no[1] * 0.1, g + min(H * 0.45, 6)), (w0[0] + no[0] * 0.1, w0[1] + no[1] * 0.1, g + min(H * 0.45, 6))], [(0, 1, 2, 3)])
            b.raw('acqua', [(m[0] - 2.2, m[1] + no[1] * 0.3, g + 0.65), (m[0] + 2.2, m[1] + no[1] * 0.3, g + 0.65),
                            (m[0] + 2.2, m[1] + no[1] * 2.4, g + 0.65), (m[0] - 2.2, m[1] + no[1] * 2.4, g + 0.65)], [(0, 1, 2, 3)])
    # cornice in cima e piante che pendono
    p0 = A - u * 0.5; p1 = B_ + u * 0.5; o = np.array(n_out)
    b.raw('trav2', [(p0[0] + o[0] * 1.1, p0[1] + o[1] * 1.1, ztop - 0.6), (p1[0] + o[0] * 1.1, p1[1] + o[1] * 1.1, ztop - 0.6),
                    (p1[0] + o[0] * 1.1, p1[1] + o[1] * 1.1, ztop + 0.1), (p0[0] + o[0] * 1.1, p0[1] + o[1] * 1.1, ztop + 0.1)], [(0, 1, 2, 3)])
    rnd = rnd or random.Random(4)
    s = 0.0
    while s < L:
        w = rnd.uniform(1.5, 5.0); d = rnd.uniform(1.0, 4.5)
        if rnd.random() < 0.55:
            q0 = A + u * s; q1 = A + u * min(L, s + w)
            b.raw('foglie', [(q0[0] + o[0] * 1.15, q0[1] + o[1] * 1.15, ztop), (q1[0] + o[0] * 1.15, q1[1] + o[1] * 1.15, ztop),
                             (q1[0] + o[0] * 1.25, q1[1] + o[1] * 1.25, ztop - d * rnd.uniform(0.6, 1.0)), (q0[0] + o[0] * 1.25, q0[1] + o[1] * 1.25, ztop - d)], [(0, 1, 2, 3)])
        s += w + rnd.uniform(0.5, 4.0)


def claudio(b, rnd):
    x, y = 0.0, -330.0; z = roma.quota(x, y); zt = z + 9.0
    hx, hy = 90.0, 100.0
    lati = [((x - hx, y + hy), (x + hx, y + hy), (0, 1), True),      # nord: verso il Colosseo, ninfeo
            ((x + hx, y + hy), (x + hx, y - hy), (1, 0), False),
            ((x + hx, y - hy), (x - hx, y - hy), (0, -1), False),
            ((x - hx, y - hy), (x - hx, y + hy), (-1, 0), False)]
    for A, B_, n_out, nin in lati:
        _facciata_arcate(b, A, B_, n_out, zt, 6.5, nin, rnd)


def terme(b):
    x, y = 177.0, 190.0; z = roma.quota(x, y); r = 0.75; c, s = math.cos(r), math.sin(r)
    W = lambda u, v: (x + u * c - v * s, y + u * s + v * c)
    for side in (-1, 1):                                    # finestroni ad arco sul corpo in laterizio (55 x 22)
        for i in range(10):
            u = -50 + i * 11.0
            P0 = W(u - 2.6, side * 22.06); P1 = W(u + 2.6, side * 22.06)
            _arco_quad(b, 'buio', P0, P1, (-s * side, c * side), z + 6, z + 13, 2.6)
    for (u, v, rr) in ((0, 0, 14.0), (-38, 0, 9.0), (38, 0, 9.0)):   # cupole basse
        cx, cy = W(u, v); zz = z + (26 if u == 0 else 14)
        V = []; F = []; nu, nv = 24, 6
        for j in range(nv + 1):
            ph = (math.pi / 2) * j / nv
            for i in range(nu):
                a = 2 * math.pi * i / nu
                V.append((cx + rr * math.cos(ph) * math.cos(a), cy + rr * math.cos(ph) * math.sin(a), zz + rr * 0.45 * math.sin(ph)))
        for j in range(nv):
            for i in range(nu):
                F.append((j * nu + i, j * nu + (i + 1) % nu, (j + 1) * nu + (i + 1) % nu, (j + 1) * nu + i))
        b.raw('tegole', V, F)


def orizzonte(scn):
    """colline vere lontane al posto dell'anello grigio: altezza per rotta (STIMA dalle carte), foschia azzurrina"""
    ob = bpy.data.objects.get('roma_monti')
    if ob:
        bpy.data.objects.remove(ob, do_unlink=True)
    rnd = random.Random(12); V = []; F = []; n = 2880
    def h_rotta(br, d):
        h = 25.0
        for c, w, hh in ((150, 22, 900), (95, 18, 750), (70, 14, 1100), (45, 20, 1250), (20, 12, 900), (125, 10, 600)):
            dd = (br - c + 180) % 360 - 180
            h += hh * math.exp(-(dd / w) ** 2)
        return h
    for i in range(n):
        a = 2 * math.pi * i / n
        p = np.array([math.cos(a), math.sin(a)])
        br = (math.degrees(math.atan2(p @ roma.E_HAT, p @ roma.N_HAT)) + 360) % 360
        d = 24000.0
        h = h_rotta(br, d) * (1 + 0.14 * math.sin(i * 0.021 + 0.7) + 0.08 * math.sin(i * 0.057 + 2.1) + 0.04 * math.sin(i * 0.13))   # profili morbidi, niente denti
        V += [(d * p[0], d * p[1], -2.0), (d * p[0], d * p[1], max(10.0, h))]
    for i in range(n):
        j = (i + 1) % n
        F.append((2 * i, 2 * j, 2 * j + 1, 2 * i + 1))
    me = bpy.data.meshes.new('colline'); me.from_pydata(V, [], F)
    m = bpy.data.materials.new('colline'); m.use_nodes = True; nt = m.node_tree
    for nd in list(nt.nodes):
        nt.nodes.remove(nd)
    out = nt.nodes.new('ShaderNodeOutputMaterial'); e = nt.nodes.new('ShaderNodeEmission')
    g = nt.nodes.new('ShaderNodeNewGeometry'); sz = nt.nodes.new('ShaderNodeSeparateXYZ'); nt.links.new(g.outputs['Position'], sz.inputs[0])
    mr = nt.nodes.new('ShaderNodeMapRange'); mr.inputs['From Min'].default_value = 0; mr.inputs['From Max'].default_value = 1300
    nt.links.new(sz.outputs[2], mr.inputs['Value'])
    rp = nt.nodes.new('ShaderNodeValToRGB'); rp.color_ramp.elements[0].color = (0.62, 0.6, 0.58, 1); rp.color_ramp.elements[1].color = (0.5, 0.53, 0.58, 1)
    nt.links.new(mr.outputs['Result'], rp.inputs[0]); nt.links.new(rp.outputs[0], e.inputs['Color']); e.inputs['Strength'].default_value = 1.0
    nt.links.new(e.outputs[0], out.inputs[0]); me.materials.append(m)
    scn.collection.objects.link(bpy.data.objects.new('colline', me))


def sporca(mat, forza=0.45):
    """polvere, paglia e macchie sopra il colore della pietra (scala di qualche metro, niente righe)"""
    if mat is None or not mat.use_nodes:
        return
    nt = mat.node_tree; N = nt.nodes; L = nt.links
    bsdf = next((n for n in N if n.type == 'BSDF_PRINCIPLED'), None)
    if bsdf is None or not bsdf.inputs['Base Color'].is_linked:
        return
    src = bsdf.inputs['Base Color'].links[0].from_socket
    g = N.new('ShaderNodeNewGeometry')
    no = N.new('ShaderNodeTexNoise'); no.inputs['Scale'].default_value = 0.35; no.inputs['Detail'].default_value = 10; no.inputs['Roughness'].default_value = 0.65
    L.new(g.outputs['Position'], no.inputs['Vector'])
    mr = N.new('ShaderNodeMapRange'); mr.inputs['From Min'].default_value = 0.45; mr.inputs['From Max'].default_value = 0.75
    L.new(no.outputs['Fac'], mr.inputs['Value'])
    mu = N.new('ShaderNodeMath'); mu.operation = 'MULTIPLY'; mu.inputs[1].default_value = forza; L.new(mr.outputs['Result'], mu.inputs[0])
    mx = N.new('ShaderNodeMix'); mx.data_type = 'RGBA'
    L.new(mu.outputs[0], mx.inputs['Factor']); L.new(src, mx.inputs['A']); mx.inputs['B'].default_value = (0.42, 0.33, 0.22, 1)
    pa = N.new('ShaderNodeTexVoronoi'); pa.inputs['Scale'].default_value = 9.0; L.new(g.outputs['Position'], pa.inputs['Vector'])
    pm = N.new('ShaderNodeMapRange'); pm.inputs['From Min'].default_value = 0.0; pm.inputs['From Max'].default_value = 0.06
    pm.inputs['To Min'].default_value = 0.35; pm.inputs['To Max'].default_value = 0.0; L.new(pa.outputs['Distance'], pm.inputs['Value'])
    mx2 = N.new('ShaderNodeMix'); mx2.data_type = 'RGBA'
    L.new(pm.outputs['Result'], mx2.inputs['Factor']); L.new(mx.outputs['Result'], mx2.inputs['A']); mx2.inputs['B'].default_value = (0.78, 0.66, 0.38, 1)
    L.new(mx2.outputs['Result'], bsdf.inputs['Base Color'])


def colori_vestiti(mat):
    """vestiti di tutti i colori (tinte naturali romane: robbia, guado, zafferano, verde salvia, terre), non solo crema"""
    pal = ['#e9e2d3', '#ddd3bf', '#8f2f24', '#b5532c', '#c99a3a', '#3f5a78', '#5b6b4a', '#7a4a6a', '#d8cbb0', '#9c7a52', '#a8432f', '#efe9dc']
    nt = mat.node_tree
    ramp = next((n for n in nt.nodes if n.type == 'VALTORGB'), None)
    if ramp is None:
        return
    els = ramp.color_ramp.elements
    while len(els) < len(pal):
        els.new(0.5)
    for i, h in enumerate(pal):
        els[i].position = i / len(pal); els[i].color = (*materiali._hex(h), 1)


def applica(scn, MAT, mesh_obj, coll):
    rnd = random.Random(80)
    b = Builder()
    claudio(b, rnd)
    terme(b)
    for mat, (V, F) in b.parts.items():
        if V:
            mesh_obj(f'foto_{mat}', V, F, mat, coll)
    orizzonte(scn)
    for nome in ('viale_trav', 'basolato', 'lastre', 'lastre2'):
        sporca(MAT.get(nome), 0.5 if nome != 'lastre' else 0.35)
    colori_vestiti(MAT['stoffa'])
    print('FOTO_EXTRA ok')
