// Plane · Choose your seat: the real clips of the plane + the choices (plan, class, seat, ticket, upgrades, The Residence).
// Pianta: passi sulle classi (arancio + biglietto), clic. Economy e Premium: ogni posto si può scegliere, gli occupati sono "Booked".
// Biglietto: Book this seat oppure upgrade alla classe dopo. Residence: See the whole Residence, poi Book this flight. R ricomincia.
const A = 'assets/';
const SEATS = { E: [], P: [] }; let ZONES = {};
const still = {}, layer = {}, vid = {};
const CLS = { E: ['Economy class', 'Economy', FLIGHT.price.E, ['38 seats left', 'ok']], P: ['Premium economy', 'Premium', FLIGHT.price.P, ['12 seats left', 'few']], F: ['First class · 6 suites', 'First Suite', FLIGHT.price.F, ['2 left', 'few']], R: ['One per flight', 'The Residence', FLIGHT.price.R, ['Last one', 'no']] };
const TITLE_OF = { EA: 'K2', K3: 'K3', K5: 'K5', K6: 'K6' };   // EA = pianta -> Economy al centro: lì esce il titolo Economy
const ZOOM_TO = { EA: [1, 0, 0], EB: [1, 0, 0], K2: [1.06, 0, 0], K3: [1.02, 0.02, 0.01], K4: [1.065, 0, 0], K5: [1.02, 0.01, 0], K6: [1.05, 0.01, 0], K7: [1.0, 0, 0], K8: [1.05, 0, 0] };   // zoom sull'ultimo fotogramma prima della clip dopo (come nel reel)
const PREV = { EA: 'K1', EB: 'EA', K2: 'K1', K3: 'EB', K4: 'K3', K5: 'K4', K6: 'K5', K7: 'K6', K8: 'K7' };

// ---------------- caricamento ----------------
let toLoad = 1; const loaded = () => { if (--toLoad === 0) start(); };
const ld = s => { const im = new Image(); toLoad++; im.onload = im.onerror = loaded; im.src = s; return im; };
for (const k of ['K1', 'EA', 'EB', 'K3', 'K4', 'K5', 'K6', 'K7', 'K8']) { still[k] = ld(`${A}s_${k}.jpg`); still['f' + k] = ld(`${A}f_${k}.jpg`);
  const v = document.createElement('video'); v.src = `${A}${k}.mp4`; v.muted = true; v.playsInline = true; v.preload = 'auto'; vid[k] = v; }
for (const n of ['K1_E', 'K1_P', 'K1_F', 'K1_R', 'EA_Ebooked', 'EA_Efree', 'K3_Pbooked', 'K3_Pfree']) layer[n] = ld(`${A}${n}.png`);
for (const [f, u] of [['SFD', 'fonts/Inter-SemiBold.otf'], ['SFTB', 'fonts/Inter-Bold.otf'], ['SFTS', 'fonts/Inter-SemiBold.otf']]) { toLoad++; new FontFace(f, `url("${u}")`).load().then(x => { document.fonts.add(x); loaded(); }, loaded); }
toLoad++; fetch(A + 'seats.json').then(r => r.json()).then(j => { SEATS.E = j.EZ; SEATS.P = j.P; ZONES = j.zones; loaded(); });
loaded();

// ---------------- stato ----------------
// st: intro | plan | seats(E/P) | ticket(eco/premT/first/book) | res | play | booked
let S = { st: 'load', t0: 0 }, mouse = { x: -1, y: -1, down: false }, hoverSeat = null, hoverCls = null, chosen = { E: null, P: null };
const now = () => performance.now() / 1000;
function go(st, extra = {}) { S = { st, t0: now(), ...extra }; }
function start() { go('intro'); requestAnimationFrame(frame); }

// porta il mouse dalle coordinate della finestra a quelle del canvas 1920x1080 (canvas a tutto schermo, "cover")
function toCanvas(e) { const r = cv.getBoundingClientRect(), s = Math.max(r.width / W, r.height / H), ox_ = (r.width - W * s) / 2, oy = (r.height - H * s) / 2; return [(e.clientX - r.left - ox_) / s, (e.clientY - r.top - oy) / s]; }
const AUTO = new URLSearchParams(location.search).get('auto') === '1';   // ?auto=1: giro automatico, il mouse vero non conta
addEventListener('mousemove', e => { if (AUTO) return; [mouse.x, mouse.y] = toCanvas(e); });
addEventListener('mousedown', e => { if (AUTO) return; [mouse.x, mouse.y] = toCanvas(e); onClick(); });
addEventListener('keydown', e => { if (AUTO) return; if (e.key === 'r' || e.key === 'R') { stopAll(); go('intro'); } if (e.key === ' ' && S.st === 'intro') playClip('K1'); });
const inR = (r, x = mouse.x, y = mouse.y) => r && x >= r[0] && x <= r[2] && y >= r[1] && y <= r[3];

// ---------------- clip: zoom morbido sull'ultimo fotogramma, poi la clip, poi la scena dopo ----------------
function stopAll() { for (const v of Object.values(vid)) { v.pause(); } }
function playClip(k, extra = {}) { go('zoom', { k, ...extra }); }
function stage(k) {   // scena ferma sull'ultimo fotogramma della clip k
  return { K1: 'plan', EA: 'seatsE', EB: 'eco', K3: 'seatsP', K2: 'eco', K4: 'premT', K5: 'first', K6: 'res', K7: 'shower', K8: 'book' }[k];
}

// ---------------- clic ----------------
function onClick() {
  const st = S.st;
  if (st === 'intro') { if (inR(window.__ibtn)) playClip('K1'); return; }
  if (st === 'plan' && hoverCls) {
    if (hoverCls === 'E') playClip('EA');   // clip vera: zoom dritto che mette l'Economy al centro
    if (hoverCls === 'P') go('fade', { to: 'seatsP', img: 'K3' });
    if (hoverCls === 'F') go('fade', { to: 'first', img: 'K5' });
    if (hoverCls === 'R') go('fade', { to: 'res', img: 'K6' });
    return;
  }
  if ((st === 'seatsE' || st === 'seatsP') && hoverSeat) {
    const cls = st === 'seatsE' ? 'E' : 'P';
    if (hoverSeat[3]) { S.shake = now(); S.shakeId = hoverSeat[0]; return; }   // posto occupato: la card trema
    chosen[cls] = hoverSeat[0]; S.pick = now();
    setTimeout(() => playClip(cls === 'E' ? 'EB' : 'K4'), 650); return;
  }
  if (['eco', 'premT', 'first', 'book'].includes(st) && window.__btn) {
    if (inR(window.__btn.book)) { go('booked', { from: st, o: ticketOf(st) }); return; }
    if (inR(window.__btn.up)) {
      if (st === 'eco') playClip('K3');
      else if (st === 'premT') playClip('K5');
      else if (st === 'first') playClip('K6');
      else if (st === 'book') go('booked', { from: st, o: ticketOf(st) });
      return;
    }
  }
  if (st === 'res' && inR(window.__gbtn)) { playClip('K7'); return; }
  if (st === 'booked' && inR(window.__btn && window.__btn.up)) { stopAll(); chosen = { E: null, P: null }; go('plan'); return; }
}

// ---------------- biglietti di ogni scena ----------------
function ticketOf(st) {
  const e = chosen.E || '32A', p = chosen.P || '12A';
  if (st === 'eco') return { theme: 'light', cls: 'E', clsName: 'Economy', seat: e, gate: 'B12', boards: '07:55', price: FLIGHT.price.E, status: ['Available', 'ok'], q1: 'Not satisfied?', btn: 'See Premium →', book: 'Book seat ' + e };
  if (st === 'premT') return { theme: 'light', cls: 'P', clsName: 'Premium', seat: p, gate: 'B12', boards: '07:45', price: FLIGHT.price.P, status: ['Available', 'ok'], q1: 'Want more space?', btn: 'Upgrade to First →', book: 'Book seat ' + p, up: 'first' };
  if (st === 'first') return { theme: 'first', cls: 'F', clsName: 'First', seatLab: 'Suite', seat: '2A', gate: 'A1', boards: '07:30', price: FLIGHT.price.F, status: ['2 suites left', 'few'], q1: 'Want even more?', btn: 'The Residence →', book: 'Book Suite 2A', up: 'gold' };
  return { theme: 'gold', cls: 'R', clsName: 'The Residence', seatLab: 'Apartment', seat: 'R1', gate: 'A1', boards: 'Any time', price: FLIGHT.price.R, status: ['Last one', 'no'], q1: 'Your flight is ready', btn: 'Book this flight →' };
}

// ---------------- disegno ----------------
// vista: s = zoom, cu/cv = centro (0..1) della foto che va al centro dello schermo
const V0 = { s: 1, cu: 0.5, cv: 0.5 }, VIEW_E = { s: 1.7, cu: 0.328, cv: 0.498 };   // Economy al centro, più grande
const eio = x => { x = clamp(x); return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; };
const vmix = (a, b, e) => ({ s: a.s + (b.s - a.s) * e, cu: a.cu + (b.cu - a.cu) * e, cv: a.cv + (b.cv - a.cv) * e });
const toScr = (u, v, w = V0) => [((u - w.cu) * w.s + 0.5) * W, ((v - w.cv) * w.s + 0.5) * H];
function bgV(k, w = V0) { const im = still[k], iw = im.naturalWidth, ih = im.naturalHeight; ctx.drawImage(im, iw * (w.cu - 0.5 / w.s), ih * (w.cv - 0.5 / w.s), iw / w.s, ih / w.s, 0, 0, W, H); }
function bg(k, z = [1, 0, 0]) { bgV(k, { s: z[0], cu: 0.5 + z[1], cv: 0.5 + z[2] }); }   // ultimo fotogramma della clip k, con zoom z (s, dx, dy)
function lay(n, a, clipU = 1, w = V0) {   // strato allineato alla foto, stessa vista; clipU = tendina da sinistra (0..1 della foto)
  if (a <= 0.003) return; const im = layer[n], iw = im.naturalWidth, ih = im.naturalHeight, u0 = w.cu - 0.5 / w.s, v0 = w.cv - 0.5 / w.s, uc = Math.min(clipU, u0 + 1 / w.s);
  if (uc <= u0) return; ctx.save(); ctx.globalAlpha = a; ctx.drawImage(im, iw * u0, ih * v0, (uc - u0) * iw, ih / w.s, 0, 0, (uc - u0) * w.s * W, H); ctx.restore();
}
function cardSeat(cls, s, t, mine, shake, view = V0) {
  const [id, u, v, bk] = s, [x, y] = toScr(u, v, view), w = (cls === 'E' ? 20 : 92) * (view.k || view.s), h = (cls === 'E' ? 14 : 70) * (view.k || view.s);
  ctx.save(); ctx.lineWidth = cls === 'E' ? 3 : 5; ctx.strokeStyle = bk ? '#ff4a4a' : '#ffc24a';
  if (mine) { ctx.fillStyle = 'rgba(255,122,18,0.9)'; ctx.globalCompositeOperation = 'multiply'; ctx.beginPath(); ctx.roundRect(x - w / 2, y - h / 2, w, h, 4); ctx.fill(); ctx.globalCompositeOperation = 'source-over'; ctx.strokeStyle = '#ffffff'; }
  else if (!bk) { ctx.fillStyle = 'rgba(255,194,74,0.5)'; ctx.beginPath(); ctx.roundRect(x - w / 2, y - h / 2, w, h, 4); ctx.fill(); }
  ctx.beginPath(); ctx.roundRect(x - w / 2 - 3, y - h / 2 - 3, w + 6, h + 6, 6); ctx.stroke(); ctx.restore();
  const row = id.slice(0, -1), sz = smallTicket(CLSN[cls] + ' · Row ' + row + (/[AK]$/.test(id) ? ' · Window' : ''), 'Seat ' + id, PRICE_C[cls], bk ? ['Booked', 'no'] : ['Available', 'ok']);
  const below = v < 0.3, sh = shake ? Math.sin(shake * 60) * 10 * Math.max(0, 1 - shake / 0.4) : 0;
  putSmall(sz, x + sh, below ? y + h / 2 + 4 : y - h / 2 - 6, t, 0, below);
}
const CLSN = { E: 'Economy', P: 'Premium' }, PRICE_C = { E: FLIGHT.price.E, P: FLIGHT.price.P };
function nearestSeat(cls, view = V0) {
  let best = null, bd = (cls === 'E' ? 16 : 60) * (view.k || view.s);
  for (const s of SEATS[cls]) { if (s[1] < 0 || s[1] > 1 || s[2] < 0 || s[2] > 1) continue; const [x, y] = toScr(s[1], s[2], view), d = Math.hypot(x - mouse.x, y - mouse.y); if (d < bd) { bd = d; best = s; } }
  return best;
}
let hoverT = 0, lastHover = null;
function frame() {
  requestAnimationFrame(frame);
  const t = now() - S.t0; ctx.globalAlpha = 1; ctx.filter = 'none'; cv.style.cursor = 'default';
  const lastBtn = window.__btn, lastG = window.__gbtn, lastI = window.__ibtn; window.__btn = null; window.__gbtn = null; window.__ibtn = null; window.__lastI = lastI;
  switch (S.st) {
    case 'intro': { introCard(t); if (inR(window.__ibtn)) cv.style.cursor = 'pointer'; break; }
    case 'zoom': {   // 0,5 s di zoom morbido sull'ultimo fotogramma, poi parte la clip
      const k = S.k, p = PREV[k];
      if (!p) { go('play', { k: S.k }); vid[k].currentTime = 0; vid[k].play(); ctx.drawImage(still.fK1, 0, 0, W, H); break; }
      const z = ZOOM_TO[k], to = { s: z[0], cu: 0.5 + z[1], cv: 0.5 + z[2] }, D = S.from ? 0.85 : (z[0] === 1 && !z[1] && !z[2] ? 0.05 : 0.5), e = (S.from ? eio : ss)(t / D), w = vmix(S.from || V0, to, e);
      bgV(p, w);
      if (t >= D) { go('play', { k }); vid[k].currentTime = 0; vid[k].play(); }
      break;
    }
    case 'play': {
      const v = vid[S.k];
      if (v.readyState >= 2) ctx.drawImage(v, 0, 0, W, H); else bg(PREV[S.k] || 'K1', ZOOM_TO[S.k] || [1, 0, 0]);
      if (TITLE_OF[S.k]) classTitle(TITLES[TITLE_OF[S.k]], v.currentTime);
      if (v.ended || (v.duration && v.currentTime >= v.duration - 0.02)) { const nx = stage(S.k); go(nx); }
      break;
    }
    case 'fade': {   // dalla pianta direttamente a un'altra classe: dissolvenza al nero e ritorno
      const a = ss(t / 0.45); if (t < 0.45) { bg('K1'); ctx.fillStyle = `rgba(0,0,0,${a})`; ctx.fillRect(0, 0, W, H); }
      else { const b = 1 - ss((t - 0.45) / 0.45); bg(S.img); ctx.fillStyle = `rgba(0,0,0,${b})`; ctx.fillRect(0, 0, W, H); if (t > 0.9) go(S.to); }
      break;
    }
    case 'plan': {
      bg('K1');
      hoverCls = null; for (const c of 'EPFR') if (inR([ZONES[c][0] * W, ZONES[c][1] * H, ZONES[c][2] * W, ZONES[c][3] * H])) hoverCls = c;
      if (hoverCls !== lastHover) { lastHover = hoverCls; hoverT = now(); }
      if (hoverCls) { lay('K1_' + hoverCls, ss((now() - hoverT) / 0.18)); const z = CLS[hoverCls], zr = ZONES[hoverCls]; const sz = smallTicket(z[0], z[1], z[2], z[3]); putSmall(sz, (zr[0] + zr[2]) / 2 * W, zr[1] * H - 10, now() - hoverT); cv.style.cursor = 'pointer'; }
      chipGold('Flight 001', 'Choose your class', ss(t / 0.5));
      break;
    }
    case 'seatsE': case 'seatsP': {
      const cls = S.st === 'seatsE' ? 'E' : 'P', k = cls === 'E' ? 'K1' : 'K3';
      const view = cls === 'E' ? { ...V0, k: 1.7 } : V0; S.view = view;   // Economy: la foto è già quella ravvicinata (clip EA)
      bgV(k === 'K1' ? 'EA' : k, view); const w = ss(t / 0.6); const lk = cls === 'E' ? 'EA' : k; lay(lk + '_' + cls + 'booked', 1, w, view); lay(lk + '_' + cls + 'free', 1, w, view);
      const s = S.pick ? SEATS[cls].find(x => x[0] === chosen[cls]) : (t > 0.5 ? nearestSeat(cls, view) : null);
      hoverSeat = S.pick ? null : s;
      const key = s ? s[0] : null; if (key !== lastHover) { lastHover = key; hoverT = now(); }
      if (s) { cardSeat(cls, s, now() - hoverT, !!S.pick, S.shake && S.shakeId === s[0] ? now() - S.shake : 0, view); cv.style.cursor = s[3] ? 'not-allowed' : 'pointer'; }
      chipGold(cls === 'E' ? 'Economy' : 'Premium', 'Choose your seat', ss(t / 0.5));
      break;
    }
    case 'eco': case 'premT': case 'first': case 'book': {
      const k = { eco: 'EB', premT: 'K4', first: 'K5', book: 'K8' }[S.st]; bg(k);
      const o = ticketOf(S.st); o.hoverBook = !!(lastBtn && inR(lastBtn.book));
      drawPass(ctx, o, t, 0, false);
      if (window.__btn && (inR(window.__btn.up) || inR(window.__btn.book))) cv.style.cursor = 'pointer';
      break;
    }
    case 'res': {
      bg('K6'); chipGold('The Residence', 'Bedroom', ss(t / 0.45)); goldBar(ctx, 'Your bedroom', 'See the whole Residence →', H - 150, ss(t / 0.45), false);
      if (inR(window.__gbtn)) cv.style.cursor = 'pointer';
      break;
    }
    case 'shower': {   // la doccia si guarda un attimo, poi si esce dall'aereo
      bg('K7'); chipGold('The Residence', 'Shower at 40,000 ft', ss(t / 0.45));
      if (t > 1.6) playClip('K8');
      break;
    }
    case 'booked': {
      const k = { eco: 'EB', premT: 'K4', first: 'K5', book: 'K8' }[S.from]; bg(k);
      const o = { ...S.o, status: ['Booked', 'ok'], q1: 'You are booked', btn: 'Choose another seat ↺', book: null, up: null };
      if (o.theme === 'light' || o.theme === 'first') o.btn = 'Choose another seat ↺';
      drawPass(ctx, o, 9, 0, false); tText(ctx, 'Booked ✓', W / 2, 110, 'SFD', 64, '#ffffff', 'center');
      if (window.__btn && inR(window.__btn.up)) cv.style.cursor = 'pointer';
      break;
    }
  }
  if (AUTO) drawCur();
}

// ---------------- intro: Book a flight, con le informazioni del volo ----------------
function introCard(t) {
  ctx.drawImage(still.fK1, 0, 0, W, H);
  const a = eio(t / 0.8); ctx.fillStyle = `rgba(6,8,12,${0.35 * a})`; ctx.fillRect(0, 0, W, H);
  const PW = 1080, PH = 600, x0 = W / 2 - PW / 2, y0 = H / 2 - PH / 2 + (1 - a) * 24, cx = W / 2;
  ctx.save(); ctx.globalAlpha = a;
  ctx.shadowColor = 'rgba(0,0,0,0.45)'; ctx.shadowBlur = 60; ctx.shadowOffsetY = 20;
  ctx.fillStyle = 'rgba(12,12,15,0.72)'; ctx.beginPath(); ctx.roundRect(x0, y0, PW, PH, 38); ctx.fill(); ctx.shadowColor = 'transparent';
  ctx.strokeStyle = 'rgba(255,255,255,0.12)'; ctx.lineWidth = 1.5; ctx.stroke();
  // testa
  tText(ctx, FLIGHT.number + '  ·  Non-stop  ·  ' + FLIGHT.date, cx, y0 + 62, 'SFTB', 18, '#d8b27a', 'center', 0.22, true);
  // Dubai ✈ Los Angeles centrati come gruppo; sotto ogni città il suo codice e orario, sotto l'aereo la durata
  const wD = tW(ctx, FLIGHT.fromName, 'SFD', 76), wL = tW(ctx, FLIGHT.toName, 'SFD', 76), G = 76, gx = cx - (wD + 2 * G + wL) / 2, pxp = gx + wD + G;
  tText(ctx, FLIGHT.fromName, gx, y0 + 140, 'SFD', 76, '#ffffff'); tText(ctx, FLIGHT.toName, pxp + G, y0 + 140, 'SFD', 76, '#ffffff');
  tPlane(ctx, pxp, y0 + 140, 30, '#ff7a12');
  tText(ctx, FLIGHT.from + '  ·  ' + FLIGHT.departs, gx + wD / 2, y0 + 206, 'SFTS', 24, 'rgba(255,255,255,0.7)', 'center'); tText(ctx, FLIGHT.to + '  ·  ' + FLIGHT.arrives, pxp + G + wL / 2, y0 + 206, 'SFTS', 24, 'rgba(255,255,255,0.7)', 'center');
  tText(ctx, FLIGHT.duration, pxp, y0 + 206, 'SFTS', 20, 'rgba(255,255,255,0.5)', 'center');
  ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fillRect(x0 + 70, y0 + 252, PW - 140, 1);
  // le quattro classi
  const C = [['Economy', 'from $' + FLIGHT.price.E, '#ffffff'], ['Premium', 'from $' + FLIGHT.price.P, '#ffffff'], ['First', 'from $' + FLIGHT.price.F, '#e2cba0'], ['The Residence', '$' + FLIGHT.price.R, 'gold']], cw = (PW - 140) / 4;
  C.forEach(([n, p, col], i) => { const x = x0 + 70 + cw * i + cw / 2;
    tText(ctx, ['01', '02', '03', '04'][i], x, y0 + 296, 'SFTS', 15, 'rgba(255,255,255,0.45)', 'center', 0.25, true);
    const f = col === 'gold' ? metal(ctx, x - 90, y0 + 320, x + 90, y0 + 350) : col; tText(ctx, n, x, y0 + 336, 'SFD', 30, f, 'center');
    tText(ctx, p, x, y0 + 376, 'SFTS', 20, 'rgba(255,255,255,0.65)', 'center');
    if (i) { ctx.fillStyle = 'rgba(255,255,255,0.1)'; ctx.fillRect(x0 + 70 + cw * i, y0 + 286, 1, 104); } });
  tText(ctx, 'Wide-body  ·  334 seats  ·  Choose any seat on board', cx, y0 + 440, 'SFTS', 20, 'rgba(255,255,255,0.55)', 'center', 0.02);
  // bottone Book a flight
  const btn = 'Book a flight →', bw = tW(ctx, btn, 'SFTB', 28) + 80, bh = 74, by = y0 + PH - 82, hov = inR(window.__lastI || [0, 0, 0, 0]);
  ctx.shadowColor = 'rgba(0,0,0,0.3)'; ctx.shadowBlur = 16; ctx.shadowOffsetY = 6; ctx.fillStyle = hov ? '#ff8a2e' : '#ff7a12';
  const sc = hov ? 1.03 : 1; ctx.beginPath(); ctx.roundRect(cx - bw * sc / 2, by - bh * sc / 2, bw * sc, bh * sc, bh * sc / 2); ctx.fill(); ctx.shadowColor = 'transparent';
  tText(ctx, btn, cx, by, 'SFTB', 28 * sc, '#ffffff', 'center');
  ctx.restore();
  window.__ibtn = [cx - bw / 2, by - bh / 2, cx + bw / 2, by + bh / 2];
}

// ---------------- giro automatico (?auto=1): rifà il reel Aereo Flight v2 sul 3D vero, stessi posti, stessi tempi, stesso cursore ----------------
// Spazio (o clic) parte, R ricomincia. Tempi e punti copiati da Video/aereo-flight/film.js (ACTS).
const CUR = { on: false, done: null };
const RL = { E: [0.341, 0.4992], P: [0.6139, 0.5007], F: [0.7695, 0.4956], R: [0.8593, 0.4635] };   // classi sulla pianta (come nel reel)
const RSEAT = { E: { '30E': [0.6126, 0.4882], '31B': [0.5913, 0.3879], '31C': [0.5915, 0.4088], '33A': [0.5508, 0.367], '32A': [0.571, 0.367] },
  P: { '14D': [0.5453, 0.4055], '13C': [0.6195, 0.1722], '12E': [0.7013, 0.4896], '12A': [0.6932, 0.0961] } };
const seatPt = (cls, id) => { const s = SEATS[cls].find(x => x[0] === id), uv = s ? [s[1], s[2]] : RSEAT[cls][id]; return toScr(uv[0], uv[1], S.view || V0); };
const bc = (r, dx = 8, dy = 8) => r ? [(r[0] + r[2]) / 2 + dx, (r[1] + r[3]) / 2 + dy] : null;
const TK = () => [[0.8, W * 0.84, H * 0.22], [1.45, () => bc(window.__btn && window.__btn.book)], [1.95, () => bc(window.__btn && window.__btn.book, 14, 10)], [2.45, () => bc(window.__btn && window.__btn.up)]];
// per ogni scena: punti [tempo, x, y] (o [tempo, funzione]), tempo del clic, comparsa/uscita del cursore, spostamento del disegno
const PLAN = {
  intro: { pts: () => [[0.7, W * 0.8, H * 0.9], [1.75, () => bc(window.__ibtn, 20, 10)]], click: 2.05, op: r => ramp(r, 0.7, 1.0) },
  plan: { pts: () => [[0, W * 0.92, H * 0.85], ...[['E', 0.6], ['P', 1.2], ['F', 1.8], ['R', 2.4], ['E', 3.0]].map(([c, t]) => [t, RL[c][0] * W, RL[c][1] * H]), [3.15, RL.E[0] * W, RL.E[1] * H]], click: 3.0, op: r => ramp(r, 0.05, 0.3), off: 3 },
  seatsE: { pts: () => [[0.4, W * 0.84, H * 0.8], ...[['30E', 0.8], ['31B', 1.3], ['31C', 1.8], ['33A', 2.3], ['32A', 2.8]].map(([id, t]) => [t, () => seatPt('E', id)])], click: 3.15, op: r => ramp(r, 0.4, 0.65), off: 3 },
  eco: { pts: TK, click: 2.6, op: r => ramp(r, 0.8, 1.1) },
  seatsP: { pts: () => [[0.3, W * 0.3, H * 0.78], ...[['14D', 0.9], ['13C', 1.45], ['12E', 2.0], ['12A', 2.5]].map(([id, t]) => [t, () => seatPt('P', id)])], click: 3.25, op: r => ramp(r, 0.3, 0.55), off: 4 },
  premT: { pts: TK, click: 2.6, op: r => ramp(r, 0.8, 1.1) },
  first: { pts: TK, click: 2.6, op: r => ramp(r, 0.8, 1.1) },
  res: { pts: () => [[0.55, W * 0.84, H * 0.3], [1.5, () => bc(window.__gbtn)]], click: 1.7, op: r => ss(ramp(r, 0.55, 0.85)) },
  book: { pts: () => [[1.0, W * 0.84, H * 0.22], [2.1, () => bc(window.__btn && (window.__btn.book || window.__btn.up))]], click: 2.3, op: r => ramp(r, 1.0, 1.3) },
};
function rpath(r, pts) {
  const P = pts.map(([t, x, y]) => { if (typeof x === 'function') { const v = x(); return v ? [t, v[0], v[1]] : null; } return [t, x, y]; });
  if (P.some(p => !p)) return null;
  if (r <= P[0][0]) return [P[0][1], P[0][2]];
  for (let i = 1; i < P.length; i++) if (r <= P[i][0]) { const a = P[i - 1], b = P[i], e = ss((r - a[0]) / (b[0] - a[0])); return [a[1] + (b[1] - a[1]) * e, a[2] + (b[2] - a[2]) * e]; }
  const q = P[P.length - 1]; return [q[1], q[2]];
}
function cursorR(x, y, press, op) {   // lo stesso cursore del reel
  if (op <= 0.003) return; const sc = 2.1 * (1 - 0.12 * press);
  ctx.save(); ctx.globalAlpha = op;
  if (press > 0) { ctx.strokeStyle = `rgba(255,255,255,${0.7 * (1 - press)})`; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, 14 + 30 * press, 0, 7); ctx.stroke(); }
  ctx.translate(x, y); ctx.scale(sc, sc); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, 22); ctx.lineTo(6, 16); ctx.lineTo(10, 25); ctx.lineTo(14, 23); ctx.lineTo(10, 15); ctx.lineTo(18, 15); ctx.closePath();
  ctx.shadowColor = 'rgba(0,0,0,0.35)'; ctx.shadowBlur = 4; ctx.shadowOffsetY = 1.5; ctx.fillStyle = '#fff'; ctx.fill(); ctx.shadowColor = 'transparent'; ctx.strokeStyle = '#000'; ctx.lineWidth = 1.4; ctx.stroke(); ctx.restore();
}
function drawCur() {
  cv.style.cursor = 'none';
  const pl = CUR.on && PLAN[S.st]; if (!pl) return;
  const r = now() - S.t0, pos = rpath(r, pl.pts()); if (!pos) return;
  mouse.x = pos[0]; mouse.y = pos[1];
  const d = r - pl.click, press = d < 0 || d > 0.35 ? 0 : Math.sin(Math.PI * d / 0.35), o = pl.off || 0;
  cursorR(pos[0] + o, pos[1] + o, press, pl.op(r));
  if (r >= pl.click && CUR.done !== S.t0) { CUR.done = S.t0; onClick(); }   // un clic per scena, al secondo del reel
}
function autoStart() { stopAll(); chosen = { E: null, P: null }; CUR.done = null; CUR.on = true; go('intro'); }
if (AUTO) {
  addEventListener('keydown', e => {
    if (e.key === 'r' || e.key === 'R') { CUR.on = false; stopAll(); chosen = { E: null, P: null }; go('intro'); return; }
    if (![' ', 'Enter', 'ArrowRight', 'ArrowDown'].includes(e.key) || S.st === 'load') return; e.preventDefault();
    if (!CUR.on || S.st === 'booked') autoStart();
  });
  addEventListener('mousedown', e => { if (e.button === 0) dispatchEvent(new KeyboardEvent('keydown', { key: ' ' })); });
}
