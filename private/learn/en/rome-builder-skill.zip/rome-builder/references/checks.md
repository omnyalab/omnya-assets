# The checks (numbers, not eyes)

| Step | Tool | Pass |
|---|---|---|
| The 3D scene | `blender -b rome.blend --python blender/verifica.py -- check.json` | nothing floating, chariots >= 1.2 m from people and columns, camera >= 0.6 m from walls |
| The camera | `python3 tools/smooth.py preview.mp4` | 9/10 or more for a 3D guide, 8/10 or more for a clip (side-to-side changes, rotation, jerks, sliding sideways while going in) |
| Every photo | `python3 tools/allineamento.py 3d.jpg photo.png` | under 3.2 px = same shape and place; over 5 px the camera or the proportions changed |
| Every clip | `python3 tools/controlla_clip.py clip.mp4 start.png end.png sheet.jpg last.png` | first and last frame under ~6 against the photos; saves the real last frame for the next clip |
| Joins | `python3 tools/fix_join.py frames/ A B` | the speed stays at the cruising speed of the frames before; prints how much sound to cut |

The warm grade: `tools/filtro_film_caldo.py IN OUT` on the photos and `tools/filtro_film_caldo_video.py IN.mp4 OUT.mp4` on the film (curve 0.08, blacks -1%, vibrance +12%, warm highlights R +4% G +1.5% B -6%, vignette 8%, grain 1.2%, light sharpening).

Lessons from our film:
- With the 3D guide inside the arena, Kling copied the 3D mannequins' motion: inside, use image to video with a middle photo instead.
- A photo made from a washed-out EEVEE frame alone changed the framing; editing the approved photo with the new 3D as a second reference kept it.
- Kling slows down at the end of a clip to land on the end photo: fix it in the edit with `fix_join.py`, not with a new clip.
