# The CONFIG block

Everything about one city lives in `window.CITY_CONFIG` at the top of `index.html`, between the `CONFIG` and `END OF CONFIG` comments. The engine below reads it once when the page loads. Places are always `[lat, lon]` in decimal degrees.

## The city

| Field | Type | What it does |
|---|---|---|
| `city` | text | Shown as "Build <city>" in the panel and in the browser tab. Names over 11 characters get a slightly smaller title by themselves. |
| `lang` | text | Page language code (`en`, `it`, `pt`...). |
| `look` | `day` / `night` | How the page opens. `?night=1` in the address does the same for a test. |
| `sun` | `{ azimuth, elevation }` | Degrees. Azimuth is the compass direction of the sun (90 east, 180 south, 225 south-west). Elevation 30-45 gives long, readable shadows; 60+ is flat noon light. Keep it to the side of the main camera direction. |
| `pitchedShare` | 0 to 1 | Share of low buildings (under 25 m) that get a tiled-roof colour from `roofsPitched`. 0 for modern flat-roof cities (Miami, Dubai), 0.3-0.4 for Monaco or Nice, 0.7-0.8 for Lisbon, Rome, Porto, Prague. |
| `trees` | `round` / `cone` / `palm` | Tree shape: broadleaf, cypress/pine, palm. |
| `neonTowers` | number | How many of the tallest buildings over 30 m get a thin neon crown at night (colours from `colors.neon`). 0 = none. 6-10 is right for a skyline; keep 0-4 for an old town. |
| `quality` | `auto` / `high` / `low` | `auto` gives phones smaller shadows, fewer trees and a lower pixel ratio. `?q=low` in the address forces it. |

## Colours (`colors`)

All plain hex strings. Buildings with a colour tagged in OpenStreetMap (`building:colour`, `roof:colour`) keep it, a little calmed down; the others pick from these lists, so give 4-8 close shades per list rather than one colour.

| Field | What it colours |
|---|---|
| `land` | The bare ground before anything is built, and pavements. |
| `sand` | Beaches. |
| `waterDeep`, `waterShallow` | Open water and the lighter band along every shore. |
| `road`, `roadMinor`, `pedestrian` | Main roads, small roads and service lanes, pedestrian streets and squares. |
| `park`, `wood`, `pitch`, `tree` | Grass and gardens, woods and scrub, sports pitches, tree crowns. |
| `walls` | Facades of normal buildings. |
| `roofsPitched`, `roofsFlat` | Tiled roofs (see `pitchedShare`) and flat roofs. |
| `glass` | Glass towers: every building from 55 m, and about half between 36 and 55 m. |
| `windowDay` | Window glass by day. |
| `windowWarm`, `windowCool` | Lit windows at night (mostly warm, one in five cool). |
| `neon` | Up to four colours for the neon crowns. |
| `streetLight` | The orange glow of the streets at night. |

Palettes that work:

- **Miami, beach skyline** (template default): walls `#f1ece2 #ebe1cc #f5f2ea #e2d6bd #ede0c4`, glass `#7fa3b8 #8fb0bf #6f93a8`, water `#1f6f8f` / `#4cc3c4`, `pitchedShare: 0`, `neonTowers: 8`.
- **Lisbon, Porto, southern old towns**: walls `#f1ebe0 #ede3cc #e6d6b4 #f4f1ea #e4dccd #d8cdb4`, roofsPitched `#a9634d #9c5c47 #b2735a`, water `#2a6c84` / `#58a9a6`, `pitchedShare: 0.75`, `neonTowers: 0-3`.
- **Monaco, Riviera**: template walls, water `#1b5f8c` / `#3fb2c0`, `pitchedShare: 0.35`.
- **Northern Europe (Amsterdam, Copenhagen)**: walls `#cfc4b4 #b9a48c #d9d2c6 #a88f78`, roofsPitched `#7a5446 #5d4a42 #8a6a5a`, water `#3c6475` / `#5f8c94`, `pitchedShare: 0.8`.
- **Desert skyline (Dubai, Doha)**: walls `#efe6d6 #e6dac4 #f3eee4`, glass `#7f9fb0 #9bb3c0 #6d8796`, land `#e2d3b6`, sand `#ecdcb8`, water `#1d6f8a` / `#46c0c6`, `trees: 'palm'`.
- **New York, Chicago**: walls `#c9c3b8 #b7aa98 #d8d2c6 #a99c8c`, glass `#7d8fa0 #94a6b4 #6a7d8e`, `neonTowers: 6`.

Never tint the whole city pink or purple: real colours only. The coloured veil belongs to the panel.

## The district (`district`)

| Field | What it does |
|---|---|
| `name` | Only for your own reference; the visible name is the button label. |
| `lat`, `lon` | Centre of the district. `null` = the tallest cluster that `fetch_city.py` found (printed as "district (tallest cluster)"). |
| `radius` | Metres around the centre. 350-600 is typical. |
| `minHeight` | Only buildings at least this tall inside the radius belong to the district. 25 for a skyline (the towers rise, the low city around them is already there). 0 for an old town without towers: every building inside rises. If fewer than 8 buildings qualify, the page uses 0 by itself. |

Run `city.info()` in the console: `inDistrict` is how many buildings rise with the district button. Aim for roughly 80 to 1,000.

## The buttons (`buttons`)

Seven entries in panel order. Each one is `{ label, action, shot }`.

| `action` | What the button does |
|---|---|
| `streets` | Roads draw themselves outward from the focus of the shot, with a light running along the front. |
| `city` | Every building outside the district rises (back-ease, a small overshoot), starting near the focus. |
| `nature` | Parks, woods and pitches appear and the trees grow. |
| `district` | The district's buildings rise, tallest last. |
| `goto` | Only the camera moves. |
| `full` | Only the camera moves, high and wide, with an extra turn (`spin`). |

Pressing a later button first also builds the skipped pieces. Pressing a finished button builds that piece again (handy for retakes). Space presses the next button, R starts over.

Labels: keep the Build Miami wording. Keep "Go to:" labels under about 26 characters ("Go to: São Jorge Castle", not the full official name).

## Shots

```js
{ look: [38.7077, -9.1366], heading: 330, dist: 260, height: 110, fov: 46, spin: 0 }
```

| Field | What it does |
|---|---|
| `look` | The point the camera looks at: `[lat, lon]`, or `'center'`, `'district'`, `'park'` (the biggest park near the middle). |
| `heading` | Compass direction the camera faces: 0 north, 90 east, 180 south, 270 west. The camera stands on the opposite side of `look`. |
| `dist` | Horizontal distance from `look` in metres. |
| `height` | Camera height in metres. `height` about equal to `dist` = 45 degrees down; `height` = `dist` / 2.5 = a low, drone-like angle. |
| `fov` | Vertical field of view in degrees, 36-50. |
| `spin` | Extra degrees the camera turns during the flight to this shot (for "around" moves). |

`start` is a shot too (null = straight down over the whole area with north up). After every flight the camera keeps turning slowly (`flight.drift` degrees per second); drag or zoom pauses it for a moment.

The default shots when `shot` is null (R = half the side of the area): streets high over the centre, city at about half height, nature over the biggest central park, district close to the tallest towers, goto 230 m from the place at 95 m, full city wide at about 0.6 R up. Defaults are a starting point: always look at them and adjust.

Flights: `flight.seconds` (default 4.6) is the length of every flight and of every piece's animation. Between two far places the camera arcs up so it does not skim the roofs.

Fastest way to make a shot: open the page, drag and zoom to the view you want, press **K**. The shot is printed in the console and copied to the clipboard.

## Auto mode (`auto`)

`?auto=1` hides the mouse and plays the whole sequence with a fake cursor and click sounds, for screen recordings. `auto.gap` = seconds between clicks (keep it at least `flight.seconds` + 1). `auto.nightAfter` = index of the button after which the cursor clicks Night (0 = after the first, -1 = never).

## The panel (`panel`)

`day` and `night` are three colours each for the veil inside the glass (top-left, middle, bottom-right). The default is the Build Miami sunset (violet, pink, peach by day; deeper violet and magenta at night). The veil only colours the panel and the button fills, never the city.

## Address bar options and keys

| Option / key | What it does |
|---|---|
| `?step=n` | Opens with buttons 1..n done and the camera on button n's view. `?step=0` is the start. |
| `?night=1` | Opens at night. |
| `?auto=1` | Self-playing version with the fake cursor. |
| `?clean=1` | Only the 3D: no panel, cursor or credit (for frames used as references). |
| `?q=low` | Light version. |
| Space / R / N | Next button / start over / day-night. |
| H / C / S / F | Hide panel / hide fake cursor / sound on-off / full screen. |
| P | Save a PNG of the 3D frame only. |
| K | Print the current camera as a shot. |

Console: `city.info()`, `city.jump(n)`, `city.press(i)`, `city.night(true)`, `city.shot()`, `city.state()`.
