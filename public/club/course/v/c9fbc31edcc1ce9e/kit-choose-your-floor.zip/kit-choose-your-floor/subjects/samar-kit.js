// KIT · SAMAR: the builder of the SAMAR tower (the example of the Choose Your Floor kit). subjects/samar.js gives the numbers, this file turns them into 3D:
// a "stadium" tower (straight sides + round ends), white balcony bands on every floor, glass set back, flat roof that sticks out, low lit podium,
// the marina with the yachts, palms along the water, the sea, and the real Dubai skyline across the water (assets/data/dubai-skyline.json).
// Every measure is an ESTIMATE (SAMAR is a concept with no published measures): see references/samar/MEASURES.txt.
// Silhouette check: tools/silhouette.py (3D mask ?maschera=1&clean=1 against references/samar/mask-tower.png). The apartment on floor 15 is in samar-casa.js.
// The camera of the main photo is in subjects/samar.js (riprese.mondo). Code comments below are in Italian (Omnya Lab's engine): ask Claude if you need one explained.
// Uses the engine's exports only: a new tower = a new subject file, the engine stays the same.
import * as THREE from 'three';
import { rng, canvasTex } from '../engine/kit/forme.js';
import { skylineDubai } from '../engine/kit/dubai-skyline.js';
import { palme } from '../engine/kit/quartiere-verde.js';
import { fermata, welcomeSchermo } from '../engine/fermate-torre.js';
import { casaSamar, controllaCasa } from './samar-casa.js';

const Q = new URLSearchParams(location.search);
const rad = d => d * Math.PI / 180;

// ---------- pianta a stadio: due cerchi di raggio R a distanza L lungo l'asse locale X (testata 1 a x=0, testata 2 a x=L), z locale verso la strada ----------
export function stadio(L, R, n = 28) {
  const pts = [], add = (x, z, nx, nz) => pts.push({ p: [x, z], n: [nx, nz] });
  for (let i = 0; i <= n; i++) { const t = Math.PI / 2 + Math.PI * i / n; add(Math.cos(t) * R, Math.sin(t) * R, Math.cos(t), Math.sin(t)); }   // testata 1 (verso -X)
  const nl = Math.max(1, Math.round(L / 1.5)); for (let i = 1; i < nl; i++) add(L * i / nl, -R, 0, -1);
  for (let i = 0; i <= n; i++) { const t = -Math.PI / 2 + Math.PI * i / n; add(L + Math.cos(t) * R, Math.sin(t) * R, Math.cos(t), Math.sin(t)); }   // testata 2 (verso +X)
  for (let i = nl - 1; i >= 1; i--) add(L * i / nl, R, 0, 1);
  pts.reverse();   // verso antiorario visto dall'alto: le facce delle pareti guardano fuori
  let s = 0; pts.forEach((q, i) => { if (i) s += Math.hypot(q.p[0] - pts[i - 1].p[0], q.p[1] - pts[i - 1].p[1]); q.s = s; });
  const tot = s + Math.hypot(pts[0].p[0] - pts[pts.length - 1].p[0], pts[0].p[1] - pts[pts.length - 1].p[1]);
  return { pts, tot, L, R };
}
const offs = (P, off) => P.pts.map(q => [q.p[0] + q.n[0] * off, q.p[1] + q.n[1] * off]);
// pareti verticali lungo la pianta (chiusa), uv: u = metri / uS, v da 0 a 1
export function prisma(P, off, y0, y1, uS = 1, tieni = null) {
  const pos = [], uv = [], idx = [], Q2 = [...P.pts, { ...P.pts[0], s: P.tot }];
  Q2.forEach((q, i) => { const x = q.p[0] + q.n[0] * off, z = q.p[1] + q.n[1] * off; pos.push(x, y0, z, x, y1, z); uv.push(q.s / uS, 0, q.s / uS, 1);
    if (i > 0 && (!tieni || tieni(q, Q2[i - 1]))) idx.push((i - 1) * 2, i * 2, (i - 1) * 2 + 1, (i - 1) * 2 + 1, i * 2, i * 2 + 1); });
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx); g.computeVertexNormals(); return g;
}
export function forma(P, off) { const sh = new THREE.Shape(); offs(P, off).forEach(([x, z], i) => i ? sh.lineTo(x, -z) : sh.moveTo(x, -z)); sh.closePath(); return sh; }
export function lastra(P, off, y, spess, bevel = 0) { const g = new THREE.ExtrudeGeometry(forma(P, off), { depth: spess, bevelEnabled: bevel > 0, bevelSize: bevel, bevelThickness: bevel, bevelSegments: 2, curveSegments: 4 }); g.rotateX(-Math.PI / 2); g.translate(0, y, 0); return g; }

// ---------- vetro dei piani (riflette il cielo, dentro luce calda a chiazze, tende chiare, montanti sottili ogni 1,5 m) ----------
function texVetro(seme) {
  const R = rng(seme), W = 2048, H = 256, nM = 32, celle = []; for (let i = 0; i < nM; i++) celle.push({ k: R(), tenda: R(), lamp: R(), x: R(), mob: R() });
  const dis = luce => c => {
    if (luce) { c.fillStyle = '#000'; c.fillRect(0, 0, W, H); }
    else { const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#79726a'); g.addColorStop(0.4, '#5f646a'); g.addColorStop(1, '#353a40'); c.fillStyle = g; c.fillRect(0, 0, W, H); }
    for (let i = 0; i < nM; i++) { const q = celle[i], x = i * W / nM, w = W / nM;
      if (q.k > 0.35) { const gi = c.createLinearGradient(0, 16, 0, H); const a = luce ? 0.5 : 0.45; gi.addColorStop(0, `rgba(255,214,160,${a * q.k})`); gi.addColorStop(0.5, `rgba(240,190,140,${a * 0.5 * q.k})`); gi.addColorStop(1, 'rgba(200,150,110,0)'); c.fillStyle = gi; c.fillRect(x, 16, w, H - 16); }
      if (q.tenda > 0.5) for (let f = 0; f < w * 0.7; f += 5) { c.fillStyle = luce ? `rgba(255,226,190,${0.08 + 0.06 * Math.sin(f * 0.7)})` : `rgba(236,228,214,${0.28 + 0.1 * Math.sin(f * 0.7)})`; c.fillRect(x + (q.x > 0.5 ? w * 0.3 : 0) + f, 18, 3, H - 30); }
      if (q.lamp > 0.6) { const lx = x + w * (0.2 + q.x * 0.6), ly = H * 0.45, r = 20 + q.lamp * 18, gl = c.createRadialGradient(lx, ly, 0, lx, ly, r); gl.addColorStop(0, `rgba(255,230,180,${luce ? 0.9 : 0.7})`); gl.addColorStop(1, 'rgba(255,190,130,0)'); c.fillStyle = gl; c.fillRect(lx - r, ly - r, 2 * r, 2 * r); }
      if (!luce && q.mob > 0.4) { c.fillStyle = 'rgba(28,26,26,0.5)'; c.fillRect(x + w * 0.15 + q.x * w * 0.3, H * 0.68, w * (0.25 + q.mob * 0.3), H * 0.2); }
      c.fillStyle = luce ? '#000' : 'rgba(26,26,28,0.9)'; c.fillRect(x, 0, 3, H); }
    c.fillStyle = luce ? 'rgba(255,236,206,0.9)' : '#f6ead8'; c.fillRect(0, 0, W, 6);   // la riga del soffitto acceso sotto il solaio
    c.fillStyle = luce ? '#000' : 'rgba(20,18,16,0.8)'; c.fillRect(0, H - 5, W, 5);
  };
  const map = canvasTex(W, H, dis(false), { aniso: 16 }), lu = canvasTex(W, H, dis(true), { aniso: 16 }); map.wrapS = lu.wrapS = THREE.RepeatWrapping; return { map, luce: lu, uS: 48 };
}
// verde che cola dai vasi del podio (R01, R04): foglie su trasparente, lunghezze diverse
function texCascata(seme = 5) {
  const R = rng(seme);
  return canvasTex(1024, 256, (c, w, h) => { c.clearRect(0, 0, w, h);
    let ciuffo = 0; for (let x = 0; x < w; x += 3) { if (x % 60 === 0) ciuffo = R() < 0.55 ? 1 : 0; if (!ciuffo) continue; const L = h * (0.2 + Math.pow(R(), 1.4) * 0.8); for (let y = 0; y < L; y += 3) { const v = R(); c.fillStyle = v < 0.35 ? '#2f4220' : v < 0.75 ? '#4d6330' : '#7d8a44';
      c.beginPath(); c.ellipse(x + Math.sin(y * 0.05 + x) * 3, y, 3.2 + R() * 2, 1.8 + R(), R() * 3, 0, 7); c.fill(); } }
  }, { aniso: 8 });
}

// ---------- una torre: solai con balconi tondi, vetro arretrato, parapetti di vetro col corrimano bianco, setti fra i balconi, corona ----------
function torre(T, C, M0, speciale) {
  const G = new THREE.Group(); G.name = 'torre' + T.id; G.position.set(T.x, 0, T.z); G.rotation.y = -rad(T.a);
  const P = stadio(T.L, T.R), Pg = stadio(T.L, T.R - T.balcone), ys = [];
  for (let k = 0; k < T.piani; k++) ys.push(T.y0 + T.passo * k);
  const top = T.y0 + T.passo * T.piani;
  const inst = (geo, mat, lista, ombra = true) => { const m = new THREE.InstancedMesh(geo, mat, lista.length), d = new THREE.Object3D(); lista.forEach((y, i) => { d.position.set(0, y, 0); d.updateMatrix(); m.setMatrixAt(i, d.matrix); }); m.castShadow = ombra; m.receiveShadow = true; G.add(m); return m; };
  // solaio + balcone: bordo bianco tondo, sotto il legno caldo acceso (le pance d'oro della foto R01)
  const solaio = lastra(P, 0, -T.solaio, T.solaio, 0.06);
  inst(solaio, [M0.sotto, M0.bianco], [...ys, top]);
  // vetro: tre texture a rotazione; il piano speciale (casa vera) ha il vetro vero trasparente
  const altV = T.passo - T.solaio, vetro = prisma(Pg, 0, 0, altV, M0.vetri[0].uS);
  for (let j = 0; j < 3; j++) inst(vetro, M0.vetroMat[j], ys.filter((y, k) => k % 3 === j && !(speciale && Math.abs(y - speciale.F) < 0.05)), false);
  // parapetti di vetro chiaro e corrimano bianco
  inst(prisma(P, -0.12, 0, 1.08, 1), M0.parapetto, ys, false);
  inst(prisma(P, -0.1, 1.06, 1.13, 1), M0.bianco, ys);
  // setti bianchi fra i balconi sui lati lunghi (ogni ~7,5 m), come nella foto
  if (T.setti !== false) { const ns = Math.max(1, Math.round(T.L / 7.5)), geo = new THREE.BoxGeometry(0.22, altV, T.balcone - 0.15), lista = [], d = new THREE.Object3D();
    for (const y of ys) for (let i = 1; i < ns; i++) for (const s of [-1, 1]) { const x = T.L * i / ns; if (speciale && Math.abs(y - speciale.F) < 0.05 && s > 0) continue; d.position.set(x, y + altV / 2, s * (T.R - T.balcone / 2 - 0.05)); d.updateMatrix(); lista.push(d.matrix.clone()); }
    const m = new THREE.InstancedMesh(geo, M0.bianco, lista.length); lista.forEach((mm, i) => m.setMatrixAt(i, mm)); m.castShadow = true; G.add(m); }
  // corona: lastra più larga e parapetto pieno bianco, sopra il volume tecnico arretrato
  G.add(new THREE.Mesh(lastra(P, 0.25, top, 0.5, 0.12), M0.bianco));
  if (T.tetto) {   /* foto madre SAMAR: in cima un piano tutto vetro arretrato e il tetto piatto sottile a sbalzo */
    G.add(new THREE.Mesh(prisma(Pg, 0, top + 0.5, top + T.corona, M0.vetri[0].uS), M0.vetroMat[0]));
    const tt = new THREE.Mesh(lastra(stadio(T.L, T.R + T.tetto), 0, top + T.corona, 0.7, 0.1), M0.bianco); tt.castShadow = true; G.add(tt);
  } else {
  { const m = new THREE.Mesh(prisma(P, 0.15, top + 0.5, top + T.corona, 1), M0.bianco); m.castShadow = true; G.add(m); }
  G.add(new THREE.Mesh(lastra(stadio(T.L * 0.6, T.R - 3.5), 0, top + 0.5, 3.2), M0.tecnico).translateX(T.L * 0.2)); }
  // base: atrio vetrato fra il podio e il primo piano (doppia altezza, acceso)
  /* base: il nucleo sale fino al primo piano solo sotto la parte lontana dalla fessura (R01: sotto la testata tonda c'è il vuoto con la pancia scura) */
  { const fb = T.base ?? 0, Pb = stadio(T.L * (1 - fb), T.R - T.balcone - (fb ? 1.2 : -0.4)), m = new THREE.Mesh(prisma(Pb, 0, 0, T.y0 - T.solaio, 24), M0.atrio); m.position.x = T.L * fb; G.add(m); }
  // pick (invisibile) e fasce della scelta (luce ambra come SAMAR, alta 1 e scalata sul piano)
  const pk = new THREE.Mesh(prisma(P, 0.1, T.y0, top, 1), new THREE.MeshBasicMaterial({ visible: false, side: THREE.DoubleSide })); pk.userData.torre = T.id; G.add(pk);
  const fascia = new THREE.Mesh(prisma(P, 0.25, 0, 1, 1), M0.fascia.clone()); fascia.visible = false; fascia.renderOrder = 5; const fasciaG = new THREE.Group(); fasciaG.add(fascia); G.add(fasciaG);   /* kit: the lit floor of the real version (?reale=1) is rendered from this group (engine/reale-torre.js) */
  const alone = new THREE.Mesh(prisma(P, 0.7, -0.6, 1.6, 1), M0.alone.clone()); alone.visible = false; alone.renderOrder = 6; G.add(alone);
  return { G, P, Pg, ys, top, pk, fascia, fasciaG, alone };
}

// ---------- podio: piani curvi di vetro caldo, vasi lungo il bordo e verde che cola (R01, R04) ----------
function podio(D, C, M0) {
  const G = new THREE.Group(); G.name = 'podio' + D.id; G.position.set(D.x, 0, D.z); G.rotation.y = -rad(D.a);
  const P = stadio(D.L, D.R), R0 = rng(D.seme || 3);
  const sk = k => Math.max(0, k - (D.g0 ?? 99)) * (D.gradino || 0), Pk = k => sk(k) ? stadio(D.L - sk(k), D.R) : P;   /* terrazze che arretrano dalla fessura (R01) */
  for (let k = 0; k < D.livelli; k++) { const y = k * D.passo, verde = !D.bianco && (k % 2 === 1 || k === D.livelli - 1 || sk(k + 1) > sk(k)), P = Pk(k), gk = new THREE.Group(); gk.position.x = sk(k); G.add(gk);
    gk.add(new THREE.Mesh(prisma(P, -0.45, y, y + D.passo - 0.35, 30), M0.vetroPodio));   // vetrate curve quasi a filo (R01: grandi vetri coi montanti bianchi)
    const s = new THREE.Mesh(lastra(P, 0, y + D.passo - 0.35, 0.35, 0.04), [M0.sottoPodio, M0.bianco]); s.castShadow = s.receiveShadow = true; gk.add(s);   // solaio sottile col bordo bianco
    if (!verde) continue;
    gk.add(new THREE.Mesh(prisma(P, -0.2, y + D.passo, y + D.passo + 0.55, 1), M0.bianco));   // fioriera bassa lungo il bordo
    const ca = new THREE.Mesh(prisma(P, 0.1, y + D.passo + 0.5 - 2.2, y + D.passo + 0.5, 11), M0.cascata); ca.castShadow = true; gk.add(ca);   // verde che cola a ciuffi
  }
  const top = D.livelli * D.passo; G.add(new THREE.Mesh(lastra(Pk(D.livelli - 1), -0.6, top, 0.12), M0.tettoVerde).translateX(sk(D.livelli - 1)));
  { const geo = new THREE.IcosahedronGeometry(0.5, 1), d = new THREE.Object3D(), lista = [];
    for (let k = 1; k < D.livelli; k += 2) { const P = Pk(k); for (let s = 0; s < P.tot; s += 2.2) { if (R0() < 0.45) continue; const q = P.pts.reduce((a, b) => Math.abs(b.s - s) < Math.abs(a.s - s) ? b : a); d.position.set(sk(k) + q.p[0] - q.n[0] * 0.3, (k + 1) * D.passo + 0.7, q.p[1] - q.n[1] * 0.3); const sc = 0.6 + R0() * 0.7; d.scale.set(sc * 1.4, sc, sc * 1.4); d.rotation.set(R0(), R0() * 6, 0); d.updateMatrix(); lista.push(d.matrix.clone()); } }
    const m = new THREE.InstancedMesh(geo, M0.cespuglio, lista.length); lista.forEach((mm, i) => m.setMatrixAt(i, mm)); m.castShadow = true; G.add(m); }
  return G;
}

// ---------- mare, marina, riva con le palme, città bassa dietro la strada, nuvole d'oro ----------
function intorno(S, C, M0) {
  const G = new THREE.Group(), I = S.intorno, R = rng(19); G.name = 'intorno';
  const pia = (x0, x1, z0, z1, y, mat) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(x1 - x0, z1 - z0), mat); m.rotation.x = -Math.PI / 2; m.position.set((x0 + x1) / 2, y, (z0 + z1) / 2); m.receiveShadow = true; G.add(m); return m; };
  pia(-12000, 12000, -12000, 12000, -0.4, M0.mare);
  pia(-3000, 3000, I.riva, 3000, 0, M0.terra);                       // terra (dalla riva verso la camera e oltre)
  pia(-3000, 3000, I.riva - 16, I.riva, -0.15, M0.sabbia);            // spiaggia
  pia(I.marina[0], I.marina[1], I.marina[2], I.marina[3], 0.03, M0.mare);   // bacino della marina
  pia(-60, 140, -6, 24, 0.04, M0.piazza);                             // piazza e strada fra le torri (dove sta la camera)
  // pontili e yacht della marina (bianchi, scafo affilato, lunghi 18-34 m: STIMA da marina tipo Dubai Harbour)
  { const [x0, x1, z0, z1] = I.marina; for (let x = x0 + 25; x < x1 - 10; x += 34) { const p = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.5, z1 - z0 - 20), M0.pontile); p.position.set(x, 0.3, (z0 + z1) / 2 - 6); G.add(p);
      for (let z = z0 + 8; z < z1 - 22; z += 11) for (const s of [-1, 1]) { if (R() < 0.3) continue; const y = yacht(16 + R() * 14, M0); y.position.set(x + s * 8.5, 0.05, z); y.rotation.y = s > 0 ? Math.PI / 2 : -Math.PI / 2; G.add(y); } } }
  // palme lungo la passeggiata e intorno alla piazza
  const lp = []; for (let x = -900; x < 900; x += 14) lp.push([x + R() * 4, I.riva + 6 + R() * 3, 9 + R() * 4, 0.9 + R() * 0.3]);
  for (const [x, z, h, s] of I.palme) lp.push([x, z, h, s]);
  G.add(palme(lp, { seme: 9 }));
  // città bassa sul lato terra (palazzine 4-12 piani nella foschia), e qualche torre lontana lungo la riva
  if (I.citta !== false) { const geo = new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0), d = new THREE.Object3D(), lista = [];
    for (let i = 0; i < 700; i++) { const x = (R() - 0.5) * 4000, z = 140 + Math.pow(R(), 0.8) * 2600; if (Math.abs(x) < 160 && z < 260) continue; d.position.set(x, 0, z); d.scale.set(18 + R() * 30, 14 + Math.pow(R(), 2) * 38, 18 + R() * 30); d.rotation.y = R() * 0.3; d.updateMatrix(); lista.push(d.matrix.clone()); }
    for (let i = 0; i < 70; i++) { const s = R() < 0.5 ? -1 : 1, x = s * (260 + R() * 2600), z = I.riva + 40 + R() * 500; d.position.set(x, 0, z); d.scale.set(22 + R() * 16, 60 + R() * 140, 22 + R() * 16); d.rotation.y = R(); d.updateMatrix(); lista.push(d.matrix.clone()); }
    const m = new THREE.InstancedMesh(geo, M0.citta, lista.length); lista.forEach((mm, i) => m.setMatrixAt(i, mm)); m.receiveShadow = true; G.add(m); }
  // nuvole d'oro (R01: cumuli alti accesi dal sole basso a sinistra): una cupola trasparente dipinta (una carta sola darebbe rettangoli grigi con l'occlusione GTAO)
  { const cu = new THREE.Mesh(new THREE.SphereGeometry(9000, 64, 32), new THREE.MeshBasicMaterial({ map: texCielo(I.nuvole), transparent: true, depthWrite: false, fog: false, side: THREE.BackSide }));
    cu.renderOrder = -0.5; cu.frustumCulled = false; cu.name = 'nuvole'; cu.userData.nuvola = true; G.add(cu); G.userData.nuvole = cu; }
  return G;
}
/* nuvole dipinte in equirettangolare: x = (270° - az) / 360°, y = (90° - alzo) / 180° (mappa della SphereGeometry di three) */
function texCielo(lista) {
  const W = 4096, H = 2048;
  return canvasTex(W, H, (c, w, h) => { c.clearRect(0, 0, w, h);
    for (const [az, el, , larg, seme] of lista) { const R = rng(7 + seme * 13 + Math.round(az)), x0 = (((270 - az) % 360) + 360) % 360 / 360 * w, y0 = (90 - el) / 180 * h, k = 1 / Math.max(0.25, Math.cos(el * Math.PI / 180));
      const ang = larg / 9000 * (el < 12 ? 0.5 : 1), rx = ang / (2 * Math.PI) * w * k * 0.5, ry = ang / Math.PI * h * 0.28, bolle = [];
      for (let i = 0; i < 60; i++) { const a = R(), x = x0 + (a - 0.5) * 2 * rx * 0.85, top = Math.sin(a * Math.PI), y = y0 + ry * (0.5 - top * (0.6 + R() * 0.5)) + (R() - 0.5) * ry * 0.3, r = ry * (0.25 + 0.5 * top * R()) + 6; bolle.push([x, y, r]); }
      const g2 = c.createLinearGradient(x0 - rx, y0 + ry, x0 + rx * 0.4, y0 - ry);
      for (const [x, y, r] of bolle) for (const dx of [-w, 0, w]) { const g = c.createRadialGradient(x + dx, y, 0, x + dx, y, r); g.addColorStop(0, 'rgba(226,224,226,0.6)'); g.addColorStop(0.55, 'rgba(214,212,216,0.38)'); g.addColorStop(1, 'rgba(206,206,212,0)'); c.save(); c.translate(x + dx, y); c.scale(k * 0.8 > 1 ? k * 0.8 : 1, 1); c.translate(-(x + dx), -y); c.fillStyle = g; c.fillRect(x + dx - r, y - r, 2 * r, 2 * r); c.restore(); }
    }
    // bordi accesi d'oro verso il sole (basso a sinistra, az ~252 → x ≈ 5% della larghezza): si tinge tutto quello che c'è, più forte in basso
    c.globalCompositeOperation = 'source-atop'; const g = c.createLinearGradient(0, h * 0.5, 0, h * 0.15); g.addColorStop(0, 'rgba(255,206,140,0.85)'); g.addColorStop(0.6, 'rgba(255,226,186,0.35)'); g.addColorStop(1, 'rgba(255,240,225,0.05)'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    c.globalCompositeOperation = 'source-over';
  }, { aniso: 4 });
}
function yacht(L, M0) {
  const g = new THREE.Group(), sh = new THREE.Shape(); sh.moveTo(-L / 2, 0); sh.lineTo(L * 0.3, 0); sh.quadraticCurveTo(L / 2, 0.2, L / 2 + 0.6, 1.6); sh.lineTo(-L / 2, 1.6); sh.closePath();
  const sc = new THREE.ExtrudeGeometry(sh, { depth: L * 0.26, bevelEnabled: false }); sc.translate(0, 0, -L * 0.13); g.add(new THREE.Mesh(sc, M0.scafo));
  const c = new THREE.Mesh(new THREE.BoxGeometry(L * 0.45, 1.2, L * 0.2), M0.scafo); c.position.set(-L * 0.08, 2.2, 0); g.add(c);
  const v = new THREE.Mesh(new THREE.BoxGeometry(L * 0.4, 0.5, L * 0.205), M0.vetroScuro); v.position.set(-L * 0.06, 2.3, 0); g.add(v);
  return g;
}

// ---------- materiali ----------
function materiali(C) {
  const std = (c, r, m = 0, e = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...e });
  const vetri = [texVetro(3), texVetro(11), texVetro(23)];
  const vetroMat = vetri.map(t => { const m = new THREE.MeshPhysicalMaterial({ color: '#ffffff', map: t.map, roughness: 0.04, metalness: 0, emissiveMap: t.luce, emissive: new THREE.Color('#ffffff'), emissiveIntensity: 0.65, envMapIntensity: 1.7, clearcoat: 1, clearcoatRoughness: 0.03, ior: 1.52 }); m.userData = { notte: 1.1, minimo: 0.55 }; return m; });
  const sotto = std(C.sotto, 0.6, 0, { emissive: new THREE.Color('#ffc98a'), emissiveIntensity: 0.14 }); sotto.userData = { notte: 0.9, minimo: 0.14 };
  const sottoPodio = std('#cfc6bb', 0.7, 0, { emissive: new THREE.Color('#ffd4a0'), emissiveIntensity: 0.12 });
  const casc = texCascata(5); casc.wrapS = THREE.RepeatWrapping;
  const vp = canvasTex(1024, 256, (c, w, h) => { const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#a7a9aa'); g.addColorStop(0.5, '#6d6c6b'); g.addColorStop(1, '#383a3d'); c.fillStyle = g; c.fillRect(0, 0, w, h); const r = rng(31);
    for (let i = 0; i < 24; i++) { c.fillStyle = `rgba(40,30,26,${0.2 + r() * 0.3})`; c.fillRect(r() * w, h * 0.6, 20 + r() * 50, h * 0.3); } for (let x = 0; x < w; x += 48) { c.fillStyle = '#f1ede6'; c.fillRect(x, 0, 5, h); } c.fillStyle = '#f1ede6'; c.fillRect(0, 0, w, 6); });
  vp.wrapS = THREE.RepeatWrapping;
  const vetroPodio = new THREE.MeshPhysicalMaterial({ color: '#ffffff', map: vp, emissiveMap: vp, emissive: new THREE.Color('#ffffff'), emissiveIntensity: 0.22, roughness: 0.03, clearcoat: 1, envMapIntensity: 1.8 }); vetroPodio.userData = { notte: 1.0, minimo: 0.22 };
  const fasciaTex = canvasTex(64, 256, (c, w, h) => { const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, 'rgba(255,195,94,0)'); g.addColorStop(0.2, 'rgba(255,195,94,0.95)'); g.addColorStop(0.8, 'rgba(255,195,94,0.95)'); g.addColorStop(1, 'rgba(255,195,94,0)'); c.fillStyle = g; c.fillRect(0, 0, w, h); });
  const aloneTex = canvasTex(64, 256, (c, w, h) => { const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, 'rgba(255,160,60,0)'); g.addColorStop(0.5, 'rgba(255,170,70,0.55)'); g.addColorStop(1, 'rgba(255,160,60,0)'); c.fillStyle = g; c.fillRect(0, 0, w, h); });
  const acqua = canvasTex(512, 512, (c, w, h) => { c.fillStyle = 'rgb(128,128,255)'; c.fillRect(0, 0, w, h); const r = rng(4); for (let i = 0; i < 2200; i++) { const x = r() * w, y = r() * h, l = 6 + r() * 26; c.strokeStyle = `rgba(${110 + r() * 40},${100 + r() * 60},255,0.5)`; c.lineWidth = 1 + r() * 2; c.beginPath(); c.moveTo(x, y); c.lineTo(x + l, y + (r() - 0.5) * 3); c.stroke(); } }, { srgb: false, repeat: [600, 600] });
  return {
    vetri, vetroMat, sotto, sottoPodio, bianco: std(C.bianco, 0.36, 0.05), tecnico: std('#d9d4cc', 0.7),
    parapetto: new THREE.MeshPhysicalMaterial({ color: '#dfe7ea', roughness: 0.03, transparent: true, opacity: 0.22, depthWrite: false, side: THREE.DoubleSide, envMapIntensity: 1.6, clearcoat: 1 }),
    atrio: std('#f6dcb6', 0.3, 0, { emissive: new THREE.Color('#ffcf96'), emissiveIntensity: 0.55 }),
    vetroPodio, cascata: new THREE.MeshStandardMaterial({ map: casc, alphaTest: 0.45, side: THREE.DoubleSide, roughness: 0.85, color: '#d9dcc0' }), cespuglio: std('#55693a', 0.9, 0, { flatShading: true }), tettoVerde: std('#5c7a3a', 0.95),
    fascia: new THREE.MeshBasicMaterial({ map: fasciaTex, transparent: true, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, toneMapped: false, color: new THREE.Color(1.6, 1.2, 0.7) }),
    alone: new THREE.MeshBasicMaterial({ map: aloneTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, toneMapped: false, opacity: 0.55 }),
    mare: new THREE.MeshPhysicalMaterial({ color: C.mare, roughness: 0.07, metalness: 0, normalMap: acqua, normalScale: new THREE.Vector2(0.35, 0.35), envMapIntensity: 1.25, clearcoat: 0.6 }),
    terra: std(C.terra, 0.95), sabbia: std(C.sabbia, 0.95), piazza: std(C.piazza, 0.8), pontile: std('#b8a58a', 0.8),
    scafo: std('#f4f2ee', 0.25, 0.1), vetroScuro: std('#1c2228', 0.1, 0.4), citta: std('#d6cbbb', 0.85),
  };
}

// ---------- costruzione e adattatore dei livelli per il motore ----------
export function costruisciSamar(S) {
  const C = S.modello.colori, G = new THREE.Group(), M0 = materiali(C), X = S.torri;
  const sp = S.casa.speciale, TT = {};
  for (const T of X.lista) if (!T.via) TT[T.id] = torre(T, C, M0, T.id === sp.torre ? sp : null);
  for (const t of Object.values(TT)) G.add(t.G);
  const POD = new THREE.Group(); POD.name = 'podi'; for (const D of X.podi) if (!D.via) POD.add(podio(D, C, M0)); G.add(POD);
  const fuori = intorno(S, C, M0); G.add(fuori);
  const casa = casaSamar(S, TT[sp.torre]); G.add(casa);
  window.__casa = { g: casa, controlla: () => controllaCasa(casa, sp.F + 0.07, 3.0) };   /* controllo 06-4 del corso */
  if (Q.get('plan') === '1') { for (const t of Object.values(TT)) t.G.visible = false; POD.visible = false; fuori.visible = false; }   /* pianta 06-5: solo l'appartamento */
  if (Q.get('senzaTorre')) { for (const t of Object.values(TT)) t.G.visible = false; POD.visible = false; casa.visible = false; }   /* ?senzaTorre=1: per la differenza del giudice */
  /* the real Dubai skyline across the water (assets/data/dubai-skyline.json: CTBUH heights, OSM positions), turned so the Burj sits at S.skyline.burj. No S.skyline = no skyline */
  const pronta = !S.skyline ? Promise.resolve() : fetch(new URL('../assets/data/dubai-skyline.json', import.meta.url)).then(r => r.json()).then(J => {
    const dd = J.citta.find(c => c.id === 'dubai'); if (!dd) return; const sk = skylineDubai(S.skyline.O, dd.torri, { bassi: 1400 }), b = sk.userData.burj; if (!b) return;
    const w = new THREE.Group(); w.add(sk); w.rotation.y = Math.atan2(S.skyline.burj[0], S.skyline.burj[1]) - Math.atan2(b.x, b.z);
    const sc = Math.hypot(...S.skyline.burj) / Math.hypot(b.x, b.z); w.scale.set(sc, 1, sc); w.name = 'skyline'; fuori.add(w);
    w.updateMatrixWorld(true); const M4 = new THREE.Matrix4(), v = new THREE.Vector3(), zero = new THREE.Matrix4().makeScale(0, 0, 0);
    sk.traverse(o => { if (!o.isInstancedMesh) return; for (let i = 0; i < o.count; i++) { o.getMatrixAt(i, M4); v.setFromMatrixPosition(M4).applyMatrix4(o.matrixWorld); if (v.z > S.skyline.zMax) o.setMatrixAt(i, zero); } o.instanceMatrix.needsUpdate = true; });
    sk.traverse(o => { if (o.material && o.material.name === 'torri') o.material.emissiveIntensity = 0.45; });
    if (MASK) maschera();
  }).catch(e => console.warn('skyline', e));

  /* ?maschera=1 (giudice delle sagome): torri, podi e palme vicine in grigio pieno, tutto il resto nero (anche il cielo) */
  const MASK = Q.get('maschera') === '1';
  function maschera() {
    const bianco = new THREE.MeshBasicMaterial({ color: new THREE.Color(0.6, 0.6, 0.6), fog: false }), nero = new THREE.MeshBasicMaterial({ color: 0x000000, fog: false });
    G.traverse(o => { if (!o.isMesh) return; const dentro = [...Object.values(TT).map(t => t.G), POD].some(g => { let p = o; while (p) { if (p === g) return true; p = p.parent; } return false; });
      const vicina = o.parent && o.parent.parent === fuori && o.isInstancedMesh && o.material && /palma/.test(o.material.name || '');
      o.material = dentro ? bianco : (vicina ? bianco : nero); if (o.userData.nuvola) o.visible = false; });
    for (const t of Object.values(TT)) { t.fascia.visible = false; t.alone.visible = false; t.pk.visible = false; }
    const cupola = new THREE.Mesh(new THREE.SphereGeometry(11000, 16, 8), new THREE.MeshBasicMaterial({ color: 0x000000, side: THREE.BackSide, fog: false, depthWrite: false })); cupola.renderOrder = -0.9; G.add(cupola);
    casa.visible = false;
  }
  if (MASK) maschera();

  // ---------- piani: numerati sul totale della torre (podio + piano tecnico + residenze), STIMA ----------
  const PIANI = {}; for (const T of X.lista.filter(t => !t.ala)) PIANI[T.id] = TT[T.id].ys.map((y, k) => ({ id: T.id + (T.primo + k), torre: T.id, n: T.primo + k, k, y0: y, y1: y + T.passo, esaurito: (S.esauriti[T.id] || []).includes(T.primo + k) }));
  const Tdi = id => X.lista.find(t => t.id === id);
  const loc = (T, lx, y, lz) => { const a = rad(T.a); return new THREE.Vector3(T.x + lx * Math.cos(a) - lz * Math.sin(a), y, T.z + lx * Math.sin(a) + lz * Math.cos(a)); };
  const R = S.riprese, idDi = liv => S.livelli[liv] && S.livelli[liv].id, iDi = id => S.livelli.findIndex(l => l.id === id);
  const nodoSpeciale = () => PIANI[sp.torre].find(p => Math.abs(p.y0 - sp.F) < 0.05);
  const M = {
    gruppo: G, ombra: 300, info: { TT, PIANI, loc, fascia: TT[sp.torre].fasciaG },
    ripresa(liv, n, st) {
      const id = idDi(liv), prima = st && st.livPrima != null ? idDi(st.livPrima) : null;
      M._camera = null;
      if (id === 'mondo' || id === 'piani') return prima && prima !== 'mondo' && prima !== 'piani' ? { percorso: [{ ...R.mondo, t: 0.05 }] } : R.mondo;   /* finito il giro si torna alla foto madre di colpo (nella versione vera è una dissolvenza) */
      const g = S.giroFn(S, M)[id]; M._camera = g && g.camera || null; if (g) return { percorso: g, arrivo: g[g.length - 1].t };
      return R.mondo;
    },
    trova(liv, ray) {
      if (S.livelli[liv].tipo !== 'piani') return null;
      const pk = X.lista.filter(t => !t.ala).map(t => TT[t.id].pk); for (const o of pk) o.updateWorldMatrix(true, false);
      const h = ray.intersectObjects(pk, false); if (!h.length) return null;
      const id = h[0].object.userData.torre, y = h[0].point.y, p = PIANI[id].find(q => y >= q.y0 && y < q.y1); return p || null;
    },
    accendi(st) {
      for (const t of Object.values(TT)) { t.fascia.visible = false; t.alone.visible = false; }
      if (S.livelli[st.liv].tipo !== 'piani') return; const h = st.hover || st.ultimoHover; if (!h) return;
      if (Q.get('clean') === '1' && Q.get('rec') === '1') return;   /* guides (?clean=1&rec=1): no lit floor band, so G1 starts on the clean cover */
      const t = TT[h.torre], col = h.esaurito ? new THREE.Color(0.55, 0.58, 0.62) : new THREE.Color(1.6, 1.15, 0.62), T = Tdi(h.torre);
      t.fascia.position.y = h.y0 - T.solaio; t.fascia.scale.y = T.passo + T.solaio * 0.5; t.fascia.material.color.copy(col); t.fascia.visible = true;
      t.alone.position.y = h.y0; t.alone.scale.y = T.passo / 1; t.alone.visible = !h.esaurito; t.G.updateMatrixWorld(true);
    },
    /* a move of the tour can write the camera itself (salone.camera in samar-casa.js: G1 zoom standing still, G2 straight in); u = 0…1 over the whole path */
    dopoCamera(cam, u) { if (M._camera) M._camera(cam, u); },
    etichetta: () => null,
    ancora(liv, n) { const T = Tdi(n.torre); return T.id === 'B' ? loc(T, T.L + T.R, (n.y0 + n.y1) / 2, 0) : loc(T, -T.R * 0.2, (n.y0 + n.y1) / 2, T.R); },
    punto(p, st, proietta, ui) {
      if (p.bottone) { const b = ui.btns.find(b => b.id === p.bottone); return b ? b.c : null; }
      if (p.piano != null) { const T = Tdi(p.torre), y = T.y0 + T.passo * (p.piano - T.primo) + T.passo * 0.45; return proietta(loc(T, p.lx ?? T.L * 0.15, y, T.R)); }
      return p.xy || null;
    },
    finale: () => null,
    ogniFrame(t, st, cam) { if (fuori.userData.nuvole) fuori.userData.nuvole.position.copy(cam.pos); },
    pannello(c, st, now, ui, fermo) {
      const id = idDi(st.liv), iS = (S.stanze || []).findIndex(q => q.id === id);
      if (iS >= 0) {
        const B = S.benvenuto; if (B && id === S.stanze[0].id && welcomeSchermo(c, ui, B, now - (st.tEntra ?? st.tIn), Q.get('wf') || B.wf || 'V1')) return;
        if (st.arrivato !== st.liv) return;
        const q = S.stanze[iS], dopo = S.stanze[iS + 1], a0 = Math.max(0, Math.min(1, (now - st.tIn - (iS === 0 ? 0.6 : 0.25)) / 0.9)), a = a0 * a0 * (3 - 2 * a0); if (a <= 0) return;
        const idB = dopo ? 'liv:' + iDi(dopo.id) : 'liv:' + iDi('piani');
        fermata(c, ui, { stanza: q.nome, n: iS + 1, tot: S.stanze.length, prossima: dopo ? dopo.nome : 'Choose another floor', esci: false, dir: q.dir, id: idB, hov: st.hBtn === idB, stanze: S.stanze.map(z => z.breve || z.nome) }, a, now, Q.get('fermate') || S.fermateStile || 'P1');
        return;
      }
      if (id !== 'piani' || !fermo) return;
      // card di vetro come SAMAR (la nostra prima, 30/10): a destra, «Choose your floor», livello grande, nome, m², bottone blu «Enter»
      const W = ui.W, H = ui.H, w = 392, h = 420, x = W - W * 0.06 - w, y = H / 2 - h / 2, a = Math.min(1, (now - st.tIn) / 0.5), rr = (x, y, w, h, r) => { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); };
      const n = st.hover || st.ultimoHover || nodoSpeciale(), spec = n.torre === sp.torre && Math.abs(n.y0 - sp.F) < 0.05, T = Tdi(n.torre);
      c.save(); c.globalAlpha = a;
      c.save(); rr(x, y, w, h, 30); c.clip(); if (ui.sfondo) { c.filter = 'blur(28px) saturate(1.6)'; c.drawImage(ui.sfondo, 0, 0, W, H); c.filter = 'none'; }
      c.fillStyle = 'rgba(16,22,40,0.28)'; c.fillRect(x, y, w, h); const g = c.createLinearGradient(0, y, 0, y + h * 0.42); g.addColorStop(0, 'rgba(255,255,255,0.22)'); g.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = g; c.fillRect(x, y, w, h); c.restore();
      rr(x + 0.5, y + 0.5, w - 1, h - 1, 30); c.strokeStyle = 'rgba(255,255,255,0.55)'; c.lineWidth = 1; c.stroke();
      const X0 = x + 28; c.textAlign = 'left'; c.fillStyle = '#fff';
      c.font = '500 12px SFTS'; c.fillStyle = 'rgba(255,255,255,0.72)'; c.letterSpacing = '3px'; c.fillText(`${S.testi.torre.toUpperCase()} · TOWER ${n.torre}`, X0, y + 42); c.letterSpacing = '0px';
      c.font = '600 34px SFD'; c.fillStyle = '#fff'; c.fillText('Choose', X0, y + 86); c.fillText('your floor', X0, y + 122);
      c.font = '14px SFTS'; c.fillStyle = 'rgba(255,255,255,0.78)'; c.fillText('Move along the towers to light up a floor.', X0, y + 152); c.fillText('Select it to fly in through the glass.', X0, y + 172);
      c.font = '500 13px SFTS'; c.fillStyle = 'rgba(255,255,255,0.72)'; c.fillText('LEVEL', X0, y + 246);
      c.font = '600 68px SFD'; c.fillStyle = '#fff'; c.fillText(String(n.n), X0 + 52, y + 250);
      c.font = '600 17px SFTS'; c.fillText(n.esaurito ? `Residence ${n.n}${n.torre} · sold` : spec ? `${sp.nome} · ${Math.round(n.y0)} m` : `Residence ${n.n}${n.torre} · ${Math.round(n.y0)} m`, X0, y + 282);
      c.font = '14px SFTS'; c.fillStyle = 'rgba(255,255,255,0.72)'; c.fillText(spec ? `${S.aree[n.torre]} m² · ${sp.sotto}` : `${S.aree[n.torre]} m² · ${S.testi.vista}`, X0, y + 304);
      const bw = w - 56, bh = 48, by = y + h - bh - 26, hov = st.hBtn === 'scegliUltimo', spento = n.esaurito;
      rr(X0, by, bw, bh, 24); c.fillStyle = spento ? 'rgba(255,255,255,0.22)' : (hov ? '#2a95ff' : '#0a84ff'); c.fill();
      c.font = '600 16px SFTS'; c.fillStyle = '#fff'; c.textAlign = 'center'; c.fillText(spento ? 'Sold' : spec ? `Enter ${sp.nome}` : `Enter level ${n.n}`, X0 + bw / 2, by + 30); c.textAlign = 'left';
      if (!spento) ui.btns.push({ id: 'scegliUltimo', r: [X0, by, X0 + bw, by + bh], c: [X0 + bw / 2, by + bh / 2] });
      // lineetta e numero accanto alla torre, sul piano acceso (come SAMAR)
      if (st.hover) { const p = ui.proietta(M.ancora(1, st.hover)); if (p[2]) { const s = T.id === 'B' ? 1 : -1; c.strokeStyle = 'rgba(255,255,255,0.95)'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(p[0] + 14 * s, p[1]); c.lineTo(p[0] + 64 * s, p[1]); c.stroke(); c.font = '300 22px SFD'; c.fillStyle = '#fff'; c.textAlign = s > 0 ? 'left' : 'right'; c.fillText(String(st.hover.n), p[0] + 76 * s, p[1] + 8); c.textAlign = 'left'; } }
      c.restore();
    },
  };
  M.pronta = pronta;
  return M;
}
