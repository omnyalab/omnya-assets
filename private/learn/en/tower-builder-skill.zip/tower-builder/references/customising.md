# Customising beyond the config

Read this only when the config in `references/config.md` cannot do what the user wants. All the places named here are in the engine part of `tower.js` (below the `ENGINE` line). Make the smallest change that works, and re-check all the steps on phone and desktop afterwards (`?step=tower`, `floor`, `unit`, `upgrade`, `penthouse`, `card`).

## How the tower is drawn (so changes stay consistent)

- Metres, y up. The tower stands on the origin. **x is north, z is east, the view side (sea, river, open side) is west at -z.** The hero camera stands east of the tower, a little to the north (`AZ`, 24 degrees), so the water is behind the tower in the first shot and in front of the view-side residences.
- `BASE` is the footprint at scale 1: a convex outline of points with their outward normals. `polyAt(s, d)` gives that outline scaled by `s` (taper) and pushed out by `d` metres. Every facade part is a band or a cap of such an outline: `GB().band(poly, y0, y1)`, `cap(poly, y)`, `ring(inner, outer, y)`.
- Levels: `LY[L]` is the floor height of level `L` (1 = ground), `LH[L]` its height. `dG(L)` is where its glass stands (0 for residences, -1.4 for the lobby, -3.2 for the penthouse), `dS(L)` where its slab edge ends (the balcony). `SLAB` is the height of the white band.
- One merged mesh per material: `mFrame` (slabs, roof, handrails), `mGlass` (all residential glass, texture of 32 panels x 8 levels with lit rooms), `mLobby`, `mRail` (glass balustrades), `mPool`, `mCrown`. Never make one mesh per floor or per residence.
- `CUT` is a clipping plane on every tower material. The floor view sets it 1.05 m above the chosen level, which opens the building there; everything else sets it out of the way.
- Residences are wedges around the core: residence `k` is centred on angle `thetaOf(k)` (PI = facing the view), `WEDGE` wide. `UNIT[L][k]` holds its type, price and `taken`.
- `viewOf(step)` returns the camera for a step. `fit()` frames a set of points inside the part of the screen not covered by the header and the sheet, always with the subject on the optical axis (a sideways shift makes the moves swing).
- `moveTo(view)` is the only camera move: the target travels in a straight line, the distance changes on a log scale, the direction is blended in the same vertical plane, smooth start and stop, no roll. `cut(fn)` is the soft fade used for every jump that is not a straight move (opening the floor, going inside, coming out). The sheet also crossfades from the old card to the new one, never a jump. Keep both: they are what makes the recordings pass the smoothness checks.

## Shape

- **A wider or deeper tower**: `footprint.width` / `depth` in the config. Keep the depth at least 20 m, or the rooms get too shallow for the view camera (it stands up to 6.4 m behind the glass).
- **Thicker white bands**: `SLAB` (bands: 0.68). **Deeper balconies**: `balcony` in the config.
- **More taper or a different taper curve**: `scaleOf(L)`; the exponent 1.15 keeps the lower half almost straight.
- **A different crown**: the `CROWN` block after the roof slab. The slanted crown rises towards -z; change `hAt(z)` to turn it.
- **No pool on the penthouse terrace**: delete the `if (PEN) { ... bPool ... }` block.
- **Two towers**: not supported by the floor picker. Build two folders, or ask before rewriting the engine.

## Colours of parts that are not in the config

| Part | Where |
|---|---|
| Lit windows, curtains | `glassTextures()` (the warm gradient is the emissive map; `LK.lit` is how many rooms are lit) |
| Lobby glow | `lobbyTexture()` and `mLobby` |
| Pool | `mPool` |
| Unit tiles on the open floor | `PAPER`, `HOVER`, and `colors.accent` / `colors.taken` |
| Interior floor, ceiling, walls | `roomTextures()` (oak planks, travertine, wood slats) and `buildRoom()` |
| Furniture | `buildRoom()`: `fab` (sofa), `cush`, `stone`, `walnut`, `leather`, `rugM` |
| Plaza, lawn ring | the "plaza around the tower" block |
| Land, beach, roads | the canvas drawing in the "ground" block (`LANDC`, `blot`, the beach strokes) |
| Water | `LOOKS[...].water` and the water material |

## Light and sky

- `LOOKS` holds the three looks. `el` is the sun height in degrees, `off` its angle from the hero camera's line of sight (positive = to the right), `exp` the exposure, `fog`/`fogD` the haze, `win` the strength of the lit windows, `lit` the share of lit rooms, `roomI` the light inside the residences.
- To put the sun on the other side of the tower, change the sign of `off`. Keep `golden` low (2 to 6 degrees): the glitter on the water and the sun in the view from the residences come from that.

## Cameras

- Hero shot: `viewOf('tower')`, direction `dirAE(AZ, 0.15)` (0.15 rad, about 9 degrees from above), field of view 28 on desktop and 36 on phones.
- Flying to a floor: `viewOf('approach', L)` frames that level from outside with the same tilt and lens as the hero shot, so the flight is a straight push in and rise with no tilt change (a tilt change while flying reads as a rotation and fails the smoothness check). On arrival a soft fade opens the floor.
- Open floor: `viewOf('floor')`, 0.68 rad (39 degrees) from above so all the residences are visible.
- Penthouse upgrade: a fade to `viewOf('approach', level, 0.32)` (wide, outside the chosen level), a straight move up and in to `viewOf('approach', penthouseLevel, 0.8)`, then a fade inside. Do not replace it with a pure vertical slide: on the repeating bands of the facade it reads as shaking.
- Inside: `roomFrame()` puts the camera up to 6.4 m behind the glass (9.5 m in the penthouse), eye at 1.55 m, looking straight out through the facade.
- Views hold still between moves (no idle drift, no moving water): still frames record cleanly. If the user wants a living hero shot, add a very small, slow sway to the tower step only and record again to check it.
- To change where the hero camera stands, change `AZ`. The sea, the sun and the view side follow the world axes, not the camera, so check the hero shot still shows the water.

## Steps and wording

- All words: `text` in the config.
- The sheet of each step is built in `towerSheet`, `floorSheet`, `unitSheet`, `enterUpgrade`, `pentSheet`; the card in `enterCard`.
- No penthouse upgrade: set `penthouse: null` in the config; Continue then goes straight to the card.
- Real availability: replace the `taken: ...` part where `UNIT[L]` is filled with data from the user (for example a JSON list of sold residence names like `32D`), then set `text.note` to `''`.
- Styles are all in `ui.css`: dark glass (`--glass`, `--edge`), the light card (`--paper`, `--pink`), `--accent` is set from the config at load.

## Things not to do

- Do not create one mesh per floor or per residence; keep the merged meshes and the clipping plane.
- Do not add camera moves that orbit, swing sideways or roll; use `moveTo` (straight) or `cut` (soft fade).
- Do not change the three.js version without testing every step: `Sky` and `RoundedBoxGeometry` come from the same pinned version.
- Do not add a build step, a framework or a backend for the page itself.
