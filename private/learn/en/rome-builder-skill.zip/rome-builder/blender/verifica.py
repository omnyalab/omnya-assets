# Controlli automatici della scena (giudice esterno, niente occhio):
# 1) niente pezzi sospesi: ogni pezzo di Roma, Fuori e del mercato deve poggiare su qualcosa
# 2) bighe: mai a meno di 1,2 m da una persona o da una colonna in nessun fotogramma
# 3) camera: mai a meno di 0,6 m da muri, gradini o soffitti
# blender -b file.blend --python verifica.py -- out.json
import bpy, bmesh, math, json, sys
import numpy as np
from mathutils import Vector

argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
OUT = argv[0] if argv else '/tmp/verifica.json'
scn = bpy.context.scene
for o in scn.objects:                       # i volumi non sono superfici
    if o.name.startswith(('polvere', 'foschia')) or o.type in ('CAMERA', 'LIGHT'):
        o.hide_viewport = True
dg = bpy.context.evaluated_depsgraph_get()
DOWN = Vector((0, 0, -1))
ris = {}

# 1) pezzi sospesi
terr = bpy.data.objects['terreno']
def terra_z(x, y):
    hit, loc, *_ = terr.ray_cast(terr.matrix_world.inverted() @ Vector((x, y, 2000)), DOWN)
    return (terr.matrix_world @ loc).z if hit else None
sospesi = []
for cname in ('Roma', 'Fuori'):
    for ob in bpy.data.collections[cname].objects:
        if ob.type != 'MESH' or ob.name.startswith(('terreno', 'terra_lontana')) or 'foglie' in ob.name and 'corteo' in ob.name:
            continue
        if ob.modifiers:
            continue
        bm = bmesh.new(); bm.from_mesh(ob.data); bm.verts.ensure_lookup_table()
        seen = set()
        for v0 in bm.verts:
            if v0.index in seen:
                continue
            comp = []; stack = [v0]; seen.add(v0.index)
            while stack:
                v = stack.pop(); comp.append(v)
                for e in v.link_edges:
                    w = e.other_vert(v)
                    if w.index not in seen:
                        seen.add(w.index); stack.append(w)
            zs = [v.co.z for v in comp]; zmin = min(zs)
            if max(zs) - zmin < 0.05:                 # quadrati piatti (strade, lastre): controllati come gli altri
                pass
            base = [v.co for v in comp if v.co.z < zmin + 0.05][:8]
            gap = 0.0
            # sostegno al centro: se il pezzo poggia su un altro oggetto (tetto sul muro) le gronde non contano
            cxy = sum((ob.matrix_world @ c for c in base), Vector()) / len(base)
            hit0, loc0, n0, i0, hob0, m0 = scn.ray_cast(dg, cxy + Vector((0, 0, -0.01)), DOWN, distance=500)
            if hit0 and hob0 is not None and not hob0.name.startswith('terreno') and cxy.z - loc0.z < 0.15:
                continue
            for c in base:
                w = ob.matrix_world @ c
                tz = terra_z(w.x, w.y)
                if tz is not None and w.z <= tz + 0.03:          # poggia sul terreno o ci entra: va bene
                    continue
                # parte appena sopra la base (così trova la faccia sopra di chi lo sostiene), salta la propria faccia di sotto
                hit, loc, nrm, idx, hob, mx = scn.ray_cast(dg, w + Vector((0, 0, 0.05)), DOWN, distance=500)
                if hit and hob is not None and hob.name == ob.name and (w.z - loc.z) < 0.02:
                    hit, loc, nrm, idx, hob, mx = scn.ray_cast(dg, loc + Vector((0, 0, -0.01)), DOWN, distance=500)
                if hit:
                    g = w.z - loc.z
                else:                                   # niente sotto: o è sepolto (terreno sopra) o è nel vuoto
                    up, *_ = scn.ray_cast(dg, w + Vector((0, 0, -0.01)), Vector((0, 0, 1)), distance=200)
                    g = 0.0 if up else 500.0
                gap = max(gap, g)
            if gap > 0.15:
                cx = sum(v.co.x for v in comp) / len(comp); cy = sum(v.co.y for v in comp) / len(comp)
                sospesi.append(dict(oggetto=ob.name, x=round(cx, 1), y=round(cy, 1), z=round(zmin, 2), vuoto_m=round(gap, 2)))
        bm.free()
sospesi.sort(key=lambda d: -d['vuoto_m'])
ris['sospesi_n'] = len(sospesi); ris['sospesi'] = sospesi[:40]
print('SOSPESI', len(sospesi), sospesi[:10])

# punti delle istanze (mercato e città) contro il terreno
gap_ist = []
for nome in ('mercato_banchi', 'mercato_gente', 'viale_botteghe', 'citta'):
    if nome not in bpy.data.objects:
        continue
    me = bpy.data.objects[nome].data
    co = np.zeros(len(me.vertices) * 3); me.vertices.foreach_get('co', co); co = co.reshape(-1, 3)
    idx = np.linspace(0, len(co) - 1, min(len(co), 1500)).astype(int)
    worst = 0.0; wxy = None
    for i in idx:
        x, y, z = co[i]
        tz = terra_z(x, y)
        if tz is not None:
            # la città scende 9 m sotto la base: conta solo se il terreno è più giù di così
            margine = 9.0 if nome in ('citta', 'viale_botteghe') else 0.0
            if (z - margine) - tz > worst:
                worst = (z - margine) - tz; wxy = (round(float(x), 1), round(float(y), 1), round(float(z), 2), round(tz, 2))
    gap_ist.append((nome, round(worst, 3), wxy if worst > 0 else None))
ris['istanze_vuoto_max_m'] = gap_ist
print('ISTANZE', gap_ist)

# 2) bighe contro persone e colonne, fotogramma per fotogramma
pers = []
for nome in ('folla_fuori', 'mercato_gente'):
    me = bpy.data.objects[nome].data
    co = np.zeros(len(me.vertices) * 3); me.vertices.foreach_get('co', co); co = co.reshape(-1, 3)[:, :2]
    mv = np.zeros((len(me.vertices), 3))
    if 'mv' in me.attributes:
        a = np.zeros(len(me.vertices) * 3); me.attributes['mv'].data.foreach_get('vector', a); mv = a.reshape(-1, 3)
    pers.append((co, mv[:, :2]))
col = []
cc = bpy.data.objects.get('colonne_corteo_marmo')
if cc:
    v = np.zeros(len(cc.data.vertices) * 3); cc.data.vertices.foreach_get('co', v); v = v.reshape(-1, 3)
    col = v[v[:, 2] > 3.0][:, :2]
bighe = [o for o in bpy.data.objects if o.name.startswith('biga') and o.type == 'EMPTY']
min_p = 99.0; min_c = 99.0; dove = None
for f in range(scn.frame_start, scn.frame_end + 1, 2):
    scn.frame_set(f); t = (f - 1) / scn.render.fps
    P = np.vstack([co + mv * t for co, mv in pers])
    for b in bighe:
        m = b.matrix_world
        for lx, ly in ((0, 2.6), (0, 1.6), (0, -0.3), (-0.45, 1.6), (0.45, 1.6), (0.72, -0.35), (-0.72, -0.35)):
            w = m @ Vector((lx, ly, 0))
            d = np.min(np.hypot(P[:, 0] - w.x, P[:, 1] - w.y))
            if d < min_p:
                min_p = d; dove = (f, b.name)
            if len(col):
                min_c = min(min_c, float(np.min(np.hypot(col[:, 0] - w.x, col[:, 1] - w.y))))
ris['bighe_persona_min_m'] = round(float(min_p), 2); ris['bighe_dove'] = dove; ris['bighe_colonna_min_m'] = round(float(min_c), 2)
print('BIGHE persona', min_p, dove, 'colonna', min_c)

# 3) camera contro le superfici
cam = scn.camera
mind = 99.0; dove = None
for f in range(scn.frame_start, scn.frame_end + 1):
    scn.frame_set(f); dg = bpy.context.evaluated_depsgraph_get()
    p = cam.matrix_world.translation; R = cam.matrix_world.to_3x3()
    for d in (Vector((0, 0, -1)), Vector((0, 0, 1)), R @ Vector((1, 0, 0)), R @ Vector((-1, 0, 0)), R @ Vector((0, 0, -1))):
        hit, loc, *_ = scn.ray_cast(dg, p, d, distance=5.0)
        if hit:
            dd = (loc - p).length
            if dd < mind:
                mind = dd; dove = (f, tuple(round(x, 1) for x in p))
ris['camera_superficie_min_m'] = round(mind, 2); ris['camera_dove'] = dove
print('CAMERA min', mind, dove)
json.dump(ris, open(OUT, 'w'), indent=1)
print('VERIFICA', json.dumps({k: v for k, v in ris.items() if k != 'sospesi'}))
