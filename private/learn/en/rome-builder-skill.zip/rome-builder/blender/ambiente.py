# Intorno, corteo, cielo, polvere e camere (giro A1 + foto).
import bpy, math, random
import numpy as np
from mathutils import Vector, Euler
import geo
from geo import M, Builder, frame, bay_s, PERIM, BAYW, NBAY

SUN_DIR = Vector((-0.30, -0.95, 0.0))   # verso il sole sul piano (da ovest-sudovest), elevazione a parte
SUN_ELEV = 11.0


def _flush(b, prefix, coll, mesh_obj):
    out = []
    for mat, (V, F) in b.parts.items():
        if V:
            out.append(mesh_obj(f'{prefix}_{mat}', V, F, mat, coll))
    return out


AV = {}
CITTA = False
ESC = None


def _quota(x, y):
    """colli intorno alla valle (STIMA di forma): Palatino SO, Celio SE, Oppio N, Velia O; valle e viale piani"""
    h = 0.0
    for cx, cy, sg, hh in ((-330, -260, 150, 55), (170, -390, 190, 48), (-40, 400, 210, 52), (-300, 60, 85, 20), (420, 180, 220, 40)):
        h += hh * math.exp(-((x - cx) ** 2 + (y - cy) ** 2) / (2 * sg ** 2))
    r = math.hypot(x / 1.2, y)
    f = min(1.0, max(0.0, (r - 125) / 140))
    if AV:
        rel = np.array([x, y]) - AV['pc']
        al = rel @ AV['nc']; lat = abs(rel @ AV['tc'])
        if al > -20:
            f = min(f, max(0.0, (lat - 20) / 60))
    return h * f * f * (3 - 2 * f)


def _zmin(cx, cy, hx, hy, rot=0.0, n=6):
    c, s = math.cos(rot), math.sin(rot); m = 1e9
    for i in range(n + 1):
        for j in range(n + 1):
            u = -hx + 2 * hx * i / n; v = -hy + 2 * hy * j / n
            m = min(m, _quota(cx + u * c - v * s, cy + u * s + v * c))
    return min(m, _quota(cx, cy))


def costruisci(scn, MAT, coll, mesh_obj, CAM_BAY, leggero):
    rnd = random.Random(11)
    sc = bay_s(CAM_BAY); pc, nc = frame(sc); tc = np.array([-nc[1], nc[0]])
    AV.update(pc=pc, nc=nc, tc=tc)
    # terreno a colli
    n = 640 if CITTA else 160; R = 6000.0 if CITTA else 1400.0
    V = []; F = []
    gm = lambda u: R * (0.22 * u + 0.78 * u ** 3)
    g1 = gm(np.linspace(-1, 1, n + 1)); GX, GY = np.meshgrid(g1, g1)
    if CITTA:
        import roma
        GZ = roma.quota_np(GX, GY) - 0.04
    else:
        GZ = np.vectorize(_quota)(GX, GY) - 0.04
    V = list(zip(GX.ravel().tolist(), GY.ravel().tolist(), GZ.ravel().tolist()))
    for j in range(n):
        for i in range(n):
            a = j * (n + 1) + i
            F.append((a, a + 1, a + n + 2, a + n + 1))
    t = mesh_obj('terreno', V, F, 'terra', coll)
    if CITTA:
        mesh_obj('terra_lontana', [(-40000, -40000, -0.6), (40000, -40000, -0.6), (40000, 40000, -0.6), (-40000, 40000, -0.6)], [(0, 1, 2, 3)], 'orizzonte', coll)
    for p in t.data.polygons:
        p.use_smooth = True
    b = Builder()
    # lastricato di travertino 17,5 m e cippi ogni 3,4 m
    V, F = geo.ellipse_ring_mesh(0.95, 17.5, 0.0, 1440)
    mesh_obj('lastricato', V, F, 'lastre', coll)
    V, F = geo.ellipse_ring_mesh(17.5, 62.0, -0.005, 1440)
    mesh_obj('piazza', V, F, 'viale_trav', coll)        # piazza in grandi lastre bianche di travertino
    _colosso(b, pc + nc * 125 + tc * 48)
    ring = geo.offset_perim(17.0); ncip = int(ring / 3.4)
    s_porta = bay_s(CAM_BAY)
    for i in range(ncip):
        s0 = PERIM * i / ncip
        if abs((s0 - s_porta + PERIM / 2) % PERIM - PERIM / 2) < 5.5:
            continue
        b.box('trav2', s0, -0.32, 0.32, 16.8, 17.44, 0.0, 1.75, 1)
        b.box('trav2', s0, -0.38, 0.38, 16.74, 17.5, 1.75, 1.9, 1)
    # viale del corteo (basoli) dritto sulla normale dell'arco del biglietto
    def quad_viale(o0, o1, l0, l1, z, mat):
        pts = [pc + nc * o0 + tc * l0, pc + nc * o1 + tc * l0, pc + nc * o1 + tc * l1, pc + nc * o0 + tc * l1]
        b.raw(mat, [(float(q[0]), float(q[1]), z) for q in pts], [(0, 1, 2, 3)])
    for k in range(26):
        o0 = 17.5 + k * 8; o1 = o0 + 8
        quad_viale(o0, o1, -8.5, 8.5, 0.012, 'viale_trav')
        quad_viale(o0, o1, 8.5, 15.0, 0.008, 'lastre')
        quad_viale(o0, o1, -15.0, -8.5, 0.008, 'lastre')
    # stendardi del corteo ai lati del viale (aste con drappo rosso e aquila d'oro), corsia della camera libera
    for side in (-1, 1):
        for k in range(0 if CITTA else 5):
            o = 24 + k * 13
            q = pc + nc * o + tc * side * 5.2
            x, y = float(q[0]), float(q[1])
            _asta(b, x, y, 7.5, tc, side)
    # case, templi e alberi sui colli, mai sul viale né vicino al Colosseo
    nb = 0 if CITTA else (900 if leggero else 7000)
    placed = 0; tries = 0
    occ = set()
    _monumenti(b)
    while placed < nb and tries < nb * 6:
        tries += 1
        ang = rnd.uniform(0, 2 * math.pi); rr = 165 + rnd.random() ** 1.3 * 1050
        x = math.cos(ang) * rr * 1.15; y = math.sin(ang) * rr
        rel = np.array([x, y]) - pc
        if abs(rel @ tc) < 26 and rel @ nc > -10:
            continue
        if np.linalg.norm(np.array([x, y]) - (pc + nc * 125 + tc * 48)) < 26:
            continue
        # strade: griglia ruotata, niente case sulle strade
        u = x * 0.94 + y * 0.34; v = -x * 0.34 + y * 0.94
        if (u % 46) < 6 or (v % 38) < 5:
            continue
        if np.hypot(x - 177, y - 190) < 85 or np.hypot(x - 0, y + 330) < 120:
            continue
        z = _quota(x, y)
        w = rnd.uniform(10, 28); d = rnd.uniform(9, 18)
        cells = {(int((x + dx) // 14), int((y + dy) // 14)) for dx in (-w / 2, 0, w / 2) for dy in (-w / 2, 0, w / 2)}
        if cells & occ:
            continue
        occ |= cells; h = rnd.choice((9, 12, 12, 15, 15, 18, 21)) + rnd.uniform(-0.5, 0.5)
        rot = math.atan2(0.34, 0.94) + rnd.choice((0, math.pi / 2)) + rnd.uniform(-0.04, 0.04)
        _casa(b, x, y, z, w, d, h, rot, rnd.choice(('intonaco', 'intonaco2', 'intonaco3', 'mattoni', 'intonaco')))
        placed += 1
    nt = 220 if leggero else (3000 if CITTA else 1600)
    for i in range(nt):
        ang = rnd.uniform(0, 2 * math.pi); rr = rnd.uniform(120, 2400 if CITTA else 1100)
        x = math.cos(ang) * rr * 1.15; y = math.sin(ang) * rr
        rel = np.array([x, y]) - pc
        if abs(rel @ tc) < 34 and rel @ nc > -10:
            continue
        if math.hypot(x / 1.2, y) < 150:
            continue
        if ESC is not None and ESC(x, y) and rnd.random() < 0.85:
            continue
        _albero(b, x, y, _quota(x, y), rnd)
    # petali nell'aria lungo il viale
    npet = 0
    for i in range(npet):
        o = rnd.uniform(4, 110); lat = rnd.uniform(-16, 16); z = rnd.uniform(0.4, 16)
        if abs(lat) < 4.5 and z < 13:
            continue
        q = pc + nc * o + tc * lat
        c = Vector((float(q[0]), float(q[1]), z))
        e = Euler((rnd.uniform(0, 6.3), rnd.uniform(0, 6.3), rnd.uniform(0, 6.3))).to_matrix()
        sz = rnd.uniform(0.02, 0.035)
        pts = [c + e @ Vector(v) * sz for v in ((-1, -0.6, 0), (1, -0.6, 0.15), (1, 0.6, 0), (-1, 0.6, 0.15))]
        b.raw('petalo', [tuple(p) for p in pts], [(0, 1, 2, 3)])
    _flush(b, 'fuori', coll, mesh_obj)


def _asta(b, x, y, h, tc, side):
    def bx(cx, cy, z0, z1, rx, ry, mat):
        V = [(cx + sx * rx, cy + sy * ry, zz) for zz in (z0, z1) for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
        F = [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]
        b.raw(mat, V, F)
    bx(x, y, 0.0, 0.6, 0.35, 0.35, 'trav2')
    bx(x, y, 0.6, h, 0.05, 0.05, 'legno')
    bx(x, y, h, h + 0.12, 0.16, 0.16, 'oro')
    t2 = Vector((float(tc[0]), float(tc[1]), 0))
    corpo = [Vector((x, y, h + 0.12)), Vector((x, y, h + 0.5))]
    for k in range(3):
        bx(x, y, h - 0.9 - k * 0.55, h - 0.6 - k * 0.55, 0.16, 0.03, 'oro')
    for sg in ():
        a0 = Vector((x, y, h + 0.38)); a1 = a0 + t2 * sg * 0.55 + Vector((0, 0, 0.32)); a2 = a0 + t2 * sg * 0.42 + Vector((0, 0, 0.05))
        nn = Vector((-t2.y, t2.x, 0)) * 0.02
        b.raw('oro', [tuple(a0 - nn), tuple(a1 - nn), tuple(a2 - nn), tuple(a0 + nn), tuple(a1 + nn), tuple(a2 + nn)],
              [(0, 1, 2), (3, 5, 4), (0, 3, 4, 1), (1, 4, 5, 2), (2, 5, 3, 0)])
    # drappo appeso a una traversa, piano parallelo al viale
    t = Vector((float(tc[0]), float(tc[1]), 0))
    nrm = Vector((-t.y, t.x, 0))
    top = h - 0.3
    V = []; F = []
    for j in range(7):
        for i in range(5):
            u = (i / 4 - 0.5) * 1.3; v = j / 6 * 2.6
            p = Vector((x, y, top - v)) + nrm * u + t * (0.08 * math.sin(i * 1.3 + j * 0.7))
            V.append(tuple(p))
    for j in range(6):
        for i in range(4):
            a = j * 5 + i
            F.append((a, a + 1, a + 6, a + 5))
    b.raw('stendardo', V, F)
    bx(x, y, top, top + 0.06, 0.04, 0.04, 'legno')


def _monumenti(b):
    """Terme di Tito (inaugurate nell'80, colle Oppio, NNE) e Tempio del Divo Claudio (Celio, SSE): masse semplici, STIMA"""
    def bx(cx, cy, z0, z1, rx, ry, mat, rot=0.0):
        c, s_ = math.cos(rot), math.sin(rot)
        V = [(cx + sx * rx * c - sy * ry * s_, cy + sx * rx * s_ + sy * ry * c, zz) for zz in (z0, z1) for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
        F = [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]
        b.raw(mat, V, F)
    # Terme di Tito
    x, y = 177.0, 190.0; z = _quota(x, y); r = 0.75
    bx(x, y, _zmin(x, y, 62, 50, r) - 3, z + 4, 62, 50, 'trav2', r)
    bx(x, y, z + 4, z + 18, 55, 22, 'mattoni', r)
    bx(x, y, z + 4, z + 26, 18, 18, 'intonaco3', r)
    bx(x, y, z + 26, z + 28, 20, 20, 'tegole', r)
    for sx in (-1, 1):
        bx(x + sx * 38 * math.cos(r), y + sx * 38 * math.sin(r), z + 4, z + 14, 12, 26, 'mattoni', r)
    # Tempio del Divo Claudio: grande terrazza ad arcate e tempio esastilo
    x, y = 0.0, -330.0; z = _quota(x, y); r = 0.0
    bx(x, y, _zmin(x, y, 90, 100, r) - 3, z + 9, 90, 100, 'muro', r)
    bx(x, y, z + 9, z + 9.4, 86, 96, 'foglie', r)
    bx(x, y + 30, z + 9, z + 12, 14, 24, 'marmo', r)
    bx(x, y + 34, z + 12, z + 25, 11, 18, 'marmo', r)
    bx(x, y + 34, z + 25, z + 29, 12.5, 19.5, 'tegole', r)
    for i in range(6):
        bx(x - 10 + i * 4, y + 9.5, z + 12, z + 25, 0.7, 0.7, 'marmo', r)
    V = [(x - 12.5, y + 9.0, z + 29), (x + 12.5, y + 9.0, z + 29), (x, y + 9.0, z + 34), (x - 12.5, y + 53.5, z + 29), (x + 12.5, y + 53.5, z + 29), (x, y + 53.5, z + 34)]
    b.raw('marmo', V, [(0, 1, 2), (3, 5, 4), (0, 3, 4, 1), (1, 4, 5, 2), (2, 5, 3, 0)])


def _colosso(b, p):
    """Colosso di Nerone come Sol (~30 m, bronzo dorato) sul basamento, nel vestibolo della Domus Aurea (STIMA di posizione)"""
    import folla
    x, y = float(p[0]), float(p[1]); z = _quota(x, y)
    def bx(cx, cy, z0, z1, rx, ry, mat):
        V = [(cx + sx * rx, cy + sy * ry, zz) for zz in (z0, z1) for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
        F = [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]
        b.raw(mat, V, F)
    bx(x, y, _zmin(x, y, 9.5, 8.0) - 1, z + 1.2, 9.5, 8.0, 'trav2')
    bx(x, y, z + 1.2, z + 9.5, 7.6, 6.4, 'marmo')
    bx(x, y, z + 9.5, z + 10.4, 8.2, 7.0, 'trav2')
    st = folla.figura('colosso_tmp', 'braccio')
    sc = 17.5; rot = math.atan2(-AV['nc'][0], AV['nc'][1]) + math.pi * 0.85
    c, s_ = math.cos(rot), math.sin(rot)
    V = [(x + (v.co.x * c - v.co.y * s_) * sc, y + (v.co.x * s_ + v.co.y * c) * sc, z + 10.4 + v.co.z * sc) for v in st.data.vertices]
    F = [tuple(pl.vertices) for pl in st.data.polygons]
    b.raw('bronzo', V, F)
    # corona di raggi
    hz = z + 10.4 + 1.66 * sc
    for i in range(7):
        a = -1.2 + i * 0.4
        d = Vector((math.cos(a) * c - 0 * s_, math.cos(a) * s_, math.sin(a) + 0.2)).normalized()
        q0 = Vector((x, y, hz)); q1 = q0 + d * 3.4
        nn = Vector((0, 0, 0.12))
        b.raw('bronzo', [tuple(q0 - nn), tuple(q1), tuple(q0 + nn)], [(0, 1, 2)])
    bpy.data.objects.remove(st, do_unlink=True)


def _casa(b, x, y, z, w, d, h, rot, mat):
    c, s = math.cos(rot), math.sin(rot)
    def P(u, v, zz):
        return (x + u * c - v * s, y + u * s + v * c, zz)
    V = [P(sx * w / 2, sy * d / 2, zz) for zz in (z - 3, z + h) for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    F = [(0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]
    b.raw(mat, V, F)
    rh = min(w, d) * 0.16
    R = [P(-w / 2 - 0.4, -d / 2 - 0.4, z + h), P(w / 2 + 0.4, -d / 2 - 0.4, z + h), P(w / 2 + 0.4, d / 2 + 0.4, z + h),
         P(-w / 2 - 0.4, d / 2 + 0.4, z + h), P(-w / 2 + d / 2, 0, z + h + rh), P(w / 2 - d / 2, 0, z + h + rh)]
    b.raw('tegole', R, [(0, 1, 5, 4), (2, 3, 4, 5), (1, 2, 5), (3, 0, 4)])


def _albero(b, x, y, z, rnd):
    if rnd.random() < 0.55:   # pino a ombrello
        h = rnd.uniform(11, 16); r = rnd.uniform(4, 6)
        _cil(b, x, y, z, z + h + 0.5, 0.55, 'tronco', 8, top=0.35)
        _ellissoide(b, x, y, z + h, r, r * 0.38, 'foglie')
    else:                     # cipresso
        h = rnd.uniform(10, 17)
        _cil(b, x, y, z, z + h, 0.9, 'foglie', 8, top=0.1)


def _cil(b, x, y, z0, z1, r, mat, n, top=None):
    top = r if top is None else top
    V = [(x + rr * math.cos(2 * math.pi * i / n), y + rr * math.sin(2 * math.pi * i / n), zz) for zz, rr in ((z0, r), (z1, top)) for i in range(n)]
    F = [(i, (i + 1) % n, n + (i + 1) % n, n + i) for i in range(n)]
    b.raw(mat, V, F)


def _ellissoide(b, x, y, z, r, rz, mat, nu=10, nv=5):
    V = [(x, y, z + rz)]
    for j in range(1, nv):
        a = math.pi * j / nv
        for i in range(nu):
            u = 2 * math.pi * i / nu
            V.append((x + r * math.sin(a) * math.cos(u), y + r * math.sin(a) * math.sin(u), z + rz * math.cos(a)))
    V.append((x, y, z - rz))
    F = [(0, 1 + i, 1 + (i + 1) % nu) for i in range(nu)]
    for j in range(nv - 2):
        for i in range(nu):
            a = 1 + j * nu + i; bb = 1 + j * nu + (i + 1) % nu
            F.append((a, a + nu, bb + nu, bb))
    last = len(V) - 1; base = 1 + (nv - 2) * nu
    F += [(base + i, last, base + (i + 1) % nu) for i in range(nu)]
    b.raw(mat, V, F)


# ---------------------------------------------------------------- LUCE, POLVERE, CAMERE
def _mondo(scn):
    w = bpy.data.worlds.new('cielo'); scn.world = w; w.use_nodes = True
    nt = w.node_tree; N = nt.nodes; L = nt.links
    for n in list(N):
        N.remove(n)
    out = N.new('ShaderNodeOutputWorld'); bg = N.new('ShaderNodeBackground')
    sky = N.new('ShaderNodeTexSky')
    for tipo in ('NISHITA', 'MULTIPLE_SCATTERING', 'SINGLE_SCATTERING', 'HOSEK_WILKIE'):
        try:
            sky.sky_type = tipo; break
        except Exception:
            pass
    az = math.atan2(SUN_DIR.y, SUN_DIR.x)
    for attr, val in (('sun_elevation', math.radians(SUN_ELEV)), ('sun_rotation', az - math.pi / 2 + math.pi / 2),
                      ('air_density', 1.4), ('dust_density', 3.5), ('altitude', 30.0), ('sun_disc', True)):
        try:
            setattr(sky, attr, val)
        except Exception:
            pass
    bg.inputs['Strength'].default_value = 0.22
    L.new(sky.outputs[0], bg.inputs[0]); L.new(bg.outputs[0], out.inputs['Surface'])
    print('cielo', sky.sky_type)


def _sole(scn):
    d = bpy.data.lights.new('sole', 'SUN'); d.energy = 6.0; d.angle = math.radians(0.6)
    d.color = (1.0, 0.78, 0.55)
    o = bpy.data.objects.new('sole', d); scn.collection.objects.link(o)
    v = Vector((SUN_DIR.x, SUN_DIR.y, 0)).normalized() * math.cos(math.radians(SUN_ELEV)) + Vector((0, 0, math.sin(math.radians(SUN_ELEV))))
    o.rotation_euler = (-v).to_track_quat('-Z', 'Y').to_euler()
    return o


def _polvere(scn):
    """foschia che cala con la quota + polvere calda vicino a terra e nell'arena"""
    m = bpy.data.materials.new('polvere'); m.use_nodes = True
    nt = m.node_tree; N = nt.nodes; L = nt.links
    for n in list(N):
        N.remove(n)
    out = N.new('ShaderNodeOutputMaterial'); vol = N.new('ShaderNodeVolumePrincipled')
    geo_n = N.new('ShaderNodeNewGeometry'); sep = N.new('ShaderNodeSeparateXYZ'); L.new(geo_n.outputs['Position'], sep.inputs[0])
    m1 = N.new('ShaderNodeMath'); m1.operation = 'MULTIPLY'; m1.inputs[1].default_value = -1 / 16.0
    L.new(sep.outputs[2], m1.inputs[0])
    ex = N.new('ShaderNodeMath'); ex.operation = 'EXPONENT'; L.new(m1.outputs[0], ex.inputs[0])
    no = N.new('ShaderNodeTexNoise'); no.inputs['Scale'].default_value = 0.03; no.inputs['Detail'].default_value = 3
    L.new(geo_n.outputs['Position'], no.inputs['Vector'])
    mr = N.new('ShaderNodeMapRange'); mr.inputs['To Min'].default_value = 0.4; mr.inputs['To Max'].default_value = 1.6
    L.new(no.outputs['Fac'], mr.inputs['Value'])
    mu = N.new('ShaderNodeMath'); mu.operation = 'MULTIPLY'; L.new(ex.outputs[0], mu.inputs[0]); L.new(mr.outputs['Result'], mu.inputs[1])
    ad = N.new('ShaderNodeMath'); ad.operation = 'MULTIPLY_ADD'
    L.new(mu.outputs[0], ad.inputs[0]); ad.inputs[1].default_value = 0.0024; ad.inputs[2].default_value = 0.00014
    vl = N.new('ShaderNodeVectorMath'); vl.operation = 'LENGTH'
    cz = N.new('ShaderNodeCombineXYZ'); L.new(sep.outputs[0], cz.inputs[0]); L.new(sep.outputs[1], cz.inputs[1]); L.new(cz.outputs[0], vl.inputs[0])
    rr = N.new('ShaderNodeMapRange'); rr.inputs['From Min'].default_value = 2600.0; rr.inputs['From Max'].default_value = 6200.0
    rr.inputs['To Min'].default_value = 1.0; rr.inputs['To Max'].default_value = 0.0; rr.interpolation_type = 'SMOOTHSTEP'
    L.new(vl.outputs['Value'], rr.inputs['Value'])
    hz = N.new('ShaderNodeMath'); hz.operation = 'MULTIPLY'; hz.inputs[1].default_value = -1 / 260.0; L.new(sep.outputs[2], hz.inputs[0])
    he = N.new('ShaderNodeMath'); he.operation = 'EXPONENT'; L.new(hz.outputs[0], he.inputs[0])
    fm = N.new('ShaderNodeMath'); fm.operation = 'MULTIPLY'; L.new(rr.outputs['Result'], fm.inputs[0]); L.new(he.outputs[0], fm.inputs[1])
    dd = N.new('ShaderNodeMath'); dd.operation = 'MULTIPLY'; L.new(ad.outputs[0], dd.inputs[0]); L.new(fm.outputs[0], dd.inputs[1])
    L.new(dd.outputs[0], vol.inputs['Density'])
    vol.inputs['Color'].default_value = (1.0, 0.9, 0.76, 1)
    vol.inputs['Anisotropy'].default_value = 0.55
    L.new(vol.outputs[0], out.inputs['Volume'])
    bpy.ops.mesh.primitive_cube_add(size=1)
    c = bpy.context.active_object; c.name = 'polvere'; c.scale = (14000, 14000, 760) if CITTA else (2600, 2600, 260); c.location = (0, 0, 370 if CITTA else 128)
    c.data.materials.append(m)
    c.visible_shadow = False
    return c


def _cam(nome, loc, yaw, pitch, lens):
    cd = bpy.data.cameras.new(nome); cd.lens = lens; cd.sensor_width = 36; cd.clip_start = 0.1; cd.clip_end = 5000
    o = bpy.data.objects.new(nome, cd); bpy.context.scene.collection.objects.link(o)
    o.location = loc
    o.rotation_euler = Euler((math.radians(90 + pitch), 0, yaw), 'XYZ')
    return o


def _catmull(P, n_per=400):
    """Catmull-Rom centripeta sui punti P, ricampionata a passo costante"""
    P = [np.array(p, float) for p in P]
    pts = []
    ext = [P[0] + (P[0] - P[1])] + P + [P[-1] + (P[-1] - P[-2])]
    for i in range(1, len(ext) - 2):
        p0, p1, p2, p3 = ext[i - 1], ext[i], ext[i + 1], ext[i + 2]
        def tj(ti, a, b):
            return ti + np.linalg.norm(b - a) ** 0.5
        t0 = 0; t1 = tj(t0, p0, p1); t2 = tj(t1, p1, p2); t3 = tj(t2, p2, p3)
        for t in np.linspace(t1, t2, n_per, endpoint=False):
            A1 = (t1 - t) / (t1 - t0) * p0 + (t - t0) / (t1 - t0) * p1
            A2 = (t2 - t) / (t2 - t1) * p1 + (t - t1) / (t2 - t1) * p2
            A3 = (t3 - t) / (t3 - t2) * p2 + (t - t2) / (t3 - t2) * p3
            B1 = (t2 - t) / (t2 - t0) * A1 + (t - t0) / (t2 - t0) * A2
            B2 = (t3 - t) / (t3 - t1) * A2 + (t - t1) / (t3 - t1) * A3
            pts.append((t2 - t) / (t2 - t1) * B1 + (t - t1) / (t2 - t1) * B2)
    pts.append(P[-1])
    pts = np.array(pts)
    seg = np.linalg.norm(np.diff(pts, axis=0), axis=1); s = np.concatenate([[0], np.cumsum(seg)])
    return pts, s


def _lucerna(scn, p, energia=60.0):
    l = bpy.data.lights.new('lucerna', 'POINT'); l.energy = energia; l.color = (1.0, 0.6, 0.3); l.shadow_soft_size = 0.15
    o = bpy.data.objects.new('lucerna', l); scn.collection.objects.link(o); o.location = p


def luce_e_camera(scn, MAT, CAM_BAY, RAMP, walks, leggero):
    _mondo(scn); _sole(scn); _polvere(scn)
    sc = bay_s(CAM_BAY); pc, nc = frame(sc)
    tcv = np.array([-nc[1], nc[0]])
    # lucerne a olio lungo la scala e nei corridoi della nostra campata
    sl = (RAMP['z_top'] + 0.4) / (RAMP['d_in'] - RAMP['d_top'])
    for dd in (35.0, 31.0, 27.0, 23.5):
        zf = -0.4 + (RAMP['d_in'] - dd) * sl
        for sg in (-1, 1):
            q = pc + nc * (dd - 51) + tcv * sg * 0.85
            _lucerna(scn, (float(q[0]), float(q[1]), zf + 2.6), 12.0)
    for off in (-5.2, -11.8):
        for lat in (-3.4, 3.4):
            q = pc + nc * off + tcv * lat
            _lucerna(scn, (float(q[0]), float(q[1]), 4.2), 35.0)
    inward = -nc
    yaw = math.atan2(inward[1], inward[0]) - math.pi / 2

    def W(off, z):
        q = pc + nc * off
        return (float(q[0]), float(q[1]), z)
    dw, zw = walks[1]
    # giro A1: dal viale giù dritti nell'arco LII, corridoi, scala, bocca del vomitorio, sopra le gradinate
    P = [W(84, 11.5), W(44, 6.4), W(8, 2.4), W(-6, 2.0), W(-13.6, 2.0),
         W(RAMP['d_in'] - 51 - 1.5, 2.2), W(RAMP['d_top'] - 51 + 0.6, zw + 1.75),
         W(dw - 51 - 0.2, zw + 1.85), W(dw - 51 - 3.4, zw + 2.4), W(dw - 51 - 5.4, zw + 2.7)]
    pts, s = _catmull(P)
    fps = 24; dur = 20.0; nf = int(fps * dur)
    scn.render.fps = fps; scn.frame_start = 1; scn.frame_end = nf
    cam = _cam('CAM_GIRO', P[0], yaw, 3.0, 22)
    total = s[-1]
    # velocità: parte piano, crociera, rallenta in fondo (smoothstep sulla distanza, con tratto finale fermo 1,5 s)
    # profilo di velocità: accelera nel primo 12%, crociera, frena nell'ultimo 22% (niente scatti)
    U = np.linspace(0, 1, 4001)
    def ramp(x):
        x = np.clip(x, 0, 1); return x * x * (3 - 2 * x)
    vel = ramp(U / 0.12) * ramp((1 - U) / 0.22)
    cum = np.concatenate([[0], np.cumsum(0.5 * (vel[1:] + vel[:-1]))]); cum /= cum[-1]
    for f in range(1, nf + 1):
        u = min(1.0, (f - 1) / (fps * (dur - 1.5)))
        e = float(np.interp(u, U, cum))
        d = e * total
        i = np.searchsorted(s, d); i = min(max(i, 1), len(s) - 1)
        a = (d - s[i - 1]) / max(1e-9, s[i] - s[i - 1])
        p = pts[i - 1] * (1 - a) + pts[i] * a
        cam.location = Vector(p); cam.keyframe_insert('location', frame=f)
    cam.rotation_euler = Euler((math.radians(93), 0, yaw), 'XYZ')
    try:
        for fc in cam.animation_data.action.fcurves:
            for kp in fc.keyframe_points:
                kp.interpolation = 'LINEAR'
    except Exception:
        pass
    scn.camera = cam
    print('giro lunghezza m', round(total, 1))
    # FOTO
    side = np.array([-nc[1], nc[0]])
    def WW(off, lat, z):
        q = pc + nc * off + side * lat
        return (float(q[0]), float(q[1]), z)
    _cam('F1_viale', WW(96, 2.0, 9.0), yaw + math.radians(-1.0), 5.0, 26)
    _cam('F2_arco', WW(14, 1.2, 1.9), yaw + math.radians(-3), 13.0, 28)
    _dF3 = RAMP['d_top'] + 6.0
    _zF3 = -0.4 + (RAMP['d_in'] - _dF3) * (RAMP['z_top'] + 0.4) / (RAMP['d_in'] - RAMP['d_top']) + 1.7
    _cam('F3_scala', W(_dF3 - 51, _zF3), yaw, 20.0, 24)
    _cam('F4_arena', W(dw - 51 - 5.4, zw + 2.7), yaw, -4.0, 20)
    # vista principale da drone 3/4 (come il riferimento: il Colosseo intero col velario)
    q = pc + nc * 170 + side * -120
    yd = math.atan2(-(q[1]), -(q[0])) - math.pi / 2
    _cam('F5_drone', (float(q[0]), float(q[1]), 92.0), yd, -17.0, 30)
    # dall'arena verso il palco imperiale e il velario
    sI, nI = frame(bay_s(60))
    a = sI + nI * -95.0
    yi = math.atan2(nI[1], nI[0]) - math.pi / 2
    _cam('F6_palco', (float(a[0]), float(a[1]), 1.7), yi, 14.0, 24)
    # render: valori di base (il render vero li sovrascrive)
    scn.render.resolution_x = 1920; scn.render.resolution_y = 1080
    scn.view_settings.view_transform = 'AgX'
    try:
        scn.view_settings.look = 'AgX - Medium High Contrast'
        scn.view_settings.exposure = -0.45
    except Exception:
        pass
