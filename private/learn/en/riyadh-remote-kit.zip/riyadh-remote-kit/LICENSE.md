# The Riyadh Remote Kit · Licence

Copyright © 2026 Omnya Lab. All rights reserved.

This licence covers the kit made by Omnya Lab: `server.py`, `monitor.html`, `remote.html`, `config.json`, `tools/prepare_clips.py`, the launchers, `README.md` and the demo clips and pictures in `clips/` and `thumbs/`. One purchase is one licence for one person or one studio.

## You can

- Open, study and modify the code.
- Use it, as it is or modified, with your own clips in your personal projects.
- Use it, as it is or modified, in the work you make for your clients: showrooms, sales galleries, events, presentations, videos and reels. Your clients receive the finished installation or the finished work, not the kit as a product of their own.
- Film it and publish what you film, with no credit required.

## You cannot

- Resell, sublicense, share or give away the kit files, as they are or modified, alone or together with other files.
- Include the kit in a template, an asset pack, a course, a tool or any product whose value is the kit itself.
- Use the demo clips and pictures of the Burj Al Ballur tower in your own commercial work: they are there to show how the kit works. Replace them with your own clips.
- Claim that you wrote the original kit.

## Third-party code

When the big screen is online it loads the qrcode-generator library by Kazuhiko Arase (MIT License) from cdnjs, and the title font from Google Fonts under its own licence. Neither is included in this folder or covered by the terms above.

## No warranty

The kit is provided as it is, without warranty of any kind. Omnya Lab is not liable for any damage that comes from using it.

Questions about a use that is not listed here: info@omnyalab.com
