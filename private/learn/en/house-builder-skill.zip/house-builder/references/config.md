# The config object

Everything about one house lives in `window.BUILD_CONFIG` at the top of `build.js`. The engine below it reads the config once, when the page loads.

| Field | Type | What it does |
|---|---|---|
| `brand` | text | The name top left, at the end, and in the browser tab. Use the user's name exactly as they wrote it. |
| `brandTag` | text | A small word next to the brand, e.g. `Homes`, `Architects`. `''` hides it. |
| `title` | text | The first part of the browser tab title, before the brand. |
| `lang` | text | Page language code, e.g. `en`, `it`, `de`. |
| `mode` | `stills` / `frames` | `stills` fades between one photo per phase. `frames` plays every frame of the clips (needs `frames.js`, made by `tools/make_frames.py frames`). If `frames.js` is empty the page falls back to stills and warns in the console. |
| `stills` | list of paths | The photos in the order of the build, one per phase. Relative to `index.html`. Only used in `stills` mode. |
| `phases` | list | One entry per phase, in order: `tag` (the small label, also shown top right), `a` and `b` (the two lines of the big caption, `b` in the accent colour), `p` (one short sentence). |
| `pxPerPhase` | pixels | `stills`: how much scrolling one phase takes. 700 feels calm; 500 faster. |
| `pxPerFrame` | pixels | `frames`: how much scrolling one frame takes. 9 is the speed of our demo. |
| `zoom` | number | A very slow zoom in along the whole build. 0.035 = 3.5%. 0 for none. |
| `focus` | `[x, y]` from 0 to 1 | Which part of the picture stays on screen when the screen is narrower than the picture (phones). `[0.5, 0.5]` is the centre; `[0.4, 0.5]` keeps more of the left. |
| `hold` | true / false | Shows the "Hold to build" button. Holding it (or the space bar) plays the build forward; releasing stops it. |
| `holdSpeed` | phases per second | `stills`: speed while holding. In `frames` mode a phase takes about 3 seconds. |
| `cta` | `{ label, url }` | The button at the end. `url: ''` hides it. Use only a link the user gave (contact page, WhatsApp, booking or payment link). |
| `ending` | text | The line under the brand at the end. |
| `colors.accent` | hex | Captions, dots, progress bar, buttons. The text on the buttons turns dark or white by itself. |
| `colors.ink`, `colors.bg` | hex | Text colour and the background behind the pictures and the loading screen. |
| `fonts.display`, `fonts.body` | Google Fonts names | Change them here and in the Google Fonts link in `index.html` together. |
| `text` | strings | Every other word on the page (loading, hold button, "or scroll", "Build it again"). Translate them all. |

## Checks in the console

- `house.info()` gives the mode, the number of pictures and phases, the frame where every phase ends and the total scroll length.
- `index.html?f=3` opens the page on picture 3 (in frames mode, on frame 3). Use it to screenshot every phase.
