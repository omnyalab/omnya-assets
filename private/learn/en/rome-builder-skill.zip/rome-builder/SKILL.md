---
name: rome-builder
description: Rebuilds the Omnya Lab "Rome in one shot" film from the Colosseum reel - ancient Rome in 80 AD built in Blender with Python (the Colosseum in real metres, 80 arches on four storeys, the triumphal avenue, the market, chariots, 37,861 buildings, a crowd in the stands), one continuous camera from the sky down the avenue, through gate LII, up the stairs and into the arena where two gladiators fight, then the real photos, the clips, the warm grade, the sound and the 9:16 reels. Use it whenever someone asks for "the Rome film", "build me ancient Rome", "rebuild the Colosseum reel", a historical city or monument flythrough in one shot, a 3D-to-real film like the Colosseum one, or wants to change the Rome scene (another gate, another time of day, another monument) and make their own reel from it.
---

# Rome Builder

You help the user make the Colosseum film from our reel: first the 3D of Rome in Blender (the code is in `blender/`, it already builds the whole city and the camera), then a real photo for every key frame, then the clips that join them, then the grade, the sound and the reels. Everything we used is here: the code, the measures with their sources, every prompt word for word, our 10 approved photos, our final film, and the small tools we used to check each step.

Read `references/how-it-works.md` before you change anything in `blender/`. The code comments are in Italian (it is the code we really used); the files in `references/` explain it in English.

## 1. Ask first, in one short message

Ask what you do not know yet, with a default for each; "use the defaults" gives the exact film from the reel:

1. **The goal**: the same film as the reel (default), or a change (another gate, another light, a different end, another monument with the same method).
2. **Where the photos and clips are made**: Higgsfield (default: Seedream 5.5 for the photos, Kling 4.0 for the clips) or another tool that takes a reference image and start / end frames.
3. **Budget**: on 25/11/2026 a Seedream 5.5 2K photo cost about 3.5 Higgsfield credits, a Kling 4.0 clip 18 credits for 4 s and 22.5 for 5 s. Our film has 10 photos and 8 clips. Prices change: check the estimate in the app before every generation.
4. **The computer**: Blender installed (we used Blender 5.2)? A Mac with Apple Silicon renders EEVEE previews well; the final Cycles frames are faster on an NVIDIA GPU.

Never start a paid generation without saying first what it is, which model and how many credits, and waiting for the user's yes.

## 2. The steps

1. **Build the 3D.** `blender -b --factory-startup --python blender/costruisci.py -- rome.blend` (add `leggero` for a light scene to test the camera quickly, `foto` for the version with the extra detail for the photos). It prints `REGIA` (the key frames of the camera) and writes `rome_conteggio.json` (how many buildings, people, chariots). Then `blender -b rome.blend --python blender/verifica.py -- check.json`: nothing floating, no chariot through a person, the camera never inside a wall.
2. **Check the camera.** `blender -b rome.blend --python blender/anteprima.py -- prev/ 640 8` makes a fast EEVEE preview; turn it into a video with ffmpeg and run `python3 tools/smooth.py preview.mp4`: it must score at least 9 out of 10 before you spend a credit (Kling copies the camera you give it).
3. **The key frames.** Render the start and end frame of every clip from the 3D (`blender/rendi_frames.py`, Cycles, 1920 wide) and the 3D guide video of each outside clip (`blender/rendi.py ... giro`).
4. **One real photo per key frame.** Seedream 5.5, 2K, 16:9, the 3D frame as the only reference, the prompt from `references/prompts.md` (K1-K12). Check every photo with `python3 tools/allineamento.py 3d.jpg photo.png`: under 3.2 px it kept the shape, over 5 px the camera changed and the clip will warp. Then `tools/filtro_film_caldo.py` on every approved photo.
5. **The clips.** Outside (C1-C5): Kling 4.0 video edit with the 3D guide video + start photo + end photo. Inside (E6, X1, X2): image to video WITHOUT the 3D guide (with it, the fighters move like 3D mannequins), start + a middle photo + end for the descent, the start photo alone for the fight. One clip at a time: the next one starts from the real last frame of the one before (`tools/controlla_clip.py` saves it and compares first and last frame with the photos, under ~6 = the same).
6. **Edit.** Put the clips in order at 24 fps. Where Kling slows down to land on the end photo, the film seems to stop: `tools/fix_join.py` measures the speed and keeps fewer frames at the cruising speed (on our film: clip 2, 18 frames became 9). Then `tools/filtro_film_caldo_video.py` for the warm grade.
7. **Sound.** `python3 tools/mix.py sounds/ film.wav --cut 7.67 7.945` (the list of free sounds is in `references/sound.md`), then put it on the film with ffmpeg.
8. **Reels.** `python3 tools/reel_916.py film.mp4 reel.mp4` (the film under a black band for the hook) or with a second file (the 3D on top, the real film below, like our split reel). Hooks, pills and captions go on top in the editing app, never burnt in.

## 3. Rules

- **The 3D decides the shapes, the photo only the look.** Every prompt says what is in the frame and keeps the camera, the size and the place of every building. If a photo drifts, edit the approved photo with the new 3D as a second reference (K12fix), do not reroll from zero.
- **One straight movement per stretch.** No turns while the camera goes forward, turns only while it is still. Score every 3D guide with `smooth.py` first.
- **People are silhouettes.** In the 3D the crowd and the people on the avenue have no faces; in the photos they stay small, moving or in backlight, except the two gladiators.
- **Honest numbers.** The measures in `references/measures.md` come from the sources listed there; what no source gives is marked ESTIMATE. Do not invent new ones: look them up and write the source.
- **Our photos and our film** are in `film/` so the user can see the target and use them for their own demos; they are not for resale on their own.

## 4. Before handing over, check

- [ ] `verifica.py` finds nothing floating and no collisions; `smooth.py` gives the 3D guide 9 or more.
- [ ] Every photo is under 3.2 px on `allineamento.py` and looks like the frame before it (same light, same colours).
- [ ] Every clip starts and ends on its photos (`controlla_clip.py` under ~6) and has no stop at the joins.
- [ ] The sound grows with the camera: wind in the sky, people and chariots in the street, the crowd muffled behind the gate, the roar at the top of the stairs, swords low under the crowd.
- [ ] The reel is clean, with no text burnt in; the hook goes on top in the editing app.
