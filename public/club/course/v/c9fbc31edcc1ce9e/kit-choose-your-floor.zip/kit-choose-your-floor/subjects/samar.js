// SUBJECT · SAMAR, the finished example of the Choose Your Floor kit (open it with index.html?s=samar).
// A concept tower by Omnya Lab: one slim tower, white balcony bands on every floor, flat roof that sticks out, low lit podium, marina with yachts, Dubai Marina on the left.
// Main photo: references/samar-sunset.jpg (= references/samar/main-photo.jpg). Camera and volume were fitted on it: tools/silhouette.py gives 0.907 (aim >= 0.90).
// Every measure is an ESTIMATE (SAMAR is a concept, nothing is published): see references/samar/MEASURES.txt.
// Tour A (TOUR.md): choose the floor → G1 zoom standing still (only the lens), tight on the window of level 15 → G2 straight in, into the living room → G3 turn standing still towards the bathroom door
//   → G4 straight to the bathroom → G5 back out, the tower in front. ?tour=prima = the old tour (G1 opened the lens, G2 from far away, turn and walk in the same move: G3 failed the judge).
// Course states of the apartment (?passo=0|1|3, ?person=1, ?plan=1): see samar-casa.js. Keys of this file are in Italian because the engine reads them:
//   torri = towers, casa.speciale = special floor, esauriti = sold floors, intorno = surroundings, looks = light, riprese = camera shots, stanze = rooms, giri = automatic tours.
import { costruisciSamar } from './samar-kit.js';
import { giroSamar } from './samar-casa.js';

/* camera of the main photo (fit 25/11): 449 m away, three-quarter view (azimuth 25°), at eye height of floor 15 (66.7 m), vertical lens 23.9° */
const CAM0 = { pos: [189.74, 66.7, 406.89], tgt: [155.6, 64.19, 312.93], fov: 23.91 };
/* ?reale=1: the first frame of clip C1 is framed a little differently from the main photo (0.8% wider, 43 px higher, 16 px to the left at 1080p):
   same camera, lens 24.09°, turned 0.36° right and shifted, so the lit floor lands on the floor of photo 1 */
const REALE = new URLSearchParams(location.search).get('reale') === '1';
const CAMR = { pos: CAM0.pos, tgt: [156.19, 64.19, 312.72], fov: 24.088, shift: -0.0396 };

/* ?mod=B.L:30 changes one measure on the fly (silhouette tests) */
const SUB = {}; for (const kv of (new URLSearchParams(location.search).get('mod') || '').split(',').filter(Boolean)) { const [k, v] = kv.split(':'), [id, c] = k.split('.'); (SUB[id] = SUB[id] || {})[c] = +v; }
const mod = o => ({ ...o, ...(SUB[o.id] || {}) });
const CAMQ = (new URLSearchParams(location.search).get('cam') || '').split(',').filter(Boolean).map(Number);   /* ?cam=px,py,pz,tx,ty,tz,fov */
const CAM = CAMQ.length === 7 ? { pos: CAMQ.slice(0, 3), tgt: CAMQ.slice(3, 6), fov: CAMQ[6] } : REALE ? CAMR : CAM0;
const L = 33.82, R = 12.49;

export default {
  id: 'samar', nome: 'SAMAR', valuta: 'AED',
  torri: {
    /* one "stadium" tower (straight sides + round ends), centred on the origin, long axis on x. R = edge of the balconies, glass 2 m behind.
       Podium 9 m, 30 floors of 4 m (levels 1-30), a glass floor on top and the flat roof sticking out 4 m. ESTIMATE from the fit on the main photo */
    lista: [
      mod({ id: 'B', x: -L / 2, z: 0, a: 0, L, R, balcone: 2.0, y0: 9, passo: 4.0, piani: 30, solaio: 0.35, corona: 4.0, tetto: 4.0, setti: false, primo: 1 }),
    ],
    podi: [
      mod({ id: 'PB', x: -L / 2 - 6, z: 0, a: 0, L: L + 12, R: R + 8, livelli: 2, passo: 4.5, seme: 3, bianco: true }),
    ],
  },
  casa: { speciale: { torre: 'B', F: 65.0, nome: 'Majlis Al Bahr', sotto: 'whole floor · sea and marina' } },
  esauriti: { B: [4, 9, 12, 21, 26] },
  aree: { B: 640 },   /* gross m² of a floor: ESTIMATE from the plan (stadium at the glass) */
  palette: 3,
  testi: { torre: 'SAMAR', vista: 'sea and marina view' },
  modello: { colori: { bianco: '#efe9df', sotto: '#b9b1a8', mare: '#3f7a86', terra: '#c9bea9', sabbia: '#e3d3b4', piazza: '#d6ccbb' } },
  intorno: {
    /* the sea behind the tower and on the right, the marina with the yachts in front on the right, the palm promenade along the water (main photo) */
    riva: -34, marina: [20, 210, 40, 170],
    palme: [[-40, 30, 9, 1], [-60, 50, 10, 1.1], [30, 28, 9, 1], [-20, 60, 8, 0.9], [220, 30, 10, 1], [240, 60, 9, 1]],
    nuvole: [], citta: false,
  },
  skyline: { O: [25.0935, 55.1405], burj: [-4015, -5735], zMax: -2500 },   /* Dubai Marina across the water, left of the tower (main photo) */
  costruisci() { return costruisciSamar(this); },
  giroFn: giroSamar,
  inizio: 1,   /* the page opens straight on "choose your floor" over the main photo */
  lookIniziale: 'sera',
  looks: {
    /* evening like the main photo: sun just under the horizon, right, behind the tower; sky blue up high and orange on the sea; windows lit */
    sera: { sole: { alt: 1.5, az: 160, colore: '#ffb27a', forza: 1.4, alone: '#ffab6e', aloneK: 0.6 }, envSole: 1.6, cielo: ['#2f6d9b', '#b8bcc4', '#f2a46c'], orizzonte: 0.22,
      amb: { cielo: '#9fb4c8', terra: '#8a7a6a', forza: 0.9, riflessi: 1.2 }, nebbia: { colore: '#b7c0cb', densita: 0.00005, orizzonte: 0.35 }, esposizione: 1.0, luci: 1.0, fari: 0.6, bloom: [0.35, 0.5, 0.85] },
  },
  riprese: {
    mondo: { pos: CAM.pos, tgt: CAM.tgt, fov: CAM.fov, shift: 0 },
    rif: { pos: CAM0.pos, tgt: CAM0.tgt, fov: CAM0.fov, shift: 0 },
    pianta: { pos: [0, 700, 0], tgt: [0, 0, -0.01], fov: 30 },
  },
  tempi: { g0: 3.0, g1: 4.0, g2: 3.0, g3: 3.6, g4: 4.0 },   /* seconds of each move of the tour (guides between 3 and 4 s) */
  benvenuto: { sopra: 'Welcome to', titolo: 'Majlis Al Bahr', ar: 'مجلس البحر', sotto: 'Level 15 · SAMAR', wf: 'V1',
    schermo: { velo: [2.3, 3.1, 4.4, 5.4], benv: [2.5, 3.1], resto: [2.8, 3.5], via: [4.0, 5.0] } },
  stanze: [
    { id: 'salone', nome: 'The Sea Salon', breve: 'Salon', dir: 'su' },
    { id: 'bagno', nome: 'The Master Bath', breve: 'Bath', dir: 'su' },
    { id: 'fuori', nome: 'SAMAR', breve: 'Tower', dir: 'su' },
  ], fermateStile: 'P2',
  livelli: [
    { id: 'mondo', tipo: 'mondo', titolo: null, bottone: () => ({ testo: 'Choose your floor', id: 'avanti' }) },
    { id: 'piani', tipo: 'piani', titolo: null },
    { id: 'salone', tipo: 'stanza', titolo: null }, { id: 'bagno', tipo: 'stanza', titolo: null }, { id: 'fuori', tipo: 'stanza', titolo: null },
  ],
  giri: {
    A: { look: 'sera', passi: [{ pausa: 0.8 }, { piano: 8, torre: 'B', dur: 0.8, ferma: 0.35 }, { piano: 22, torre: 'B', dur: 0.7, ferma: 0.35 }, { piano: 15, torre: 'B', dur: 0.6, ferma: 0.6, clic: true },
      { pausa: 2.6 }, { bottone: 'liv:3', dur: 0.9, ferma: 0.45, clic: true }, { pausa: 1.8 }, { bottone: 'liv:4', dur: 0.9, ferma: 0.45, clic: true },
      { pausa: 2.0 }, { bottone: 'liv:1', dur: 0.9, ferma: 0.45, clic: true }, { pausa: 1.5 }] },   /* TOUR.md: tower → living room → bathroom → out */
  },
  /* the photoreal version (?reale=1): photos and Kling clips in assets/reale/samar/, played untouched (no recompression).
     Photos are numbered in the order of the tour: 1 tower · 2 the living room seen from the terrace · 3 inside the living room · 4 bathroom.
     Clip N goes from photo N to photo N+1; C4 = the way back out (bathroom → tower) made of the same frames played backwards, never generated again.
     A stop shows its photo; a jump without a clip (e.g. "Choose another floor") is a slow dissolve. The lit floor on photo 1 comes from the 3D. */
  reale: { modulo: 'torre', cartella: 'assets/reale/samar/', luce: 1,
    foto: { piani: '1.jpg', salone: '2.jpg', bagno: '4.jpg', fuori: '1.jpg' }, anticipo: { piani: 0, salone: 0.8, bagno: 0.6, fuori: 0.6 },
    clip: { 'piani>salone': ['clips/C1'], 'salone>bagno': ['clips/C2', 'clips/C3'], 'bagno>fuori': ['clips/C4'] } },
  pannello: true,
  biglietto: false,
};
