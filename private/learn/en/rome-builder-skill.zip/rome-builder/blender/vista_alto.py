# mappa dall'alto (ortografica) per trovare i vuoti + alcuni fotogrammi del giro. blender -b f.blend --python vista_alto.py -- <dir> <scala_m> <fotogrammi,..>
import bpy, sys, os
a = sys.argv[sys.argv.index('--') + 1:]
D, SC = a[0], float(a[1]); FR = [int(x) for x in a[2].split(',')] if len(a) > 2 and a[2] else []
os.makedirs(D, exist_ok=True)
scn = bpy.context.scene
for e in ('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE'):
    try: scn.render.engine = e; break
    except Exception: pass
scn.eevee.taa_render_samples = 8
for k, v in (('use_volumetric_shadows', False), ('volumetric_tile_size', '16'), ('volumetric_end', 1500.0), ('use_raytracing', False)):
    try: setattr(scn.eevee, k, v)
    except Exception: pass
scn.render.image_settings.file_format = 'JPEG'; scn.render.image_settings.quality = 88
cam0 = scn.camera
for f in FR:
    scn.render.resolution_x = 960; scn.render.resolution_y = 540
    scn.frame_set(f); scn.render.filepath = os.path.join(D, f'g_{f:04d}.jpg'); bpy.ops.render.render(write_still=True)
cd = bpy.data.cameras.new('ALTO'); cd.type = 'ORTHO'; cd.ortho_scale = SC; cd.clip_end = 5000
c = bpy.data.objects.new('ALTO', cd); scn.collection.objects.link(c); c.location = (60, 0, 1500); c.rotation_euler = (0, 0, 0)
for o in scn.objects:
    if o.name.startswith(('polvere', 'foschia')):
        o.hide_render = True
scn.camera = c; scn.render.resolution_x = 1600; scn.render.resolution_y = 1600; scn.frame_set(1)
scn.render.filepath = os.path.join(D, 'alto.jpg'); bpy.ops.render.render(write_still=True)
print('FATTO')
