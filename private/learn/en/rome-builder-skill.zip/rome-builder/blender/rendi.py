# blender -b scena.blend --python rendi.py -- <outdir> <camere|giro> <motore EEVEE|CYCLES> <campioni> <larghezza> [frames]
import bpy, sys, os, time
a = sys.argv[sys.argv.index('--') + 1:]
D, CAMS, ENG, S, Wd = a[0], a[1], a[2], int(a[3]), int(a[4])
FR = a[5] if len(a) > 5 else None
scn = bpy.context.scene; os.makedirs(D, exist_ok=True)
if ENG == 'CYCLES':
    scn.render.engine = 'CYCLES'
    pr = bpy.context.preferences.addons['cycles'].preferences
    for t in ('OPTIX', 'CUDA', 'METAL', 'HIP'):
        try:
            pr.compute_device_type = t; break
        except Exception:
            pass
    pr.refresh_devices()
    for d in pr.devices:
        d.use = d.type != 'CPU'
    print('DEVICES', [(d.name, d.type, d.use) for d in pr.devices])
    scn.cycles.device = 'GPU'; scn.cycles.samples = S; scn.cycles.use_denoising = True
    scn.cycles.denoiser = 'OPENIMAGEDENOISE'
    try: scn.cycles.denoising_use_gpu = True
    except Exception: pass
    scn.cycles.max_bounces = 6; scn.cycles.volume_bounces = 1; scn.cycles.transparent_max_bounces = 8
    scn.cycles.use_adaptive_sampling = True; scn.cycles.adaptive_threshold = 0.01
    scn.cycles.volume_step_rate = 4.0
    scn.render.use_persistent_data = True
else:
    for e in ('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE'):
        try:
            scn.render.engine = e; break
        except Exception:
            pass
    ee = scn.eevee
    ee.taa_render_samples = S
    for k, v in (('use_volumetric_shadows', True), ('volumetric_tile_size', '8'), ('volumetric_end', 1200.0), ('use_shadows', True), ('use_raytracing', True)):
        try: setattr(ee, k, v)
        except Exception: pass
scn.render.resolution_x = Wd; scn.render.resolution_y = Wd * 9 // 16; scn.render.resolution_percentage = 100
scn.render.image_settings.file_format = 'JPEG'; scn.render.image_settings.quality = 92
if CAMS == 'giro':
    scn.render.use_motion_blur = True; scn.render.motion_blur_shutter = 0.5
    x, y = map(int, FR.split('-')) if FR else (scn.frame_start, scn.frame_end)
    step = int(a[6]) if len(a) > 6 else 1
    scn.camera = bpy.data.objects['CAM_GIRO']
    for f in range(x, y + 1, step):
        out = os.path.join(D, f'g_{f:04d}.jpg')
        if os.path.exists(out): continue
        t = time.time(); scn.frame_set(f); scn.render.filepath = out
        bpy.ops.render.render(write_still=True); print('FRAME', f, round(time.time() - t, 1), flush=True)
else:
    for c in CAMS.split(','):
        t = time.time()
        scn.camera = bpy.data.objects[c]
        if FR: scn.frame_set(int(FR))
        scn.render.filepath = os.path.join(D, f'{c}.jpg')
        bpy.ops.render.render(write_still=True); print('FOTO', c, round(time.time() - t, 1), flush=True)
