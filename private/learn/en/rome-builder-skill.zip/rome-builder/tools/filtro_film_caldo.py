# filtro_film_caldo.py IN OUT : il caldo «giallino non acceso» del film Blender del Colosseo (Nico 25/11).
# Base filtro leggero (curva 0,08, neri -1%, vibrance +12%) + luce calda sulle zone medie e chiare
# (rosso +4%, verde +1,5%, blu -6% pesati sulla luminosità; ombre quasi neutre), vignetta 8%, grana fine 1,2%, unsharp r2 25%.
import sys
import numpy as np
from PIL import Image, ImageFilter

im = Image.open(sys.argv[1]).convert('RGB')
a = np.asarray(im).astype(np.float32) / 255.0
k = 0.08
a = a + k * (a - 0.5) * (1 - np.abs(2 * a - 1))
a = np.clip((a - 0.01) / (1 - 0.01), 0, 1)
mx, mn = a.max(2, keepdims=True), a.min(2, keepdims=True)
sat = (mx - mn) / (mx + 1e-6)
g = a.mean(2, keepdims=True)
a = g + (a - g) * (1 + 0.12 * (1 - sat))
lum = (0.2126 * a[..., 0] + 0.7152 * a[..., 1] + 0.0722 * a[..., 2])[..., None]
w = np.clip((lum - 0.15) / 0.6, 0, 1)                      # il caldo cresce dalle ombre alle luci
a = a * (1 + w * np.array([0.04, 0.015, -0.06], np.float32))
h, wd = a.shape[:2]
y, x = np.ogrid[:h, :wd]
r = np.sqrt(((x - wd / 2) / (wd / 2)) ** 2 + ((y - h / 2) / (h / 2)) ** 2) / np.sqrt(2)
a = a * (1 - 0.08 * np.clip(r, 0, 1) ** 2)[..., None]
rng = np.random.default_rng(7)
a = a + rng.normal(0, 0.012, a.shape[:2])[..., None].astype(np.float32)
out = Image.fromarray((np.clip(a, 0, 1) * 255 + 0.5).astype(np.uint8))
out = out.filter(ImageFilter.UnsharpMask(radius=2, percent=25, threshold=2))
out.save(sys.argv[2], quality=95)
print(sys.argv[2], out.size)
