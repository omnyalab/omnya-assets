# The sound

Only free sounds, put together by `tools/mix.py`. Download them (Freesound needs a free account; all of these are CC0) and save them in one folder with these names:

| Name | What | Where |
|---|---|---|
| wind.wav | desert / open-air wind | Mixkit, "wind desert" (free licence) |
| tunnel.wav | wind in a tunnel | Mixkit, "wind tunnel" |
| crowd.wav | big stadium crowd | freesound.org/s/829453 |
| roar.wav | roaring crowd | freesound.org/s/130568 |
| market.wav | market crowd | freesound.org/s/173013 |
| street.wav | crowded medieval street | freesound.org/s/424790 |
| cart.wav | horse with an old cart | freesound.org/s/538438 |
| carriage.wav | horse and carriage | freesound.org/s/137843 |
| swoosh.wav | soft swoosh | freesound.org/s/169867 |
| woosh.wav | quick woosh | freesound.org/s/683101 |
| sword.wav | sword swing | freesound.org/s/37596 |
| clash.wav | sword clash | freesound.org/s/471095 |

Then: `python3 tools/mix.py sounds/ film.wav --cut 7.67 7.945` (add `--intro` for the reel that opens on 2 s of the duel) and
`ffmpeg -i film.mp4 -i film.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest film_sound.mp4`.
With these files it gives exactly the sound of our film.

## How it is built (and how to change it)

- Every bed (wind, tunnel, crowd, roar, street, carts) is looped with crossfades, brought to the same loudness, and given a volume curve on the film's seconds (`KEYS`).
- Outside you hear only the street: people talking, horses and carts. The stadium crowd is only inside: muffled behind the gate (a low-pass copy of the same crowd), then full the moment you step out at the top of the stairs, with the roar growing during the descent.
- Three soft swooshes on the big moves (the dive, the descent, the fast zoom). Swords only on the hits of the duel, low under the crowd.
- At the end one loudness curve (`TARGET`, in dB) drives the whole mix, so it grows step by step with the camera and never jumps. Then +6 dB with a limiter.
- A different film: change the seconds in `KEYS`, `TARGET`, the swooshes and `X2` (the frame where the duel starts) to your film's moments.
