---
name: plane-builder
description: Builds a premium flight booking website where visitors pick their own seat on a real-looking airliner - a white jet over the clouds, the fuselage seen from above with four classes that light up, every Economy and Premium seat selectable (booked or available), the ride down to the window view, boarding passes, upgrades class by class up to a private suite. One folder, runs in any browser, goes online for free. Use it whenever someone asks for a flight or airline booking page, a "choose your seat" plane, a seat map for a jet, a private jet or charter booking demo, an interactive airline website, or says "build me the plane booking site from the reel".
---

# Plane Builder

You build a "book your flight, pick your seat" website for one airline, flight or charter, starting from the working site in `assets/template/`. The template already does everything: the plane over the clouds, the four classes lit on hover, every seat with its state, the real camera moves, the tickets, the upgrades, The Residence, the booked screen. Your job is to fit it to the user's brand and flight, check it, and hand over a folder they can put online.

Most builds only touch `config.js` and the words. Change `app.js`, `tickets.js` or `lib.js` only for what the config cannot do, and read `references/customising.md` first.

## 1. Ask first, in one short message

Ask everything you do not know yet in one message, offer a default for each, and say they can answer "use the defaults". Never ask again for something they already said.

1. **Airline or brand name** (what goes on the boarding pass and the page title).
2. **Flight**: from and to (city names and 3-letter airport codes), date, departure and arrival time, duration, flight number.
3. **Prices** for the four classes (Economy, Premium, First, The Residence) and the **currency**.
4. **Class names** if they want their own (for example "Business" instead of "First", "The Apartment" instead of "The Residence").
5. **Brand colour** for the highlight (the template uses orange #ff7a12).
6. **Language** of the page.
7. Optional: a payment or contact link for the final button.

If the first message already gives enough ("Emirates-style booking for Skyline Air, Rome to New York, prices in euros"), do not stop: pick sensible defaults, build, and list the defaults at the end.

## 2. Build

1. **Copy the template.** Copy the whole `assets/template/` folder to a new folder named after the brand in lowercase with dashes, e.g. `skyline-air-booking/`. Never edit the template itself.
   - The photos, clips and glow layers of the plane are already in `assets/template/assets/`: keep them in the copy.
2. **Fill `config.js`** (all fields in `references/config.md`): flight number, date, cities and codes, times, duration, currency and the four prices. Prices are text, written the way they appear on the ticket (`'1,190'`, `'28.000'`).
3. **Brand and words** (`references/customising.md`): the brand name on the passes, the class names, the currency symbol (the template writes `$` in a few places), the highlight colour, and every visible string if the page is not in English. Keep the four class keys `E P F R` in the code; only the labels change.
4. **Look at every step.** Serve the folder (`python3 -m http.server 5313` inside it, or the Start file) and open `http://localhost:5313`. With a browser tool, screenshot: the intro card, the plan with each class hovered, Economy with a free and a booked seat, the ticket, an upgrade, First, The Residence, the booked screen. Then click the real flow once: Book a flight, Economy, a seat, Book seat, Choose another seat, then the upgrades up to The Residence. Check the console has no errors.

## 3. Rules

- **One folder, no build step.** Plain HTML, JS and the `assets/` folder. No npm, no bundler, no framework.
- **It must run from a server.** Browsers block the videos and `seats.json` from `file://`. The template ships Start (Mac) and Start (Windows); online hosting is a server too.
- **Keep the file names and sizes in `assets/`.** The code loads `s_*.jpg`, `f_*.jpg`, `*.mp4` and the `*.png` layers by name, all 1920x1080. If the user brings their own plane, follow `references/your-own-plane.md`.
- **Honest data.** Booked and free seats come from `assets/seats.json` and are sample data. The page does not take payments: the last button only opens a link the user owns. Say so in the hand-over.
- **No names you were not given.** Use only the user's brand, flight and prices. Do not put real airline names, logos or trademarks on the page unless the user says they own them.

## 4. Before handing over, check

- [ ] Every price on the intro card, the class tickets and the boarding pass matches `config.js`, with the right currency.
- [ ] The brand name and class names are the user's everywhere, and every visible word is in the user's language.
- [ ] The highlight colour shows on the plan, the chosen seat and the buttons, and is different from the red "Booked".
- [ ] Booked seats shake and say Booked, free seats say Available and go down to the window.
- [ ] R starts again from the beginning; Choose another seat goes back to the plan.
- [ ] No errors in the console.

## 5. Put it online for free

Tell the user these steps in plain words:

**Netlify Drop:** go to app.netlify.com/drop, drag the whole folder (the one with `index.html`) onto the page, and in a few seconds there is a link. Sign in with a free account to keep it and rename it.

**Vercel:** sign in at vercel.com, Add New, Project, drag the folder (or import it from GitHub). Framework "Other", no build command. Deploy.
