#!/usr/bin/env python3
"""
Riyadh Remote Kit - the server.

A small server written only with Python's standard library: nothing to install.
It serves the big screen (/), the phone remote (/remote) and relays commands in real time over a WebSocket (/ws).
  remote  -> big screen : the commands (go to a view, change the light, orbit, zoom)
  big screen -> remotes : the state (where the camera is, light, zoom), so the phone lights up the right buttons

Run it:   python3 server.py              (Windows: py server.py)
Options:  python3 server.py --port 6000  use another port
          python3 server.py --no-browser do not open the big screen automatically
The port can also be set in config.json ("port") or with the PORT environment variable.
If the port is busy, the next free one is used and printed.
"""
import asyncio, base64, hashlib, json, mimetypes, os, socket, struct, sys, threading, webbrowser
from urllib.parse import urlsplit, parse_qs, unquote

ROOT = os.path.dirname(os.path.abspath(__file__))
PAGES = {'/': 'monitor.html', '/monitor': 'monitor.html', '/remote': 'remote.html', '/r': 'remote.html'}
GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11'
mimetypes.add_type('video/mp4', '.mp4')
mimetypes.add_type('application/json', '.json')
mimetypes.add_type('text/javascript', '.js')

monitors, remotes = set(), set()
last_state = None
PORT = 5377


def read_port():
    args = sys.argv[1:]
    if '--port' in args:
        try:
            return int(args[args.index('--port') + 1])
        except (IndexError, ValueError):
            pass
    if os.environ.get('PORT', '').isdigit():
        return int(os.environ['PORT'])
    try:
        with open(os.path.join(ROOT, 'config.json'), encoding='utf-8') as f:
            return int(json.load(f).get('port', 5377))
    except Exception:
        return 5377


def lan_ip():
    """The address of this computer on the local network (Wi-Fi or cable). Nothing is sent anywhere."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('10.255.255.255', 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return '127.0.0.1'


def phone_link():
    return f'http://{lan_ip()}:{PORT}/remote'


# ---------------- WebSocket (RFC 6455, text frames only) ----------------
def frame(text):
    data = text.encode()
    n = len(data)
    if n < 126:
        head = struct.pack('!BB', 0x81, n)
    elif n < 65536:
        head = struct.pack('!BBH', 0x81, 126, n)
    else:
        head = struct.pack('!BBQ', 0x81, 127, n)
    return head + data


async def read_frame(r):
    b1, b2 = await r.readexactly(2)
    op = b1 & 0x0F
    n = b2 & 0x7F
    if n == 126:
        n = struct.unpack('!H', await r.readexactly(2))[0]
    elif n == 127:
        n = struct.unpack('!Q', await r.readexactly(8))[0]
    mask = await r.readexactly(4) if b2 & 0x80 else None
    data = await r.readexactly(n) if n else b''
    if mask:
        data = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
    return op, data


async def send(w, text):
    try:
        w.write(frame(text))
        await w.drain()
    except Exception:
        pass


def broadcast(group, text):
    for w in list(group):
        try:
            w.write(frame(text))
        except Exception:
            group.discard(w)


def count():
    broadcast(monitors, json.dumps({'t': 'remotes', 'n': len(remotes)}))


async def websocket(r, w, headers, role):
    global last_state
    key = headers.get('sec-websocket-key', '')
    accept = base64.b64encode(hashlib.sha1((key + GUID).encode()).digest()).decode()
    w.write(('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n'
             f'Sec-WebSocket-Accept: {accept}\r\n\r\n').encode())
    await w.drain()
    sock = w.get_extra_info('socket')
    if sock is not None:
        try:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)  # minimum delay: every command leaves at once
        except OSError:
            pass
    group = monitors if role == 'monitor' else remotes
    group.add(w)
    if role == 'monitor':
        await send(w, json.dumps({'t': 'link', 'url': phone_link()}))
    elif last_state:
        await send(w, last_state)
    count()
    try:
        while True:
            op, data = await read_frame(r)
            if op == 0x8:          # close
                break
            if op == 0x9:          # ping -> pong
                w.write(struct.pack('!BB', 0x8A, len(data)) + data)
                continue
            if op != 0x1:
                continue
            text = data.decode('utf-8', 'replace')
            if role == 'monitor':
                last_state = text
                broadcast(remotes, text)
            else:
                broadcast(monitors, text)
    except Exception:
        pass
    finally:
        group.discard(w)
        count()
        try:
            w.close()
        except Exception:
            pass


# ---------------- files (with Range requests, so videos can be scrubbed) ----------------
async def serve_file(w, path, headers, head_only):
    try:
        size = os.path.getsize(path)
    except OSError:
        return await reply(w, 404, b'not found', 'text/plain')
    ctype = mimetypes.guess_type(path)[0] or 'application/octet-stream'
    if path.endswith('.html'):
        ctype = 'text/html; charset=utf-8'
    elif path.endswith('.json'):
        ctype = 'application/json; charset=utf-8'
    start, end, status = 0, size - 1, 200
    rng = headers.get('range', '')
    if rng.startswith('bytes='):
        try:
            p0, p1 = rng[6:].split(',')[0].split('-')
            if p0:
                start = int(p0)
                end = int(p1) if p1 else size - 1
            else:
                start = max(0, size - int(p1))
            end = min(end, size - 1)
            status = 206
        except Exception:
            start, end, status = 0, size - 1, 200
    n = end - start + 1
    head = [f'HTTP/1.1 {status} {"Partial Content" if status == 206 else "OK"}', f'Content-Type: {ctype}',
            f'Content-Length: {n}', 'Accept-Ranges: bytes', 'Cache-Control: no-store', 'Connection: close']
    if status == 206:
        head.append(f'Content-Range: bytes {start}-{end}/{size}')
    w.write(('\r\n'.join(head) + '\r\n\r\n').encode())
    if not head_only:
        with open(path, 'rb') as f:
            f.seek(start)
            left = n
            while left > 0:
                chunk = f.read(min(1 << 20, left))
                if not chunk:
                    break
                w.write(chunk)
                left -= len(chunk)
                await w.drain()
    await w.drain()


async def reply(w, status, body, ctype):
    w.write((f'HTTP/1.1 {status} OK\r\nContent-Type: {ctype}\r\nContent-Length: {len(body)}\r\n'
             'Cache-Control: no-store\r\nConnection: close\r\n\r\n').encode() + body)
    await w.drain()


async def client(r, w):
    try:
        line = (await r.readline()).decode('latin-1').strip()
        if not line:
            return
        method, url, _ = (line.split(' ') + ['', ''])[:3]
        headers = {}
        while True:
            l = (await r.readline()).decode('latin-1')
            if l in ('\r\n', '\n', ''):
                break
            if ':' in l:
                k, v = l.split(':', 1)
                headers[k.strip().lower()] = v.strip()
        u = urlsplit(url)
        route = unquote(u.path)
        if route == '/ws' and headers.get('upgrade', '').lower() == 'websocket':
            role = parse_qs(u.query).get('role', ['remote'])[0]
            return await websocket(r, w, headers, 'monitor' if role == 'monitor' else 'remote')
        if route == '/link':
            return await reply(w, 200, json.dumps({'url': phone_link()}).encode(), 'application/json')
        name = PAGES.get(route, route.lstrip('/'))
        path = os.path.normpath(os.path.join(ROOT, name))
        # only files inside the kit folder, never hidden files or the server itself
        if not path.startswith(ROOT + os.sep) or os.path.basename(path).startswith('.') or path.endswith(('.py', '.command', '.bat')):
            return await reply(w, 404, b'not found', 'text/plain')
        await serve_file(w, path, headers, method == 'HEAD')
    except (asyncio.IncompleteReadError, ConnectionError):
        pass
    except Exception as e:
        print('error:', e, file=sys.stderr)
    finally:
        try:
            w.close()
        except Exception:
            pass


async def main():
    global PORT
    first = read_port()
    server = None
    for p in range(first, first + 20):
        try:
            server = await asyncio.start_server(client, '0.0.0.0', p)
            PORT = p
            break
        except OSError:
            print(f'  Port {p} is busy, trying {p + 1}...', flush=True)
    if server is None:
        print(f'\n  Could not find a free port between {first} and {first + 19}. Start with: python3 server.py --port 7000\n')
        return
    big = f'http://localhost:{PORT}/'
    print('\n  REMOTE KIT IS RUNNING\n'
          f'\n  Big screen (this computer):   {big}'
          f'\n  Phone (same Wi-Fi):           {phone_link()}'
          f'\n  Remote on this computer:      http://localhost:{PORT}/remote'
          '\n\n  On the big screen press F for full screen, Q to show or hide the QR code.'
          '\n  To stop: close this window or press Ctrl+C.\n', flush=True)
    if '--no-browser' not in sys.argv:
        threading.Timer(0.6, lambda: webbrowser.open(big)).start()
    async with server:
        await server.serve_forever()


if __name__ == '__main__':
    if sys.version_info < (3, 7):
        sys.exit('Python 3.7 or newer is needed. Download it from python.org')
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
