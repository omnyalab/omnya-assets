# Colosseo (Anfiteatro Flavio), 80 d.C. — misure usate nel 3D

Fonti (lette il 24/11/2026):
- TC-D https://the-colosseum.net/wp/en/description/
- TC-N https://the-colosseum.net/wp/en/numbers/
- UC  https://penelope.uchicago.edu/encyclopaedia_romana/romanurbs/colosseum.html
- ARL https://ancientromelive.org/colosseum-flavian-amphitheatre/ (testo di Platner & Ashby 1929)
- WH  https://www.worldhistory.org/Colosseum/
- ST  https://structurae.net/en/structures/colosseum
- Britannica https://www.britannica.com/topic/Colosseum
- Colosso di Nerone https://en.wikipedia.org/wiki/Colossus_of_Nero
- Meta Sudans https://en.wikipedia.org/wiki/Meta_Sudans

| Misura | Valore usato | Fonte | Note |
|---|---|---|---|
| Asse lungo esterno | **188 m** | TC-N, TC-D, ARL | UC e WH dicono 189: differenza 0,5% |
| Asse corto esterno | **156 m** | TC-D, TC-N, ARL, WH | |
| Perimetro esterno | **545 m** | ARL, UC | nel 3D: 80 campate uguali da 6,81 m |
| Altezza totale con attico e cornici | **48,5 m** | TC-D, TC-N, ARL | altre fonti 48 m (Nico) o 45 m |
| Ordini | **4**: 3 arcate + attico | tutte | |
| Ordine 1 / 2 / 3 / attico | **Tuscanico (dorico) / Ionico / Corinzio / lesene corinzie** | TC-D, ARL, UC | TC-D dice tuscanico, ARL dorico: stessa cosa a quella scala |
| Archi per piano | **80** | TC-D, TC-N, UC, ARL | |
| Archi numerati | **76** (I–LXXVI) + **4** ingressi assiali senza numero | TC-D, UC, ARL | i numeri sono incisi sopra l'arco: oggi si vede da XXIII a LIV |
| Arco piano terra | **4,20 × 7,05 m** | TC-D, TC-N, ARL | |
| Archi 2° e 3° piano | **4,20 × 6,45 m** e **4,20 × 6,40 m** | TC-D, ARL | |
| Pilastro | **2,40 m largo, 2,70 m profondo** | ARL | 4,20 + 2,40 = 6,60 m di interasse; noi 6,81 per chiudere i 545 m |
| Trabeazione 1° piano | 2,35 m | ARL | |
| Piedistallo/attico tra 1° e 2° | 2,35 m | ARL | |
| Trabeazione 2° piano | 2,10 m | ARL | |
| Piedistallo tra 2° e 3° | 1,95 m | ARL | |
| Piedistallo sopra il 3° | 2,10 m | ARL | |
| Quota cornici 10,5 / 22,3 / 33,6 / 48,5 m | **STIMA** | ricavata dalle misure ARL sopra (arco + reni + trabeazione) | nessuna fonte dà le quote dei piani |
| Attico | finestrella ogni 2 campate, **scudi di bronzo dorato** fra le finestre, **3 mensole** per campata | ARL, UC, TC-D | |
| Pali del velario | **240** nelle mensole, attraverso la cornice | TC-D, TC-N, UC, Britannica | colore del telo NON noto (STIMA: lino naturale a spicchi) |
| Statue | una statua in ogni arco del 2° e 3° piano | ARL | «dei e imperatori», dipinte (TC-D) |
| Colori | muri dipinti bianco e rosso, passaggi stuccati e dipinti, marmo al podio | TC-D | |
| Arena | **86 × 54 m** | ARL (Platner) | WH/ST 87,5 × 54,8; TC 76 × 44 (probabilmente senza il podio) |
| Podio sopra l'arena | **3,6 m** | TC-N | ARL ~4 m |
| Pendenza gradinate | **37°** | TC-D, TC-N | |
| File | maenianum primum ~20 file, secundum ~16 + 16 | ARL | |
| Spettatori | 50.000–75.000 (~65.000) | TC-D, ARL | nel 3D ~45.000 figure |
| Muri anulari interni | a 5,8 m e 4,5 m dal precedente | ARL | |
| Lastricato in travertino intorno | **17,5 m** | ARL | |
| Cippi (paracarri) | sul bordo esterno del lastricato, forse 80 | UC, ARL | |
| Orientamento | asse lungo ~WSW–ENE | TC-D | ingresso trionfale a ovest-nordovest |
| Materiali | travertino fuori (45.000 m³), tufo e mattoni dentro, volte in calcestruzzo | TC-D, TC-N | |

## Cosa NON c'era nell'80 d.C. (errori da non fare)
- **Arco di Costantino**: 315 d.C. → non si mette.
- **Arco di Tito**: dopo la morte di Tito (81 d.C.) → non si mette.
- **Meta Sudans** flavia: 89–96 d.C. → non si mette.
- **Tempio di Venere e Roma**: 121 d.C. → non si mette.
- **Ludus Magnus** (Domiziano) → non si mette.
- C'era il **Colosso di Nerone** (~30 m, bronzo), ma nel vestibolo della Domus Aurea sulla Velia, non accanto al Colosseo (lo sposta Adriano nel 128). Lontano a ovest, solo come sagoma.
- Le **Terme di Tito** si inauguravano nello stesso 80 d.C., sul colle Oppio a nord.
- Il riferimento di Gladiator II (colonne con aquile d'oro, scritta HAEC EST GLORIA ROMAE) è del film: si prende solo luce e polvere.
