# Customising beyond config.js

## Where the words are
- `app.js` line `const CLS = {...}`: the class titles, names and "seats left" pills shown on the plan.
- `app.js`: the intro card (`'Book a flight'`, `'Non-stop'`, `'Wide-body'`, `'334 seats'`, `'Choose any seat on board'`, `'Your flight is ready'`, `'Any time'`), the plan title (`'Choose your class'`, `'Choose your seat'`), `'Book seat '`, `'Booked'`, `'Available'`, `'You are booked'`, `'Your bedroom'`, `'Bedroom'`, `'Suite'`, `'Apartment'`.
- `lib.js` the object with `K2 K3 K5 K6`: the big titles that appear as the camera arrives in each class (number, name, layout and "From" price).
- `tickets.js`: the boarding pass (`'Boarding pass'`, `'Passenger'`, `'Seat'`, `'Gate'`, `'Boards'`, `'Zone'`, `'Scan at gate'`, `'Seat map'`, `'Taken'`).
Search for the English string and replace it; keep the quotes and the code around it.

## Currency symbol
The template writes `'$'` next to the prices in `app.js` (the intro classes) and `lib.js` (the class titles). Replace it with the user's symbol, or put the symbol in front of the numbers in `config.js` and remove the `'$'` from the code.

## Brand name
Put the brand on the boarding pass header in `tickets.js` and in `<title>` in `index.html`.

## Highlight colour
The orange is `#ff7a12` (and the hover `#ff8a2e`) in `lib.js` (`ORC`), `tickets.js` (`TK_C.or`) and `app.js`. Replace all of them with the brand colour and a slightly lighter hover. The orange glow on the plan comes from the PNG layers in `assets/` (`K1_E.png` and the others): to recolour them, change their hue with any image tool, keep size and transparency.

## Final button
In `app.js`, on the booked screen, add a link to the user's payment or contact page if they gave one. Never fake a payment.
