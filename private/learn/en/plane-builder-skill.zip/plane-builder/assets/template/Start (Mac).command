#!/bin/zsh
# The 3D Plane · pick your seat. Double click: starts a small local server and opens the page.
# On the page: R starts again. To stop the server: double click "Stop (Mac).command".
cd "$(dirname "$0")"
PORT=5313
URL="http://localhost:$PORT/"
if ! lsof -ti tcp:$PORT >/dev/null 2>&1; then
  nohup python3 -m http.server $PORT --bind 127.0.0.1 >/dev/null 2>&1 &
fi
for i in {1..50}; do curl -s -o /dev/null "$URL" && break; sleep 0.2; done
if ! curl -s -o /dev/null "$URL"; then
  echo "The server did not start. Check that python3 is installed (type: python3 --version)."
  read -k1 "?Press a key to close"; exit 1
fi
open "$URL"
echo "The plane is open in your browser. You can close this window."
