PLANE BUILDER · a skill for Claude · Omnya Lab

What it does
Ask Claude "build me the plane booking site for my airline" and it builds the flight booking site from our reels with your
brand, your flight, your prices and your words: the plane over the clouds, the four classes, every seat you can pick, the ride
down to the window, the boarding passes and the upgrades up to The Residence.

Install
- Claude Code: unzip this into ~/.claude/skills (you get ~/.claude/skills/plane-builder/SKILL.md), start Claude Code in an
  empty folder and ask for your plane.
- claude.ai (Pro): keep the zip you downloaded (plane-builder-skill.zip) as it is, do not unzip it. Check that "Create and
  edit files" is on in Settings > Capabilities (older screens call it "Code execution and file creation"). Then in the menu
  on the left click Plugins, then Add (top right) > Upload plugin, choose the zip, click Upload, and ask for your plane in
  a new chat.
  (Older screens: Settings > Capabilities > Skills > Upload skill, same zip.)
- On a Mac, download the zip with Chrome: Safari unzips downloads by itself and deletes the zip. If you only have a folder
  called plane-builder, that folder is what Claude Code needs; for claude.ai right-click it, choose Compress "plane-builder"
  and upload the new plane-builder.zip.

The site it gives you is one folder. Open it with Start (Mac) or Start (Windows), or put it online for free with Netlify Drop
(app.netlify.com/drop) or Vercel: the steps are at the end of SKILL.md.

What is inside
SKILL.md (what Claude does), references/ (every field and how to change words, colours and the plane), assets/template/ (the
working site with the real photos and clips of our plane).

Omnya Lab · omnyalab.com
