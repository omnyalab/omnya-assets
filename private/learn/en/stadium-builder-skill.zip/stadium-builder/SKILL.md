---
name: stadium-builder
description: Builds a complete one-folder website with a 3D stadium or arena in three.js where visitors choose their seat - a plan from above with stands and prices, a zoom into a stand, its blocks, one single seat with the view from it, an offer to upgrade to a VIP box, and a ticket summary. Works on phones, needs no build step and goes online for free. Use it whenever someone asks for a stadium, arena, ballpark, court, padel or tennis club, concert venue or theatre where people pick a seat in 3D, a "choose your seat" or seat map page, an interactive 3D venue for a club, a ticketing demo, or a 3D stadium website, even if they only say "build me a stadium for my club".
---

# Stadium Builder

You build a 3D "choose your seat" website for one venue, starting from the working template in `assets/template/`. The template already does everything: the stadium in three.js with every seat as one instance, the five steps of the choice, the ticket, phone layout, loading screen. Your job is to fit it to the user's venue by editing the config object, check it, and hand over a folder they can put online.

Most builds only touch `window.STADIUM_CONFIG` at the top of `stadium.js`. Change the engine only when the user asks for something the config cannot do, and then read `references/customising.md` first.

## 1. Ask first, in one short message

Before building, ask the user for what you do not already know. Ask everything in one message, offer a default for each, and say they can answer "use the defaults". Do not ask again for anything they already said.

1. **Name** of the club or venue, and a short version for the LED boards.
2. **City** (used for the page description and to suggest surroundings: park, city or desert).
3. **Sport or use**: football, basketball, tennis, padel, or none (concerts, events). This sets the field.
4. **Colours**: the seats (one or two colours) and the brand colour. Suggest an accent for the highlight that stands out from both.
5. **Size**: small (about 5,000), medium (about 20,000), huge (50,000 to 110,000), or an exact number.
6. **Prices**: currency, and either one price per stand or a cheap / mid / premium level you can spread over the stands. The VIP upgrade price.
7. **Language** of the page.
8. Optional: the event on the ticket (title, date, time), sponsor names for the boards, a payment link for the Confirm button, day or sunset or night.

If the user gave enough in the first message (for example "a 20,000-seat basketball arena for the Lisbon Lions, black and gold, prices in euros"), do not stop to ask: pick sensible defaults for the rest, build, and list the defaults you chose at the end so they can change them.

## 2. Build

1. **Copy the template.** Copy the whole `assets/template/` folder to a new folder named after the venue in lowercase with dashes, e.g. `lisbon-lions-arena/`. It holds `index.html`, `stadium.js` and `ui.css`. Never edit the template itself.
   - On claude.ai (no local terminal), create the same three files in your sandbox with the template's content and give them back as a zip at the end.
2. **Fill the config** at the top of `stadium.js`. Every field is in `references/config.md`. In order:
   - `name`, `shortName`, `event`, `lang`, `locale`, `currency`. Use the name exactly as the user wrote it ("Lisbon Lions", not an invented "Lisbon Lions Arena"). `locale` = page language + the venue's country, e.g. English page in Portugal with euros = `en-IE` style `€85`, Italian page = `it-IT` (`85 €`).
   - `field`, then `tiers` (rows per tier) for the capacity. Use the capacity table in `references/config.md` as a starting point.
   - `colors`, `roof`, `scoreboard`, `surroundings`, `look`. Arenas usually want `roof: 'closed'` and `scoreboard: 'center'`; open stadiums `roof: 'ring'` and `scoreboard: 'ends'`.
   - Colours with two brand colours: the highlight (`accent`) must not be one of the seat colours, or a chosen seat disappears among the others. For "black and gold", make the seats black (`seat2: ''`), the bands gold (`brand`) and the highlight a bright gold (`accent`). For "green and white", seats green with a little white (`seat2`) and an accent that is neither (for example orange or yellow).
   - `zones` with names and prices, clockwise from the north long side. 8 zones = 4 sides and 4 corners, 4 zones = the 4 sides. Mark one as `soldOut: true` only if the user wants that.
   - `vip` name, upgrade price and perks. `boards`, `checkoutUrl` if given.
   - Translate every string in `text` if the page is not in English.
3. **Check the capacity.** Serve the folder (see step 4) and read the `stadium ready` line in the console, or run `stadium.info()`. Adjust `rows` until `seats` is within about 5% of the target. Tell the user the real number. Never claim a capacity you did not measure.
4. **Look at every step.** Serve the folder locally, e.g. `python3 -m http.server 8080` inside it, and open:
   - `index.html?step=plan`, `?step=zone`, `?step=pick`, `?step=seat`, `?step=upgrade`, `?step=ticket` (and `?step=vip` for the VIP ticket),
   - at phone size (390 x 844) and desktop size (1440 x 900).
   With a browser tool, screenshot each one. Without one, at least load the page in headless Chrome and check the console has the `stadium ready` line and no errors. Then click through the real flow once: tap a stand, a block, a seat, Take this seat, Continue, Upgrade, Confirm.

## 3. Rules

- **One folder, no build step.** Three files: `index.html`, `stadium.js`, `ui.css`. No npm, no bundler, no framework. Images you add go in the same folder with relative paths.
- **three.js from the CDN, pinned.** Keep the import map on `three@0.160.0` from jsDelivr. Do not use `latest` or an unpinned version, and do not switch to another library. The page needs internet only for that file; everything else is local.
- **The engine is a plain script.** `stadium.js` is loaded with a normal `<script>` and receives three.js from the small module in `index.html`. Keep it that way: it is what lets the page also open with a double click on many setups. Do not turn `stadium.js` into an ES module with imports.
- **Phone first.** Every control is at least 44 px tall, the sheet sits at the bottom within thumb reach, nothing needs hover. On a phone the first tap on a block selects it and shows its price, the second tap (or the button) goes in. Check the phone screenshots before the desktop ones.
- **Performance limits.** All seats stay in one `InstancedMesh`; never create one mesh per seat. Keep the pixel ratio capped (2 on desktop, 1.5 on phones, already in the engine). Do not raise the shadow map above 4096 or add real-time lights per seat. Up to about 120,000 seats is tested; above that, warn the user about older phones and suggest `quality: 'low'`.
- **Honest data.** Prices, free seats and sold-out blocks are sample data generated from the config, the same on every load. Keep `text.note` on the ticket unless the user connects real data. There is no booking or payment inside the page; `checkoutUrl` only hands the choice to a payment link the user owns.
- **No names you were not given.** Use the user's venue, club and sponsor names only. Do not invent sponsors, players, capacities, records or event dates. If the user has no event yet, keep a neutral title like "Opening night" or leave it empty.
- **Keep the user's brand out of trouble.** Do not use logos or trademarks of other clubs, leagues or sponsors unless the user says they own them or have permission.

## 4. Before handing over, check

- [ ] Console shows `stadium ready` with the seat count, and no errors.
- [ ] All six steps look right on phone and desktop: labels readable and not on top of each other, the sheet not covering the chosen seat, the ticket fits the screen.
- [ ] The highlight colour is clearly visible on the seats and different from the taken grey.
- [ ] With `look: 'night'` or a closed roof, the field is not blown out to white and its lines are readable in the seat view.
- [ ] Prices use the right currency and format; the zone "from" prices match the tiers.
- [ ] The VIP view shows the box and the field, the VIP ticket shows the upgrade in the total.
- [ ] Back button and Esc go one step back; "Choose another seat" goes to the plan.
- [ ] Every visible word is in the user's language.
- [ ] Seat count told to the user is the measured one.

## 5. Put it online for free

Tell the user these steps in plain words (they are in the user's language if the page is):

**Netlify Drop (no account needed to try, free account to keep it):**
1. Go to app.netlify.com/drop.
2. Drag the whole folder (the one with `index.html` inside) onto the page.
3. In a few seconds you get a link like `something.netlify.app`. Sign in with a free account to keep it online and to rename it.

**Vercel (free Hobby account):**
1. Sign in at vercel.com and choose Add New, then Project.
2. Drag the folder onto the upload area (or push it to a GitHub repository and import it).
3. No settings to change: framework "Other", no build command. Deploy, and the link is ready.
4. If the dashboard does not offer a folder upload, run `npx vercel` inside the folder (it asks to log in once) or push the folder to GitHub and import it.

Both give HTTPS, which phones need. To update later, drag the folder again (Netlify: Deploys, then drag; Vercel: a new deployment). A custom domain can be added in either dashboard.

## 6. More, only when asked

- Change the shape, colours of parts, add sponsor boards, add a logo, change camera views: `references/customising.md`.
- Turn frames of the 3D into realistic stills for posts or a landing page: `references/photoreal.md`.
- What every config field does: `references/config.md`.

## What to say at the end

Short and concrete: the folder name, the measured seat count, the stands and prices, the defaults you chose that the user did not specify, how to open it locally, and the free publishing steps. Attach or show two or three screenshots (plan, seat view, ticket) if you have them.
