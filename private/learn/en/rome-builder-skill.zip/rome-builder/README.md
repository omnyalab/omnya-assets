# The Rome Builder skill · Omnya Lab

Ask Claude "build me ancient Rome" and it walks you through the film from our Colosseum reel, on your computer: Rome in 80 AD built
in Blender with Python, one camera from the sky down the triumphal avenue, through gate LII, up the stairs and into the arena where two
gladiators fight, then a real photo for every key frame, the clips that join them, the warm grade, the sound and the reels.
Built with Claude Code.

## Install

**Claude Code:** unzip this into `~/.claude/skills` (you get `~/.claude/skills/rome-builder/SKILL.md`), start Claude Code in an empty
folder and ask "build me ancient Rome like the Colosseum reel".

**claude.ai (Pro and up):** keep the zip you downloaded (`rome-builder-skill.zip`) as it is, do not unzip it. Check that "Create and
edit files" is on in Settings > Capabilities (older screens: "Code execution and file creation"). Then in the menu on the left click
Plugins, then Add (top right) > Upload plugin, choose the zip, click Upload, and ask in a new chat. (Older screens: Settings >
Capabilities > Skills > Upload skill, same zip.) On claude.ai Claude can read the code, the prompts and the photos and plan with you;
Blender runs on your own computer, so for the 3D use Claude Code.

**On a Mac, download the zip with Chrome:** Safari unzips downloads by itself and deletes the zip. If you only have a folder called
`rome-builder`, that folder is what Claude Code needs; for claude.ai right-click it, choose Compress "rome-builder" and upload the new zip.

## What you need

- Blender (free, blender.org; we used 5.2), Python 3 with numpy, Pillow and opencv-python (`pip3 install numpy pillow opencv-python`), ffmpeg.
- For the photos and the clips: an image model that takes a reference image (we used Seedream 5.5 on Higgsfield) and a video model
  with start and end frames (we used Kling 4.0 on Higgsfield). These are paid; Claude tells you the cost before every generation.

## What is inside

- `SKILL.md` what Claude does, step by step.
- `blender/` the code of the 3D: `costruisci.py` builds everything (the Colosseum from `geo.py`, the city `roma.py`, the avenue
  `viale.py`, the market `mercato.py`, the procession and the gladiators `corteo.py`, the crowd `folla.py`, the camera `regia.py`),
  plus the render, preview and check scripts. `MISURE.md` is our measures table with every source (in Italian; English in
  `references/measures.md`). The comments in the code are in Italian: it is the code we really used.
- `tools/` the checks and the post: `smooth.py` (is the camera smooth?), `allineamento.py` (did the photo keep the 3D?),
  `controlla_clip.py` (does the clip start and end on its photos?), `fix_join.py` (no stops at the joins), `filtro_film_caldo.py`
  and `filtro_film_caldo_video.py` (the warm grade), `mix.py` (the sound), `reel_916.py` (the 9:16 reels).
- `references/` how it works, every prompt word for word (`prompts.md`, `prompts.json`), the measures, the sound, the checks, how to change it.
- `film/` our 10 approved photos (`photos/`) and our final film with its sound (`rome_film_16x9.mp4`, 1080p, 24 fps, 31.9 s).

## Good to know

- The measures of the Colosseum come from the sources in `references/measures.md`; where no source gives a number it says ESTIMATE.
  The city around it is placed from real maps with about 50 m precision (ESTIMATE).
- The sounds are not in the zip: `references/sound.md` lists the free ones we used (Freesound CC0 and Mixkit) and their names.
- Our photos and our film are there to show you the target and for your own demos; do not resell them on their own.

Omnya Lab · omnyalab.com
