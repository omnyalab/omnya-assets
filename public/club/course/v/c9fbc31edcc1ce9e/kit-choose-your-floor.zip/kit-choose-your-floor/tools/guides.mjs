// guides.mjs · the guide videos of a tour (step 7). Records the tour frame by frame (24 fps, 1920x1080) into one mp4, notes when the camera moves,
// then cuts every move into guides/G1.mp4, G2.mp4 … and saves the first and the last frame of each one: frames/G1-start.png, frames/G1-end.png …
// A move made of several stretches that stop (path keys with zero speed) becomes several guides. Moves shorter than 0.5 s (UI jumps) are dropped.
// Needs Node 22+, Chrome, ffmpeg and the kit server running (Start). Use the clean page (&clean=1) and &rec=1.
// node tools/guides.mjs [guides folder] [frames folder] ["url"] [tour]
// default: node tools/guides.mjs guides frames "http://127.0.0.1:5320/?s=my-tower&clean=1&rec=1" A
// Then judge them: python3 tools/smooth.py guides/G*.mp4
import { spawn, spawnSync } from 'node:child_process';
import { writeFileSync, mkdirSync, mkdtempSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
const [dirG = 'guides', dirF = 'frames', url = 'http://127.0.0.1:5320/?s=my-tower&clean=1&rec=1', giro = 'A'] = process.argv.slice(2); const W = 1920, H = 1080, fps = 24; mkdirSync(dirG, { recursive: true }); mkdirSync(dirF, { recursive: true });
const CHROME = process.env.CHROME || [
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  `${process.env.ProgramFiles}\\Google\\Chrome\\Application\\chrome.exe`, `${process.env['ProgramFiles(x86)']}\\Google\\Chrome\\Application\\chrome.exe`, `${process.env.LOCALAPPDATA}\\Google\\Chrome\\Application\\chrome.exe`,
  '/usr/bin/google-chrome', '/usr/bin/chromium'].find(p => { try { return existsSync(p); } catch { return false; } });
if (!CHROME) { console.error('Google Chrome not found: install it, or set CHROME=/path/to/chrome'); process.exit(1); }
const GPU = process.platform === 'darwin' ? ['--use-angle=metal'] : [];
const port = 9300 + Math.floor(Math.random() * 400), prof = mkdtempSync(join(tmpdir(), 'cyf-'));
const ch = spawn(CHROME, ['--headless=new', ...GPU, '--enable-gpu', '--ignore-gpu-blocklist', `--remote-debugging-port=${port}`, `--user-data-dir=${prof}`, `--window-size=${W},${H}`, '--hide-scrollbars', 'about:blank'], { stdio: 'ignore' });
const sleep = ms => new Promise(r => setTimeout(r, ms));
let ws; for (let i = 0; i < 60; i++) { try { const l = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json(); const p = l.find(t => t.type === 'page'); if (p) { ws = new WebSocket(p.webSocketDebuggerUrl); break; } } catch { } await sleep(150); }
await new Promise(r => ws.onopen = r);
let id = 0; const pend = new Map(); ws.onmessage = m => { const d = JSON.parse(m.data); if (d.id && pend.has(d.id)) { pend.get(d.id)(d); pend.delete(d.id); } };
const send = (method, params = {}) => new Promise(r => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
const ev = async e => { const r = (await send('Runtime.evaluate', { expression: e, awaitPromise: true, returnByValue: true })).result; if (r?.exceptionDetails) console.error('JS ERR', r.exceptionDetails.exception?.description || r.exceptionDetails.text); return r?.result?.value; };
await send('Page.enable'); await send('Emulation.setDeviceMetricsOverride', { width: W, height: H, deviceScaleFactor: 1, mobile: false });
await send('Page.navigate', { url });
for (let i = 0; i < 240; i++) { await sleep(250); if (await ev('!!(window.__motore && __motore.ready)')) break; }
await sleep(1500);
const tutto = join(dirG, `giro-${giro}-intero.mp4`);
const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-i', '-', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '12', '-preset', 'medium', '-movflags', '+faststart', tutto], { stdio: ['pipe', 'inherit', 'inherit'] });
const shot = async () => Buffer.from((await send('Page.captureScreenshot', { format: 'png' })).result.data, 'base64');
await ev(`__motore.avviaGiro(${JSON.stringify(giro)})`);
const tagli = []; let on = false, f = 0, fine = -1, prev = null, ki = 0, ts = null;
for (; f < 120 * fps; f++) {
  await ev(`__motore.step(1, ${fps})`); const v = await ev('__motore.fly.on ? [__motore.T.now - __motore.fly.t0, __motore.fly.P ? __motore.fly.P.ts : null] : null'); const png = await shot(); ff.stdin.write(png);
  if (v && !on) { ts = v[1] || [0, 1e9]; ki = 1; tagli.push({ da: f - 1, png0: prev }); }
  if (v && ts && ki < ts.length - 1 && v[0] >= ts[ki]) { const c = tagli[tagli.length - 1]; c.a = f; c.png1 = png; tagli.push({ da: f, png0: png }); ki++; }
  if (!v && on) { const c = tagli[tagli.length - 1]; c.a = f - 1; c.png1 = prev; }
  on = !!v; prev = png;
  if (f > fps && fine < 0 && !(await ev('__motore.giroAcceso()'))) fine = f + fps; if (fine > 0 && f >= fine) break;
}
ff.stdin.end(); await new Promise(r => ff.on('close', r));
if (on) { tagli[tagli.length - 1].a = f; tagli[tagli.length - 1].png1 = prev; }
const voli = tagli.filter(v => v.a - v.da >= fps / 2);
voli.forEach((v, i) => {
  const g = join(dirG, `G${i + 1}.mp4`);
  spawnSync('ffmpeg', ['-y', '-loglevel', 'error', '-i', tutto, '-vf', `trim=start_frame=${v.da}:end_frame=${v.a + 1},setpts=PTS-STARTPTS`, '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '18', '-preset', 'medium', '-movflags', '+faststart', g]);
  if (v.png0) writeFileSync(join(dirF, `G${i + 1}-start.png`), v.png0);
  if (v.png1) writeFileSync(join(dirF, `G${i + 1}-end.png`), v.png1);
  console.log(`G${i + 1}: frames ${v.da}-${v.a} (${((v.a - v.da + 1) / fps).toFixed(2)} s)  → ${g}`);
});
console.log('whole tour', tutto, f, 'frames');
try { ws.close(); } catch { } ch.kill('SIGKILL'); setTimeout(() => { try { rmSync(prof, { recursive: true, force: true }); } catch { } process.exit(0); }, 300);
