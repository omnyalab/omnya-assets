#!/usr/bin/env python3
"""
Riyadh Remote Kit - prepare your own clips.

Needs ffmpeg (free): https://ffmpeg.org/download.html
  Mac:     brew install ffmpeg
  Windows: winget install ffmpeg

What it does, reading config.json:
  1. re-encodes your tour clip and day clip at 720p (or 1080p) with a short keyframe interval, so they scrub smoothly
  2. builds the reversed tour clip (tourReverse) from the tour clip
  3. saves the poster (tour, first frame)
  4. saves one thumbnail per view, at the "frame" you set for that view
  5. saves the small preview frames of the day clip that the phone shows while you orbit

Usage (from the kit folder):
  python3 tools/prepare_clips.py --tour my_flight.mp4 --day my_orbit.mp4
  python3 tools/prepare_clips.py                 only rebuild thumbnails and previews from the clips already in config.json
  python3 tools/prepare_clips.py --probe         print the length and frame count of the clips in config.json
Options:
  --height 1080      encode at 1080p instead of 720p (bigger files, sharper on a 4K TV)
  --crf 23           quality, lower is better and bigger (default 28)
  --ffmpeg PATH      path to ffmpeg if it is not on your PATH
"""
import argparse, json, os, shutil, subprocess, sys

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def find_ffmpeg(given):
    if given:
        return given
    for name in ('ffmpeg', 'ffmpeg.exe'):
        p = shutil.which(name)
        if p:
            return p
    sys.exit('ffmpeg not found. Install it (Mac: brew install ffmpeg, Windows: winget install ffmpeg) or pass --ffmpeg /path/to/ffmpeg')


def run(cmd):
    print('  >', ' '.join(os.path.basename(c) if i == 0 else c for i, c in enumerate(cmd)))
    subprocess.run(cmd, check=True)


def k(p):
    return os.path.join(KIT, p)


def probe(ff, path):
    """Return (fps, frame count) by decoding the clip once."""
    out = subprocess.run([ff, '-hide_banner', '-i', path, '-map', '0:v:0', '-f', 'null', '-'], capture_output=True, text=True).stderr
    frames, fps = 0, 0.0
    for line in out.splitlines():
        if 'frame=' in line:
            try:
                frames = int(line.split('frame=')[-1].split()[0])
            except ValueError:
                pass
        if ' fps,' in line and 'Video:' in line:
            try:
                fps = float(line.split(' fps,')[0].split()[-1])
            except ValueError:
                pass
    return fps, frames


def encode(ff, src, dst, height, crf, gop, extra_vf=None):
    """Encode to a temporary file first, so the source can even be the same file as the destination."""
    vf = f'scale=-2:{height}:flags=lanczos' + (',' + extra_vf if extra_vf else '')
    tmp = dst + '.part.mp4'
    run([ff, '-hide_banner', '-loglevel', 'error', '-y', '-i', src, '-an', '-vf', vf, '-c:v', 'libx264', '-preset', 'slow',
         '-crf', str(crf), '-g', str(gop), '-keyint_min', str(gop), '-sc_threshold', '0', '-bf', '0', '-pix_fmt', 'yuv420p',
         '-movflags', '+faststart', tmp])
    return tmp


def grab(ff, src, frame, dst, width):
    run([ff, '-hide_banner', '-loglevel', 'error', '-y', '-i', src, '-vf', f'select=eq(n\\,{frame}),scale={width}:-2',
         '-frames:v', '1', '-q:v', '4', dst])


def main():
    ap = argparse.ArgumentParser(description='Prepare your own clips for the Remote Kit')
    ap.add_argument('--tour', help='your tour clip (the flight through every view)')
    ap.add_argument('--day', help='your day clip (360 orbit, night > day > night)')
    ap.add_argument('--height', type=int, default=720)
    ap.add_argument('--crf', type=int, default=28)
    ap.add_argument('--ffmpeg')
    ap.add_argument('--probe', action='store_true')
    a = ap.parse_args()
    ff = find_ffmpeg(a.ffmpeg)
    with open(k('config.json'), encoding='utf-8') as f:
        C = json.load(f)
    clips = C['clips']

    if a.probe:
        for key in ('tour', 'tourReverse', 'day'):
            fps, n = probe(ff, k(clips[key]))
            print(f'  {key:12s} {clips[key]:28s} {n} frames at {fps:g} fps = {n / fps if fps else 0:.2f} s')
        return

    os.makedirs(k('clips'), exist_ok=True)
    done = []
    if a.tour:
        print('\n1. Tour clip')
        done.append((encode(ff, a.tour, k(clips['tour']), a.height, a.crf, 12), k(clips['tour'])))
        print('\n2. Reversed tour clip')
        done.append((encode(ff, a.tour, k(clips['tourReverse']), a.height, a.crf, 12, 'reverse'), k(clips['tourReverse'])))
    if a.day:
        print('\nDay clip')
        done.append((encode(ff, a.day, k(clips['day']), a.height, a.crf, 6), k(clips['day'])))
    for tmp, dst in done:
        os.replace(tmp, dst)

    tour, day = k(clips['tour']), k(clips['day'])
    print('\n3. Poster')
    if clips.get('poster'):
        grab(ff, tour, 0, k(clips['poster']), 1280)

    print('\n4. View thumbnails')
    for i, v in enumerate(C['views']):
        thumb = v.get('thumb') or f'thumbs/views/view{i}.jpg'
        os.makedirs(os.path.dirname(k(thumb)), exist_ok=True)
        grab(ff, tour, int(v.get('frame', 0)), k(thumb), 640)

    pf = (C.get('light') or {}).get('previewFrames')
    if pf:
        print('\n5. Day preview frames')
        _, n = probe(ff, day)
        count = int(pf.get('count', 65))
        folder = k(pf['folder'])
        os.makedirs(folder, exist_ok=True)
        for j in range(count):
            frame = round(j * (n - 1) / max(1, count - 1))
            grab(ff, day, frame, os.path.join(folder, f"{pf.get('prefix', '')}{j:02d}.jpg"), 512)

    fps, n = probe(ff, tour)
    print(f'\nDone. Your tour clip has {n} frames at {fps:g} fps.')
    print('Now set "fps" and the "frame" of every view in config.json, then run this script again without --tour/--day to refresh the thumbnails.\n')


if __name__ == '__main__':
    main()
