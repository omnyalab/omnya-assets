# The config object

Everything about a tower lives in `window.TOWER_CONFIG` at the top of `tower.js`. Change these fields and nothing else for a normal build. The engine below the config line reads them once, when the page loads.

## The building

| Field | Type | What it does |
|---|---|---|
| `name` | text | The tower name exactly as the user wrote it. Shown in the header and on the reservation card. |
| `shortName` | text | 1 to 3 letters for the round monogram on the card, e.g. `AR` for Aurora Residences. |
| `city` | text | Shown next to the name in the header and above the name on the card. |
| `lang` | text | Page language code, e.g. `en`, `it`, `pt`. Goes into `<html lang>`. |
| `locale` | text | How prices and numbers are written: `en-IE` gives `€1,250,000`, `it-IT` gives `1.250.000 €`, `en-US` with USD gives `$1,250,000`. Short labels use the compact form (`€1.25M`). |
| `currency` | ISO code | `EUR`, `USD`, `GBP`, `AED`, `CHF`... Prices show no decimals. |

## The shape

| Field | Type | What it does |
|---|---|---|
| `floors` | number | All levels above ground, lobby and penthouse included. 6 to 120. |
| `floorHeight` | metres | Height of one residential level (4.2 is a premium tower). Lobby levels are 1.25 times this, the penthouse 1.5 times. |
| `height` | metres or `null` | Use instead of `floorHeight` when the user gives a total height: set `floorHeight: null, height: 150`. |
| `podiumFloors` | number | Lobby and amenity levels at the base, not for sale (0 to 6). They glow warm and have a wide canopy on top. |
| `footprint.shape` | `rect` / `rounded` / `oval` / `tapered` | The plan of the tower. `tapered` is a rounded plan that gets narrower towards the top. |
| `footprint.width`, `footprint.depth` | metres | Size of the plan at the base, glass line to glass line. 28 to 45 m is a usual residential tower. Width runs along the view side. |
| `footprint.corner` | metres | Corner radius for `rect` (default 0.6), `rounded` and `tapered` (default 8). |
| `footprint.taper` | 0 to 0.75 | Only for `tapered`: how much narrower the top is (0.4 = 40% narrower). |
| `crown` | `flat` / `slanted` / `spire` | The top: a flat roof with a wide overhang, a glass crown that rises towards the view, or a flat roof with a spire. |
| `facade` | `bands` / `glass` / `fins` | `bands`: wide white slab edges with glass balconies on every floor (the look of most premium waterfront towers). `glass`: a flush curtain wall with thin bands and slim mullions. `fins`: vertical white fins on every floor. |
| `balcony` | metres | Optional, only for `bands`: how far the slab edges stick out (default 1.8). |

## The look

| Field | Type | What it does |
|---|---|---|
| `colors.glass` | hex | The glass between the floors. Keep it dark (e.g. `#2c3642`, `#26302a`, `#3a3430`): the white bands and the lit windows read against it. |
| `colors.frame` | hex | Slab edges, balconies, fins, the roof. Usually a warm white or a stone colour (`#f3efe6`, `#e7dccb`). |
| `colors.accent` | hex | The light on the chosen floor, the chosen residence and the buttons. It must stand out from the glass, the frame and the grey. Soft yellow `#ffc95c` is the default. Text on the buttons turns dark or white by itself. |
| `colors.taken` | hex | Sold residences and sold-out floors. A neutral grey. |
| `surroundings` | `sea` / `river` / `city` / `desert` / `park` | What is around: the sea behind the tower with a skyline across the bay; a river with the far bank and its hills; a city of blocks and towers; sand dunes with a distant skyline; a park with lakes and trees. The view side of the residences always faces the water (or the open side). |
| `look` | `day` / `golden` / `night` | Sun and sky. `golden` (default) is the sun low over the water, warm windows. `night` lights every window, the lobby and the streets. Try `?look=night` in the address bar before changing the config. |

## What people buy

| Field | Type | What it does |
|---|---|---|
| `zones` | list | Groups of levels, from the bottom up, e.g. `{ name: 'Sky residences', from: 27, to: 39, price: 1250000 }`. Levels outside every zone join the nearest one. The lobby and penthouse levels are never in a zone. |
| `zones[].price` | number | The price of the cheapest residence on the lowest level of the zone (smallest type, city side). Every level up adds `floorPremium`, bigger types cost more, side and view residences cost 3% and 8% more. |
| `zones[].pricePerM2` | number | Use instead of `price` to price by size: price = pricePerM2 × m² × floor and view factors. |
| `zones[].soldOut` | true | Shows the whole zone as sold out. |
| `floorPremium` | number | Share added per level inside a zone, 0.006 = +0.6% per level. |
| `unitsPerFloor` | 2 to 12 | Residences per level. They are wedges around the core, lettered A, B, C... and the ones facing the view are in the middle of the letters. 4 to 8 reads best. |
| `unitTypes` | list | The sizes on offer, `{ name, size, bedrooms }`. The engine gives the biggest ones to the corners and the view side and the smallest to the sides, the same on every level. |
| `occupancy` | 0 to 1 | Share of residences shown as sold. Sample data, the same on every load. |
| `soldOutFloors` | list of levels | Levels shown completely sold. |
| `penthouse` | object or `null` | The top level. `name`, `floors` (1 or 2), `size` (m²), `bedrooms`, `upgrade` (price added to the chosen residence) and `perks` (2 or 3 short lines). It is offered after a residence is chosen, like a VIP upgrade. `null` = no penthouse and no upgrade step. |
| `checkoutUrl` | URL or `''` | When set, Reserve becomes "Continue to payment" and opens this link with `tower`, `level`, `unit`, `size`, `penthouse` and `price` added to the query. Empty = the card shows a "Reserved" stamp. |
| `quality` | `auto` / `high` / `low` | `auto` gives phones the light version (smaller shadows, fewer buildings and trees, lower pixel ratio). You can also add `?q=low` to the address. |

### Hitting a price range

The cheapest residence is the lowest zone's `price`. The most expensive is roughly the top zone's `price` × (largest size ÷ smallest size)^0.92 × (1 + floorPremium × levels in that zone) × 1.08. Do not trust the arithmetic: open the page and read `priceRange` in the `tower ready` line (or run `tower.info()`), then adjust the zone prices until it matches what the user asked for.

## Words

`text` holds every word on the page: step titles, hints, buttons, the labels on the card, the view names, the compass letters, the loading line and the small note under the card. Translate all of them when the page is not in English, and keep them short: they sit on a phone screen.

- `viewFront` / `viewSide` / `viewBack` name what the residences see. Match them to `surroundings`: sea `Sea view / Coast view / City view`, river `River view / River and city / City view`, city `Skyline view / City view / City view`, desert `Desert view / Desert and city / City view`, park `Park view / Park and city / City view`.
- `compass` is the 8 compass letters in the page language. The view side faces west (sunset over the water).
- Set `text.note` to `''` only when prices and availability are real.

## What `tower ready` reports

The console prints `tower ready {json}` once the tower is built, and `tower.info()` returns the same object:
`floors`, `levels` (podium, residences, penthouse ranges), `height` (with the crown), `roof`, `floorHeight`, `footprint`, `facade`, `crown`, `surroundings`, `units`, `unitsPerFloor`, `free`, `zones` (name, levels, units, free, from-price), `priceRange` [min, max] and `penthouse`. Tell the user the measured numbers, never estimated ones.

## Address bar options (for testing and for clean frames)

| Option | What it does |
|---|---|
| `?step=tower` / `floor` / `unit` / `upgrade` / `penthouse` / `card` | Opens straight on that step with a sensible level and residence (a free one with the view, about three quarters up). `pick` is the floor with a residence selected. |
| `&level=32` | With `step`, which level to use. With `step=tower` it lights that level and shows its sheet. |
| `&unit=D` | With `step`, which residence (letter or number). |
| `&pent=1` | With `step=card`, the penthouse card. |
| `?shot=1` | No transitions, for screenshots. (Any `?step=` link also lands without half-finished animations.) |
| `?clean=1` | Hides the whole interface, only the 3D. |
| `?look=night` | Try another light without editing the config. |
| `?q=low` | Force the light version. |
| key `P` | Saves a PNG of the 3D frame without the interface. |
| key `Esc` | One step back. Arrow up and down change the level on the tower and on the open floor. |
