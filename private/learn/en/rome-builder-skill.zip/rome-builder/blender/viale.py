# Il viale prima del Colosseo come una strada da film (Nico 25/11, riferimento: la città di Troia): palazzi romani
# continui di 3-5 piani ai due lati, portico al piano terra con botteghe e merci, balconi di legno (maeniana)
# pieni di gente, drappi colorati appesi, tetti bassi di coppi. Segmenti istanziati con Geometry Nodes.
import bpy, math, random
import numpy as np
import geo
from geo import Builder
import roma, folla, mercato

FRONTE = 15.0          # filo dei palazzi dal centro del viale (m)
PROF = 14.0            # profondità del palazzo
PORTICO = 3.6          # profondità del portico al piano terra
H0 = 4.4               # altezza del piano terra (portico)
HP = 3.3               # piani sopra
FOTO = False           # solo per le foto: panni stesi, vasi e piante sui balconi, insegne delle botteghe

# (lunghezza, piani sopra il portico, balcone, drappi, tetto: 'pad' a padiglione / 'terrazza')
VAR = [(14.0, 3, True, True, 'pad'), (18.0, 4, True, False, 'pad'), (12.0, 2, False, True, 'terrazza'),
       (16.0, 3, True, True, 'pad'), (13.0, 4, False, False, 'pad'), (15.0, 2, True, True, 'terrazza')]


def _bx(b, mat, x0, x1, y0, y1, z0, z1):
    b.raw(mat, [(x, y, z) for z in (z0, z1) for x, y in ((x0, y0), (x1, y0), (x1, y1), (x0, y1))],
          [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)])


def _quad_y(b, mat, x0, x1, y, z0, z1):
    b.raw(mat, [(x0, y, z0), (x1, y, z0), (x1, y, z1), (x0, y, z1)], [(0, 1, 2, 3)])


def tetto_pad(b, mat, x0, x1, y0, y1, z, rh):
    """tetto a padiglione basso di coppi (falde a 15-18°, come sulle insulae)"""
    hx, hy = (x1 - x0) / 2, (y1 - y0) / 2; cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    if hx >= hy:
        r0, r1 = (cx - (hx - hy), cy, z + rh), (cx + (hx - hy), cy, z + rh)
    else:
        r0, r1 = (cx, cy - (hy - hx), z + rh), (cx, cy + (hy - hx), z + rh)
    V = [(x0, y0, z), (x1, y0, z), (x1, y1, z), (x0, y1, z), r0, r1]
    if hx >= hy:
        F = [(0, 1, 5, 4), (2, 3, 4, 5), (1, 2, 5), (3, 0, 4)]
    else:
        F = [(1, 2, 5, 4), (3, 0, 4, 5), (0, 1, 4), (2, 3, 5)]
    b.raw(mat, V, F)


def segmento(nome, L, piani, balcone, drappi, tetto, rnd):
    """palazzo lungo L sul viale: fronte a y=0 verso -y (la strada), si allunga in +y"""
    b = Builder()
    hx = L / 2; H = H0 + piani * HP
    _bx(b, 'mattoni', -hx, hx, 0, PROF, -7.0, 0.0)                          # basamento in laterizio
    _bx(b, 'm', -hx, hx, PORTICO, PROF, 0.0, H)                              # corpo dietro il portico
    _bx(b, 'm', -hx, hx, 0.0, PORTICO, H0, H)                                # piani sopra il portico, a filo strada
    _bx(b, 'lastre', -hx, hx, 0.0, PORTICO, 0.0, 0.06)                       # pavimento del portico
    n = max(3, int(L / 3.6)); passo = L / n
    for i in range(n + 1):                                                   # pilastri del portico
        x = -hx + i * passo
        _bx(b, 'trav2', x - 0.38, x + 0.38, 0.0, 0.75, 0.0, H0)
    _bx(b, 'trav2', -hx, hx, -0.05, 0.75, H0 - 0.7, H0)                      # architrave
    for i in range(n):                                                       # botteghe in fondo al portico
        x = -hx + (i + 0.5) * passo
        _quad_y(b, 'f', x - passo * 0.32, x + passo * 0.32, PORTICO - 0.03, 0.0, 3.0)
    for k in range(piani):                                                   # finestre e marcapiani
        z0 = H0 + k * HP
        _bx(b, 'trav2', -hx - 0.05, hx + 0.05, -0.18, 0.0, z0, z0 + 0.22)
        for i in range(n):
            x = -hx + (i + 0.5) * passo
            _quad_y(b, 'f', x - 0.55, x + 0.55, -0.02, z0 + 0.9, z0 + 2.4)
    _bx(b, 'trav2', -hx - 0.1, hx + 0.1, -0.35, 0.0, H - 0.35, H)            # cornicione
    if balcone:                                                              # maenianum di legno al primo piano
        zb = H0 + 0.05
        _bx(b, 'legno', -hx + 0.4, hx - 0.4, -1.4, 0.0, zb, zb + 0.18)
        for i in range(n + 1):
            x = -hx + 0.5 + i * (L - 1.0) / n
            _bx(b, 'legno', x - 0.06, x + 0.06, -1.4, -1.28, zb, zb + 1.05)
            _bx(b, 'legno', x - 0.08, x + 0.08, -1.3, 0.0, zb - 0.5, zb)     # mensole
        _bx(b, 'legno', -hx + 0.4, hx - 0.4, -1.42, -1.3, zb + 0.95, zb + 1.07)
        _bx(b, 'legno', -hx + 0.4, hx - 0.4, -1.4, -1.36, zb + 0.4, zb + 0.46)
    if drappi:                                                               # drappi colorati appesi
        for i in range(rnd.randint(2, 4)):
            x = rnd.uniform(-hx + 1.2, hx - 1.2); w = rnd.uniform(0.9, 1.5)
            ztop = H0 + HP * rnd.randint(1, max(1, piani)) - 0.3; zlo = ztop - rnd.uniform(2.6, 4.2)
            _quad_y(b, 'tenda', x - w / 2, x + w / 2, -1.5 if balcone else -0.12, max(H0 + 0.3, zlo), ztop)
    if FOTO:
        for i in range(n):                                               # insegne di legno sopra le botteghe
            x = -hx + (i + 0.5) * passo
            if rnd.random() < 0.6:
                _quad_y(b, 'legno', x - 0.9, x + 0.9, PORTICO - 0.08, 3.15, 3.6)
        for k in range(1, piani):                                        # panni stesi fra le finestre
            if rnd.random() < 0.55:
                z0 = H0 + k * HP + 2.55; x0 = rnd.uniform(-hx + 0.5, 0); x1 = x0 + rnd.uniform(2.5, 5.0)
                _bx(b, 'legno', x0, x1, -0.42, -0.4, z0, z0 + 0.02)
                xx = x0 + 0.2
                while xx < x1 - 0.5:
                    w = rnd.uniform(0.35, 0.8); _quad_y(b, 'tenda', xx, xx + w, -0.41, z0 - rnd.uniform(0.5, 1.1), z0); xx += w + rnd.uniform(0.1, 0.4)
        if balcone:                                                      # vasi e piante sul balcone
            for i in range(int(L / 1.6)):
                if rnd.random() < 0.5:
                    x = -hx + 0.8 + i * 1.6 + rnd.uniform(-0.3, 0.3)
                    _bx(b, 'terracotta', x - 0.18, x + 0.18, -1.35, -1.05, H0 + 0.23, H0 + 0.6)
                    _bx(b, 'foglie', x - 0.35, x + 0.35, -1.45, -0.95, H0 + 0.6, H0 + 0.6 + rnd.uniform(0.3, 0.9))
    if tetto == 'pad':
        tetto_pad(b, 't', -hx - 0.7, hx + 0.7, -0.9, PROF + 0.7, H, min(L, PROF) * 0.14)
    else:
        _bx(b, 't', -hx, hx, 0, PROF, H, H + 0.25)
        _bx(b, 'm', -hx, hx, -0.1, 0.25, H, H + 1.0)                          # parapetto
        for i in range(4):                                                   # pergola
            x = -hx + 1 + i * (L - 2) / 3
            _bx(b, 'legno', x - 0.08, x + 0.08, 3.0, 3.16, H, H + 2.4)
        _bx(b, 'legno', -hx + 0.8, hx - 0.8, 2.9, 3.3, H + 2.4, H + 2.55)
    ordine = ['m', 't', 'f', 'mattoni', 'legno', 'trav2', 'lastre', 'tenda', 'terracotta', 'foglie']
    V = []; F = []; mi = []
    for k, mat in enumerate(ordine):
        if mat in b.parts:
            vv, ff = b.parts[mat]; o = len(V); V += vv
            F += [tuple(o + i for i in f) for f in ff]; mi += [k] * len(ff)
    me = bpy.data.meshes.new(nome); me.from_pydata(V, [], F)
    for p, k in zip(me.polygons, mi):
        p.material_index = k
    return bpy.data.objects.new(nome, me), ordine


def costruisci(scn, MAT, coll, AVd, leggero, o_max=440.0):
    mercato._mats(MAT)
    rnd = random.Random(79)
    pc, nc, tc = AVd['pc'], AVd['nc'], AVd['tc']
    cv = bpy.data.collections.new('VariantiViale'); scn.collection.children.link(cv)
    mats = {'m': 'muri_citta', 't': 'tegole', 'f': 'buio'}
    for i, v in enumerate(VAR):
        o, ordine = segmento(f'v{i}_palazzo', *v, rnd)
        for m in ordine:
            o.data.materials.append(MAT[mats.get(m, m)])
        cv.objects.link(o)
    scn.view_layers[0].layer_collection.children['VarianteViale'.replace('Variante', 'Varianti')].exclude = True
    ng = mercato._gn_moto(cv, 'viale_istanze')
    S = []; B = []; G = []
    for side in (-1, 1):
        a = 20.0
        while a < o_max:
            k = rnd.randrange(len(VAR)); L = VAR[k][0]
            if a + L > o_max:
                break
            c = pc + nc * (a + L / 2) + tc * side * FRONTE
            # il fronte (y locale = 0) guarda il viale: y locale va verso fuori (side * tc)
            yv = tc * side
            rot = math.atan2(yv[1], yv[0]) - math.pi / 2
            S.append((float(c[0]), float(c[1]), roma.quota(*c), rot, k, rnd.random(), 1.0, 0.0, 0.0))
            # merci sotto il portico e mercanti, gente sui balconi
            n = max(3, int(L / 3.6)); passo = L / n
            for i in range(n):
                if rnd.random() < 0.75:
                    q = pc + nc * (a + (i + 0.5) * passo) + tc * side * (FRONTE + 1.9)
                    B.append((float(q[0]), float(q[1]), roma.quota(*q), mercato._rot_verso(*(-yv)), rnd.choice((0, 1, 2)), rnd.random(), 0.92, 0.0, 0.0))
                    m = q + yv * 0.4
                    G.append((float(m[0]), float(m[1]), roma.quota(*m), mercato._rot_verso(*(-yv)), rnd.choice((5, 6, 4)), rnd.random(), 1.0, 0.0, 0.0))
            if VAR[k][2]:
                for i in range(int(L / 0.75)):
                    if rnd.random() < 0.7:
                        q = pc + nc * (a + 0.6 + i * 0.75) + tc * side * (FRONTE - rnd.uniform(0.35, 1.0))
                        G.append((float(q[0]), float(q[1]), roma.quota(*q) + H0 + 0.23, mercato._rot_verso(*(-yv)) + rnd.uniform(-0.5, 0.5),
                                  rnd.choice((4, 5, 6, 7, 7)), rnd.random(), rnd.uniform(0.9, 1.05), 0.0, 0.0))
            a += L + (0.0 if rnd.random() < 0.8 else rnd.uniform(1.5, 3.0))
        # gente che passa sotto il portico
        for k in range(int(500 * (0.35 if leggero else 1.0))):
            a = rnd.uniform(22, o_max - 10); lt = side * rnd.uniform(FRONTE - 0.2, FRONTE + 0.4)
            q = pc + nc * a + tc * lt; d = nc * rnd.choice((-1, 1)); v = rnd.uniform(0.6, 1.1)
            G.append((float(q[0]), float(q[1]), roma.quota(*q), mercato._rot_verso(*d), rnd.choice((4, 4, 5, 6)), rnd.random(), rnd.uniform(0.9, 1.1), float(d[0] * v), float(d[1] * v)))
    mercato.nuvola('viale_palazzi', S, coll, ng)
    mercato.nuvola('viale_merci', B, coll, bpy.data.node_groups['mercato_istanze'])
    mercato.nuvola('viale_gente', G, coll, bpy.data.node_groups['gente_istanze'])
    roma.STATS['edifici_citta'] += len(S)
    print('VIALE palazzi', len(S), 'banchi', len(B), 'gente', len(G))
    return len(S)
