# filtro_film_caldo_video.py IN.mp4 OUT.mp4 : lo stesso filtro caldo delle foto (filtro_film_caldo.py) su ogni fotogramma,
# in streaming (niente fotogrammi su disco), grana diversa a ogni fotogramma, unsharp leggero, crf 12.
import sys, subprocess, json
import numpy as np
src, dst = sys.argv[1], sys.argv[2]
pr = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height,r_frame_rate', '-of', 'json', src]))['streams'][0]
W, H, fps = pr['width'], pr['height'], pr['r_frame_rate']
dec = subprocess.Popen(['ffmpeg', '-v', 'error', '-i', src, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], stdout=subprocess.PIPE)
enc = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', fps, '-i', '-',
                        '-vf', 'unsharp=5:5:0.25', '-c:v', 'libx264', '-crf', '12', '-preset', 'slow', '-pix_fmt', 'yuv420p', dst], stdin=subprocess.PIPE)
y, x = np.ogrid[:H, :W]
r = np.sqrt(((x - W / 2) / (W / 2)) ** 2 + ((y - H / 2) / (H / 2)) ** 2) / np.sqrt(2)
vig = (1 - 0.08 * np.clip(r, 0, 1) ** 2)[..., None].astype(np.float32)
warm = np.array([0.04, 0.015, -0.06], np.float32)
rng = np.random.default_rng(7); n = 0
while True:
    buf = dec.stdout.read(W * H * 3)
    if len(buf) < W * H * 3:
        break
    a = np.frombuffer(buf, np.uint8).reshape(H, W, 3).astype(np.float32) / 255.0
    a = a + 0.08 * (a - 0.5) * (1 - np.abs(2 * a - 1))
    a = np.clip((a - 0.01) / 0.99, 0, 1)
    mx, mn = a.max(2, keepdims=True), a.min(2, keepdims=True)
    sat = (mx - mn) / (mx + 1e-6); g = a.mean(2, keepdims=True)
    a = g + (a - g) * (1 + 0.12 * (1 - sat))
    lum = (0.2126 * a[..., 0] + 0.7152 * a[..., 1] + 0.0722 * a[..., 2])[..., None]
    a = a * (1 + np.clip((lum - 0.15) / 0.6, 0, 1) * warm)
    a = a * vig + rng.normal(0, 0.012, (H, W, 1)).astype(np.float32)
    enc.stdin.write((np.clip(a, 0, 1) * 255 + 0.5).astype(np.uint8).tobytes()); n += 1
enc.stdin.close(); enc.wait(); dec.wait()
print(dst, n, 'fotogrammi')
