# Local server for the villa page. Like "python3 -m http.server", plus byte ranges (HTTP 206), so the film can jump to any
# second even when the browser streams it instead of keeping it in memory. Only the Python 3 standard library.
# Usage: python3 server.py [port]   (default 5316), then open http://localhost:5316
import functools, http.server, os, re, sys

class Part:
    def __init__(self, f, n): self.f, self.n = f, n
    def read(self, k=-1):
        if self.n <= 0: return b''
        k = self.n if k is None or k < 0 else min(k, self.n)
        b = self.f.read(k); self.n -= len(b); return b
    def close(self): self.f.close()

class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map, '.js': 'text/javascript', '.mjs': 'text/javascript',
                      '.json': 'application/json', '.mp4': 'video/mp4', '.ttf': 'font/ttf', '.woff2': 'font/woff2'}
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store'); self.send_header('Accept-Ranges', 'bytes'); super().end_headers()
    def log_message(self, *a): pass
    def send_head(self):
        rng = self.headers.get('Range'); path = self.translate_path(self.path)
        m = re.match(r'bytes=(\d*)-(\d*)$', (rng or '').strip())
        if not m or os.path.isdir(path) or m.groups() == ('', ''): return super().send_head()
        try: f = open(path, 'rb')
        except OSError: self.send_error(404); return None
        size = os.fstat(f.fileno()).st_size; a, b = m.groups()
        if a == '': start, end = max(0, size - int(b)), size - 1
        else: start, end = int(a), (min(int(b), size - 1) if b else size - 1)
        if start > end:
            f.close(); self.send_response(416); self.send_header('Content-Range', f'bytes */{size}'); self.end_headers(); return None
        self.send_response(206); self.send_header('Content-Type', self.guess_type(path))
        self.send_header('Content-Range', f'bytes {start}-{end}/{size}'); self.send_header('Content-Length', str(end - start + 1))
        self.end_headers(); f.seek(start); return Part(f, end - start + 1)

class Server(http.server.ThreadingHTTPServer):
    request_queue_size = 128; daemon_threads = True

if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 5316
    here = os.path.dirname(os.path.abspath(__file__))
    print(f'Choose your villa: http://localhost:{port}  (Ctrl+C or Stop to close)')
    Server(('127.0.0.1', port), functools.partial(Handler, directory=here)).serve_forever()
