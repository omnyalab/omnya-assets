# Geometria di base del Colosseo: ellisse esterna, ascissa curvilinea, offset, costruttore di mesh.
# Coordinate locali di campata: x lungo la facciata (m), off = distanza dalla faccia esterna (+ fuori), z = quota.
import math
import numpy as np

A, B = 94.0, 78.0          # semiassi esterni (188 x 156 m)
D_TOT = 51.0               # dalla faccia esterna al bordo dell'arena (arena 86 x 54)
NBAY = 80

_T = np.linspace(0, 2 * math.pi, 40001)
_dx = -A * np.sin(_T); _dy = B * np.cos(_T)
_ds = np.sqrt(_dx ** 2 + _dy ** 2)
_S = np.concatenate([[0], np.cumsum(0.5 * (_ds[1:] + _ds[:-1]) * (_T[1] - _T[0]))])
PERIM = float(_S[-1])
BAYW = PERIM / NBAY


def t_of_s(s):
    s = np.mod(s, PERIM)
    return np.interp(s, _S, _T)


def frame(s):
    """punto sull'ellisse esterna e normale esterna unitaria per l'ascissa s"""
    t = t_of_s(s)
    p = np.array([A * math.cos(t), B * math.sin(t)])
    n = np.array([B * math.cos(t), A * math.sin(t)]); n /= np.linalg.norm(n)
    return p, n


def M(s, off, z):
    p, n = frame(s)
    q = p + n * off
    return (float(q[0]), float(q[1]), float(z))


def bay_s(k):
    return k * BAYW


def offset_perim(off):
    return PERIM + 2 * math.pi * off


class Builder:
    """accumula vertici e facce per materiale, in coordinate di campata (s0 = centro)"""

    def __init__(self):
        self.parts = {}

    def _get(self, mat):
        if mat not in self.parts:
            self.parts[mat] = ([], [])
        return self.parts[mat]

    def poly(self, mat, pts):
        V, F = self._get(mat)
        i0 = len(V); V.extend(pts); F.append(tuple(range(i0, i0 + len(pts))))

    def raw(self, mat, verts, faces):
        V, F = self._get(mat)
        i0 = len(V); V.extend(verts)
        F.extend(tuple(i0 + i for i in f) for f in faces)

    # --- primitive in coordinate di campata ---
    def box(self, mat, s0, x0, x1, o0, o1, z0, z1, nx=None):
        x0, x1 = min(x0, x1), max(x0, x1); o0, o1 = min(o0, o1), max(o0, o1); z0, z1 = min(z0, z1), max(z0, z1)
        if nx is None:
            nx = max(1, int(abs(x1 - x0) / 1.2))
        xs = [x0 + (x1 - x0) * i / nx for i in range(nx + 1)]
        V = []; F = []
        idx = {}
        def v(i, a, b):  # i = indice x, a in (0,1) off, b in (0,1) z
            k = (i, a, b)
            if k not in idx:
                idx[k] = len(V); V.append(M(s0 + xs[i], (o0, o1)[a], (z0, z1)[b]))
            return idx[k]
        for i in range(nx):
            F.append((v(i, 1, 0), v(i + 1, 1, 0), v(i + 1, 1, 1), v(i, 1, 1)))  # fronte (off=o1)
            F.append((v(i + 1, 0, 0), v(i, 0, 0), v(i, 0, 1), v(i + 1, 0, 1)))  # retro
            F.append((v(i, 0, 1), v(i, 1, 1), v(i + 1, 1, 1), v(i + 1, 0, 1)))  # sopra
            F.append((v(i, 0, 0), v(i + 1, 0, 0), v(i + 1, 1, 0), v(i, 1, 0)))  # sotto
        F.append((v(0, 0, 0), v(0, 1, 0), v(0, 1, 1), v(0, 0, 1)))
        F.append((v(nx, 1, 0), v(nx, 0, 0), v(nx, 0, 1), v(nx, 1, 1)))
        self.raw(mat, V, F)

    def spandrel(self, mat, s0, w, zs, ztop, o0, o1, nseg=16):
        """pezzo di muro sopra un arco a tutto sesto largo w, imposta zs, fino a ztop"""
        r = w / 2
        arc = [(-r * math.cos(math.pi * i / nseg), zs + r * math.sin(math.pi * i / nseg)) for i in range(nseg + 1)]
        V = []; F = []
        def add(x, o, z):
            V.append(M(s0 + x, o, z)); return len(V) - 1
        fa = [add(x, o1, z) for x, z in arc]; ft = [add(x, o1, ztop) for x, z in arc]
        ba = [add(x, o0, z) for x, z in arc]; bt = [add(x, o0, ztop) for x, z in arc]
        for i in range(nseg):
            F.append((fa[i], fa[i + 1], ft[i + 1], ft[i]))
            F.append((ba[i + 1], ba[i], bt[i], bt[i + 1]))
            F.append((ba[i], ba[i + 1], fa[i + 1], fa[i]))  # intradosso
        self.raw(mat, V, F)

    def arch_ring(self, mat, s0, w, zs, o0, o1, th, nseg=16):
        """archivolto: anello sporgente attorno all'arco"""
        r0 = w / 2; r1 = r0 + th
        V = []; F = []
        def add(x, o, z):
            V.append(M(s0 + x, o, z)); return len(V) - 1
        rows = []
        for (r, o) in ((r0, o1), (r1, o1), (r1, o0), (r0, o0)):
            rows.append([add(-r * math.cos(math.pi * i / nseg), o, zs + r * math.sin(math.pi * i / nseg)) for i in range(nseg + 1)])
        for k in range(4):
            a, b = rows[k], rows[(k + 1) % 4]
            for i in range(nseg):
                F.append((a[i], a[i + 1], b[i + 1], b[i]))
        self.raw(mat, V, F)

    def cyl(self, mat, s0, x, o, z0, z1, r, n=16, r1=None):
        if r1 is None:
            r1 = r
        V = []; F = []
        for zz, rr in ((z0, r), (z1, r1)):
            for i in range(n):
                a = 2 * math.pi * i / n
                V.append(M(s0 + x + rr * math.cos(a), o + rr * math.sin(a), zz))
        for i in range(n):
            j = (i + 1) % n
            F.append((i, j, n + j, n + i))
        F.append(tuple(range(n - 1, -1, -1))); F.append(tuple(range(n, 2 * n)))
        self.raw(mat, V, F)

    def disk(self, mat, s0, x, o, z, r, n=24, bulge=0.15):
        """scudo: disco verticale nel piano della facciata, sporgente in off"""
        V = [M(s0 + x, o + bulge, z)]
        for ring in (0.6, 1.0):
            for i in range(n):
                a = 2 * math.pi * i / n
                V.append(M(s0 + x + r * ring * math.cos(a), o + bulge * (1 - ring ** 2) + 0.03, z + r * ring * math.sin(a)))
        F = []
        for i in range(n):
            j = (i + 1) % n
            F.append((0, 1 + i, 1 + j))
            F.append((1 + i, 1 + n + i, 1 + n + j, 1 + j))
        self.raw(mat, V, F)

    def sweep(self, mat, prof, n=None, closed_prof=True, s_from=0.0, s_to=None):
        """profilo [(off,z),...] spazzato lungo tutta l'ellisse (anello chiuso) o un tratto"""
        full = s_to is None
        if n is None:
            n = 720
        if full:
            ss = [PERIM * i / n for i in range(n)]
        else:
            ss = [s_from + (s_to - s_from) * i / n for i in range(n + 1)]
        P = len(prof)
        V = []
        for s in ss:
            p, nn = frame(s)
            for o, z in prof:
                q = p + nn * o
                V.append((float(q[0]), float(q[1]), float(z)))
        F = []
        nr = len(ss)
        segs = range(nr) if full else range(nr - 1)
        for i in segs:
            j = (i + 1) % nr
            for k in range(P if closed_prof else P - 1):
                kk = (k + 1) % P
                F.append((i * P + k, j * P + k, j * P + kk, i * P + kk))
        if not full and closed_prof:
            F.append(tuple(range(P - 1, -1, -1)))
            F.append(tuple((nr - 1) * P + k for k in range(P)))
        self.raw(mat, V, F)


def ellipse_ring_mesh(off_in, off_out, z, n=720):
    V = []; F = []
    for i in range(n):
        s = PERIM * i / n
        V.append(M(s, off_in, z)); V.append(M(s, off_out, z))
    for i in range(n):
        j = (i + 1) % n
        F.append((2 * i, 2 * j, 2 * j + 1, 2 * i + 1))
    return V, F


def ellipse_disk_mesh(off, z, n=360):
    V = [(0.0, 0.0, z)] + [M(PERIM * i / n, off, z) for i in range(n)]
    F = [(0, 1 + i, 1 + (i + 1) % n) for i in range(n)]
    return V, F


ROMAN = [(1000, 'M'), (900, 'CM'), (500, 'D'), (400, 'CD'), (100, 'C'), (90, 'XC'), (50, 'L'), (40, 'XL'), (10, 'X'), (9, 'IX'), (5, 'V'), (4, 'IV'), (1, 'I')]


def roman(n):
    out = ''
    for v, r in ROMAN:
        while n >= v:
            out += r; n -= v
    return out


def bay_number(k):
    """numerazione STIMA: assi a 0,20,40,60; I parte dopo l'asse sud (60) e gira in senso antiorario,
    così sul lato nord cadono i numeri XXIII-LIV che oggi si vedono."""
    if k % 20 == 0:
        return None
    if k > 60:
        return k - 60
    if k < 20:
        return k + 19
    if k < 40:
        return k + 18
    return k + 17  # 41..59 -> LVIII..LXXVI


def prism(builder, mat, s0, pts, o0, o1):
    """prisma: poligono 2D [(x,z)...] nel piano della facciata, estruso fra off o0 e o1"""
    n = len(pts)
    V = [M(s0 + x, o1, z) for x, z in pts] + [M(s0 + x, o0, z) for x, z in pts]
    F = [tuple(range(n)), tuple(range(2 * n - 1, n - 1, -1))]
    for i in range(n):
        j = (i + 1) % n
        F.append((n + i, n + j, j, i))
    builder.raw(mat, V, F)


GLYPH_W = {'I': 0.16, 'V': 0.42, 'X': 0.42, 'L': 0.34}


def stroke(x0, z0, x1, z1, w):
    dx, dz = x1 - x0, z1 - z0
    L = math.hypot(dx, dz); nx, nz = -dz / L * w / 2, dx / L * w / 2
    return [(x0 - nx, z0 - nz), (x1 - nx, z1 - nz), (x1 + nx, z1 + nz), (x0 + nx, z0 + nz)]


def numeral(builder, mat, s0, text, zc, h, o0, o1):
    """numero romano inciso/dipinto, centrato su x=0 alla quota zc"""
    gap = 0.07; w = 0.085
    tot = sum(GLYPH_W[c] for c in text) + gap * (len(text) - 1)
    x = -tot / 2; zb = zc - h / 2; zt = zc + h / 2
    for c in text:
        gw = GLYPH_W[c]
        S = []
        if c == 'I':
            S.append(stroke(x + gw / 2, zb, x + gw / 2, zt, w))
        elif c == 'V':
            S.append(stroke(x, zt, x + gw / 2, zb, w)); S.append(stroke(x + gw / 2, zb, x + gw, zt, w * 0.7))
        elif c == 'X':
            S.append(stroke(x, zt, x + gw, zb, w)); S.append(stroke(x + gw, zt, x, zb, w * 0.7))
        elif c == 'L':
            S.append(stroke(x + w / 2, zb, x + w / 2, zt, w)); S.append(stroke(x, zb + w / 2, x + gw, zb + w / 2, w))
        for P in S:
            prism(builder, mat, s0, P, o0, o1)
        x += gw + gap
