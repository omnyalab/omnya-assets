# Folla: figure semplici (nessun viso, solo sagome) istanziate con Geometry Nodes su ogni posto.
import bpy, math, random
import numpy as np
import geo
from geo import M, frame, bay_s, PERIM, BAYW, NBAY

POSE = {
    # nome: [(nome_vertice, (x,y,z), raggio)], spigoli
    'in_piedi': [('bacino', (0, 0, 0.95), 0.19), ('petto', (0, -0.01, 1.3), 0.19), ('collo', (0, 0, 1.49), 0.06),
                 ('testa', (0, 0.01, 1.6), 0.105), ('cima', (0, 0, 1.71), 0.075),
                 ('spS', (-0.2, 0, 1.42), 0.07), ('gomS', (-0.25, 0.02, 1.15), 0.055), ('manS', (-0.27, 0.06, 0.9), 0.045),
                 ('spD', (0.2, 0, 1.42), 0.07), ('gomD', (0.25, 0.02, 1.15), 0.055), ('manD', (0.27, 0.06, 0.9), 0.045),
                 ('gonna', (0, 0.01, 0.58), 0.2),
                 ('ginS', (-0.1, 0, 0.5), 0.07), ('pieS', (-0.11, 0.02, 0.06), 0.06), ('puntaS', (-0.11, 0.17, 0.04), 0.045),
                 ('ginD', (0.1, 0, 0.5), 0.07), ('pieD', (0.11, 0.02, 0.06), 0.06), ('puntaD', (0.11, 0.17, 0.04), 0.045)],
    'seduto': [('bacino', (0, 0, 0.13), 0.19), ('petto', (0, -0.03, 0.48), 0.19), ('collo', (0, -0.02, 0.67), 0.06),
               ('testa', (0, 0, 0.78), 0.105), ('cima', (0, -0.01, 0.89), 0.075),
               ('spS', (-0.2, -0.02, 0.6), 0.07), ('gomS', (-0.24, 0.12, 0.36), 0.055), ('manS', (-0.15, 0.3, 0.27), 0.045),
               ('spD', (0.2, -0.02, 0.6), 0.07), ('gomD', (0.24, 0.12, 0.36), 0.055), ('manD', (0.15, 0.3, 0.27), 0.045),
               ('gonna', (0, 0.25, 0.14), 0.2),
               ('ginS', (-0.1, 0.42, 0.15), 0.075), ('pieS', (-0.11, 0.45, -0.34), 0.06), ('puntaS', (-0.11, 0.58, -0.36), 0.045),
               ('ginD', (0.1, 0.42, 0.15), 0.075), ('pieD', (0.11, 0.45, -0.34), 0.06), ('puntaD', (0.11, 0.58, -0.36), 0.045)],
}
SPIGOLI = [('bacino', 'petto'), ('petto', 'collo'), ('collo', 'testa'), ('testa', 'cima'),
           ('petto', 'spS'), ('spS', 'gomS'), ('gomS', 'manS'), ('petto', 'spD'), ('spD', 'gomD'), ('gomD', 'manD'),
           ('bacino', 'gonna'), ('bacino', 'ginS'), ('ginS', 'pieS'), ('bacino', 'ginD'), ('ginD', 'pieD'), ('pieS', 'puntaS'), ('pieD', 'puntaD')]


def figura(nome, posa='in_piedi', braccio=False, sub=2, gesto=None):
    base = 'seduto' if posa == 'seduto' else 'in_piedi'
    P = [list(p) for p in POSE[base]]
    names = [p[0] for p in P]
    top = 1.42 if base == 'in_piedi' else 0.6
    if braccio or posa == 'braccio' or gesto == 'due':
        for p in P:
            if p[0] == 'gomD':
                p[1] = (0.3, 0.05, top + 0.25)
            if p[0] == 'manD':
                p[1] = (0.33, 0.1, top + 0.52)
    if gesto == 'due':
        for p in P:
            if p[0] == 'gomS':
                p[1] = (-0.3, 0.05, top + 0.22)
            if p[0] == 'manS':
                p[1] = (-0.31, 0.12, top + 0.5)
    if gesto == 'avanti':
        for p in P:
            if p[0] in ('petto', 'collo', 'testa', 'cima', 'spS', 'spD'):
                p[1] = (p[1][0], p[1][1] + 0.12 * (p[1][2] - P[0][1][2]) / 0.5, p[1][2] - 0.03)
    if gesto == 'braccia':
        for p in P:
            if p[0] == 'manS':
                p[1] = (-0.08, 0.16, top - 0.2)
            if p[0] == 'manD':
                p[1] = (0.08, 0.16, top - 0.22)
            if p[0] == 'gomS':
                p[1] = (-0.24, 0.08, top - 0.25)
            if p[0] == 'gomD':
                p[1] = (0.24, 0.08, top - 0.27)
    verts = [p[1] for p in P]
    edges = [(names.index(a), names.index(b)) for a, b in SPIGOLI]
    me = bpy.data.meshes.new(nome + '_sk'); me.from_pydata(verts, edges, [])
    ob = bpy.data.objects.new(nome + '_sk', me); bpy.context.scene.collection.objects.link(ob)
    ob.modifiers.new('skin', 'SKIN')
    if len(me.skin_vertices) == 0:
        me.skin_vertices.new()
    sv = me.skin_vertices[0].data
    for i, p in enumerate(P):
        sv[i].radius = (p[2], p[2] * (0.8 if p[0] in ('petto', 'bacino', 'gonna') else 1.0))
    sv[0].use_root = True
    ss = ob.modifiers.new('sub', 'SUBSURF'); ss.levels = sub; ss.render_levels = sub
    dg = bpy.context.evaluated_depsgraph_get()
    me2 = bpy.data.meshes.new_from_object(ob.evaluated_get(dg))
    bpy.data.objects.remove(ob, do_unlink=True); bpy.data.meshes.remove(me)
    o2 = bpy.data.objects.new(nome, me2); bpy.context.scene.collection.objects.link(o2)
    # pelle: testa, collo e mani
    zcollo = [p[1][2] for p in P if p[0] == 'collo'][0] - 0.03
    testa = [p[1] for p in P if p[0] == 'testa'][0]
    mani = [p[1] for p in P if p[0] in ('manS', 'manD')]
    for poly in me2.polygons:
        c = poly.center
        pelle = c.z > zcollo and abs(c.x) < 0.14
        for h in mani:
            if (c.x - h[0]) ** 2 + (c.y - h[1]) ** 2 + (c.z - h[2]) ** 2 < 0.07 ** 2:
                pelle = True
        capelli = pelle and (c.z > testa[2] + 0.015 or (c.y < testa[1] - 0.04 and c.z > testa[2] - 0.06))
        poly.material_index = 2 if capelli else (1 if pelle else 0)
        poly.use_smooth = True
    return o2


def _gn_istanze(coll_varianti):
    ng = bpy.data.node_groups.new('folla_istanze', 'GeometryNodeTree')
    ng.interface.new_socket('Geometry', in_out='INPUT', socket_type='NodeSocketGeometry')
    ng.interface.new_socket('Geometry', in_out='OUTPUT', socket_type='NodeSocketGeometry')
    N = ng.nodes; L = ng.links
    gi = N.new('NodeGroupInput'); go = N.new('NodeGroupOutput')
    ci = N.new('GeometryNodeCollectionInfo'); ci.inputs['Collection'].default_value = coll_varianti
    ci.inputs['Separate Children'].default_value = True; ci.inputs['Reset Children'].default_value = True
    ip = N.new('GeometryNodeInstanceOnPoints'); ip.inputs['Pick Instance'].default_value = True

    def attr(name, typ):
        a = N.new('GeometryNodeInputNamedAttribute'); a.data_type = typ; a.inputs['Name'].default_value = name
        return a.outputs['Attribute']
    L.new(gi.outputs[0], ip.inputs['Points']); L.new(ci.outputs[0], ip.inputs['Instance'])
    L.new(attr('var', 'INT'), ip.inputs['Instance Index'])
    rot = attr('rot', 'FLOAT_VECTOR')
    try:
        e2r = N.new('FunctionNodeEulerToRotation'); L.new(rot, e2r.inputs[0]); L.new(e2r.outputs[0], ip.inputs['Rotation'])
    except Exception:
        L.new(rot, ip.inputs['Rotation'])
    L.new(attr('scl', 'FLOAT'), ip.inputs['Scale'])
    L.new(ip.outputs[0], go.inputs[0])
    return ng


def nuvola(nome, P, coll, ng):
    """P: lista di (x,y,z, rotz, var, col, scl)"""
    me = bpy.data.meshes.new(nome)
    me.vertices.add(len(P))
    arr = np.array(P, dtype=np.float32)
    me.vertices.foreach_set('co', arr[:, :3].ravel())
    rot = np.zeros((len(P), 3), np.float32); rot[:, 2] = arr[:, 3]
    a = me.attributes.new('rot', 'FLOAT_VECTOR', 'POINT'); a.data.foreach_set('vector', rot.ravel())
    a = me.attributes.new('var', 'INT', 'POINT'); a.data.foreach_set('value', arr[:, 4].astype(np.int32))
    a = me.attributes.new('col', 'FLOAT', 'POINT'); a.data.foreach_set('value', arr[:, 5])
    a = me.attributes.new('scl', 'FLOAT', 'POINT'); a.data.foreach_set('value', arr[:, 6])
    ob = bpy.data.objects.new(nome, me); coll.objects.link(ob)
    mod = ob.modifiers.new('folla', 'NODES'); mod.node_group = ng
    return ob


PALCHI = []
ESCLUSI = []


def _var(rnd, seduto):
    x = rnd.random()
    v = 0 if x < 0.58 else 1 if x < 0.74 else 2 if x < 0.84 else 3
    return v if seduto else v + 4


def _rot_verso(vx, vy):
    return math.atan2(-vx, vy)


def costruisci(scn, MAT, coll, SEZ, LEGNO, VOM, CAM_BAY, leggero):
    rnd = random.Random(2026)
    cv = bpy.data.collections.new('Varianti'); scn.collection.children.link(cv)
    for i, (n, posa, br, ge) in enumerate([('v0_seduto', 'seduto', False, None), ('v1_seduto_braccio', 'seduto', True, None),
                                            ('v2_seduto_due', 'seduto', False, 'due'), ('v3_seduto_avanti', 'seduto', False, 'avanti'),
                                            ('v4_piedi', 'in_piedi', False, None), ('v5_piedi_braccio', 'in_piedi', True, None),
                                            ('v6_piedi_due', 'in_piedi', False, 'due'), ('v7_piedi_braccia', 'in_piedi', False, 'braccia')]):
        o = figura(n, posa, br, gesto=ge)
        for c in o.users_collection:
            c.objects.unlink(o)
        cv.objects.link(o)
        o.data.materials.append(MAT['stoffa']); o.data.materials.append(MAT['pelle']); o.data.materials.append(MAT['capelli'])
    scn.view_layers[0].layer_collection.children['Varianti'].exclude = True
    ng = _gn_istanze(cv)
    dens = 0.3 if leggero else 1.0

    vom = [(bay_s(k), dw, df) for k, dw, df, zw in VOM]
    vom.append((bay_s(CAM_BAY) - 0.6, 16.6, 22.0)); vom.append((bay_s(CAM_BAY) + 0.6, 16.6, 22.0))   # bocca della rampa della camera

    def in_vom(s, d, scale):
        for sp, half, of, zf in PALCHI:
            ds = (s - sp + PERIM / 2) % PERIM - PERIM / 2
            if abs(ds) < half + 1.0 and d < 6.2:
                return True
        for sv, dw, df in vom:
            ds = (s - sv + PERIM / 2) % PERIM - PERIM / 2
            if abs(ds) * scale < 1.7 and dw - 0.3 < d < df + 0.2:
                return True
        return False

    P = []

    def righe(d0, z0, n, rise, tread, posa_sed=True, passo=0.52, vuoti=0.06):
        for i in range(n):
            df = d0 + i * tread; zt = z0 + (i + 1) * rise
            d = df + 0.3; off = d - geo.D_TOT
            scale = geo.offset_perim(off) / PERIM
            s = rnd.uniform(0, 0.5)
            while s < PERIM:
                s += passo / scale * rnd.uniform(0.85, 1.15)
                if rnd.random() > dens or rnd.random() < vuoti:
                    continue
                if in_vom(s, d, scale):
                    continue
                p, nn = frame(s)
                dd = d + rnd.uniform(-0.04, 0.04)
                x, y, _ = M(s, dd - geo.D_TOT, 0)
                if any((x - c[0]) ** 2 + (y - c[1]) ** 2 + (zt + 1.0 - c[2]) ** 2 < r * r for c, r in ESCLUSI):
                    continue
                r = _rot_verso(-nn[0], -nn[1]) + rnd.uniform(-0.35, 0.35)
                var = _var(rnd, posa_sed)
                P.append((x, y, zt, r, var, rnd.random(), rnd.uniform(0.9, 1.1)))

    for sez in SEZ:
        righe(*sez)
    righe(*LEGNO)
    # senatori sul podio: più radi
    righe(2.4, 3.6, 3, 0.35, 1.0, passo=0.62, vuoti=0.05)
    # in piedi sui passaggi e nella galleria in cima
    for d0, z0 in ((SEZ[1][0] - 1.0, SEZ[1][1] - 1.5), (SEZ[2][0] - 0.9, SEZ[2][1] - 1.5)):
        righe(d0 - 0.4, z0 - 0.0, 1, 0.0, 0.5, posa_sed=False, passo=2.2, vuoti=0.4)
    zg = LEGNO[1] + LEGNO[2] * LEGNO[3]
    for dd in (44.2, 45.0, 45.8, 46.6, 47.4):
        righe(dd - 0.3, zg, 1, 0.0, 0.5, posa_sed=False, passo=0.6, vuoti=0.1)
    # dentro i palchi: pochi seduti (l'imperatore e la corte), di spalle o di lato, mai in primo piano
    for sp, half, of, zf in PALCHI:
        for i in range(int(14 * max(dens, 0.5))):
            x = rnd.uniform(-half + 1.0, half - 1.0); o = rnd.uniform(of + 1.4, -51.0 + 3.0)
            pp, nn = frame(sp + x)
            q = pp + nn * o
            r = _rot_verso(-nn[0], -nn[1]) + rnd.uniform(-0.4, 0.4)
            P.append((q[0], q[1], zf + 0.45, r, rnd.choice((0, 0, 3)), rnd.choice((0.9, 0.62, 0.05)), 1.0))
    nuvola('folla_cavea', P, coll, ng)
    print('folla cavea', len(P))

    # FUORI: lungo il viale del corteo e sul lastricato
    Q = []
    sc = bay_s(CAM_BAY); pc, nc = frame(sc); tc = np.array([-nc[1], nc[0]])
    for side in (-1, 1):
        for row in range(5):
            lat = side * (9.4 + row * 0.62)
            o = 19.0
            while o < 330:
                o += rnd.uniform(0.45, 0.65)
                if rnd.random() > dens or rnd.random() < 0.05 + row * 0.04:
                    continue
                q = pc + nc * o + tc * (lat + rnd.uniform(-0.15, 0.15))
                vx, vy = -side * tc
                r = _rot_verso(vx, vy) + rnd.uniform(-0.5, 0.5)
                Q.append((q[0], q[1], 0.0, r, 5 if rnd.random() < 0.08 else 4, rnd.random(), rnd.uniform(0.9, 1.1)))
    # il corteo: due file per lato in tunica rossa che marciano verso l'arco (di spalle), corsia centrale libera
    for side in (-1, 1):
        for fila in range(2):
            lat = side * (5.0 + fila * 0.85)
            o = 21.0
            while o < 240:
                o += rnd.uniform(0.75, 1.6)
                q = pc + nc * o + tc * (lat + rnd.uniform(-0.08, 0.08))
                r = _rot_verso(-nc[0], -nc[1]) + rnd.uniform(-0.12, 0.12)
                Q.append((q[0], q[1], 0.0, r, rnd.choice((4, 4, 4, 5)), rnd.random(), rnd.uniform(0.92, 1.08)))
    # gente che entra dagli archi (spalle a noi), corsia della camera libera
    for i in range(int(2600 * dens)):
        s = rnd.uniform(0, PERIM); o = rnd.uniform(1.5, 16.5)
        ds = (s - sc + PERIM / 2) % PERIM - PERIM / 2
        if abs(ds) < 4.6:
            continue
        if abs(ds) > 70 and rnd.random() < 0.75:
            continue
        p, nn = frame(s)
        q = p + nn * o
        r = _rot_verso(-nn[0], -nn[1]) + rnd.uniform(-0.6, 0.6)
        Q.append((q[0], q[1], 0.0, r, rnd.choice((4, 4, 4, 4, 4, 7)), rnd.random(), rnd.uniform(0.9, 1.1)))
    nuvola('folla_fuori', Q, coll, ng)
    print('folla fuori', len(Q))
    return P, Q
