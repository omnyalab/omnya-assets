#!/usr/bin/env python3
"""serve.py — the local server of the kit (the page must be served, never opened as a file).
Usage: python3 tools/serve.py [--open] [--port 5320] [--page "?s=samar"]
  --open  opens Chrome (or the default browser) on the page.
It uses the first free port from 5320 up and prints the address. Stop it with Ctrl+C (or close the window)."""
import http.server, functools, sys, os, socket, subprocess, webbrowser, shutil, threading

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
args = sys.argv[1:]
def opt(name, default):
    if name in args:
        i = args.index(name)
        if i + 1 < len(args): return args[i + 1]
    return default
port0 = int(opt('--port', 5320)); page = opt('--page', '?s=samar')

class H(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map, '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json', '.mp4': 'video/mp4', '.ttf': 'font/ttf'}
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store'); super().end_headers()
    def log_message(self, *a): pass
class S(http.server.ThreadingHTTPServer):
    request_queue_size = 128; daemon_threads = True

def free(p):
    with socket.socket() as s:
        try: s.bind(('127.0.0.1', p)); return True
        except OSError: return False
port = next(p for p in range(port0, port0 + 50) if free(p))
url = f'http://127.0.0.1:{port}/{page}'

def open_chrome():
    if sys.platform == 'darwin':
        if subprocess.call(['open', '-a', 'Google Chrome', url], stderr=subprocess.DEVNULL) == 0: return
    elif sys.platform.startswith('win'):
        for c in [os.path.expandvars(r'%ProgramFiles%\Google\Chrome\Application\chrome.exe'), os.path.expandvars(r'%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe'), os.path.expandvars(r'%LocalAppData%\Google\Chrome\Application\chrome.exe')]:
            if os.path.exists(c): subprocess.Popen([c, url]); return
    else:
        c = shutil.which('google-chrome') or shutil.which('chromium')
        if c: subprocess.Popen([c, url]); return
    webbrowser.open(url)

srv = S(('127.0.0.1', port), functools.partial(H, directory=ROOT))
print(f'Choose Your Floor kit is running: {url}')
print(f'  your tower: http://127.0.0.1:{port}/?s=my-tower   ·   tour: add &auto=A   ·   photoreal: add &reale=1   ·   clean (for guides): add &clean=1')
print('Leave this window open while you work. Ctrl+C stops it.', flush=True)
if '--open' in args: threading.Timer(0.6, open_chrome).start()
try: srv.serve_forever()
except KeyboardInterrupt: pass
