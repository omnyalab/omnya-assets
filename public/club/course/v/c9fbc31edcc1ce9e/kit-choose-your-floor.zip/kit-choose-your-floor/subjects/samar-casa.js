// SAMAR · the special floor "Majlis Al Bahr" (level 15, floor at 65 m: ESTIMATE), built for the SAMAR course (messages 06-1 … 06-5 and 07-x),
// copying the layout of the real photos (references/samar/interiors/living.jpg and bath.jpg).
// Misure vere (06-1): soffitto a 3,0 m dal pavimento, seduta del divano 45 cm, isola 90 cm, porte 2,10 m.
// Coordinate locali della torre B: x lungo l'asse (testata tonda a x < 0), z verso la strada (+z, da dove si entra), y = quota vera. Pavimento FL = F + 0,07 (la lastra del solaio della torre arriva a F + 0,06: sotto, il pavimento spariva).
// Pianta: SALONE x -3,9 → 9 e z -5,6 → vetro +z (parete TV di marmo a z = -5,6 con la porta del bagno a destra, muro di rovere a sinistra a x = -3,9 con l'opera),
//   CUCINA contro il muro di noce a x = 9, PRANZO nella testata tonda, BAGNO dietro la parete TV (x 1 → 9, vetro sul mare a -z), GUARDAROBA dietro la parete TV a sinistra,
//   CAMERA oltre il muro di noce (x 9 → 15).
// Stati del corso (?passo=): 0 = guscio vuoto a misura (06-0) · 1 = pezzi grandi al loro posto come la foto (06-1) · 3 = arredo vissuto (06-3) · 4 o niente = dopo il controllo (06-4).
// ?person=1 sagoma di 1,80 m accanto al divano (06-2) · ?plan=1 pianta dall'alto con le stanze colorate e il giro disegnato (06-5) · ?tour=prima il giro di prima (07, G3 bocciata).
import * as THREE from 'three';
import { stadio, prisma } from './samar-kit.js';
import * as A from './samar-arredi.js';

const Q = new URLSearchParams(location.search);
const rad = d => d * Math.PI / 180;
export const PASSO = Q.get('passo') == null ? 9 : +Q.get('passo');
export const CS = { arretra: 0, zc: 1.8, P1x: 3.4, alto: 3.0, porta: 2.1, zTV: -5.6, xSx: -3.9, xNoce: 9.0, xBagno: 1.0, xDoccia: 6.4, xNucleo: 15.0, portaBagno: [2.8, 4.0], zBagno: -7.6, zBagnoDopo: -5.1, g1Alto: 9, g2Fuoco: 8 };   /* g1Alto: metres of facade in the frame at the end of G1 (tight on the window of floor 15) · g2Fuoco: the point past P1 that stays still in the frame during G2 */   /* dopo (07): ci si ferma sulla soglia del bagno (44 cm prima del muro: la porta riempie tutto il quadro); attraversare la porta dava 8,1-8,8 al giudice */

/* il punto a terra CS.arretra metri dietro la camera madre (lungo il suo sguardo) da cui si sale; 0 = si sale dalla camera madre */
export function indietro(m) { const d = [m.tgt[0] - m.pos[0], m.tgt[2] - m.pos[2]], l = Math.hypot(d[0], d[1]); return [m.pos[0] - d[0] / l * CS.arretra, m.pos[1], m.pos[2] - d[1] / l * CS.arretra]; }
/* dove la camera attraversa il vetro (coordinate locali della torre): si entra a bolla lungo la linea dalla camera madre al punto P1, lì niente montante */
export function entrata(S) {
  const sp = S.casa.speciale, T = S.torri.lista.find(t => t.id === sp.torre), a = rad(T.a), Rg = T.R - T.balcone, m = S.riprese.mondo;
  const B = indietro(m), P1w = [T.x + CS.P1x * Math.cos(a) - CS.zc * Math.sin(a), T.z + CS.P1x * Math.sin(a) + CS.zc * Math.cos(a)], pl = Math.hypot(P1w[0] - B[0], P1w[1] - B[2]);
  const uw = [(P1w[0] - B[0]) / pl, (P1w[1] - B[2]) / pl], ul = [uw[0] * Math.cos(a) + uw[1] * Math.sin(a), -uw[0] * Math.sin(a) + uw[1] * Math.cos(a)];
  const t = (Rg - CS.zc) / -ul[1]; return [CS.P1x - ul[0] * t, Rg, ul];
}

export function casaSamar(S, TT) {
  S._entra = entrata(S);
  const sp = S.casa.speciale, T = S.torri.lista.find(t => t.id === sp.torre), F = sp.F, FL = F + 0.07, Rg = T.R - T.balcone, H = CS.alto, P = PASSO, FIX = P >= 4;
  const g = new THREE.Group(); g.name = 'casa'; g.position.set(T.x, 0, T.z); g.rotation.y = -rad(T.a);
  const MA = A.materialiSamar(), RUG = 0.015, std = (c, r, m = 0, e = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...e });
  const pezzi = []; g.userData.pezzi = pezzi;
  /* mette un pezzo: x, z, rotazione, y dal pavimento; «su» = il pezzo su cui appoggia (per il controllo) */
  const put = (o, x, z, ry = 0, y = 0) => { o.position.set(x, FL + y, z); o.rotation.y = ry; g.add(o); pezzi.push(o); return o; };
  const luce = (x, y, z, k = 1, d = 10) => { const l = new THREE.PointLight(0xffd9a8, 8 * k, d, 1.6); l.position.set(x, FL + y, z); g.add(l); return l; };
  const muri = []; g.userData.muri = muri;
  /* muro dritto spesso 12 cm (box): lungo x (asse 'x', a z = c) o lungo z (asse 'z', a x = c), da a0 ad a1, da y0 a y1 */
  const muro = (asse, c, a0, a1, y0 = 0, y1 = H, mat = MA.intonaco, nome = 'muro') => { const L = a1 - a0, h = y1 - y0, m = new THREE.Mesh(asse === 'x' ? new THREE.BoxGeometry(L, h, 0.12) : new THREE.BoxGeometry(0.12, h, L), mat);
    m.position.set(asse === 'x' ? (a0 + a1) / 2 : c, FL + y0 + h / 2, asse === 'x' ? c : (a0 + a1) / 2); m.castShadow = m.receiveShadow = true; m.userData = { muro: nome }; g.add(m); muri.push(m); return m; };
  /* rivestimento (lastra a 5 mm dal muro): piano verticale; n = verso della faccia (+1/-1 lungo l'asse perpendicolare) */
  const rivesti = (asse, c, n, a0, a1, mat, rep = 1.2, y0 = 0, y1 = H, nome = 'rivestimento') => { const L = a1 - a0, h = y1 - y0, ge = new THREE.PlaneGeometry(L, h), mm = mat.map ? mat.clone() : mat;
    if (mat.map) { mm.map = A.texRep(mat.map, L / rep, h / (rep === 1.2 ? 3 : rep)); }
    const m = new THREE.Mesh(ge, mm); m.receiveShadow = true; m.userData = { rivestimento: nome };
    if (asse === 'x') { m.position.set((a0 + a1) / 2, FL + y0 + h / 2, c + n * 0.065); m.rotation.y = n > 0 ? 0 : Math.PI; } else { m.position.set(c + n * 0.065, FL + y0 + h / 2, (a0 + a1) / 2); m.rotation.y = n > 0 ? Math.PI / 2 : -Math.PI / 2; }
    g.add(m); return m; };
  const xCerchio = z => -Math.sqrt(Math.max(0, Rg * Rg - z * z));   /* bordo del vetro tondo alla quota z */

  // ---------- pavimento, soffitto a 3,0 m, intercapedine ----------
  const sagoma = (x1 = CS.xNucleo) => { const sh = new THREE.Shape(); sh.moveTo(0, -Rg); for (let i = 1; i <= 48; i++) { const t = Math.PI / 2 + Math.PI * i / 48; sh.lineTo(Math.cos(t) * Rg, -Math.sin(t) * Rg); } sh.lineTo(x1, Rg); sh.lineTo(x1, -Rg); sh.closePath(); return sh; };
  const piano = (mat, y, giu = false, rep = 2.4, buco = null) => { const sh = sagoma(); if (buco) { const h = new THREE.Path(); h.moveTo(buco[0], -buco[2]); h.lineTo(buco[1], -buco[2]); h.lineTo(buco[1], -buco[3]); h.lineTo(buco[0], -buco[3]); h.closePath(); sh.holes.push(h); } const ge = new THREE.ShapeGeometry(sh); ge.rotateX(-Math.PI / 2); const uv = ge.attributes.uv, pa = ge.attributes.position; for (let i = 0; i < uv.count; i++) uv.setXY(i, pa.getX(i) / rep, pa.getZ(i) / rep);
    const m = new THREE.Mesh(ge, mat); m.position.y = y; if (giu) { m.rotation.x = Math.PI; m.scale.z = -1; } m.receiveShadow = true; g.add(m); return m; };
  const pavimento = piano(P >= 1 ? MA.pavimento : MA.grezzo, FL); pavimento.userData = { strato: 'pavimento' };
  const BAGNO = [CS.xBagno + 0.06, CS.xNoce - 0.06, -Rg + 0.04, CS.zTV - 0.06];   /* il bagno ha il soffitto d'intonaco (foto vera): buco nelle doghe e lastra bianca alla stessa quota */
  const soffitto = piano(P >= 1 ? MA.doghe : MA.intonaco, FL + H, true, 1.2, P >= 1 ? BAGNO : null); soffitto.userData = { soffitto: true };
  { const sc = piano(std('#2a2522', 0.8), F + T.passo - T.solaio - 0.02, true); sc.userData = { soffitto: true }; }
  // vetro vero del piano (trasparente) con i montanti scuri ogni 1,5 m, tranne dove si entra (G2) e dove si esce (G5)
  { const Pg = stadio(T.L, Rg), vv = new THREE.MeshPhysicalMaterial({ color: '#d6e0e6', roughness: 0.02, transparent: true, opacity: 0.12, side: THREE.DoubleSide, envMapIntensity: 1.4, clearcoat: 1, depthWrite: false });
    const ve = new THREE.Mesh(prisma(Pg, 0, F, F + T.passo - T.solaio, 1), vv); ve.userData = { vetro: true }; g.add(ve);
    const nero = std('#18181a', 0.4, 0.5), d = new THREE.Object3D(), lista = []; let ult = -9;
    for (const q of Pg.pts) { if (q.s - ult < 1.5) continue; ult = q.s; const [x, z] = q.p; if (Math.hypot(x - S._entra[0], z - S._entra[1]) < 1.2) continue; if (z > 0 && Math.abs(x - CS.P1x) < 1.1 && Math.abs(z - Rg) < 0.2) continue;
      d.position.set(x, F + (T.passo - T.solaio) / 2, z); d.rotation.set(0, Math.atan2(q.n[0], q.n[1]), 0); d.scale.set(0.06, T.passo - T.solaio, 0.08); d.updateMatrix(); lista.push(d.matrix.clone()); }
    const im = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), nero, lista.length); lista.forEach((m, i) => im.setMatrixAt(i, m)); im.userData = { vetro: true }; g.add(im); }

  // ---------- muri (12 cm) e porte da 2,10 m ----------
  const hp = CS.porta, [pb0, pb1] = CS.portaBagno, zt = CS.zTV;
  muro('x', zt, xCerchio(zt) + 0.05, -6.0, 0, H, MA.intonaco, 'parete TV (guardaroba)'); muro('x', zt, -4.8, pb0, 0, H, MA.intonaco, 'parete TV'); muro('x', zt, pb1, CS.xNoce - 0.06, 0, H, MA.intonaco, 'parete TV (destra)');
  muro('x', zt, -6.0, -4.8, hp, H, MA.intonaco, 'sopraluce guardaroba'); muro('x', zt, pb0, pb1, hp, H, MA.intonaco, 'sopraluce bagno');
  muro('z', CS.xSx, zt + 0.06, -0.8, 0, H, MA.intonaco, 'muro di sinistra');
  muro('z', CS.xNoce, -Rg, 6.4, 0, H, MA.intonaco, 'muro di noce'); muro('z', CS.xNoce, 7.6, Rg, 0, H, MA.intonaco, 'muro di noce (fondo)'); muro('z', CS.xNoce, 6.4, 7.6, hp, H, MA.intonaco, 'sopraluce camera');
  muro('z', CS.xBagno, -Rg, zt - 0.06, 0, H, MA.intonaco, 'muro bagno-guardaroba');
  { const n = new THREE.Mesh(new THREE.BoxGeometry(0.3, H, 2 * Rg), MA.noce); n.position.set(CS.xNucleo + 0.15, FL + H / 2, 0); n.userData = { muro: 'nucleo' }; g.add(n); muri.push(n); }
  // stipiti di bronzo e ante aperte a battuta contro il muro (dalla parte della stanza dopo)
  const stipiti = (asse, c, a0, a1) => { const b = MA.bronzo; for (const a of [a0, a1]) { const m = new THREE.Mesh(asse === 'x' ? new THREE.BoxGeometry(0.03, hp, 0.14) : new THREE.BoxGeometry(0.14, hp, 0.03), b); m.position.set(asse === 'x' ? a : c, FL + hp / 2, asse === 'x' ? c : a); g.add(m); }
    const t = new THREE.Mesh(asse === 'x' ? new THREE.BoxGeometry(a1 - a0 + 0.06, 0.03, 0.14) : new THREE.BoxGeometry(0.14, 0.03, a1 - a0 + 0.06), b); t.position.set(asse === 'x' ? (a0 + a1) / 2 : c, FL + hp + 0.015, asse === 'x' ? c : (a0 + a1) / 2); g.add(t); };
  const anta = (x, z, ax, L) => { const m = new THREE.Mesh(ax === 'x' ? new THREE.BoxGeometry(L, hp - 0.02, 0.04) : new THREE.BoxGeometry(0.04, hp - 0.02, L), MA.noce); m.position.set(x, FL + hp / 2, z); m.castShadow = true; m.userData = { pezzo: 'anta', tipo: 'porta' }; g.add(m); pezzi.push(m); };
  stipiti('x', zt, pb0, pb1); stipiti('x', zt, -6.0, -4.8); stipiti('z', CS.xNoce, 6.4, 7.6);
  anta(pb1 + 0.6, zt - 0.1, 'x', 1.18); anta(-6.0 - 0.6, zt - 0.1, 'x', 1.18); anta(CS.xNoce + 0.1, 7.6 + 0.6, 'z', 1.18);

  // ---------- rivestimenti (06-1): marmo palissandro dietro la TV, rovere a pannelli, travertino nel bagno; travi scure sotto le doghe ----------
  if (P >= 1) {
    rivesti('x', zt, 1, -2.3, 2.3, MA.palissandro, 3.0, 0, H, 'marmo parete TV'); rivesti('x', zt, 1, CS.xSx + 0.06, -2.3, MA.rovere, 1.2, 0, H, 'rovere'); rivesti('x', zt, 1, 2.3, pb0, MA.rovere); rivesti('x', zt, 1, pb1, CS.xNoce - 0.06, MA.rovere);
    rivesti('x', zt, 1, xCerchio(zt) + 0.1, -6.0, MA.rovere); rivesti('x', zt, 1, -4.8, CS.xSx - 0.06, MA.rovere);
    rivesti('z', CS.xSx, 1, zt + 0.06, -0.8, MA.rovere, 1.2, 0, H, 'rovere muro sinistra'); rivesti('z', CS.xSx, -1, zt + 0.06, -0.8, MA.rovere);
    rivesti('z', CS.xNoce, -1, zt + 0.06, 6.4, MA.rovere); rivesti('z', CS.xNoce, -1, 7.6, Rg - 0.1, MA.rovere); rivesti('z', CS.xNoce, -1, 6.4, 7.6, MA.rovere, 1.2, hp + 0.03, H);
    rivesti('x', zt, 1, pb0, pb1, MA.rovere, 1.2, hp + 0.03, H); rivesti('x', zt, 1, -6.0, -4.8, MA.rovere, 1.2, hp + 0.03, H); rivesti('x', zt, -1, pb0, pb1, MA.travBagno, 2.4, hp + 0.03, H);
    rivesti('x', zt, -1, CS.xBagno + 0.06, pb0, MA.travBagno, 2.4, 0, H, 'travertino bagno'); rivesti('x', zt, -1, pb1, CS.xNoce - 0.06, MA.travBagno, 2.4);
    rivesti('z', CS.xBagno, 1, -Rg + 0.05, zt - 0.06, MA.travBagno, 2.4); rivesti('z', CS.xNoce, -1, -Rg + 0.05, zt - 0.06, MA.travBagno, 2.4);
    // travi scure (foto vera) lungo z e due di traverso, sotto le doghe
    const trave = (x0, x1, z0, z1) => { const m = new THREE.Mesh(new THREE.BoxGeometry(x1 - x0, 0.12, z1 - z0), MA.trave); m.position.set((x0 + x1) / 2, FL + H - 0.06, (z0 + z1) / 2); m.userData = { soffitto: true, trave: true }; g.add(m); };
    for (const x of [-2.6, 0.7, 4.6, 7.4]) trave(x - 0.13, x + 0.13, zt + 0.06, Rg - 0.3);
    for (const z of [-4.4, 2.4]) trave(CS.xSx + 0.06, CS.xNoce - 0.06, z - 0.13, z + 0.13);
    // faretti incassati nel soffitto
    /* faretti: prima un disco acceso 3 mm sotto il soffitto (due superfici quasi sovrapposte, sfarfallano); 06-4: anello di bronzo da 1,2 cm con la luce sotto */
    const faro = new THREE.CircleGeometry(0.045, 16), fm = MA.luce, anello = new THREE.CylinderGeometry(0.065, 0.065, 0.012, 24);
    for (const [x, z] of [[-3.3, -4.9], [-1.0, -4.9], [1.3, -4.9], [5.0, -4.9], [7.0, -4.9], [8.4, -3.5], [8.4, -1.0], [8.4, 2.0], [-3.3, 0.5], [2.2, 0.5], [5.8, 4.4], [2.2, 6.4]]) { const f = new THREE.Mesh(faro, fm); f.rotation.x = Math.PI / 2; f.position.set(x, FL + H - (FIX ? 0.013 : 0.003), z); f.userData = { soffitto: true }; g.add(f);
      if (FIX) { const r = new THREE.Mesh(anello, MA.bronzo); r.position.set(x, FL + H - 0.006, z); r.userData = { soffitto: true }; g.add(r); } }
    { const sb = new THREE.Mesh(new THREE.PlaneGeometry(BAGNO[1] - BAGNO[0], BAGNO[3] - BAGNO[2]), MA.intonaco); sb.rotation.x = Math.PI / 2; sb.position.set((BAGNO[0] + BAGNO[1]) / 2, FL + H, (BAGNO[2] + BAGNO[3]) / 2); sb.userData = { soffitto: true }; g.add(sb); }
  }

  // luci generali (anche nel guscio vuoto) e la tenda scura del bagno tirata davanti al sole basso della sera (dalla porta il sole abbagliava)
  luce(0.5, 2.7, -0.8, 0.7, 10); luce(0.0, 2.7, 2.4, 0.7, 9); luce(5.5, 2.7, 4.0, 0.8, 10); luce(3.5, 2.6, -8.0, 0.55, 7);
  put(A.tenda(MA, 2.0, H), 5.3, -Rg + 0.22, 0, H);
  // ---------- 06-1 · SALONE come la foto: divano angolare davanti alla parete di marmo con la TV, due poltrone scure di lato, lampadario d'ottone sopra ----------
  if (P >= 1) {
    put(A.tappeto(MA, 5.3, 4.25), -0.3, -2.875);
    put(A.divanoAngolare(MA), -1.0, -1.525, Math.PI, RUG);                 // schiena verso l'ingresso, guarda la TV (-z); ritorno a sinistra, chaise a destra
    put(A.tavolinoMarmo(MA), -0.95, -2.9, 0, RUG);
    put(A.poltronaScura(MA), 1.55, -3.55, Math.atan2(-2.5, 0.65), RUG); put(A.poltronaScura(MA), 1.85, -4.55, Math.atan2(-2.8, 1.65), RUG);   // rivolte al tavolino e al divano
    { const t = A.tv(MA); put(t, 0.0, zt + 0.065, 0, 1.45); } put(A.consolle(MA), 0.0, zt + 0.065, 0);
    { const l = A.lampadarioRami(MA, 1.0); put(l, -0.95, -3.3, 0, H); luce(-0.95, 2.15, -3.3, 1.1, 9); }
    put(A.lampadaCupola(MA), -3.35, -1.5); luce(-3.35, 1.4, -1.5, 0.5, 5);
    put(A.operaMaterica(MA), CS.xSx + 0.065, -2.6, Math.PI / 2, 1.55);
    put(A.vasoNero(MA, 1.0), 1.45, zt + 0.065 + 0.22, 0, 0.64);
    // cucina contro il muro di noce, isola da 90 cm parallela, sgabelli rivolti all'isola, tre cupole d'ottone
    put(A.cucinaParete(MA, 4.4, H), CS.xNoce - 0.07, -2.8, -Math.PI / 2);
    put(A.isola(MA), 6.75, -2.8, Math.PI / 2);
    for (const z of [-3.9, -2.8, -1.7]) { put(A.sgabello(MA), 5.85, z, Math.PI / 2); put(A.pendenteCupola(MA, 1.05), 6.75, z, 0, H); }
    luce(6.75, 1.8, -2.8, 0.9, 6);
    // bagno come la foto: vasca di travertino davanti al vetro sul mare, doppio lavabo sospeso con lo specchio acceso, doccia di vetro
    put(A.vascaTravertino(MA), 2.7, -9.4, 0); put(A.rubinettoTerra(MA), 3.85, -9.4, Math.PI / 2);
    put(A.doppioLavabo(MA), CS.xBagno + 0.065, -7.3, Math.PI / 2); put(A.specchioLed(MA, 2.4, 1.0, FIX), CS.xBagno + 0.065, -7.3, Math.PI / 2, 1.7);
    { const v = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 2.2), MA.vetroDoccia); v.rotation.y = Math.PI / 2; v.position.set(CS.xDoccia, FL + 1.1, zt - 0.06 - 1.6); v.userData = { pezzo: 'vetro doccia', tipo: 'terra', piano: true }; g.add(v);
      const b = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 3.2), MA.bronzo); b.position.set(CS.xDoccia, FL + 2.2, zt - 0.06 - 1.6); g.add(b); }
 luce(1.7, 1.7, -7.3, 0.3, 4);
  }
  // ---------- 06-3 · arredo vissuto: pranzo con le sedie rivolte al tavolo, fiori, libri d'arte, candele, ciotola d'ottone, vaso alto con i rami, angolo lettura ----------
  if (P >= 3) {
    const TX = -6.8, TZ = 0.9; put(A.tavoloPranzo(MA), TX, TZ, Math.PI / 2);
    const sedie = [[TX - 0.98, TZ - 1.0], [TX - 0.98, TZ], [TX - 0.98, TZ + 1.0], [TX + 0.98, TZ - 1.0], [TX + 0.98, TZ], [TX + 0.98, TZ + 1.0], [TX, TZ - 1.92], [TX, TZ + 1.92]];
    for (const [x, z] of sedie) put(A.sediaPranzo(MA), x, z, Math.abs(x - TX) > 0.1 ? (x < TX ? Math.PI / 2 : -Math.PI / 2) : (z < TZ ? 0 : Math.PI));   // davanti (+z locale) dritto verso il bordo del tavolo, schienale fuori
    { const b = A.barraLuce(MA, 2.2, 1.15); put(b, TX, TZ, Math.PI / 2, H); luce(TX, 1.8, TZ, 1.0, 7); }
    put(A.fiori(MA, 1.1), TX, TZ, 0, 0.75); put(A.candele(MA, true), TX, TZ - 0.85, Math.PI / 2, 0.75); put(A.candele(MA, true), TX, TZ + 0.85, Math.PI / 2, 0.75);
    put(A.libriArte(MA, 3, 0), -1.25, -3.05, 0.2, RUG + 0.38); put(A.ciotolaOttone(MA), -0.75, -2.75, 0, RUG + 0.38); put(A.candele(MA), -1.05, zt + 0.065 + 0.2, 0, 0.64); put(A.libriArte(MA, 2, 2), -1.5, zt + 0.065 + 0.2, 0.1, 0.64);
    if (FIX) put(A.vasoRami(MA, 0.32), -3.25, -4.95); else put(A.vasoRami(MA), -3.45, -5.15);   /* 06-4: i rami entravano di 11-12 cm nei due muri dell'angolo → più stretto e staccato dall'angolo */
    put(A.fiori(MA, 0.9), 6.75, -3.4, 0, 0.9); put(A.ciotolaOttone(MA), 6.75, -2.2, 0, 0.9);
    // angolo lettura davanti al vetro sul mare, ulivo nella testata tonda, tende pesanti raccolte ai lati
    put(A.poltronaLounge(MA), -1.5, 6.4, 0.25); put(A.poltronaLounge(MA), 0.6, 6.4, -0.25); put(A.tavolinoTondo(MA), -0.45, 7.3); put(A.libriArte(MA, 2, 1), -0.45, 7.3, 0.5, 0.52); luce(-0.45, 2.4, 6.8, 0.6, 7);
    put(A.ulivo(MA, 1.1), -6.3, 6.2); put(A.ulivo(MA, 0.9), -7.6, -4.0);
    put(A.tenda(MA, 0.7, H), 8.5, Rg - 0.22, 0, H); put(A.tenda(MA, 0.7, H), 0.2, Rg - 0.22, 0, H); put(A.tenda(MA, 0.7, H), 1.5, -Rg + 0.22, 0, H);
    put(A.portaSalviette(MA), 5.6, zt - 0.065, Math.PI, 1.2); put(A.fiori(MA, 0.8), CS.xBagno + 0.065 + 0.25, -8.4, 0, 0.88);
    // camera e guardaroba (si vedono solo in pianta)
    put(A.letto(MA), CS.xNucleo - 1.21, 0.0, -Math.PI / 2); put(A.comodino(MA), CS.xNucleo - 0.3, -1.65, -Math.PI / 2); put(A.comodino(MA), CS.xNucleo - 0.3, 1.65, -Math.PI / 2); luce(12, 2.6, 0, 0.6, 8);
    { const ar = new THREE.Group(); ar.userData = { pezzo: 'armadi', tipo: 'terra' }; const m = new THREE.Mesh(new THREE.BoxGeometry(4.6, 2.6, 0.6), MA.noce); m.position.set(0, 1.3, 0); m.castShadow = true; ar.add(m); put(ar, -1.75, zt - 0.06 - 0.31); luce(-3.0, 2.6, -8.0, 0.4, 6); }
  }
  // ---------- 06-2 · sagoma di persona da 1,80 m accanto al divano ----------
  if (Q.get('person') === '1') put(A.sagomaPersona(MA, 1.8), 1.25, -0.35, -2.6);

  // ---------- 06-5 · pianta dall'alto: stanze colorate e giro disegnato ----------
  /* dentro casa il cielo non si riflette come fuori: riflessi dell'ambiente bassi su tutto tranne vetro e specchi */
  g.traverse(o => { if (!o.isMesh || o.userData.vetro) return; for (const m of Array.isArray(o.material) ? o.material : [o.material]) if (m && m.isMeshStandardMaterial && m.envMapIntensity === 1) m.envMapIntensity = m.metalness > 0.5 ? 0.45 : +(Q.get('env') || 0.12); });   /* i metalli vivono di riflessi: un po' di più */
  if (Q.get('plan') === '1') pianta(g, FL, Rg, H);
  return g;
}

/* pianta (06-5): niente soffitti, stanze in colori trasparenti con il nome, il giro della camera (07-1) in arancio con le frecce e le fermate numerate */
function pianta(g, FL, Rg, H) {
  g.traverse(o => { if (o.userData && (o.userData.soffitto || o.userData.pezzo === 'lampadario' || o.userData.pezzo === 'lampada del pranzo' || o.userData.pezzo === 'sospensione' || o.userData.pezzo === 'tenda')) o.visible = false; });
  g.add(new THREE.AmbientLight(0xfff4e6, 1.6));
  const fondo = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.MeshBasicMaterial({ color: '#16181c' })); fondo.rotation.x = -Math.PI / 2; fondo.position.y = FL - 0.6; g.add(fondo);
  const circX = (x0, x1, n = 12) => { const p = []; for (let i = 0; i <= n; i++) { const x = x0 + (x1 - x0) * i / n; p.push([x, Math.sqrt(Math.max(0, Rg * Rg - x * x))]); } return p; };
  const circ = (z0, z1, n = 24) => { const p = []; for (let i = 0; i <= n; i++) { const z = z0 + (z1 - z0) * i / n; p.push([-Math.sqrt(Math.max(0, Rg * Rg - z * z)), z]); } return p; };
  const zt = CS.zTV + 0.06;
  const stanze = [
    { nome: 'LIVING', col: '#3d7bd9', pts: [[CS.xSx + 0.06, zt], [CS.xNoce - 0.06, zt], [CS.xNoce - 0.06, Rg], [0, Rg], ...circX(0, CS.xSx + 0.06)], lab: [1.2, 3.6] },
    { nome: 'KITCHEN', col: '#3fae6a', pts: [[5.0, zt], [CS.xNoce - 0.06, zt], [CS.xNoce - 0.06, 0.3], [5.0, 0.3]], lab: [7.0, -0.4], sopra: true },
    { nome: 'DINING', col: '#e0a63a', pts: [[CS.xSx - 0.06, zt], [CS.xSx - 0.06, Math.sqrt(Rg * Rg - (CS.xSx - 0.06) ** 2)], ...circ(Math.sqrt(Rg * Rg - (CS.xSx - 0.06) ** 2), zt)], lab: [-6.6, 4.6] },
    { nome: 'BATH', col: '#d9578b', pts: [[CS.xBagno + 0.06, -Rg], [CS.xNoce - 0.06, -Rg], [CS.xNoce - 0.06, zt - 0.12], [CS.xBagno + 0.06, zt - 0.12]], lab: [5.0, -8.0] },
    { nome: 'DRESSING', col: '#8e6bd6', pts: [...circ(zt - 0.12, -Rg + 0.0), [CS.xBagno - 0.06, -Rg], [CS.xBagno - 0.06, zt - 0.12]], lab: [-3.6, -8.4] },
    { nome: 'BEDROOM', col: '#2fb3b0', pts: [[CS.xNoce + 0.06, -Rg], [CS.xNucleo, -Rg], [CS.xNucleo, Rg], [CS.xNoce + 0.06, Rg]], lab: [12.0, 4.6] },
  ];
  for (const s of stanze) { const sh = new THREE.Shape(); s.pts.forEach(([x, z], i) => (i ? sh.lineTo(x, -z) : sh.moveTo(x, -z))); const ge = new THREE.ShapeGeometry(sh); ge.rotateX(-Math.PI / 2);
    const m = new THREE.Mesh(ge, new THREE.MeshBasicMaterial({ color: s.col, transparent: true, opacity: 0.34, depthWrite: false })); m.position.y = FL + 0.007 + (s.sopra ? 0.001 : 0); m.renderOrder = 2; g.add(m);
    const ed = new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(s.pts.map(([x, z]) => new THREE.Vector3(x, FL + 2.9, z))), new THREE.LineBasicMaterial({ color: s.col })); g.add(ed);
    g.add(etichetta(s.nome, s.lab[0], FL + 2.92, s.lab[1], s.col)); }
  // il giro (07-1): 2 dentro dal vetro fino al salone · 3 il salone · fermi e girati verso il bagno · 4 dritti nel bagno · 5 indietro fuori, la torre davanti
  const P1 = [CS.P1x, CS.zc], e = new THREE.Vector2(...[CS.P1x - 0.4485 * -11.5, CS.zc - 0.8938 * -11.5]), B = [CS.P1x, CS.zBagnoDopo], y = FL + 2.95, arancio = '#ff8a1e';
  const nastro = (a, b, col, w = 0.16, freccia = true) => { const d = new THREE.Vector2(b[0] - a[0], b[1] - a[1]), L = d.length(), n = d.clone().normalize(), Lb = freccia ? L - 0.55 : L;
    const r = new THREE.Mesh(new THREE.PlaneGeometry(Lb, w), new THREE.MeshBasicMaterial({ color: col, depthTest: false, toneMapped: false, transparent: true })); r.rotation.set(-Math.PI / 2, 0, Math.atan2(-n.y, n.x)); r.position.set(a[0] + n.x * Lb / 2, y, a[1] + n.y * Lb / 2); r.renderOrder = 5; g.add(r);
    if (freccia) { const sh = new THREE.Shape(); sh.moveTo(0.6, 0); sh.lineTo(0, 0.32); sh.lineTo(0, -0.32); sh.closePath(); const f = new THREE.Mesh(new THREE.ShapeGeometry(sh), r.material); f.rotation.set(-Math.PI / 2, 0, Math.atan2(-n.y, n.x)); f.position.set(a[0] + n.x * (L - 0.6), y, a[1] + n.y * (L - 0.6)); f.renderOrder = 5; g.add(f); } };
  nastro([e.x, e.y], P1, arancio); nastro(P1, [B[0], B[1]], arancio);
  nastro([B[0] + 0.45, B[1]], [B[0] + 0.45, Rg + 1.1], '#f4efe6', 0.1);   // 5: indietro fuori dal vetro (stessa linea, sguardo fisso sul bagno)
  { const yaw0 = Math.atan2(-0.4485, -0.8938), yaw1 = Math.PI, pts = []; for (let i = 0; i <= 20; i++) { const a = yaw0 + (yaw1 - yaw0 - 2 * Math.PI) * i / 20; pts.push(new THREE.Vector3(P1[0] + Math.sin(a) * 1.25, y, P1[1] + Math.cos(a) * 1.25)); }
    const tb = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 40, 0.09, 8), new THREE.MeshBasicMaterial({ color: '#ffd400', depthTest: false, toneMapped: false, transparent: true })); tb.renderOrder = 6; g.add(tb); }
  for (const [n, x, z] of [['2·3', P1[0] - 1.3, P1[1] + 0.6], ['4', B[0], B[1] - 0.1], ['5', B[0] + 1.3, Rg + 0.6]]) g.add(etichetta(n, x, y + 0.02, z, arancio, true));
}
function etichetta(testo, x, y, z, col, tondo = false) {
  const c = document.createElement('canvas'), w = tondo ? 256 : 768, h = tondo ? 256 : 192; c.width = w; c.height = h; const k = c.getContext('2d');
  if (tondo) { k.fillStyle = col; k.beginPath(); k.arc(w / 2, h / 2, w / 2 - 6, 0, 7); k.fill(); k.fillStyle = '#111'; k.font = `700 ${testo.length > 1 ? 92 : 140}px Helvetica, Arial`; }
  else { k.fillStyle = 'rgba(14,16,20,0.78)'; const r = 40; k.beginPath(); k.roundRect(8, 30, w - 16, h - 60, r); k.fill(); k.fillStyle = col; k.fillRect(36, h / 2 - 22, 44, 44); k.fillStyle = '#fff'; k.font = '600 76px Helvetica, Arial'; }
  k.textAlign = 'center'; k.textBaseline = 'middle'; k.fillText(testo, tondo ? w / 2 : w / 2 + 34, h / 2 + 4);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; const s = tondo ? 1.1 : 3.2, m = new THREE.Mesh(new THREE.PlaneGeometry(s, s * h / w), new THREE.MeshBasicMaterial({ map: t, transparent: true, depthTest: false }));
  m.rotation.x = -Math.PI / 2; m.position.set(x, y, z); m.renderOrder = 8; return m;
}

/* controllo 06-4: misura davvero (scatole dei pezzi, muri, appoggi, superfici sovrapposte, verso delle sedie). Lo chiama strumenti (window.__controllaCasa) */
export function controllaCasa(g, FL, H) {
  g.updateMatrixWorld(true); const out = [], box = o => new THREE.Box3().setFromObject(o), tol = 0.012;
  const pezzi = g.userData.pezzi.filter(o => o.visible !== false), muri = g.userData.muri;
  const meshDi = p => { const l = []; p.traverse(o => { if (o.isMesh && o.visible && !(o.material && o.material.transparent && o.material.opacity < 0.3 && !(o.userData && o.userData.piano))) l.push(o); }); return l; };
  const nome = p => `${p.userData.pezzo} (${(p.position.x).toFixed(2)}, ${(p.position.z).toFixed(2)})`;
  const pen = (a, b) => Math.min(a.max.x - b.min.x, b.max.x - a.min.x, a.max.y - b.min.y, b.max.y - a.min.y, a.max.z - b.min.z, b.max.z - a.min.z);
  const mb = new Map(); for (const p of pezzi) mb.set(p, meshDi(p).map(m => box(m)));
  // 1) pezzi che entrano nei muri
  for (const p of pezzi) for (const w of muri) { const bw = box(w); let mx = 0; for (const b of mb.get(p)) if (b.intersectsBox(bw)) mx = Math.max(mx, pen(b, bw)); if (mx > tol) out.push({ tipo: 'entra nel muro', pezzo: nome(p), muro: w.userData.muro, cm: +(mx * 100).toFixed(1) }); }
  // 2) pezzi che si compenetrano (il tappeto è uno strato: si guarda solo che i pezzi ci stiano sopra)
  for (let i = 0; i < pezzi.length; i++) for (let j = i + 1; j < pezzi.length; j++) { const a = pezzi[i], b = pezzi[j]; if (a.userData.strato || b.userData.strato) continue;
    let mx = 0; for (const ba of mb.get(a)) for (const bb of mb.get(b)) if (ba.intersectsBox(bb)) mx = Math.max(mx, pen(ba, bb)); if (mx > tol) out.push({ tipo: 'si compenetrano', pezzo: nome(a), con: nome(b), cm: +(mx * 100).toFixed(1) }); }
  // 3) cose che volano o che sprofondano: «terra» tocca il pavimento (o il tappeto se ci sta sopra), «su» tocca un piano sotto, «appeso» arriva al soffitto, «muro» tocca un muro o un rivestimento
  const rug = pezzi.find(p => p.userData.strato), brug = rug ? box(rug) : null, riv = []; g.traverse(o => { if (o.userData && o.userData.rivestimento) riv.push(box(o).expandByScalar(0.004)); });
  for (const p of pezzi) { const b = box(p), t = p.userData.tipo;
    /* impronta = solo le parti che toccano terra (gambe, zoccolo, vaso), non i rami o i braccioli che sporgono in aria */
    const im = new THREE.Box3(), v = new THREE.Vector3(); for (const m of meshDi(p)) { const pa = m.geometry.attributes.position; for (let i = 0; i < pa.count; i++) { v.fromBufferAttribute(pa, i).applyMatrix4(m.matrixWorld); if (v.y < b.min.y + 0.01) im.expandByPoint(v); } } if (im.isEmpty()) im.copy(b);   /* i vertici che toccano terra */
    const sulTappeto = brug && im.min.x > brug.min.x - 0.01 && im.max.x < brug.max.x + 0.01 && im.min.z > brug.min.z - 0.01 && im.max.z < brug.max.z + 0.01;
    const sottoTappeto = brug && !sulTappeto && im.max.x > brug.min.x && im.min.x < brug.max.x && im.max.z > brug.min.z && im.min.z < brug.max.z;
    if (t === 'porta' && (b.min.y - FL > 0.015 || b.min.y < FL - 0.002)) out.push({ tipo: 'porta: luce da terra sbagliata', pezzo: nome(p), cm: +((b.min.y - FL) * 100).toFixed(1) });   /* sotto un'anta 0-1,5 cm di luce è giusto */
    if (t === 'terra' && !p.userData.strato) { const base = FL + (sulTappeto ? 0.015 : 0), d = b.min.y - base; if (Math.abs(d) > 0.006) out.push({ tipo: d > 0 ? 'vola' : 'sprofonda', pezzo: nome(p), cm: +(d * 100).toFixed(1) });
      if (sottoTappeto) out.push({ tipo: 'a cavallo del bordo del tappeto', pezzo: nome(p) }); }
    if (t === 'su') { let ok = false, best = 9; for (const q of pezzi) { if (q === p) continue; for (const bq of mb.get(q)) { if (bq.max.x < b.min.x || bq.min.x > b.max.x || bq.max.z < b.min.z || bq.min.z > b.max.z) continue; const d = b.min.y - bq.max.y; if (Math.abs(d) < Math.abs(best)) best = d; if (Math.abs(d) < 0.006) ok = true; } }
      if (!ok) out.push({ tipo: best > 0 ? 'vola sopra il piano' : 'entra nel piano', pezzo: nome(p), cm: +(best * 100).toFixed(1) }); }
    if (t === 'appeso' && Math.abs(b.max.y - (FL + H)) > 0.006) out.push({ tipo: b.max.y > FL + H ? 'entra nel soffitto' : 'non arriva al soffitto', pezzo: nome(p), cm: +((b.max.y - FL - H) * 100).toFixed(1) });
    if (t === 'muro') { const near = [...muri.map(w => box(w).expandByScalar(0.004)), ...riv].some(bw => bw.intersectsBox(b)); if (!near) out.push({ tipo: 'staccato dal muro', pezzo: nome(p) }); } }
  // 4) superfici sovrapposte (stesso piano, a meno di 5 mm, che si coprono): orizzontali (pavimenti, piani) e verticali (rivestimenti)
  const sup = []; g.traverse(o => { if (!o.isMesh || !o.visible) return; const ge = o.geometry; if (!ge.boundingBox) ge.computeBoundingBox(); const b = box(o), s = b.getSize(new THREE.Vector3());
    const ax = s.y < 0.003 ? 'y' : s.x < 0.003 ? 'x' : s.z < 0.003 ? 'z' : null; if (ax) sup.push({ o, b, ax, c: (b.min[ax] + b.max[ax]) / 2 }); });
  for (let i = 0; i < sup.length; i++) for (let j = i + 1; j < sup.length; j++) { const a = sup[i], b = sup[j]; if (a.ax !== b.ax || Math.abs(a.c - b.c) > 0.005) continue; const o = ['x', 'y', 'z'].filter(k => k !== a.ax);
    const ov = o.map(k => Math.min(a.b.max[k], b.b.max[k]) - Math.max(a.b.min[k], b.b.min[k])); if (!(ov[0] > 0.01 && ov[1] > 0.01)) continue;
    /* le scatole si coprono: si guarda davvero con 7 x 7 raggi perpendicolari se lo stesso punto sta su tutte e due le superfici (i buchi, es. il soffitto del bagno, non contano) */
    let doppi = 0; const rc = new THREE.Raycaster(), dir = new THREE.Vector3(), lo = o.map(k => Math.max(a.b.min[k], b.b.min[k]));
    for (let i = 0; i < 7; i++) for (let j = 0; j < 7; j++) { const p0 = new THREE.Vector3(); p0[o[0]] = lo[0] + ov[0] * (i + 0.5) / 7; p0[o[1]] = lo[1] + ov[1] * (j + 0.5) / 7; p0[a.ax] = a.c + 0.05; dir.set(0, 0, 0); dir[a.ax] = -1;
      const su = q => { rc.set(p0, dir); rc.far = 0.1; if (rc.intersectObject(q, false).length) return true; const p1 = p0.clone(); p1[a.ax] = a.c - 0.05; rc.set(p1, dir.clone().negate()); return rc.intersectObject(q, false).length > 0; };   /* da sopra o da sotto: le facce hanno un lato solo */
      if (su(a.o) && su(b.o)) doppi++; }
    if (doppi) { const nm = x => x.o.userData.strato || x.o.userData.rivestimento || x.o.userData.pezzo || x.o.parent?.userData?.pezzo || x.o.geometry.type;
      out.push({ tipo: 'superfici sovrapposte', a: nm(a), b: nm(b), mm: +(Math.abs(a.c - b.c) * 1000).toFixed(1), punti: doppi + '/49' }); } }
  // 5) sedie col verso sbagliato: il davanti (+z locale) deve guardare il centro del tavolo (o dell'isola)
  //    (il raggio che parte dalla sedia nel verso della seduta deve colpire il piano del tavolo più vicino entro 1 m, e la sedia deve stare dritta sul bordo: al massimo 10° di storto)
  const tavoli = pezzi.filter(p => p.userData.tavolo === true).map(p => box(p)), ray = new THREE.Ray(), hit = new THREE.Vector3();
  for (const p of pezzi.filter(p => p.userData.sedia)) { const f = new THREE.Vector3(0, 0, 1).applyQuaternion(p.getWorldQuaternion(new THREE.Quaternion())).setY(0).normalize(), c = p.getWorldPosition(new THREE.Vector3());
    const t = tavoli.reduce((a, q) => (a && a.distanceToPoint(c) < q.distanceToPoint(c) ? a : q), null); if (!t) continue; const tb = t.clone(); tb.min.y = -1e4; tb.max.y = 1e4;
    ray.set(c, f); const h = ray.intersectBox(tb, hit), dist = h ? h.distanceTo(c) : Infinity, storto = Math.min(...[[1, 0], [-1, 0], [0, 1], [0, -1]].map(([x, z]) => Math.acos(Math.max(-1, Math.min(1, f.x * x + f.z * z))) * 180 / Math.PI));
    if (dist > 1.0) out.push({ tipo: 'sedia girata male (non guarda il tavolo)', pezzo: nome(p) }); else if (storto > 10) out.push({ tipo: 'sedia storta rispetto al tavolo', pezzo: nome(p), gradi: +storto.toFixed(0) }); }
  // 6) il pavimento si vede davvero? raggi dall'alto ogni 50 cm: la prima superficie all'altezza del pavimento deve essere della casa, non della torre
  { const rc = new THREE.Raycaster(), root = g.parent || g, bw = muri.map(w => box(w)); let coperti = 0, chi = new Set();
    for (let x = -10; x <= 14.8; x += 0.5) for (let z = -10; z <= 10; z += 0.5) { const pl = new THREE.Vector3(x, FL + 2.5, z); if (x < 0 && Math.hypot(x, z) > 10.2) continue; const pw = g.localToWorld(pl.clone()); if (bw.some(b => b.containsPoint(pw.clone().setY(FL + 1)))) continue;
      rc.set(pw, new THREE.Vector3(0, -1, 0)); const hs = rc.intersectObject(root, true).filter(h => h.point.y < FL + 0.03 && h.point.y > FL - 0.2); if (!hs.length) continue;
      let o = hs[0].object, mia = false; while (o) { if (o === g) { mia = true; break; } o = o.parent; } if (!mia) { coperti++; chi.add((hs[0].object.parent && hs[0].object.parent.name) + ' a ' + hs[0].point.y.toFixed(3)); } }
    if (coperti) out.push({ tipo: 'pavimento coperto da un\'altra superficie', punti: coperti, da: [...chi].slice(0, 3) }); }
  return { pezzi: pezzi.length, muri: muri.length, errori: out };
}

/* Giro A (07-1): 1 la torre al tramonto · 2 dentro dal vetro del piano 15 nel salone · 3 il salone · 4 nel bagno · 5 fuori, la torre davanti.
   Tratti dritti (ognuno una guida da 3-4 s). ?tour=prima: il tratto salone → bagno gira e cammina insieme (G3 di prima, bocciata dal giudice); senza: fermi, girata da fermi, poi dritti (07-4). */
export function giroSamar(S, M) {
  const sp = S.casa.speciale, T = S.torri.lista.find(t => t.id === sp.torre), E = sp.F + 0.07 + 1.7, a = rad(T.a);
  const W = (lx, y, lz) => [T.x + lx * Math.cos(a) - lz * Math.sin(a), y, T.z + lx * Math.sin(a) + lz * Math.cos(a)];
  const dirW = (dlx, dlz) => [dlx * Math.cos(a) - dlz * Math.sin(a), dlx * Math.sin(a) + dlz * Math.cos(a)];
  const k = (pos, yaw, pitch, t, fov) => ({ pos, tgt: [pos[0] + Math.sin(yaw) * Math.cos(pitch) * 60, pos[1] + Math.sin(pitch) * 60, pos[2] + Math.cos(yaw) * Math.cos(pitch) * 60], fov, shift: 0, t, yaw });
  const m = S.riprese.mondo, D = S.tempi, FI = 55;
  const B = indietro(m), P1 = W(CS.P1x, E, CS.zc), pl = Math.hypot(P1[0] - B[0], P1[2] - B[2]), u = [(P1[0] - B[0]) / pl, (P1[2] - B[2]) / pl], yawE = Math.atan2(u[0], u[1]);
  const yawB = (() => { const d = dirW(0, -1); return Math.atan2(d[0], d[1]); })();   /* verso il bagno: -z locale, dritti nella porta */
  const prima0 = /^prima/.test(Q.get('tour') || ''), PB = W(CS.P1x, E, prima0 ? CS.zBagno : CS.zBagnoDopo), PM = W(CS.P1x, E, CS.zc), prima1 = Q.get('tour') === 'prima1', prima = prima1 || Q.get('tour') === 'prima';   /* prima1 = la primissima registrazione (G3 da 6,6 s, uscita da 150 m) */
  /* TOUR.md «I choose floor 15 and the camera zooms to its window · I fly in, into the living room»:
     G1 = from the cover, the camera does NOT move, only the lens: it zooms in (evenly, on a log scale) on the glass of floor 15 where we will go in,
          and that point slides straight to the centre of the frame (a 6.6° turn you hardly see) → it ends tight on the window, seen from outside.
     G2 = straight along the same line, through the glass, into the living room (P1, same look, 55° lens): the distance drops on a log scale and the lens
          opens at the same time, so the living room keeps almost the same size while the facade opens around it (no zoom back).
     The engine only interpolates the keys (they give the timing and where tools/guides.mjs cuts the guides); the real camera is written by salone.camera,
     called by dopoCamera (samar-kit.js). */
  const salone = prima0 ? (() => { let t = 0; const TT = d => (t += d); return [k([...m.pos], yawE, 0, TT(D.g0), FI), k(P1, yawE, 0, TT(D.g1), FI)]; })()
    : (() => {
      const V = (p, q) => [q[0] - p[0], q[1] - p[1], q[2] - p[2]], N = v => { const l = Math.hypot(...v); return v.map(x => x / l); }, ang = d => [Math.atan2(d[0], d[2]), Math.atan2(d[1], Math.hypot(d[0], d[2]))];
      const B0 = [...m.pos], dE = N(V(B0, P1)), [yE, pE] = ang(dE), [y0, p0] = ang(N(V(m.pos, m.tgt))), f0 = m.fov;
      const zl = p => -(p[0] - T.x) * Math.sin(a) + (p[2] - T.z) * Math.cos(a), Rg = T.R - T.balcone, sG = (zl(B0) - Rg) / (zl(B0) - zl(P1)) * Math.hypot(...V(B0, P1));   /* metres from B to the glass */
      const H1 = CS.g1Alto, t1 = H1 / 2 / sG, f1 = 2 * Math.atan(t1) * 180 / Math.PI;   /* end of G1: H1 metres of facade, top to bottom of the frame, at the glass */
      const Dk = CS.g2Fuoco, Fp = P1.map((x, i) => x + dE[i] * Dk), DA = Math.hypot(...V(B0, Fp)), qA = DA * t1, qB = Dk * Math.tan(FI / 2 * Math.PI / 180);
      const ez = u => { u = Math.min(1, Math.max(0, u)); return u * u * (3 - 2 * u); }, tg = d => Math.tan(d * Math.PI / 360);
      const dy0 = yE - y0, dp0 = pE - p0, g0 = D.g0, g1 = D.g1;
      const K = [k(B0, yE, pE, g0, f1), k(P1, yE, pE, g0 + g1, FI)];
      K.camera = (cam, u) => {
        const t = u * (g0 + g1);
        if (t <= g0) {   /* G1: standing still, only the lens + the way-in point sliding to the centre */
          const e = ez(t / g0), tf = tg(f0) * Math.pow(t1 / tg(f0), e), r = (1 - e) * tf / tg(f0);
          const yaw = yE - Math.atan(Math.tan(dy0) * r), pit = pE - Math.atan(Math.tan(dp0) * r), fov = 2 * Math.atan(tf) * 180 / Math.PI;
          cam.pos.set(...B0); cam.tgt.set(B0[0] + Math.sin(yaw) * Math.cos(pit) * 60, B0[1] + Math.sin(pit) * 60, B0[2] + Math.cos(yaw) * Math.cos(pit) * 60); cam.fov = fov; cam.shift = 0; return;
        }
        const e = ez((t - g0) / g1), Dd = DA * Math.pow(Dk / DA, e), q = qA * Math.pow(qB / qA, e), pos = Fp.map((x, i) => x - dE[i] * Dd);   /* G2: straight, distance and lens on a log scale */
        cam.pos.set(...pos); cam.tgt.set(pos[0] + dE[0] * 60, pos[1] + dE[1] * 60, pos[2] + dE[2] * 60); cam.fov = 2 * Math.atan(q / Dd) * 180 / Math.PI; cam.shift = 0;
      };
      K.info = { f1, sG, DA, Dk, giro: (yE - y0) * 180 / Math.PI, inclina: (pE - p0) * 180 / Math.PI };
      return K;
    })();
  return {
    /* G1 zoom standing still, tight on the glass of level 15 · G2 straight in to the living room (arriving on the sofa and the TV wall). ?tour=prima: the old G1/G2 (G1 opened the lens) */
    salone,
    /* verso il bagno. Prima (?tour=prima): un tratto solo che gira di 27° mentre cammina. Dopo (07-4): fermi, girata da fermi verso la porta, poi dritti */
    bagno: prima ? [k(PB, yawB, 0, prima1 ? D.g2 + D.g3 : D.g3, FI)] : [k(P1, yawB, 0, D.g2, FI), k(PB, yawB, 0, D.g2 + D.g3, FI)],
    /* indietro dritti con lo sguardo fermo: fuori dalla porta, dal salone, dal vetro, finché la torre è davanti */
    /* 07: la prima volta si usciva di 150 m in 4 s salendo di 8 m: dentro la porta del bagno passava troppo veloce e il giudice dava 7,7 (ruota 3,7°) → 95 m, si sale di 4 m */
    fuori: prima ? [k(W(CS.P1x, E + (prima1 ? 8 : 4), T.R - T.balcone + (prima1 ? 150 : 95)), yawB, 0, D.g4, FI)]
      /* dopo (07): due tratti dritti nello stesso verso con una fermata nel salone (chiave doppia = velocità zero): prima indietro piano fuori dalla porta del bagno, poi fuori dal vetro */
      : [k(PM, yawB, 0, D.g3, FI), k(PM, yawB, 0, D.g3 + 0.02, FI), k(W(CS.P1x, E + 4, T.R - T.balcone + 95), yawB, 0, D.g3 + 0.02 + D.g4, FI)],
  };
}
