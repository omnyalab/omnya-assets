#!/usr/bin/env python3
"""reel_916.py FILM_16x9.mp4 OUT_9x16.mp4 [top.mp4]
The reel layouts of the Rome film, clean (the hook and the pills are written on top in the app):
- one film: 1080x1920, black, the film cropped to 1080x998 at y=610 (the black above is for the hook)
- with a second film (the 3D of the same moment): the 3D on top (y=512) and the real film below (y=1126), 1080x608 each,
  a thin black line between them, like the split reel «Claude + Higgsfield just rebuilt ancient Rome»."""
import sys, subprocess
src, out = sys.argv[1], sys.argv[2]
if len(sys.argv) > 3:
    top = sys.argv[3]
    fc = '[0:v]scale=1080:608,setsar=1[t];[1:v]scale=1080:608,setsar=1[b];color=c=0x0b0b0d:s=1080x1920:r=24[bg];[bg][t]overlay=0:512:shortest=1[x];[x][b]overlay=0:1126:shortest=1[o]'
    cmd = ['ffmpeg', '-y', '-i', top, '-i', src, '-filter_complex', fc, '-map', '[o]', '-map', '1:a?']
else:
    fc = '[0:v]scale=-2:998,crop=1080:998,setsar=1[f];color=c=0x0b0b0d:s=1080x1920:r=24[bg];[bg][f]overlay=0:610:shortest=1[o]'
    cmd = ['ffmpeg', '-y', '-i', src, '-filter_complex', fc, '-map', '[o]', '-map', '0:a?']
subprocess.run(cmd + ['-c:v', 'libx264', '-crf', '18', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', out], check=True)
print('ok', out)
