---
name: house-builder
description: Builds a complete one-folder "hold to build" website where a house rises from the blueprint to the finished home while visitors scroll or hold a button - the stake-out, foundation, framing, roof, walls and garden, one phase at a time, with big captions for each phase and a call to action at the end. Works on phones, needs no build step and goes online for free. Use it whenever someone wants a house, villa, cabin or building that "builds itself", a construction timeline or build-phase page for a builder, architect, developer or real estate listing, a scroll animation of a home going up, a "from blueprint to front door" page, or asks to turn their phase photos or Kling clips into a website, even if they only say "make my house build itself on scroll".
---

# House Builder

You build a "hold to build" website for one house, starting from the working template in `assets/template/`. The template already does everything: it plays the pictures of the build on a full-screen canvas while the page scrolls or while the visitor holds the button, fades the caption of every phase in and out at the right moment, shows a progress rail and bar, a loading screen, and an ending with the brand and a button. Your job is to put the user's pictures in, write the words, set the colours, check it, and hand over a folder they can put online.

Most builds only touch `window.BUILD_CONFIG` at the top of `build.js` and the pictures. Change the engine only when the user asks for something the config cannot do.

## The two modes

- **`stills`**: one photo per phase (usually 10: the blueprint, then 9 phases). The page fades from one photo to the next with a very slow zoom. Needs only the photos. Use it when the user has photos and no clips, or wants it today.
- **`frames`**: the clips between the phases cut into frames. The house really rises and the camera turns around it, like omnyalab.com/demo/hold-to-build. Needs the clips and ffmpeg (Claude Code on a computer) to cut them.

If the user has nothing yet, they make the pictures first with the prompts in `references/prompts.md` (photo of the finished house, camera-locked phase photos, clips between phases). Walk them through it one step at a time and wait for their files.

## 1. Ask first, in one short message

Ask only for what you do not already know, all in one message, with a default for each, and say they can answer "use the defaults".

1. **The pictures**: their phase photos (in order) or their clips (in order). If they have neither, offer the prompts.
2. **Brand**: the name at the top and at the end, and a short word next to it (e.g. "Homes", "Architects"), or none.
3. **The phases**: keep the 10 default phases (plan, stake-out, foundation, walls, frame, sheathing, dried in, masonry, exterior, landscape) or their own list. One caption per picture of a phase.
4. **Colour**: one accent colour for the captions, the dots and the buttons. Default: a colour taken from their brand, or the green `#22d35e`.
5. **The end**: the last line (default "Welcome home") and, if they want, a button with a link (their contact page, WhatsApp, a booking or payment link).
6. **Language** of the page.

If the user already gave the pictures and a name, do not stop to ask: use the defaults for the rest, build, and list the defaults you chose at the end.

## 2. Build

1. **Copy the template.** Copy the whole `assets/template/` folder to a new folder named after the house or brand in lowercase with dashes, e.g. `maple-ridge-house/`. It holds `index.html`, `build.js`, `ui.css`, `frames.js` and `tools/`. Never edit the template itself.
   - On claude.ai, create the same files in your sandbox with the template's content and give them back as a zip at the end.
2. **Put the pictures in**, from inside the new folder:
   - stills: `python3 tools/make_frames.py stills 00.png 01.png ... 09.png` (in the order of the build). It saves them as `phases/00.jpg ...`, 1920 px wide. Then list the same files in `stills` in the config.
   - frames: `python3 tools/make_frames.py frames clip1.mp4 ... clip9.mp4 --webp`. It writes `frames/` and `frames.js` with the frame count and the frame where every phase ends. Set `mode: 'frames'`. With 9 clips there are 10 phases (the start of clip 1 is the blueprint).
   - The number of entries in `phases` must be the number of phases: stills = number of photos, frames = number of clips + 1. The console warns if they differ.
3. **Fill the config** at the top of `build.js` (every field is in `references/config.md`): `brand`, `brandTag`, `title`, `lang`, the `phases` (each one `tag`, the two lines `a` and `b`, and one short sentence `p`), `colors.accent`, `cta`, `ending`, and the `text` strings in the user's language. Write the captions about what the visitor sees in that picture, short and concrete. Never invent facts about the user's company (years, awards, numbers of homes built).
4. **Look at it.** Serve the folder (`python3 -m http.server 8080` inside it) and open:
   - `index.html?f=0`, then every phase: `?f=1`, `?f=2` ... in stills mode, or `?f=<bound>` with the numbers in `frames.js` in frames mode, and one point halfway between two phases (`?f=3.5`, or a frame between two bounds),
   - the end (scroll to the bottom),
   - at phone size (390 x 844) and desktop size (1440 x 900).
   With a browser tool, screenshot them. Without one, load the page in headless Chrome and check the console shows `house ready · <mode> · <n> pictures · <n> phases` and no errors. Then try the real thing once: scroll down slowly, and hold the button for two seconds.

## 3. Rules

- **One folder, no build step.** Plain HTML, CSS and one script. No npm, no bundler, no framework, no external library. Fonts come from Google Fonts; everything else is local.
- **Same camera in every picture.** The effect only works if every phase is the same view of the same house. If the user's photos come from different angles, say so before building and suggest the camera-locked prompt in `references/prompts.md`.
- **Light enough for a phone.** Stills: keep them 1920 px wide JPEG (the tool does it), about 0.5 MB each. Frames: use `--webp`; above about 60 MB tell the user the page will be slow on mobile data and suggest shorter clips or stills mode. Phones load one frame in two by themselves.
- **Phone first.** The button is at least 56 px tall and at the bottom within thumb reach, the caption sits above it, nothing needs hover. Check the phone screenshots before the desktop ones, and if the house is cut on the phone, move `focus` (e.g. `[0.4, 0.5]` keeps more of the left side).
- **Honest words.** Only the user's brand, house and claims. No invented company history, prices, awards or reviews. Do not put other companies' logos in the pictures or on the page.
- **Their pictures stay theirs.** Use only pictures the user made or owns. Do not take photos of other houses from the web.

## 4. Before handing over, check

- [ ] Console shows `house ready` with the right number of pictures and phases, and no errors.
- [ ] Every phase shows the right caption on the right picture, on phone and desktop; captions never sit on top of each other.
- [ ] The first picture appears without waiting for the scroll, the loading screen goes away.
- [ ] Holding the button builds the house forward and stops when released; scrolling back takes it back.
- [ ] The end shows the brand, the last line and the buttons, and "Build it again" goes back to the top.
- [ ] Every visible word is in the user's language.
- [ ] The total size of the folder is told to the user.

## 5. Put it online for free

Tell the user these steps in plain words:

**Netlify Drop:** go to app.netlify.com/drop and drag the folder (the one with `index.html` inside) onto the page. The link is ready in seconds; a free account keeps it online and lets you rename it.

**Vercel (free Hobby account):** Add New, then Project, drag the folder in (or push it to GitHub and import it). Framework "Other", no build command, Deploy. If the dashboard has no folder upload, run `npx vercel` inside the folder.

Both give an https link that works on phones. To show it inside their own website, they can embed it full width:
`<iframe src="https://their-link/" style="width:100%;height:100vh;border:0" allow="fullscreen" loading="lazy"></iframe>`

## What to say at the end

Short and concrete: the folder name, the mode, the number of phases and pictures, the size of the folder, the defaults you chose, how to open it locally and the free publishing steps. Show two or three screenshots (the blueprint, a phase in the middle, the finished house) if you have them.
