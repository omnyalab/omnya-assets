# SAMAR's tour (rewrite it for your tower: every line is a stop = a photo, every jump is a move = a clip)
1. I see the tower at sunset
2. I choose [floor 15] and the camera zooms to its window
3. I fly in, into the living room
4. I turn to look at the living room
5. I walk to the bathroom
(the way back out = the way in, reversed)
(tools/guides.mjs also records the way back, G5-G6, because the photoreal page uses those stops; but no clips are generated for the way back: the clips of the way in are played backwards, for free)

Note on SAMAR's real page (assets/reale/samar): it uses the real photos and Kling clips we made for SAMAR,
4 photos and 4 clips (C1 tower → terrace, C2 into the living room, C3 to the bathroom, C4 the way back out).
It was made before this tour was split into 5 stops, so the count is not the same as the course: compare the method
(photo → clip → photo, one at a time), not the number of files. Nothing in it is generated for the course.
