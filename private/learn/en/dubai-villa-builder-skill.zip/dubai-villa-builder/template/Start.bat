@echo off
rem Choose your villa. Double click: starts a small local server (needs Python 3 from python.org) and opens the page.
rem Add ?auto at the end of the address for the automatic tour. Close the small black window to stop the server.
cd /d "%~dp0"
where py >nul 2>nul && (start "villa server" /min py -3 server.py 5316) || (start "villa server" /min python server.py 5316)
timeout /t 2 >nul
start "" http://localhost:5316/index.html
