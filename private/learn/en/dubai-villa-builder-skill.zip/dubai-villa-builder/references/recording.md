# Record the tour as a video

## Quick: screen recording
Open `http://localhost:5316/?auto` in Chrome, full screen (Mac: cmd+ctrl+F), and record the screen (Mac: cmd+shift+5, or QuickTime;
Windows: Win+Alt+R or OBS). R restarts the tour. The cursor is drawn by the page, hide the real one.

## Frame-perfect (no dropped frames)
`?auto&rec` freezes time; each `await __motore.step(1, 24)` moves the tour by one frame and jumps the film to the exact frame.
With a headless Chrome (Puppeteer or Playwright) at 1920x1080, deviceScaleFactor 1:
1. open `http://localhost:5316/?auto&rec`, wait until `document.body.dataset.pronto === '1'`;
2. repeat about 1,500 times: `await __motore.step(1, 24)`, then save `document.getElementById('c').toDataURL('image/jpeg', 0.95)`
   as `f_00001.jpg`, `f_00002.jpg`...; stop a second after `__motore.stato.fase === 'fine'`;
3. `ffmpeg -framerate 24 -i f_%05d.jpg -c:v libx264 -crf 16 -pix_fmt yuv420p tour.mp4`.
For a 9:16 reel, crop the centre of the 16:9 video or keep 16:9 with your text above and below.
