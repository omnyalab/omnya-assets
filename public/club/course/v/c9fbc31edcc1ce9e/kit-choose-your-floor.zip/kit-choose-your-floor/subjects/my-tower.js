// SUBJECT · MY TOWER, the starting point for your own tower (open it with index.html?s=my-tower).
// It is built with the same kit as SAMAR (subjects/samar-kit.js: a "stadium" tower with balcony bands, podium, sea, marina, palms),
// so it opens and works from minute one. Claude changes the numbers below to match YOUR references and MEASURES.txt (step 4-5 of the course):
// every number must have a source or say ESTIMATE. Nothing here is real yet: it is a placeholder.
// The apartment on the special floor is still SAMAR's (samar-casa.js) until you build yours (step 6). The real version (?reale=1) is added in step 10.
// Keys are in Italian because the engine reads them: torri = towers, casa.speciale = special floor, esauriti = sold floors, intorno = surroundings,
// looks = light, riprese = camera shots, stanze = rooms, giri = automatic tours.
import { costruisciSamar } from './samar-kit.js';
import { giroSamar } from './samar-casa.js';

/* camera of YOUR main photo: where the photographer stood (pos), where it looks (tgt), vertical lens in degrees (fov). Placeholder = SAMAR's */
const CAM0 = { pos: [189.74, 66.7, 406.89], tgt: [155.6, 64.19, 312.93], fov: 23.91 };
const L = 33.82, R = 12.49;   /* length of the straight sides and radius of the round ends, in metres (placeholder) */

export default {
  id: 'my-tower', nome: 'MY TOWER', valuta: 'USD',
  torri: {
    /* one tower: podium height y0, number of floors and floor height (passo), balcony depth, roof overhang. Placeholder numbers */
    lista: [
      { id: 'B', x: -L / 2, z: 0, a: 0, L, R, balcone: 2.0, y0: 9, passo: 4.0, piani: 30, solaio: 0.35, corona: 4.0, tetto: 4.0, setti: false, primo: 1 },
    ],
    podi: [
      { id: 'PB', x: -L / 2 - 6, z: 0, a: 0, L: L + 12, R: R + 8, livelli: 2, passo: 4.5, seme: 3, bianco: true },
    ],
  },
  /* the special floor: F = height of its floor in metres (podium 9 + 14 floors × 4 = 65 → level 15), a name with a story */
  casa: { speciale: { torre: 'B', F: 65.0, nome: 'Your special floor', sotto: 'whole floor · the best view' } },
  esauriti: { B: [] },   /* sold floors, e.g. [4, 9, 12] */
  aree: { B: 640 },   /* m² of a floor (placeholder) */
  palette: 3,
  testi: { torre: 'MY TOWER', vista: 'open view' },
  modello: { colori: { bianco: '#efe9df', sotto: '#b9b1a8', mare: '#3f7a86', terra: '#c9bea9', sabbia: '#e3d3b4', piazza: '#d6ccbb' } },
  intorno: { riva: -34, marina: [20, 210, 40, 170], palme: [], nuvole: [], citta: false },
  skyline: null,   /* SAMAR uses the real Dubai skyline: { O: [lat, lon], burj: [x, z], zMax } */
  costruisci() { return costruisciSamar(this); },
  giroFn: giroSamar,
  inizio: 1,
  lookIniziale: 'sera',
  looks: {
    sera: { sole: { alt: 1.5, az: 160, colore: '#ffb27a', forza: 1.4, alone: '#ffab6e', aloneK: 0.6 }, envSole: 1.6, cielo: ['#2f6d9b', '#b8bcc4', '#f2a46c'], orizzonte: 0.22,
      amb: { cielo: '#9fb4c8', terra: '#8a7a6a', forza: 0.9, riflessi: 1.2 }, nebbia: { colore: '#b7c0cb', densita: 0.00005, orizzonte: 0.35 }, esposizione: 1.0, luci: 1.0, fari: 0.6, bloom: [0.35, 0.5, 0.85] },
  },
  riprese: {
    mondo: { pos: CAM0.pos, tgt: CAM0.tgt, fov: CAM0.fov, shift: 0 },
    rif: { pos: CAM0.pos, tgt: CAM0.tgt, fov: CAM0.fov, shift: 0 },
    pianta: { pos: [0, 700, 0], tgt: [0, 0, -0.01], fov: 30 },
  },
  tempi: { g0: 3.0, g1: 4.0, g2: 3.0, g3: 3.6, g4: 4.0 },
  benvenuto: { sopra: 'Welcome to', titolo: 'Your special floor', sotto: 'Level 15 · MY TOWER', wf: 'V1',
    schermo: { velo: [2.3, 3.1, 4.4, 5.4], benv: [2.5, 3.1], resto: [2.8, 3.5], via: [4.0, 5.0] } },
  stanze: [
    { id: 'salone', nome: 'The Living Room', breve: 'Living', dir: 'su' },
    { id: 'bagno', nome: 'The Bathroom', breve: 'Bath', dir: 'su' },
    { id: 'fuori', nome: 'MY TOWER', breve: 'Tower', dir: 'su' },
  ], fermateStile: 'P2',
  livelli: [
    { id: 'mondo', tipo: 'mondo', titolo: null, bottone: () => ({ testo: 'Choose your floor', id: 'avanti' }) },
    { id: 'piani', tipo: 'piani', titolo: null },
    { id: 'salone', tipo: 'stanza', titolo: null }, { id: 'bagno', tipo: 'stanza', titolo: null }, { id: 'fuori', tipo: 'stanza', titolo: null },
  ],
  giri: {
    A: { look: 'sera', passi: [{ pausa: 0.8 }, { piano: 8, torre: 'B', dur: 0.8, ferma: 0.35 }, { piano: 22, torre: 'B', dur: 0.7, ferma: 0.35 }, { piano: 15, torre: 'B', dur: 0.6, ferma: 0.6, clic: true },
      { pausa: 2.6 }, { bottone: 'liv:3', dur: 0.9, ferma: 0.45, clic: true }, { pausa: 1.8 }, { bottone: 'liv:4', dur: 0.9, ferma: 0.45, clic: true },
      { pausa: 2.0 }, { bottone: 'liv:1', dur: 0.9, ferma: 0.45, clic: true }, { pausa: 1.5 }] },
  },
  pannello: true,
  biglietto: false,
};
