#!/usr/bin/env python3
"""House Builder · turns the pictures into what the page plays.

  python3 tools/make_frames.py stills  photo0.png photo1.png ...   # 'stills' mode: phases/00.jpg, 01.jpg ...
  python3 tools/make_frames.py frames  clip1.mp4 clip2.mp4 ...     # 'frames' mode: frames/0000.jpg ... + frames.js

Run it inside the site folder (the one with index.html). Give the files in the order of the build.

stills  needs Pillow (pip install pillow) or, on a Mac, nothing (it falls back to `sips`).
        Every photo is saved 1920 px wide as JPEG, so a phone loads ten phases in a few seconds.
frames  needs ffmpeg. Every clip is cut to 16:9, 1280 px wide, every frame saved as JPEG (or WebP with --webp).
        From the second clip on, the first frame is dropped: it is the last frame of the clip before.
        frames.js gets the count and the frame where every phase ends (the end of the blueprint is frame 0,
        then the last frame of every clip), so the captions land on the right picture.
"""
import json, os, shutil, subprocess, sys, tempfile, glob

def stills(files):
    os.makedirs('phases', exist_ok=True)
    try:
        from PIL import Image
    except ImportError:
        Image = None
    for i, f in enumerate(files):
        out = f'phases/{i:02d}.jpg'
        if Image:
            im = Image.open(f).convert('RGB')
            if im.width > 1920: im = im.resize((1920, round(im.height * 1920 / im.width)), Image.LANCZOS)
            im.save(out, 'JPEG', quality=86, optimize=True, progressive=True)
        elif shutil.which('sips'):
            subprocess.run(['sips', '-s', 'format', 'jpeg', '-s', 'formatOptions', '86', '--resampleWidth', '1920', f, '--out', out], check=True, capture_output=True)
        else:
            sys.exit('Install Pillow (pip install pillow) or convert the photos to JPEG by hand.')
        print('  ', out, '<-', os.path.basename(f))
    print(f'{len(files)} phases in phases/. In build.js keep mode: "stills" and list the same {len(files)} files in stills, with one entry in phases for each.')

def frames(clips, webp=False):
    if not shutil.which('ffmpeg'): sys.exit('ffmpeg is needed for frames mode (macOS: brew install ffmpeg). Or use stills mode.')
    ext = 'webp' if webp else 'jpg'
    if os.path.isdir('frames'): shutil.rmtree('frames')
    os.makedirs('frames')
    n, bounds = 0, [0]
    vf = 'scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720'
    for k, clip in enumerate(clips):
        with tempfile.TemporaryDirectory() as tmp:
            q = ['-c:v', 'libwebp', '-quality', '64'] if webp else ['-q:v', '4']
            subprocess.run(['ffmpeg', '-v', 'error', '-i', clip, '-vf', vf, *q, f'{tmp}/%05d.{ext}'], check=True)
            got = sorted(glob.glob(f'{tmp}/*.{ext}'))
            if k > 0: got = got[1:]
            for g in got:
                shutil.move(g, f'frames/{n:04d}.{ext}'); n += 1
        bounds.append(n - 1)
        print(f'   clip {k + 1}: {os.path.basename(clip)} -> ends at frame {n - 1}')
    with open('frames.js', 'w') as fh:
        fh.write('// made by tools/make_frames.py: the frames of the clips and the frame where every phase ends\n')
        fh.write('window.BUILD_FRAMES = ' + json.dumps({'folder': 'frames', 'ext': ext, 'count': n, 'bounds': bounds}) + ';\n')
    mb = sum(os.path.getsize(f) for f in glob.glob('frames/*')) / 1e6
    print(f'{n} frames ({mb:.1f} MB) and frames.js. {len(bounds)} phases: in build.js set mode: "frames" and keep {len(bounds)} entries in phases.')
    if mb > 60: print('Heavy for phones: try --webp, or shorter clips.')

if __name__ == '__main__':
    a = sys.argv[1:]
    if len(a) < 2 or a[0] not in ('stills', 'frames'): sys.exit(__doc__)
    webp = '--webp' in a; files = [x for x in a[1:] if x != '--webp']
    missing = [f for f in files if not os.path.exists(f)]
    if missing: sys.exit('Not found: ' + ', '.join(missing))
    stills(files) if a[0] == 'stills' else frames(files, webp)
