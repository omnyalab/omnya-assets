#!/bin/zsh
# Double click: stops the local server of the villa page (port 5316).
PIDS=$(lsof -ti tcp:5316 2>/dev/null)
if [ -n "$PIDS" ]; then kill $PIDS; echo "Server stopped. You can close this window."; else echo "The server was already off."; fi
