#!/bin/zsh
# Double click: stops the local server of the 3D plane (port 5313)
PIDS=$(lsof -ti tcp:5313 2>/dev/null)
if [ -n "$PIDS" ]; then kill $PIDS; echo "Server stopped."; else echo "The server was already off."; fi
