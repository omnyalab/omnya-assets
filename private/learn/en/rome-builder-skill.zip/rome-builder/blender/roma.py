# Roma antica intorno al Colosseo (80 d.C.): colli, Tevere, Foro, Campidoglio, Palatino, Circo Massimo,
# acquedotto e città procedurale istanziata con Geometry Nodes. Posizioni da rilievi reali in rotta/distanza
# dal Colosseo (STIMA: precisione ~50 m). Tutto si conta: il numero di edifici esce in roma_conteggio.json.
import bpy, math, random, json, os
import numpy as np
from mathutils import Vector
import geo
from geo import Builder, M, frame, bay_s

N_HAT = np.array([0.3907, 0.9205])   # nord vero nel nostro sistema (x = ENE, y = NNO)
E_HAT = np.array([0.9205, -0.3907])


def BR(bearing, dist):
    t = math.radians(bearing)
    return E_HAT * dist * math.sin(t) + N_HAT * dist * math.cos(t)


def dir_br(bearing):
    t = math.radians(bearing)
    return E_HAT * math.sin(t) + N_HAT * math.cos(t)


# colli: (rotta, distanza, sigma, altezza sul fondovalle)
COLLI = [(235, 400, 150, 52), (290, 1050, 120, 55), (205, 1180, 230, 55), (160, 480, 200, 46),
         (25, 560, 270, 58), (350, 1150, 210, 58), (320, 1350, 230, 62), (285, 330, 90, 18), (262, 1250, 120, 40)]
FLAT = [(None, 0)]          # zone pianeggianti: (centro, raggio)
TEVERE = [BR(b, d) for b, d in ((335, 2600), (318, 2000), (300, 1700), (278, 1520), (258, 1470), (236, 1520), (216, 1720), (202, 2150), (196, 2700))]
STATS = {'edifici_citta': 0, 'monumenti': 0}
GIARDINI = []          # (x, y, raggio, alberi): pini e cipressi nei giardini dei palazzi


def _dist_poly(p, P):
    best = 1e9
    for a, b in zip(P[:-1], P[1:]):
        ab = b - a; t = np.clip(np.dot(p - a, ab) / np.dot(ab, ab), 0, 1)
        best = min(best, np.linalg.norm(p - (a + ab * t)))
    return best


AV = {}


def quota(x, y):
    p = np.array([x, y])
    h = 0.0
    for b, d, sg, hh in COLLI:
        c = BR(b, d)
        h += hh * math.exp(-np.sum((p - c) ** 2) / (2 * sg ** 2))
    r = math.hypot(x / 1.2, y)
    f = min(1.0, max(0.0, (r - 125) / 140))
    if AV:
        rel = p - AV['pc']; al = rel @ AV['nc']; lat = abs(rel @ AV['tc'])
        if -20 < al < 470:
            w = min(1.0, max(0.0, (al - 380) / 90)); w = w * w * (3 - 2 * w)
            f = min(f, max(0.0, (lat - 20) / 60) + w)
    for c, rr in FLAT:
        if c is None:
            continue
        dd = np.linalg.norm(p - c)
        f = min(f, max(0.0, (dd - rr) / 90))
    h = h * f * f * (3 - 2 * f)
    dt = _dist_poly(p, TEVERE)
    h -= 9.0 * math.exp(-(dt / 75.0) ** 2)
    return h


def zmin(cx, cy, hx, hy, rot=0.0, n=6):
    """quota più bassa sotto un'impronta rettangolare: le basi partono da qui, così niente resta sospeso sui pendii"""
    c, s = math.cos(rot), math.sin(rot); m = 1e9
    for i in range(n + 1):
        for j in range(n + 1):
            u = -hx + 2 * hx * i / n; v = -hy + 2 * hy * j / n
            m = min(m, quota(cx + u * c - v * s, cy + u * s + v * c))
    return m


def quota_np(X, Y):
    """quota() su array (stesso risultato, veloce): serve al terreno fitto"""
    X = np.asarray(X, float); Y = np.asarray(Y, float)
    h = np.zeros_like(X)
    for b, d, sg, hh in COLLI:
        c = BR(b, d)
        h += hh * np.exp(-((X - c[0]) ** 2 + (Y - c[1]) ** 2) / (2 * sg ** 2))
    r = np.hypot(X / 1.2, Y)
    f = np.clip((r - 125) / 140, 0, 1)
    if AV:
        rx = X - AV['pc'][0]; ry = Y - AV['pc'][1]
        al = rx * AV['nc'][0] + ry * AV['nc'][1]; lat = np.abs(rx * AV['tc'][0] + ry * AV['tc'][1])
        w = np.clip((al - 380) / 90, 0, 1); w = w * w * (3 - 2 * w)
        f = np.where((al > -20) & (al < 470), np.minimum(f, np.clip((lat - 20) / 60, 0, None) + w), f)
    for c, rr in FLAT:
        if c is None:
            continue
        f = np.minimum(f, np.clip((np.hypot(X - c[0], Y - c[1]) - rr) / 90, 0, None))
    h = h * f * f * (3 - 2 * f)
    best = np.full_like(X, 1e9)
    for a, b in zip(TEVERE[:-1], TEVERE[1:]):
        ab = b - a; t = np.clip(((X - a[0]) * ab[0] + (Y - a[1]) * ab[1]) / (ab @ ab), 0, 1)
        best = np.minimum(best, np.hypot(X - (a[0] + ab[0] * t), Y - (a[1] + ab[1] * t)))
    return h - 9.0 * np.exp(-(best / 75.0) ** 2)


# ------------------------------------------------------------------ primitive in coordinate mondo
def bx(b, mat, cx, cy, z0, z1, hx, hy, rot=0.0):
    c, s = math.cos(rot), math.sin(rot)
    V = [(cx + sx * hx * c - sy * hy * s, cy + sx * hx * s + sy * hy * c, zz) for zz in (z0, z1) for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    F = [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]
    b.raw(mat, V, F)


def cil(b, mat, x, y, z0, z1, r, n=12, r1=None):
    r1 = r if r1 is None else r1
    V = [(x + rr * math.cos(2 * math.pi * i / n), y + rr * math.sin(2 * math.pi * i / n), zz) for zz, rr in ((z0, r), (z1, r1)) for i in range(n)]
    F = [(i, (i + 1) % n, n + (i + 1) % n, n + i) for i in range(n)] + [tuple(range(n - 1, -1, -1)), tuple(range(n, 2 * n))]
    b.raw(mat, V, F)


def tetto(b, mat, cx, cy, z, hx, hy, rh, rot):
    """tetto a due falde lungo l'asse y locale (frontone sui lati corti)"""
    c, s = math.cos(rot), math.sin(rot)
    def P(u, v, zz):
        return (cx + u * c - v * s, cy + u * s + v * c, zz)
    V = [P(-hx, -hy, z), P(hx, -hy, z), P(hx, hy, z), P(-hx, hy, z), P(0, -hy, z + rh), P(0, hy, z + rh)]
    b.raw(mat, V, [(0, 4, 5, 3), (1, 2, 5, 4), (0, 1, 4), (2, 3, 5)])


def tempio(b, cx, cy, z, larg, lung, h_col, ncol, rot, podio=3.5, peri=True):
    """tempio romano: podio con scalinata davanti (+y locale), colonne, cella, frontone"""
    STATS['monumenti'] += 1
    c, s = math.cos(rot), math.sin(rot)
    def W(u, v):
        return cx + u * c - v * s, cy + u * s + v * c
    bx(b, 'trav2', cx, cy, min(z, zmin(cx, cy, larg / 2 + 1, lung / 2 + 5, rot)) - 3, z + podio, larg / 2, lung / 2, rot)
    x0, y0 = W(0, lung / 2 + 4)
    for k in range(8):   # scalinata
        xx, yy = W(0, lung / 2 + 0.6 + k * 0.45)
        bx(b, 'marmo', xx, yy, min(z, quota(xx, yy)) - 1, z + podio * (1 - k / 8), larg * 0.32, 0.25, rot)
    zc = z + podio; r = h_col / 20
    xs = [-larg / 2 + 1.2 + i * (larg - 2.4) / (ncol - 1) for i in range(ncol)]
    nl = max(3, int((lung - 2.4) / (xs[1] - xs[0])) + 1)
    ys = [-lung / 2 + 1.2 + i * (lung - 2.4) / (nl - 1) for i in range(nl)]
    pts = [(x, ys[-1]) for x in xs] + ([(x, ys[-2]) for x in xs[1:-1]] if len(ys) > 2 else [])
    if peri:
        pts += [(xs[0], y) for y in ys[:-1]] + [(xs[-1], y) for y in ys[:-1]]
    for u, v in pts:
        x, y = W(u, v)
        cil(b, 'marmo', x, y, zc, zc + h_col, r, 12, r * 0.88)
        bx(b, 'marmo', x, y, zc + h_col - 0.5, zc + h_col, r * 1.4, r * 1.4, rot)
    xw, yw = W(0, -lung * 0.12)
    bx(b, 'marmo', xw, yw, zc, zc + h_col, larg / 2 - 2.6, lung * 0.36, rot)       # cella
    bx(b, 'marmo', cx, cy, zc + h_col, zc + h_col + h_col * 0.18, larg / 2 + 0.3, lung / 2 + 0.3, rot)   # trabeazione
    tetto(b, 'tegole', cx, cy, zc + h_col * 1.18, larg / 2 + 0.5, lung / 2 + 0.5, larg * 0.16, rot)
    # timpano chiaro sul fronte
    xf, yf = W(0, lung / 2 + 0.52)
    hx = larg / 2 + 0.5
    V = [(xf - hx * c, yf - hx * s, zc + h_col * 1.18), (xf + hx * c, yf + hx * s, zc + h_col * 1.18), (xf, yf, zc + h_col * 1.18 + larg * 0.16)]
    b.raw('marmo', V, [(0, 1, 2)])


def palazzo(b, x, y, z, hx, hy, h, rot, mat):
    """palazzo imperiale: terrazza in laterizio fino al terreno, corpo intonacato con file di finestre ad arco,
    portico di colonne sui lati lunghi, cornicione e tetto a padiglione di coppi (masse STIMA)"""
    STATS['monumenti'] += 1
    c, s = math.cos(rot), math.sin(rot)
    def Wp(u, v):
        return x + u * c - v * s, y + u * s + v * c
    zb = min(z, zmin(x, y, hx + 6, hy + 6, rot)) - 3
    bx(b, 'mattoni', x, y, zb, z, hx + 6, hy + 6, rot)                 # terrazza/sostruzione
    bx(b, 'lastre', x, y, z, z + 0.15, hx + 6, hy + 6, rot)
    bx(b, mat, x, y, z, z + h, hx, hy, rot)
    bx(b, 'trav2', x, y, z + h - 0.8, z + h, hx + 0.5, hy + 0.5, rot)
    nf = max(1, int((h - 2) / 5.0))
    for side in (-1, 1):
        for i in range(int(2 * hx / 4.2)):                             # finestre sui lati lunghi
            u = -hx + 2.1 + i * 4.2
            for f in range(nf):
                z0 = z + 1.2 + f * 5.0; z1 = z0 + 3.0
                p0 = Wp(u - 0.8, side * (hy + 0.04)); p1 = Wp(u + 0.8, side * (hy + 0.04))
                b.raw('buio', [(p0[0], p0[1], z0), (p1[0], p1[1], z0), (p1[0], p1[1], z1), (p0[0], p0[1], z1)], [(0, 1, 2, 3)])
            xc, yc = Wp(u, side * (hy + 3.2))                               # portico di colonne
            cil(b, 'marmo', xc, yc, z + 0.15, z + 7.5, 0.45, 10, 0.4)
        xa, ya = Wp(0, side * (hy + 3.2))
        bx(b, 'trav2', xa, ya, z + 7.5, z + 8.4, hx, 0.6, rot)
        xr, yr = Wp(0, side * (hy + 1.7))
        bx(b, 'tegole', xr, yr, z + 8.4, z + 8.7, hx, 1.9, rot)
    _padiglione_rot(b, 'tegole', x, y, z + h, hx + 0.9, hy + 0.9, min(hx, hy) * 0.28, rot)


def _padiglione_rot(b, mat, cx, cy, z, hx, hy, rh, rot):
    c, s = math.cos(rot), math.sin(rot)
    P = lambda u, v, zz: (cx + u * c - v * s, cy + u * s + v * c, zz)
    if hx >= hy:
        V = [P(-hx, -hy, z), P(hx, -hy, z), P(hx, hy, z), P(-hx, hy, z), P(-(hx - hy), 0, z + rh), P(hx - hy, 0, z + rh)]
        F = [(0, 1, 5, 4), (2, 3, 4, 5), (1, 2, 5), (3, 0, 4)]
    else:
        V = [P(-hx, -hy, z), P(hx, -hy, z), P(hx, hy, z), P(-hx, hy, z), P(0, -(hy - hx), z + rh), P(0, hy - hx, z + rh)]
        F = [(1, 2, 5, 4), (3, 0, 4, 5), (0, 1, 4), (2, 3, 5)]
    b.raw(mat, V, F)


def basilica(b, cx, cy, z, larg, lung, rot):
    STATS['monumenti'] += 1
    c, s = math.cos(rot), math.sin(rot)
    bx(b, 'trav2', cx, cy, min(z, zmin(cx, cy, larg / 2 + 2, lung / 2 + 2, rot)) - 3, z + 1.5, larg / 2 + 2, lung / 2 + 2, rot)
    for side in (-1, 1):   # due ordini di arcate sui lati lunghi
        for i in range(int(lung / 6)):
            v = -lung / 2 + 3 + i * 6
            for zz0, zz1 in ((z + 1.5, z + 9.5), (z + 11.0, z + 18.0)):
                x, y = cx + side * (larg / 2) * c - v * s, cy + side * (larg / 2) * s + v * c
                bx(b, 'marmo', x, y, zz0, zz1, 0.9, 0.9, rot)
        x, y = cx + side * (larg / 2) * c, cy + side * (larg / 2) * s
        bx(b, 'marmo', x, y, z + 9.5, z + 11.0, 1.0, lung / 2, rot)
        bx(b, 'marmo', x, y, z + 18.0, z + 19.2, 1.0, lung / 2, rot)
    bx(b, 'muro_int', cx, cy, z + 1.5, z + 24, larg / 2 - 5, lung / 2 - 2, rot)
    tetto(b, 'tegole', cx, cy, z + 24, larg / 2 - 4, lung / 2 - 1, larg * 0.12, rot)
    tetto(b, 'tegole', cx, cy, z + 19.2, larg / 2 + 1, lung / 2 + 1, 2.0, rot)


def tempio_tondo(b, cx, cy, z, r):
    STATS['monumenti'] += 1
    cil(b, 'trav2', cx, cy, min(z, zmin(cx, cy, r + 1.5, r + 1.5)) - 2, z + 2.5, r + 1.5, 24)
    for i in range(18):
        a = 2 * math.pi * i / 18
        cil(b, 'marmo', cx + r * math.cos(a), cy + r * math.sin(a), z + 2.5, z + 12, 0.45, 10)
    cil(b, 'marmo', cx, cy, z + 2.5, z + 12, r - 1.4, 24)
    cil(b, 'marmo', cx, cy, z + 12, z + 13.2, r + 0.5, 24)
    cil(b, 'bronzo', cx, cy, z + 13.2, z + 18, r + 0.5, 24, 0.4)


# ------------------------------------------------------------------ città istanziata
def _padiglione(b, mat, cx, cy, z, hx, hy, rh):
    """tetto romano a padiglione basso (coppi), falde a ~16°"""
    if hx >= hy:
        r0, r1 = (cx - (hx - hy), cy, z + rh), (cx + (hx - hy), cy, z + rh)
        F = [(0, 1, 5, 4), (2, 3, 4, 5), (1, 2, 5), (3, 0, 4)]
    else:
        r0, r1 = (cx, cy - (hy - hx), z + rh), (cx, cy + (hy - hx), z + rh)
        F = [(1, 2, 5, 4), (3, 0, 4, 5), (0, 1, 4), (2, 3, 5)]
    b.raw(mat, [(cx - hx, cy - hy, z), (cx + hx, cy - hy, z), (cx + hx, cy + hy, z), (cx - hx, cy + hy, z), r0, r1], F)


def _variante(nome, w, d, piani, corte=False, tetto_piano=False):
    """casa romana a origine, base a z=0. Sotto lo zero un basamento in laterizio (sui pendii si vede come terrazza,
    non come un muro che entra nel terreno). slot: 0 muri, 1 coppi, 2 aperture, 3 laterizio, 4 legno, 5 cornici"""
    b = Builder()
    h = piani * 3.3 + 0.8
    blocchi = []
    if corte:      # domus / horrea: quattro ali attorno al cortile (atrio)
        t = min(w, d) * 0.3
        blocchi = [(0, d / 2 - t / 2, w / 2, t / 2), (0, -d / 2 + t / 2, w / 2, t / 2), (w / 2 - t / 2, 0, t / 2, d / 2 - t), (-w / 2 + t / 2, 0, t / 2, d / 2 - t)]
    else:
        blocchi = [(0, 0, w / 2, d / 2)]
    for cx, cy, hx, hy in blocchi:
        bx(b, 'b', cx, cy, -9, 0, hx + 0.25, hy + 0.25)
        bx(b, 'm', cx, cy, 0, h, hx, hy)
        bx(b, 'c', cx, cy, h - 0.3, h, hx + 0.22, hy + 0.22)                 # cornicione
        if not corte:
            for f in range(1, piani):                                        # marcapiani
                bx(b, 'c', cx, cy, 0.8 + f * 3.3 - 0.12, 0.8 + f * 3.3, hx + 0.08, hy + 0.08)
        if tetto_piano:
            bx(b, 't', cx, cy, h, h + 0.3, hx + 0.1, hy + 0.1)
            bx(b, 'l', cx + hx * 0.4, cy, h + 0.3, h + 2.6, 0.08, hy * 0.6)  # pergola
            bx(b, 'l', cx, cy, h + 2.5, h + 2.65, hx * 0.5, hy * 0.6)
        else:
            _padiglione(b, 't', cx, cy, h, hx + 0.6, hy + 0.6, min(hx, hy) * 0.29)
    if corte:
        bx(b, 'b', 0, 0, -0.2, 0.08, w / 2 - min(w, d) * 0.3, d / 2 - min(w, d) * 0.3)   # cortile lastricato
    # botteghe ad arco al piano terra e finestre piccole sopra (insulae)
    for side, (nx, ny, L) in enumerate(((0, 1, w), (0, -1, w), (1, 0, d), (-1, 0, d))):
        nfin = max(1, int(L / 3.4))
        for f in range(1 if corte else piani):
            for i in range(nfin):
                u = -L / 2 + (i + 0.5) * L / nfin
                if f == 0:
                    z0, z1, hw = 0.0, 2.9, 1.1
                else:
                    z0 = 0.8 + f * 3.3 + 0.9; z1 = z0 + 1.2; hw = 0.42
                if nx == 0:
                    yy = ny * (d / 2 + 0.03); V = [(u - hw, yy, z0), (u + hw, yy, z0), (u + hw, yy, z1), (u - hw, yy, z1)]
                else:
                    xx = nx * (w / 2 + 0.03); V = [(xx, u - hw, z0), (xx, u + hw, z0), (xx, u + hw, z1), (xx, u - hw, z1)]
                b.raw('f', V, [(0, 1, 2, 3)])
    # balcone di legno (maenianum) sul lato lungo delle insulae alte
    if not corte and piani >= 3:
        zb = 0.8 + 3.3
        bx(b, 'l', 0, -d / 2 - 0.65, zb, zb + 0.15, w / 2 - 0.5, 0.65)
        bx(b, 'l', 0, -d / 2 - 1.25, zb + 0.15, zb + 1.0, w / 2 - 0.5, 0.05)
        for i in range(int(w / 2.5) + 1):
            bx(b, 'l', -w / 2 + 0.6 + i * (w - 1.2) / max(1, int(w / 2.5)), -d / 2 - 0.65, zb - 0.45, zb, 0.07, 0.65)
    V = []; F = []; mi = []
    for k, mat in enumerate(('m', 't', 'f', 'b', 'l', 'c')):
        if mat in b.parts:
            vv, ff = b.parts[mat]; o = len(V); V += vv
            F += [tuple(o + i for i in f) for f in ff]; mi += [k] * len(ff)
    me = bpy.data.meshes.new(nome); me.from_pydata(V, [], F)
    for p, k in zip(me.polygons, mi):
        p.material_index = k
    return bpy.data.objects.new(nome, me)


VARIANTI = [('e00_insula3', 16, 13, 3), ('e01_insula4', 20, 15, 4), ('e02_insula5', 26, 17, 5), ('e03_insula4l', 32, 14, 4),
            ('e04_domus', 26, 22, 1, True), ('e05_domus2', 34, 24, 2, True), ('e06_botteghe', 30, 9, 1), ('e07_horrea', 40, 28, 2, True),
            ('e08_insula5l', 36, 20, 5), ('e09_casetta', 11, 10, 2), ('e10_insula6', 22, 18, 6), ('e11_terrazza', 18, 14, 3, False, True)]


def citta(scn, MAT, coll, escludi, rnd, leggero):
    cv = bpy.data.collections.new('EdificiVarianti'); scn.collection.children.link(cv)
    for v in VARIANTI:
        o = _variante(v[0], v[1], v[2], v[3], v[4] if len(v) > 4 else False, v[5] if len(v) > 5 else False)
        cv.objects.link(o)
        for m in ('muri_citta', 'tegole', 'buio', 'mattoni', 'legno', 'trav2'):
            o.data.materials.append(MAT[m])
    scn.view_layers[0].layer_collection.children['EdificiVarianti'].exclude = True
    # griglia unica allineata al viale (Nico 25/11: altre strade vere, che continuano): isolati di 4x3 lotti,
    # strade lastricate a basoli ogni 5 colonne e ogni 4 righe, una strada larga ogni 15 colonne
    P = []
    R = 1600 if leggero else 3600
    passo = 30.0 if leggero else 21.0
    ang0 = math.atan2(AV['nc'][1], AV['nc'][0]); cu, su = math.cos(ang0), math.sin(ang0)
    W2 = lambda u, v: (u * cu - v * su, u * su + v * cu)
    nmax = int(R / passo) + 2
    for i in range(-nmax, nmax):
        for j in range(-nmax, nmax):
            if i % 5 == 4 or j % 4 == 3:        # strade
                continue
            x, y = W2(i * passo + rnd.uniform(-1.2, 1.2), j * passo + rnd.uniform(-1.2, 1.2))
            dq = math.hypot(x, y)
            if dq > R or escludi(x, y):
                continue
            if dq > 1900 and rnd.random() < 0.4:
                continue
            v = rnd.choices(range(len(VARIANTI)), weights=(14, 14, 9, 6, 6, 3, 6, 2, 4, 9, 3, 6))[0]
            sc = rnd.uniform(0.85, 1.08) * (passo / 21) ** 0.8
            P.append((x, y, quota(x, y), ang0 + rnd.choice((0, math.pi / 2, math.pi, -math.pi / 2)), v, rnd.random(), sc))
    # strade: quadrati di basolato che seguono il terreno, interrotti dove ci sono monumenti, fiume e mercato
    SV = []; SF = []
    def strada(u0, v0, du, dv, L, larg, passo_s):
        n = int(L / passo_s)
        for k in range(n):
            pts = []
            for t, sgn in ((k, -1), (k + 1, -1), (k + 1, 1), (k, 1)):
                uu = u0 + du * t * passo_s + (-dv) * sgn * larg / 2
                vv = v0 + dv * t * passo_s + du * sgn * larg / 2
                pts.append(W2(uu, vv))
            mx = sum(p[0] for p in pts) / 4; my = sum(p[1] for p in pts) / 4
            if math.hypot(mx, my) > R - 40 or escludi(mx, my):
                continue
            o = len(SV)
            SV.extend((px, py, quota(px, py) + 0.06) for px, py in pts); SF.append((o, o + 1, o + 2, o + 3))
    for i in range(-nmax, nmax):
        if i % 5 == 4:
            strada(i * passo, -R, 0.0, 1.0, 2 * R, 11.0 if i % 15 == 4 else 8.0, 12.0 if abs(i * passo) < 1800 else 24.0)
    for j in range(-nmax, nmax):
        if j % 4 == 3:
            strada(-R, j * passo, 1.0, 0.0, 2 * R, 8.0, 12.0 if abs(j * passo) < 1800 else 24.0)
    me = bpy.data.meshes.new('strade'); me.from_pydata(SV, [], SF); me.materials.append(MAT['basolato'])
    coll.objects.link(bpy.data.objects.new('strade', me))
    STATS['strade_m'] = int(len(SF) * 12)
    STATS['edifici_citta'] = len(P)
    import folla
    ng = _gn_citta(cv)   # il mercato riusa le botteghe (citta_istanze)
    folla.nuvola('citta', P, coll, ng)
    print('citta edifici', len(P))


def _gn_citta(cv):
    ng = bpy.data.node_groups.new('citta_istanze', 'GeometryNodeTree')
    ng.interface.new_socket('Geometry', in_out='INPUT', socket_type='NodeSocketGeometry')
    ng.interface.new_socket('Geometry', in_out='OUTPUT', socket_type='NodeSocketGeometry')
    N = ng.nodes; L = ng.links
    gi = N.new('NodeGroupInput'); go = N.new('NodeGroupOutput')
    ci = N.new('GeometryNodeCollectionInfo'); ci.inputs['Collection'].default_value = cv
    ci.inputs['Separate Children'].default_value = True; ci.inputs['Reset Children'].default_value = True
    ip = N.new('GeometryNodeInstanceOnPoints'); ip.inputs['Pick Instance'].default_value = True
    def attr(name, typ):
        a = N.new('GeometryNodeInputNamedAttribute'); a.data_type = typ; a.inputs['Name'].default_value = name
        return a.outputs['Attribute']
    L.new(gi.outputs[0], ip.inputs['Points']); L.new(ci.outputs[0], ip.inputs['Instance'])
    L.new(attr('var', 'INT'), ip.inputs['Instance Index'])
    rot = attr('rot', 'FLOAT_VECTOR')
    try:
        e2r = N.new('FunctionNodeEulerToRotation'); L.new(rot, e2r.inputs[0]); L.new(e2r.outputs[0], ip.inputs['Rotation'])
    except Exception:
        L.new(rot, ip.inputs['Rotation'])
    L.new(attr('scl', 'FLOAT'), ip.inputs['Scale'])
    L.new(ip.outputs[0], go.inputs[0])
    return ng


# ------------------------------------------------------------------ monumenti
def monti(b):
    """Colli Albani e Sabini sul fondo, nella foschia (chiudono l'orizzonte)"""
    rnd = random.Random(3); V = []; F = []; n = 180
    for i in range(n):
        a = 2 * math.pi * i / n
        br = math.degrees(math.atan2(math.cos(a), math.sin(a)))
        h = 140 + 90 * math.sin(3 * a + 1) + 60 * math.sin(7 * a) + rnd.uniform(-20, 20)
        h += 520 * math.exp(-((((math.degrees(a) - 0) % 360) - 0) / 1e9))  * 0
        d = 21000
        V.append((d * math.cos(a), d * math.sin(a), -2.0)); V.append((d * math.cos(a), d * math.sin(a), h))
    for i in range(n):
        j = (i + 1) % n
        F.append((2 * i, 2 * j, 2 * j + 1, 2 * i + 1))
    b.raw('monti', V, F)


def monumenti(b, AVd):
    pc, nc, tc = AVd['pc'], AVd['nc'], AVd['tc']
    monti(b)
    for k in range(26, 52):   # Via Sacra lastricata fino al Foro
        o0 = 17.5 + k * 8; o1 = o0 + 8
        pts = [pc + nc * o0 + tc * -8.5, pc + nc * o1 + tc * -8.5, pc + nc * o1 + tc * 8.5, pc + nc * o0 + tc * 8.5]
        b.raw('viale_trav', [(float(q[0]), float(q[1]), quota(*q) + 0.02) for q in pts], [(0, 1, 2, 3)])
    # FORO ROMANO (asse NO-SE)
    F = BR(296, 720); u = dir_br(296); rot_f = math.atan2(u[1], u[0]) - math.pi / 2
    v = np.array([-u[1], u[0]])
    zf = quota(*F)
    bx(b, 'lastre', F[0], F[1], min(zf, zmin(F[0], F[1], 30, 75, rot_f)) - 1, zf + 0.05, 30, 75, rot_f)
    def FP(along, lat):
        p = F + u * along + v * lat; return float(p[0]), float(p[1])
    x, y = FP(-70, 0); tempio(b, x, y, zf, 18, 30, 12, 6, rot_f + math.pi, podio=3.5)              # Divo Giulio (verso NO)
    x, y = FP(80, 8); tempio(b, x, y, zf, 22, 40, 14, 6, rot_f, podio=6)                           # Saturno
    x, y = FP(-30, -42); tempio(b, x, y, zf, 30, 50, 15, 8, rot_f - math.pi / 2, podio=7)          # Castore e Polluce
    x, y = FP(25, -48); basilica(b, x, y, zf, 48, 100, rot_f)                                     # Basilica Giulia
    x, y = FP(-5, 46); basilica(b, x, y, zf, 32, 90, rot_f)                                       # Basilica Emilia
    x, y = FP(60, 44); bx(b, 'mattoni', x, y, zf, zf + 30, 13, 9, rot_f); tetto(b, 'tegole', x, y, zf + 30, 13.5, 9.5, 4, rot_f + math.pi / 2); STATS['monumenti'] += 1   # Curia
    x, y = FP(-60, -40); tempio_tondo(b, x, y, zf, 7.5)                                            # Vesta
    # CAMPIDOGLIO: Giove Ottimo Massimo + Tabularium
    C = BR(290, 1060); zc = quota(*C)
    tempio(b, float(C[0]), float(C[1]), zc, 54, 62, 18, 6, rot_f + math.pi, podio=5)
    T = BR(292, 930); bx(b, 'trav2', float(T[0]), float(T[1]), zmin(float(T[0]), float(T[1]), 8, 34, rot_f + math.pi / 2) - 3, quota(*T) + 18, 8, 34, rot_f + math.pi / 2); STATS['monumenti'] += 1
    # PALATINO: palazzi imperiali (Domus Tiberiana, casa di Augusto, Apollo Palatino) sul pianoro
    Pp = BR(235, 400); zp = quota(*Pp); rp = rot_f
    for (dx, dy, hx, hy, h) in ((-80, 60, 70, 45, 22), (40, 90, 40, 30, 18), (60, -40, 55, 40, 20), (-40, -70, 45, 35, 16), (110, 20, 25, 50, 14)):
        x, y = float(Pp[0] + dx), float(Pp[1] + dy); z = quota(x, y)
        palazzo(b, x, y, z, hx, hy, h, rp, 'intonaco3')
    x, y = float(Pp[0] - 10), float(Pp[1] + 10); tempio(b, x, y, quota(x, y), 24, 40, 14, 6, rp + math.pi / 2, podio=4)
    # Palatino più pieno: ali dei palazzi, portici e terrazze (masse STIMA) attorno ai giardini
    for (dx, dy, hx, hy, h) in ((-120, -10, 22, 40, 12), (0, 125, 50, 14, 10), (95, 95, 18, 22, 16), (-10, -125, 40, 12, 9), (125, -60, 16, 30, 12),
                                (-95, 115, 26, 16, 14), (55, 30, 14, 14, 8), (-60, -110, 20, 18, 11)):
        x, y = float(Pp[0] + dx), float(Pp[1] + dy); z = quota(x, y)
        palazzo(b, x, y, z, hx, hy, h, rp, 'intonaco')
    GIARDINI.extend([(float(Pp[0]), float(Pp[1]), 140.0, 70), (0.0, -330.0, 80.0, 40)])
    # CIRCO MASSIMO
    circo(b, BR(208, 640), dir_br(112))
    # ACQUEDOTTO (Arcus Neroniani) dal Celio verso il Palatino
    acquedotto(b, [BR(124, 1900), BR(132, 1200), BR(147, 700), BR(160, 420), BR(205, 330)])
    # TEVERE
    fiume(b)


def circo(b, C, u):
    """Circo Massimo: pista 540 x 80, gradinate a 3 ordini, spina con obelisco, carceri sul lato corto"""
    STATS['monumenti'] += 1
    C = np.array(C); u = np.array(u) / np.linalg.norm(u); v = np.array([-u[1], u[0]])
    Ls, Rr = 250.0, 42.0
    zc = quota(*C)
    # percorso: lato destro dritto -> curva -> lato sinistro dritto (pista interna)
    pts = []; nrm = []
    for i in range(41):
        a = -Ls + 2 * Ls * i / 40; pts.append(C + u * a + v * (-Rr)); nrm.append(-v)
    for i in range(1, 40):
        t = -math.pi / 2 + math.pi * i / 40
        pts.append(C + u * Ls + (u * math.cos(t) + v * math.sin(t)) * Rr); nrm.append(u * math.cos(t) + v * math.sin(t))
    for i in range(41):
        a = Ls - 2 * Ls * i / 40; pts.append(C + u * a + v * Rr); nrm.append(v)
    prof = [(0, -6), (0, 3.5), (2, 3.5)]
    d, z = 2.0, 3.5
    for k in range(3):
        for i in range(10):
            prof += [(d, z + 0.6), (d + 0.75, z + 0.6)]; d += 0.75; z += 0.6
        prof += [(d, z + 1.8), (d + 1.2, z + 1.8)]; d += 1.2; z += 1.8
    prof += [(d, z + 4), (d + 3, z + 4), (d + 3, -6)]
    V = []; F = []; P = len(prof)
    for p, n in zip(pts, nrm):
        for o, zz in prof:
            q = p + n * o; V.append((float(q[0]), float(q[1]), zc + zz))
    nr = len(pts)
    for i in range(nr - 1):
        for k in range(P):
            kk = (k + 1) % P
            F.append((i * P + k, (i + 1) * P + k, (i + 1) * P + kk, i * P + kk))
    F.append(tuple(range(P - 1, -1, -1))); F.append(tuple((nr - 1) * P + k for k in range(P)))
    b.raw('sedili', V, F)
    # facciata esterna ad arcate (fasce scure ritmate) sul retro
    rot = math.atan2(u[1], u[0])
    bx(b, 'sabbia', float(C[0]), float(C[1]), min(zc, zmin(float(C[0]), float(C[1]), Ls + 20, Rr, rot)) - 1, zc + 0.05, Ls + 20, Rr, rot)
    bx(b, 'marmo', float(C[0]), float(C[1]), zc, zc + 1.6, 170, 4, rot)                     # spina
    o = C + u * 0; bx(b, 'trav2', float(o[0]), float(o[1]), zc, zc + 24, 1.3, 1.3, rot)    # obelisco di Augusto
    cil(b, 'oro', float(o[0]), float(o[1]), zc + 24, zc + 26, 1.0, 4, 0.05)
    for sg in (-1, 1):
        m = C + u * sg * 175
        for k in (-1.5, 0, 1.5):
            cil(b, 'bronzo', float(m[0] + v[0] * k), float(m[1] + v[1] * k), zc, zc + 6, 0.8, 10, 0.15)
    car = C - u * (Ls + 8)
    bx(b, 'trav2', float(car[0]), float(car[1]), min(zc, zmin(float(car[0]), float(car[1]), 6, Rr + 22, rot)) - 2, zc + 11, 6, Rr + 22, rot)            # carceri
    for i in range(12):
        q = car + u * 6.05 + v * (-36 + i * 6.5)
        bx(b, 'buio', float(q[0]), float(q[1]), zc, zc + 6, 0.05, 2.2, rot)


def acquedotto(b, pts):
    STATS['monumenti'] += 1
    ztop = 34.0
    for a, c in zip(pts[:-1], pts[1:]):
        L = np.linalg.norm(c - a); u = (c - a) / L; rot = math.atan2(u[1], u[0]) + math.pi / 2
        n = int(L / 7.5)
        for i in range(n):
            p = a + u * (i * 7.5)
            z = quota(*p)
            if ztop - z < 4:
                continue
            bx(b, 'mattoni', float(p[0]), float(p[1]), z - 2, ztop, 1.3, 1.6, rot)
        m = (a + c) / 2
        bx(b, 'mattoni', float(m[0]), float(m[1]), ztop, ztop + 3.5, 1.7, L / 2, rot)


def fiume(b):
    W = 55.0
    V = []; F = []
    pts = []
    for a, c in zip(TEVERE[:-1], TEVERE[1:]):
        for i in range(10):
            pts.append(a + (c - a) * i / 10)
    pts.append(TEVERE[-1])
    for i, p in enumerate(pts):
        q = pts[min(i + 1, len(pts) - 1)] - pts[max(i - 1, 0)]; q = q / np.linalg.norm(q); n = np.array([-q[1], q[0]])
        for sg in (-1, 1):
            w = p + n * sg * W; V.append((float(w[0]), float(w[1]), -4.2))
    for i in range(len(pts) - 1):
        F.append((2 * i, 2 * i + 2, 2 * i + 3, 2 * i + 1))
    b.raw('acqua', V, F)
    # Isola Tiberina
    I = BR(258, 1475); bx(b, 'trav2', float(I[0]), float(I[1]), -5, -1, 22, 90, 0.4); STATS['monumenti'] += 1


def escludi_fn(AVd):
    pc, nc, tc = AVd['pc'], AVd['nc'], AVd['tc']
    F = BR(296, 720); Cc = BR(208, 640); uc = dir_br(112); vc = np.array([-uc[1], uc[0]])
    Pp = BR(235, 400); Cap = BR(290, 1060); Tc = np.array([0.0, -330.0]); Te = np.array([177.0, 190.0])
    col = pc + nc * 125 + tc * 48
    aq = [BR(124, 1900), BR(132, 1200), BR(147, 700), BR(160, 420), BR(205, 330)]
    def esc(x, y):
        p = np.array([x, y])
        if math.hypot(x / 1.2, y) < 175:
            return True
        rel = p - pc
        if abs(rel @ tc) < 37 and -10 < rel @ nc < 440:
            return True
        if np.linalg.norm(p - F) < 150 or np.linalg.norm(p - Pp) < 150 or np.linalg.norm(p - Cap) < 120:
            return True
        r2 = p - Cc
        if abs(r2 @ uc) < 330 and abs(r2 @ vc) < 85:
            return True
        if np.linalg.norm(p - Tc) < 125 or np.linalg.norm(p - Te) < 90 or np.linalg.norm(p - col) < 30:
            return True
        if _dist_poly(p, TEVERE) < 80 or _dist_poly(p, aq) < 12:
            return True
        return False
    return esc
