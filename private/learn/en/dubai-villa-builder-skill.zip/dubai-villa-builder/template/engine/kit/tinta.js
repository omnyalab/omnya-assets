// Colours from config.js: OR = accent, OR2 = light accent for small words, INK = text on filled buttons, ORT = accent on white,
// BTN = filled buttons, ORH = button under the mouse, ora(a) = accent with transparency.
import CONFIG from "../../config.js";
const T = CONFIG.colors || {};
const rgb = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16)).join(",");
const OR = T.accent || "#ff7a12", OR2 = T.accentLight || "#ffb27a", INK = T.buttonText || "#ffffff", ORT = T.accentOnWhite || T.button || OR;
const BTN = T.button || OR, VERDE = T.available || "#3ddc84", ORC = rgb(OR);
const ora = (a) => `rgba(${ORC},${a})`;
const ORH = `rgb(${rgb(BTN).split(",").map((v) => Math.min(255, Math.round(+v + (255 - v) * 0.12))).join(",")})`;
export {
  BTN,
  INK,
  OR,
  OR2,
  ORC,
  ORH,
  ORT,
  VERDE,
  ora
};
