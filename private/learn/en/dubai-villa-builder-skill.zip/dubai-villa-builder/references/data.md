# dati.json

All positions are pixels on the 1920x1080 frame. Numbers, free/sold and prices are EXAMPLES.

- `foto`: the three photos by tour second: `"7"` from above, `"16"` the villa front, `"36"` the pool with the Burj Khalifa.
- `film`: `da` = tour second where film.mp4 starts (7), `fps` 24.
- `stop`: last second of the street scroll (13.04), just before the camera turns towards the villa.
- `tag27_16`: where the villa label sits on the photo at 16 s. `burj_36`: the Burj Khalifa top on the photo at 36 s.
- `strade_sel`: the streets you can pick from above (shapes and names from OpenStreetMap, projected into the camera at 7 s):
  `id` (OSM way id, keep it), `nome` street name on the pin and the card, `sopra` small capitals above it, `libere` villas left,
  `tot` villas on the street (dots), `camere` bedrooms, `vista` view, `da` price from (shown only with showPrices), `attiva` true
  for the one street that flies down (only one), `p` the line of the street (do not move).
- `strada_tag`: the villa tags in the street, one track per villa: `n` number, `libera` free (green) or sold (dark), `prezzo`, `camere`,
  `lato` side, `f0` first film frame of the track, `p` one point per frame `[x roof, y roof, x ground, y ground]` (do not move),
  `hero: true` = the villa you walk into (its number comes from config.js villa.number), `until` = hide the tag after this second.

To renumber the street: change `n` (the reel counts 23, 25 then the chosen villa on the golf side, 28 and 30 opposite, growing in the
direction you drive). To sell or free a villa: `libera`. To change a street name: `nome` and `sopra`.
Map data © OpenStreetMap contributors (ODbL): if you change street names, keep the credit line.
