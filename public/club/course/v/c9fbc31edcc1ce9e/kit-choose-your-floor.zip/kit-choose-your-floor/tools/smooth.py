#!/usr/bin/env python3
"""smooth.py VIDEO [VIDEO ...]  — the judge of camera moves (guides and clips), score 0-10.
Rule of the kit: every guide >= 9 before you spend a credit, every clip >= 8 before you make the next one.

How it works (the same method as video stabilisation): it follows ~300 points from one frame to the next
(Lucas-Kanade), estimates the camera move of every step (slide, zoom, rotation) with RANSAC, then looks at the path:
  - LEFT-RIGHT: the camera turns/slides one way and then comes back the other way (a clear change of direction);
  - TILTED: the image rolls or leans;
  - JOLT: sudden accelerations (the move changes at once instead of starting and stopping softly).
A turn standing still (no parallax) is recognised and judged on its own.
Usage: python3 tools/smooth.py guides/G1.mp4 guides/G2.mp4 ...   (add --json for machine output)
Needs: pip install opencv-python numpy
"""
import json, subprocess, sys
import numpy as np
import cv2

W = 480  # larghezza di analisi


def frames(path):
    cap = cv2.VideoCapture(path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 24
    out = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        h = int(f.shape[0] * W / f.shape[1])
        out.append(cv2.cvtColor(cv2.resize(f, (W, h), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY))
    cap.release()
    return out, fps


def motion(fr, banda=None):
    """per ogni passo: tx, ty (in % di larghezza), zoom (log scala), rot (gradi), inlier; + colonna 5: 1 se un'omografia spiega il passo senza parallasse.
    banda='orizzontale'/'verticale' (23/11): la rotazione si misura solo sulla fascia centrale (vedi judge)."""
    m = []
    for a, b in zip(fr[:-1], fr[1:]):
        p0 = cv2.goodFeaturesToTrack(a, 400, 0.01, 8)
        if p0 is None or len(p0) < 12:
            m.append((0, 0, 0, 0, 0, 0)); continue
        p1, st, _ = cv2.calcOpticalFlowPyrLK(a, b, p0, None, winSize=(21, 21), maxLevel=3)
        g = st.ravel() == 1
        if g.sum() < 12:
            m.append((0, 0, 0, 0, 0, 0)); continue
        M, inl = cv2.estimateAffinePartial2D(p0[g], p1[g], method=cv2.RANSAC, ransacReprojThreshold=2.0)
        if M is None:
            m.append((0, 0, 0, 0, 0, 0)); continue
        s = float(np.hypot(M[0, 0], M[1, 0])); r = float(np.degrees(np.arctan2(M[1, 0], M[0, 0])))
        Hh, hm = cv2.findHomography(p0[g], p1[g], cv2.RANSAC, 1.0); senza_parallasse = 0.0
        if Hh is not None:
            pr = cv2.perspectiveTransform(p0[g].reshape(-1, 1, 2).astype(np.float32), Hh).reshape(-1, 2); err = np.linalg.norm(pr - p1[g].reshape(-1, 2), axis=1)
            senza_parallasse = 1.0 if (np.median(err) < 0.35 and float(hm.mean()) > 0.9) else 0.0
        if banda:
            h0, w0 = a.shape; q = p0[g].reshape(-1, 2)
            c = (np.abs(q[:, 1] - h0 / 2) < h0 * 0.15) if banda == 'orizzontale' else (np.abs(q[:, 0] - w0 / 2) < w0 * 0.15)
            if c.sum() >= 10:
                Mb, _ = cv2.estimateAffinePartial2D(p0[g][c], p1[g][c], method=cv2.RANSAC, ransacReprojThreshold=2.0)
                if Mb is not None: r = float(np.degrees(np.arctan2(Mb[1, 0], Mb[0, 0])))
        # spostamento riferito al centro dell'immagine (lo zoom attorno al centro non deve sembrare una traslazione)
        cx, cy = a.shape[1] / 2, a.shape[0] / 2
        tx = M[0, 0] * cx + M[0, 1] * cy + M[0, 2] - cx
        ty = M[1, 0] * cx + M[1, 1] * cy + M[1, 2] - cy
        m.append((100 * tx / W, 100 * ty / W, float(np.log(max(s, 1e-6))) * 100, r, float(inl.mean()) if inl is not None else 0, senza_parallasse))
    return np.array(m, dtype=np.float64)


def smooth1(x, k=5):
    if len(x) < k:
        return x
    return np.convolve(np.pad(x, k // 2, mode='edge'), np.ones(k) / k, mode='valid')


def flips(v, thr):
    """cambi di verso decisi: prima almeno 4 passi oltre +thr, poi almeno 4 oltre -thr (o il contrario)."""
    seg = np.where(v > thr, 1, np.where(v < -thr, -1, 0))
    runs, cur, n = [], 0, 0
    for i, s in enumerate(seg):
        if s == cur:
            n += 1
        else:
            if cur != 0 and n >= 4:
                runs.append((cur, i - n, i))
            cur, n = s, 1
    if cur != 0 and n >= 4:
        runs.append((cur, len(seg) - n, len(seg)))
    out = []
    for (s1, a1, b1), (s2, a2, b2) in zip(runs, runs[1:]):
        if s1 != s2:
            out.append(a2)
    return out


def judge(path):
    fr, fps = frames(path)
    if len(fr) < 8:
        return {'clip': path, 'error': 'too short'}
    m = motion(fr)
    tx, ty, zm, rot = (smooth1(m[:, i]) for i in range(4))
    # 23/11 (villa sul lago): GIRATA o INCLINAZIONE DA FERMA (Nico: «le svolte si fanno a camera ferma»). Una camera che ruota senza spostarsi
    # non ha parallasse: un'omografia spiega ogni passo. Se succede quasi sempre e il movimento è quasi tutto orizzontale (girata) o verticale
    # (inclinazione), la prospettiva di un obiettivo largo farebbe sembrare rollio e scivolata quello che non lo è: solo in questo caso la rotazione
    # si rimisura sulla fascia centrale (dove quell'effetto è zero e il rollio vero resta) e la scivolata di lato non si applica (non è un'entrata).
    # Entrate, uscite, scivolate vere (che hanno parallasse) si giudicano come prima: controllato che le 31 clip di taratura danno gli stessi voti.
    rotazione_pura = float(np.mean(m[:, 5])) > 0.8
    mtx, mty = float(np.median(np.abs(m[:, 0]))), float(np.median(np.abs(m[:, 1])))
    girata = rotazione_pura and mtx > 2 * max(mty, 0.02); inclinata = rotazione_pura and not girata and mty > 2 * max(mtx, 0.02)
    if girata or inclinata:
        m = motion(fr, 'orizzontale' if girata else 'verticale'); rot = smooth1(m[:, 3])
    dur = len(fr) / fps
    # 1) destra-sinistra: soglia 0,15 % della larghezza a fotogramma (a 24 fps = 3,6 %/s)
    fl = flips(tx, 0.15)
    # 2) storto: rotazione accumulata e rollio a scatti
    roll_tot = float(np.abs(np.cumsum(m[:, 3])).max())
    roll_vel = float(np.percentile(np.abs(rot), 95))
    # 3) strappi: accelerazione del movimento contro il movimento medio
    vel = np.stack([tx, ty, zm], 1)
    acc = np.linalg.norm(np.diff(vel, axis=0), axis=1)
    base = max(float(np.median(np.linalg.norm(vel, axis=1))), 0.05)
    jerk = float(np.percentile(acc, 98) / base)
    jerk_at = int(np.argmax(acc)) + 1
    # entrata: quanto la camera scivola di lato mentre avanza
    zoom_mean = float(np.mean(np.abs(zm)))
    lat = float(np.mean(np.abs(tx)))
    side_ratio = lat / max(zoom_mean, 0.05) if zoom_mean > 0.15 else None
    pen = 0.0
    note = []
    if fl:
        pen += 2.5 * len(fl); note.append('LEFT-RIGHT at ' + ', '.join(f'{i / fps:.1f}s' for i in fl))
    if roll_tot > 1.5:
        pen += min(3, (roll_tot - 1.5) * 0.8); note.append(f'TILTED: rolls {roll_tot:.1f}°')
    if roll_vel > 0.25:
        pen += min(2, (roll_vel - 0.25) * 6); note.append(f'jerky roll {roll_vel:.2f}°/frame')
    if jerk > 0.9:
        pen += min(3, (jerk - 0.9) * 2); note.append(f'JOLT at {jerk_at / fps:.1f}s (x{jerk:.1f})')
    if girata or inclinata:
        side_ratio = None
    if side_ratio is not None and side_ratio > 0.6:
        pen += min(2, (side_ratio - 0.6) * 2); note.append(f'slides sideways while moving in (side/forward {side_ratio:.2f})')
    voto = max(0.0, round(10 - pen, 1))
    return {'clip': path, 'seconds': round(dur, 1), 'score': voto, 'result': 'PASS' if voto >= 9 else 'CLIP OK' if voto >= 8 else 'REDO',
            'notes': (note or ['smooth and straight']) + (['turn standing still'] if girata else ['tilt standing still'] if inclinata else []), 'measures': {'direction_changes': len(fl), 'total_roll': round(roll_tot, 2),
            'roll_p95': round(roll_vel, 3), 'jolt': round(jerk, 2), 'side_forward': None if side_ratio is None else round(side_ratio, 2)}}


if __name__ == '__main__':
    args = [a for a in sys.argv[1:] if a != '--json']
    res = [judge(a) for a in args]
    if '--json' in sys.argv:
        print(json.dumps(res, ensure_ascii=False, indent=1))
    else:
        for r in res:
            if 'error' in r:
                print(r['clip'], r['error']); continue
            print(f"{r['score']:4.1f}  {r['result']:8}  {r['clip'].replace(chr(92), '/').split('/')[-1]:28} {r['seconds']:5.1f}s  " + ' · '.join(r['notes']))
