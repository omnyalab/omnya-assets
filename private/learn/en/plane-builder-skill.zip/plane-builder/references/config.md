# config.js, field by field

`config.js` sets `window.FLIGHT`. Everything on the page reads from it: the intro card ("Book a flight"), the class tickets on the plan, the boarding passes and the upgrade cards.

| Field | Example | Where it shows |
|---|---|---|
| `number` | `'Flight 001'` | intro card, boarding pass |
| `date` | `'Tue 19 Nov'` | intro card, boarding pass |
| `from`, `to` | `'DXB'`, `'LAX'` | the big airport codes on the pass |
| `fromName`, `toName` | `'Dubai'`, `'Los Angeles'` | intro card |
| `departs`, `arrives` | `'08:40'`, `'13:55'` | intro card, pass |
| `duration` | `'16h 15m'` | intro card |
| `currency` | `'USD'` | small label on the tickets |
| `price.E` | `'1,190'` | Economy, per seat |
| `price.P` | `'2,640'` | Premium economy, per seat |
| `price.F` | `'11,800'` | First, per suite |
| `price.R` | `'28,000'` | The Residence, one per flight |

Prices are strings so they keep the user's format (`'1.190'` for Italian, `'1,190'` for English).

## seats.json

`assets/seats.json` holds every seat that can be picked: `EZ` (Economy) and `P` (Premium), each seat as `[label, x, y, booked]` where `x` and `y` are its place on the plan (0 to 1 of the frame) and `booked` is 1 or 0. To change which seats are taken, flip the last number. Keep the labels and positions unless the user brings their own plane.
