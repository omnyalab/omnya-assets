// Choose your villa · Dubai Hills. The interactive page from the reel, drawn on one 1920x1080 canvas over a film and three still photos.
// From above you drop a pin on a street, fly down, scroll along the street like a map, pick the villa, walk in
// (living room, dining room, kitchen), go out to the pool with the Burj Khalifa, and answer "Is this your home?".
// Modes: normal = with the mouse · ?auto = the tour plays by itself with a drawn cursor · ?auto&rec = one frame at a time
// (window.__motore.step) for frame-perfect recording. R starts again.
// Words, villa, prices, link and colours: config.js. Streets and villa tags: dati.json. Numbers, availability and prices are EXAMPLES.
// Map data © OpenStreetMap contributors (ODbL). Fonts: Inter (SIL Open Font License).
//
// Words used in the code (Italian): fase = step of the tour, vai = go to a step, vola = play the film from one second to another,
// disegna = draw one frame, avanza = move the film, giroAuto = the automatic tour, strada/strade = street(s), bollino = round villa tag,
// cartellino = small label over a villa, card/cardStrada/cardFinale = glass cards, FERMATE = the stops inside the house,
// DOM = second of "Is this your home?", LAND = second the camera lands in the street, STOP = end of the street scroll,
// T0 = second of the tour where film.mp4 starts (the film is seconds 7 to 48 of the tour), giroT = current second of the tour.
import * as U from "./engine/kit/quartiere-ui2.js";
import { OR, OR2, INK, ORT, ORC, ORH, BTN, ora } from "./engine/kit/tinta.js";
import { rr, testo, largo, soldi } from "./engine/kit/quartiere-ui.js";
import CONFIG from "./config.js";
const TX = CONFIG.text, V = CONFIG.villa, HN = V.number;
const Q = new URLSearchParams(location.search), VH = false, SIM = false;
const AUTO = Q.has("auto") || VH, REC = Q.has("rec") || VH || SIM;
const W = 1920, H = 1080, VERDE = CONFIG.colors.available || "#3ddc84", GRIGIO = "#a3a8ae";
const cv = document.getElementById("c"), c = cv.getContext("2d");
let K = 1;
function dimensiona() {
  if (VH || REC) {
    K = 1;
  } else {
    const r = cv.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
    K = Math.min(1.6, Math.max(1, r.width * dpr / W));
  }
  const w = Math.round(W * K), h = Math.round(H * K);
  if (cv.width !== w || cv.height !== h) {
    cv.width = w;
    cv.height = h;
  }
}
dimensiona();
addEventListener("resize", () => {
  dimensiona();
  if (typeof disegna === "function" && REC) disegna();
});
if (AUTO) document.body.classList.add("auto");
document.title = CONFIG.pageTitle;
{
  const l = document.getElementById("carica");
  if (l) l.textContent = CONFIG.loading;
}
// data, fonts, the three photos (sharp + blurred copy for the glass), then the whole film in memory (blob) for exact seeking
const D = await fetch("dati.json").then((r) => r.json());
const fonti = [["SFD", "InterDisplay-SemiBold.ttf"], ["SFTB", "Inter-Bold.ttf"], ["SFTS", "Inter-SemiBold.ttf"], ["SFDT", "InterDisplay-Thin.ttf"], ["SFDL", "InterDisplay-Light.ttf"], ["SFDM", "InterDisplay-Medium.ttf"]];
await Promise.all(fonti.map(([f, u]) => new FontFace(f, `url("./assets/fonts/${u}")`).load().then((x) => document.fonts.add(x))));
const carica = (s) => new Promise((ok, ko) => {
  const i = new Image();
  i.onload = () => ok(i);
  i.onerror = ko;
  i.src = s;
});
const FOTO = {}, SFOC = {};
for (const [k, s] of Object.entries(D.foto)) {
  const im = await carica(s);
  FOTO[k] = await createImageBitmap(im);
  const b = document.createElement("canvas");
  b.width = W;
  b.height = H;
  const bc = b.getContext("2d");
  bc.filter = "blur(34px) saturate(1.6)";
  bc.drawImage(im, 0, 0, W, H);
  SFOC[k] = b;
}
let FILM = "film.mp4";
try {
  FILM = URL.createObjectURL(await fetch("film.mp4").then((r) => r.blob()));
} catch (e) {
  console.warn("film in memoria non riuscito, uso il file diretto", e);
}
const video = document.createElement("video");
video.src = FILM;
video.muted = true;
video.playsInline = true;
video.preload = "auto";
video.style.cssText = "position:fixed;left:0;top:0;width:2px;height:2px;opacity:0.01;pointer-events:none";
document.body.appendChild(video);
await new Promise((ok) => {
  video.addEventListener("loadeddata", ok, { once: true });
  video.load();
});
const PIC = document.createElement("canvas");
PIC.width = 384;
PIC.height = 216;
const pc = PIC.getContext("2d");
const VET = document.createElement("canvas");
VET.width = 192;
VET.height = 108;
const vc = VET.getContext("2d");
function videoSfocato(px) {
  pc.filter = `blur(${(px / 5).toFixed(2)}px)`;
  pc.drawImage(video, 0, 0, 384, 216);
  pc.filter = "none";
  return PIC;
}
function vetroVideo() {
  vc.filter = "blur(3px) saturate(1.6)";
  vc.drawImage(video, 0, 0, 192, 108);
  vc.filter = "none";
  return VET;
}
const FPS = 24, T0 = D.film.da, STOP = D.stop;
// jump to a frame of the film (tour seconds) and wait until it is ready to draw
const seek = (t) => SIM ? Promise.resolve() : new Promise((ok) => {
  const v = (Math.round((t - T0) * FPS) + 0.5) / FPS;
  if (Math.abs(video.currentTime - v) < 1e-3) return ok();
  let fatto = false;
  const fine = () => {
    if (!fatto) {
      fatto = true;
      ok();
    }
  };
  if (video.requestVideoFrameCallback) video.requestVideoFrameCallback(() => fine());
  video.addEventListener("seeked", () => setTimeout(fine, video.requestVideoFrameCallback ? 500 : 30), { once: true });
  video.currentTime = v;
});
// streets you can pick from above (OSM shapes projected into the camera at second 7)
const STRADE = D.strade_sel.map((st) => {
  const L = [0];
  for (let i = 1; i < st.p.length; i++) L.push(L[i - 1] + Math.hypot(st.p[i][0] - st.p[i - 1][0], st.p[i][1] - st.p[i - 1][1]));
  return { ...st, L };
});
const DOM = 41.5;
const PRINC = STRADE.find((st) => st.attiva), LAND = 9.6, STR = (id) => STRADE.find((st) => st.id === id);
function vicino(st, x, y) {
  let best = [1e9, st.p[0], 0];
  for (let i = 1; i < st.p.length; i++) {
    const [ax, ay] = st.p[i - 1], [bx, by] = st.p[i], dx = bx - ax, dy = by - ay, L2 = dx * dx + dy * dy || 1, t = Math.max(0, Math.min(1, ((x - ax) * dx + (y - ay) * dy) / L2));
    const px = ax + t * dx, py = ay + t * dy, d = Math.hypot(px - x, py - y);
    if (d < best[0]) best = [d, [px, py], st.L[i - 1] + t * Math.sqrt(L2)];
  }
  return best;
}
const stradaSotto = (x, y) => {
  let b = null, bd = 34;
  for (const st of STRADE) {
    const d = vicino(st, x, y)[0];
    if (d < bd) {
      bd = d;
      b = st;
    }
  }
  return b;
};
const ease = (t) => {
  t = Math.max(0, Math.min(1, t));
  return 1 - Math.pow(1 - t, 3);
};
const easeIO = (t) => {
  t = Math.max(0, Math.min(1, t));
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
};
const cl = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
// state of the page
const S = { fase: "pin", t0: 0, now: 0, mouse: [W * 0.62, H * 0.86], hov: null, giu: false, pin: { stato: "libero", da: null, a: null, t: 0 }, sel: null, cardSt: null, cardPrev: null, cardT: -9, hovStrada: null, volo: null };
function vai(fase, extra = {}) {
  Object.assign(S, { fase, t0: S.now }, extra);
}
function ricomincia() {
  S.pin = { stato: "libero", da: null, a: null, t: 0 };
  S.sel = S.cardSt = S.cardPrev = S.hovStrada = null;
  S.cardT = -9;
  S.hov = null;
  S.p27 = null;
  S.arrivoStop = null;
  S.vedo27 = null;
  vai("pin");
}
const scendiVia = () => vai("scendi", { scendi: { target: LAND, partito: false } });
function vola(da, a, dopo, extra = {}) {
  S.volo = { da, a, dopo, extra, partito: false };
  vai("volo");
}
// the three stops inside: t = tour second, hot = point on the object (no hot = button at the bottom), verso = arrow direction
const FERMATE = [
  { t: 26, stanza: CONFIG.rooms[0].room, sopra: `Villa ${HN} · ${TX.ground}`, bottone: CONFIG.rooms[0].button, verso: "sx" },
  // the dining room is off-screen to the left: button at the bottom, arrow left
  { t: 29, stanza: CONFIG.rooms[1].room, sopra: `Villa ${HN} · ${TX.ground}`, bottone: CONFIG.rooms[1].button, hot: [560, 440], verso: "su", lato: "sopra" },
  // point on the kitchen island, the camera goes straight on
  { t: 31.5, stanza: CONFIG.rooms[2].room, sopra: `Villa ${HN} · ${TX.ground}`, bottone: CONFIG.rooms[2].button, hot: [1640, 400], verso: "dx", lato: "sotto" }
  // point on the glass wall, button under it
];
const ui = { W, H, sfondo: null, sfondoSfocato: null, btns: [] };
function linea(pts, col, w, glow, a = 1) {
  if (pts.length < 2) return;
  c.save();
  c.globalAlpha = a;
  c.lineCap = "round";
  c.lineJoin = "round";
  c.strokeStyle = col;
  c.lineWidth = w;
  c.shadowColor = col;
  c.shadowBlur = glow;
  c.beginPath();
  pts.forEach(([x, y], i) => i ? c.lineTo(x, y) : c.moveTo(x, y));
  c.stroke();
  c.restore();
}
const GLOW = document.createElement("canvas");
GLOW.width = 960;
GLOW.height = 540;
const gl = GLOW.getContext("2d");
// the street lit from above: a soft glow, never a hard line
function strisciaMorbida(pts, a) {
  if (pts.length < 3 || a <= 0) return;
  const giro = () => {
    gl.beginPath();
    gl.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length - 1; i++) {
      const mx = (pts[i][0] + pts[i + 1][0]) / 2, my = (pts[i][1] + pts[i + 1][1]) / 2;
      gl.quadraticCurveTo(pts[i][0], pts[i][1], mx, my);
    }
    gl.lineTo(pts[pts.length - 1][0], pts[pts.length - 1][1]);
  };
  gl.setTransform(1, 0, 0, 1, 0, 0);
  gl.clearRect(0, 0, 960, 540);
  gl.setTransform(0.5, 0, 0, 0.5, 0, 0);
  gl.lineCap = "round";
  gl.lineJoin = "round";
  for (const [w, al, bl] of [[46, 0.14, 10], [26, 0.24, 5.5], [13, 0.38, 3]]) {
    gl.filter = `blur(${bl}px)`;
    gl.strokeStyle = ora(al);
    gl.lineWidth = w;
    giro();
    gl.stroke();
  }
  gl.filter = "none";
  c.save();
  c.globalAlpha = a;
  c.drawImage(GLOW, 0, 0, W, H);
  c.restore();
}
// the label on the pin: street name
function etichettaPin(x, y, a, nome, solo = false) {
  if (a <= 0) return;
  const t1 = solo ? "" : TX.yourStreet, t2 = nome;
  const w = Math.max(largo(c, t1, "14px SFTB", 3), largo(c, t2, "26px SFD")) + 56, h = solo ? 54 : 76, X = x - w / 2, Y = y - 118 - h;
  c.save();
  c.globalAlpha = a;
  U.vetro(c, ui, X, Y, w, h, 24, { scuro: 0.5 });
  c.beginPath();
  c.moveTo(x - 10, Y + h);
  c.lineTo(x, Y + h + 11);
  c.lineTo(x + 10, Y + h);
  c.closePath();
  c.fillStyle = "rgba(20,22,26,0.7)";
  c.fill();
  if (t1) testo(c, t1, x, Y + 30, "14px SFTB", OR2, 3, "center");
  testo(c, t2, x, Y + (solo ? 37 : 60), "26px SFD", "#fff", -0.2, "center");
  c.restore();
}
function stradaParziale(st, punto, p) {
  const L = st.L[st.L.length - 1], s0 = vicino(st, punto[0], punto[1])[2], da = s0 - p * L, a = s0 + p * L, out = [];
  for (let i = 0; i < st.p.length; i++) if (st.L[i] >= da && st.L[i] <= a) out.push(st.p[i]);
  return out;
}
function titoloSx(sopra, tit, a) {
  c.save();
  c.globalAlpha = a;
  c.translate(260, 120);
  c.scale(2.6, 1);
  const g = c.createRadialGradient(0, 0, 0, 0, 0, 330);
  g.addColorStop(0, "rgba(0,0,0,0.5)");
  g.addColorStop(0.6, "rgba(0,0,0,0.22)");
  g.addColorStop(1, "rgba(0,0,0,0)");
  c.fillStyle = g;
  c.fillRect(-400, -400, 800, 800);
  c.setTransform(K, 0, 0, K, 0, 0);
  c.shadowColor = "rgba(0,0,0,0.55)";
  c.shadowBlur = 30;
  testo(c, sopra.toUpperCase(), 96, 110, "18px SFTB", OR2, 5.5);
  testo(c, tit, 92, 204, "88px SFD", "#fff", -1);
  c.restore();
}
function pallini(x, y, tot, liberi, a) {
  for (let i = 0; i < tot; i++) {
    c.save();
    c.globalAlpha = a;
    c.fillStyle = i < liberi ? VERDE : "rgba(255,255,255,0.22)";
    if (i < liberi) {
      c.shadowColor = VERDE;
      c.shadowBlur = 10;
    }
    c.beginPath();
    c.arc(x + i * 26 + 7, y, 7, 0, 7);
    c.fill();
    c.restore();
  }
}
// the "Choose your street" card on the right
function cardStrada(a) {
  const w = 540, h = 680, x = W - 90 - w + (1 - a) * 80, y = H / 2 - h / 2 + 40, X = x + 44, k = ease((S.now - S.cardT) / 0.5);
  c.save();
  c.globalAlpha = a;
  U.vetro(c, ui, x, y, w, h, 48);
  testo(c, TX.chooseStreet, X, y + 112, "36px SFDM", "#fff");
  const lib = STRADE.reduce((n, st) => n + st.libere, 0), daMin = Math.min(...STRADE.map((st) => st.da));
  const dati = (st) => st ? {
    sopra: st.sopra,
    num: String(st.libere).padStart(2, "0"),
    riga: st.libere === 1 ? TX.leftOne : TX.leftMany,
    nome: st.nome,
    tot: st.tot,
    lib: st.libere,
    col: [[TX.labels.bedrooms, st.camere], [TX.labels.view, st.vista], [CONFIG.showPrices ? TX.labels.from : TX.labels.price, soldi(st.da)]],
    st
  } : { sopra: TX.allStreets, num: String(lib).padStart(2, "0"), riga: TX.allStreetsLine, nome: TX.allStreetsName, tot: 0, lib: 0, col: [[TX.labels.streets, String(STRADE.length)], [TX.labels.bedrooms, TX.allStreetsBedrooms], [CONFIG.showPrices ? TX.labels.from : TX.labels.price, soldi(daMin)]], st: null };
  const parte = (d, al) => {
    if (al <= 0.01) return;
    c.save();
    c.globalAlpha = a * al;
    testo(c, d.sopra, X, y + 62, "15px SFTB", "#fff", 4.6);
    if (d.st) testo(c, CONFIG.area, X + largo(c, d.sopra, "15px SFTB", 4.6) + 14, y + 62, "16px SFTS", "rgba(255,255,255,0.65)");
    testo(c, d.num, X - 8, y + 330, "240px SFDL", "#fff", -9);
    c.fillStyle = OR;
    c.beginPath();
    c.arc(X + 7, y + 368, 6.5, 0, 7);
    c.fill();
    testo(c, d.riga, X + 26, y + 375, "21px SFTS", OR2);
    testo(c, d.nome, X, y + 428, "30px SFD", "#fff", -0.3);
    if (d.tot) pallini(X, y + 460, d.tot, d.lib, 1);
    c.fillStyle = "rgba(255,255,255,0.22)";
    c.fillRect(X, y + 492, w - 88, 1);
    const cw = (w - 88) / 3;
    d.col.forEach(([kk, v], i) => {
      testo(c, kk, X + i * cw, y + 526, "13px SFTS", "rgba(255,255,255,0.6)", 2.6);
      testo(c, v, X + i * cw, y + 560, "24px SFDM", "#fff");
    });
    const bx = X, by = y + h - 100, bw = w - 88, bh = 66;
    if (!d.st || d.st !== S.sel) {
      rr(c, bx, by, bw, bh, bh / 2);
      c.strokeStyle = "rgba(255,255,255,0.35)";
      c.lineWidth = 1.5;
      c.setLineDash([6, 6]);
      c.stroke();
      c.setLineDash([]);
      testo(c, d.st ? TX.clickHint : TX.dropHint, bx + bw / 2, by + bh / 2 + 9, "24px SFD", "rgba(255,255,255,0.8)", 0, "center");
    } else if (d.st.attiva) {
      const hov = S.hov === "vola";
      c.save();
      c.shadowColor = ora(0.6);
      c.shadowBlur = hov ? 40 : 26;
      c.shadowOffsetY = 8;
      rr(c, bx, by, bw, bh, bh / 2);
      c.fillStyle = hov ? ORH : BTN;
      c.fill();
      c.restore();
      c.save();
      c.shadowColor = "rgba(0,0,0,0.28)";
      c.shadowBlur = 6;
      c.shadowOffsetY = 1;
      testo(c, TX.flyDown, bx + bw / 2, by + bh / 2 + 10, "27px SFD", INK, 0, "center");
      c.restore();
      if (al > 0.5) ui.btns.push({ id: "vola", r: [bx, by, bx + bw, by + bh] });
    } else {
      rr(c, bx, by, bw, bh, bh / 2);
      c.fillStyle = "rgba(255,255,255,0.1)";
      c.fill();
      c.strokeStyle = "rgba(255,255,255,0.4)";
      c.lineWidth = 1.5;
      c.stroke();
      testo(c, TX.comingSoon, bx + bw / 2, by + bh / 2 + 9, "24px SFD", "rgba(255,255,255,0.85)", 0, "center");
    }
    c.restore();
  };
  parte(dati(S.cardPrev), 1 - cl(k * 2));
  parte(dati(S.cardSt), cl(k * 2 - 1));
  c.restore();
  return { x, y, w, h, yNum: y + 419 };
}
// the thin line from the lit point to the card
function filo(p, q, a, prog) {
  const [x0, y0] = p, [x1, y1] = q, xm = x0 + (x1 - x0) * prog;
  c.save();
  c.globalAlpha = a;
  c.strokeStyle = "rgba(255,255,255,0.95)";
  c.lineWidth = 2;
  c.shadowColor = "rgba(0,0,0,0.45)";
  c.shadowBlur = 8;
  c.beginPath();
  c.moveTo(x0, y0);
  c.lineTo(x0 + (x1 - x0) * Math.min(prog, 0.12), y0);
  if (prog > 0.12) {
    c.lineTo(xm, y0 + (y1 - y0) * cl((prog - 0.12) / 0.88));
  }
  c.stroke();
  c.fillStyle = OR;
  c.shadowColor = OR;
  c.shadowBlur = 14;
  c.beginPath();
  c.arc(x0, y0, 6, 0, 7);
  c.fill();
  if (prog >= 1) {
    c.fillStyle = "#fff";
    c.shadowBlur = 0;
    c.beginPath();
    c.arc(x1, y1, 4.5, 0, 7);
    c.fill();
  }
  c.restore();
}
// the round tag over a villa: number, free (green) or sold (dark); the chosen villa is orange and pulses
function bollino(v, a, hov, t, pos) {
  const [x, yt] = pos || v.tetto, s = pos ? pos[2] : 1, y = yt - (v.eroe ? pos ? pos[3] : 118 : pos ? pos[4] : 44) * s;
  c.save();
  c.translate(x, y);
  c.scale(s, s);
  c.translate(-x, -y);
  c.save();
  c.globalAlpha = a;
  c.strokeStyle = "rgba(255,255,255,0.85)";
  c.lineWidth = 2;
  c.beginPath();
  c.moveTo(x, y + (yt - y) / s);
  c.lineTo(x, y + 18);
  c.stroke();
  c.fillStyle = "#fff";
  c.beginPath();
  c.arc(x, y + (yt - y) / s, 3.5, 0, 7);
  c.fill();
  if (v.eroe) {
    const pulse = t * 1.2 % 1;
    c.strokeStyle = `rgba(${ORC},${0.7 * (1 - pulse)})`;
    c.lineWidth = 3;
    c.beginPath();
    c.arc(x, y, 20 + pulse * 22, 0, 7);
    c.stroke();
  }
  c.shadowColor = v.eroe ? ora(0.7) : "rgba(0,0,0,0.45)";
  c.shadowBlur = v.eroe ? 22 : 12;
  c.fillStyle = v.eroe ? OR : v.libera ? "#ffffff" : "rgba(14,16,20,0.82)";
  c.beginPath();
  c.arc(x, y, hov ? 22 : 19, 0, 7);
  c.fill();
  c.shadowBlur = 0;
  c.strokeStyle = v.eroe ? "#fff" : v.libera ? VERDE : "rgba(255,255,255,0.35)";
  c.lineWidth = 3;
  c.stroke();
  testo(c, String(v.n), x, y + 6, "16px SFD", v.eroe ? INK : v.libera ? "#0c0d10" : "rgba(255,255,255,0.75)", 0, "center");
  c.restore();
  c.restore();
  if (hov) U.cartellino(c, [x, y - 26 * s], { n: v.n, libera: v.libera, prezzo: v.prezzo, solo: true }, a, v.eroe);
  S.colpi.push({ id: "villa:" + v.n, cx: x, cy: y, r: 30 * s });
  return [x, y, s];
}
// in the street: tags follow their houses frame by frame (tracks in dati.json strada_tag)
function bolliniStrada(g) {
  const f = (g - 7) * FPS, fi = Math.floor(f), q = f - fi;
  let p27 = null;
  for (const b of [...D.strada_tag.filter((b2) => !b2.hero), ...D.strada_tag.filter((b2) => b2.hero)]) {
    const i = fi - b.f0;
    if (i < 0 || i >= b.p.length - 1) continue;
    const [x1, y1, , y2] = b.p[i].map((v2, k) => v2 + (b.p[i + 1][k] - v2) * q), s = cl((y2 - y1) / 170, 1.05, 1.7);
    const a = cl((x1 + 20) / 80) * cl((1940 - x1) / 80) * cl((g - 9.45) / 0.3) * cl(i / 5);
    if (a <= 0.01) continue;
    const v = { n: b.hero ? HN : b.n, eroe: !!b.hero, libera: b.hero ? true : b.libera, prezzo: b.hero ? V.price : b.prezzo, camere: b.camere, golf: b.golf };
    if (b.until && g > b.until) continue;
    const r = bollino(v, a, S.hov === "villa:" + v.n || S.fase === "scegli" && b.hero, S.now, [x1, y1, s, 64, 40]);
    if (b.hero) p27 = r;
  }
  return p27;
}
const PASSO = 1.1;
// "Scroll down the street" pill with the progress bar
function rotella(p, a) {
  if (a <= 0) return;
  const lab = TX.scroll, w = largo(c, lab, "28px SFD") + 130, h = 84, x = W / 2 - w / 2, y = H - 150;
  c.save();
  c.globalAlpha = a;
  U.vetro(c, ui, x, y, w, h, h / 2, { scuro: 0.55 });
  const mx = x + 50, my = y + 18;
  rr(c, mx - 14, my, 28, 46, 14);
  c.strokeStyle = "#fff";
  c.lineWidth = 2.5;
  c.stroke();
  const ph = S.now * 1.4 % 1;
  c.fillStyle = OR;
  c.beginPath();
  c.arc(mx, my + 11 + ph * 13, 4, 0, 7);
  c.fill();
  c.shadowColor = "rgba(0,0,0,0.4)";
  c.shadowBlur = 6;
  testo(c, lab, x + 92, y + h / 2 + 10, "28px SFD", "#fff", -0.2);
  c.shadowBlur = 0;
  rr(c, x + 28, y + h - 10, w - 56, 4, 2);
  c.fillStyle = "rgba(255,255,255,0.18)";
  c.fill();
  rr(c, x + 28, y + h - 10, (w - 56) * cl(p), 4, 2);
  c.fillStyle = OR;
  c.shadowColor = OR;
  c.shadowBlur = 10;
  c.fill();
  c.restore();
}
// after "Yes": the villa card on the dark film, with the photo, info, price and the two buttons
function cardFinale(a, t) {
  if (a <= 0) return;
  const w = 1240, h = 640, x = W / 2 - w / 2, y = H / 2 - h / 2 + (1 - a) * 40, fw = 600;
  c.save();
  c.globalAlpha = a;
  c.save();
  c.shadowColor = "rgba(0,0,0,0.6)";
  c.shadowBlur = 80;
  c.shadowOffsetY = 30;
  rr(c, x, y, w, h, 36);
  c.fillStyle = "#121418";
  c.fill();
  c.restore();
  c.save();
  rr(c, x, y, w, h, 36);
  c.clip();
  const im = fotoK("16"), sc = Math.max(fw / im.width, h / im.height), iw = im.width * sc, ih = im.height * sc;
  c.drawImage(im, x + fw / 2 - iw / 2 - 40, y + h / 2 - ih / 2, iw, ih);
  c.fillStyle = "#121418";
  c.fillRect(x + fw, y, w - fw, h);
  const g = c.createLinearGradient(x + fw - 120, 0, x + fw, 0);
  g.addColorStop(0, "rgba(18,20,24,0)");
  g.addColorStop(1, "rgba(18,20,24,1)");
  c.fillStyle = g;
  c.fillRect(x + fw - 120, y, 120, h);
  c.restore();
  rr(c, x + 0.75, y + 0.75, w - 1.5, h - 1.5, 36);
  c.strokeStyle = "rgba(255,255,255,0.16)";
  c.lineWidth = 1.5;
  c.stroke();
  const X = x + fw + 40, CW = w - fw - 80;
  testo(c, TX.welcome, X, y + 70, "15px SFTB", OR2, 4.2);
  testo(c, `Villa ${HN}`, X - 3, y + 146, "76px SFD", "#fff", -1.5);
  testo(c, `${V.street} · ${CONFIG.area}`, X, y + 190, "22px SFTS", "rgba(255,255,255,0.75)");
  c.fillStyle = "rgba(255,255,255,0.16)";
  c.fillRect(X, y + 222, CW, 1);
  const info = [[TX.labels.bedrooms, String(V.bedrooms)], [TX.labels.builtUp, V.builtUp], [TX.labels.view, V.viewLong], [CONFIG.landmark.label, CONFIG.landmark.distance]];
  info.forEach(([k, v], i) => {
    const cx = X + i % 2 * (CW / 2), cy = y + 266 + Math.floor(i / 2) * 82;
    testo(c, k, cx, cy, "13px SFTS", "rgba(255,255,255,0.55)", 2.6);
    testo(c, v, cx, cy + 36, "28px SFDM", "#fff");
  });
  c.fillStyle = "rgba(255,255,255,0.16)";
  c.fillRect(X, y + 420, CW, 1);
  testo(c, soldi(V.price), X, y + 476, "44px SFD", "#fff", -0.4);
  c.fillStyle = VERDE;
  c.beginPath();
  c.arc(X + largo(c, soldi(V.price), "44px SFD", -0.4) + 24, y + 462, 6.5, 0, 7);
  c.fill();
  testo(c, V.status, X + largo(c, soldi(V.price), "44px SFD", -0.4) + 38, y + 469, "20px SFTS", "rgba(255,255,255,0.8)");
  const by = y + h - 112, bh = 72, b1 = CW * 0.62, hv1 = S.hov === "visita", hv2 = S.hov === "liv:0";
  c.save();
  c.shadowColor = ora(0.5);
  c.shadowBlur = hv1 ? 40 : 26;
  c.shadowOffsetY = 8;
  rr(c, X, by, b1, bh, bh / 2);
  c.fillStyle = hv1 ? ORH : BTN;
  c.fill();
  c.restore();
  c.save();
  c.shadowColor = "rgba(0,0,0,0.28)";
  c.shadowBlur = 6;
  testo(c, TX.book, X + b1 / 2, by + bh / 2 + 10, "26px SFD", INK, 0, "center");
  c.restore();
  rr(c, X + b1 + 14, by, CW - b1 - 14, bh, bh / 2);
  c.fillStyle = hv2 ? "rgba(255,255,255,0.16)" : "rgba(255,255,255,0.08)";
  c.fill();
  c.strokeStyle = "rgba(255,255,255,0.6)";
  c.lineWidth = 1.5;
  c.stroke();
  testo(c, TX.again, X + b1 + 14 + (CW - b1 - 14) / 2, by + bh / 2 + 10, "26px SFD", "#fff", 0, "center");
  if (CONFIG.developer) testo(c, `${TX.presented} ${CONFIG.developer}`, x + w - 36, y + h + 44, "17px SFTS", "rgba(255,255,255,0.6)", 0.6, "right");
  c.restore();
  ui.btns.push({ id: "visita", r: [X, by, X + b1, by + bh] }, { id: "liv:0", r: [X + b1 + 14, by, X + CW, by + bh] });
}
// outside by the pool: "Private garden" bottom left
function nomeFuori(a) {
  if (a <= 0) return;
  c.save();
  c.globalAlpha = a;
  const g = c.createLinearGradient(0, H - 340, 0, H);
  g.addColorStop(0, "rgba(0,0,0,0)");
  g.addColorStop(1, "rgba(0,0,0,0.55)");
  c.fillStyle = g;
  c.fillRect(0, H - 340, W, 340);
  c.shadowColor = "rgba(0,0,0,0.5)";
  c.shadowBlur = 24;
  testo(c, TX.garden, 92, H - 112, "84px SFD", "#fff", -1.2 + (1 - a) * 4);
  testo(c, TX.gardenLine, 96, H - 66, "26px SFTS", "rgba(255,255,255,0.86)", 0.2);
  c.restore();
}
// room name bottom left inside the house
function nomeStanza(F, a) {
  if (a <= 0) return;
  c.save();
  c.globalAlpha = a;
  const g = c.createLinearGradient(0, H - 330, 0, H);
  g.addColorStop(0, "rgba(0,0,0,0)");
  g.addColorStop(1, "rgba(0,0,0,0.55)");
  c.fillStyle = g;
  c.fillRect(0, H - 330, W, 330);
  c.shadowColor = "rgba(0,0,0,0.5)";
  c.shadowBlur = 24;
  testo(c, F.sopra.toUpperCase(), 96, H - 150, "17px SFTB", OR2, 5);
  testo(c, F.stanza, 92, H - 78, "76px SFD", "#fff", -1 + (1 - a) * 4);
  c.restore();
}
function freccia(cx, cy, verso, col) {
  const R = { dx: 0, sx: Math.PI, su: -Math.PI / 2 }[verso] || 0;
  c.save();
  c.translate(cx, cy);
  c.rotate(R);
  c.strokeStyle = col;
  c.lineWidth = 3.5;
  c.lineCap = "round";
  c.lineJoin = "round";
  c.beginPath();
  c.moveTo(-10, 0);
  c.lineTo(10, 0);
  c.moveTo(3, -8);
  c.lineTo(11, 0);
  c.lineTo(3, 8);
  c.stroke();
  c.restore();
}
// the "View ..." button at each stop
function bottoneView(F, a, t) {
  if (a <= 0) return;
  const lab = F.bottone, w = largo(c, lab, "32px SFD") + 150, h = 92, hov = S.hov === "next";
  let x, y, conn = null;
  if (!F.hot) {
    x = W / 2 - w / 2;
    y = H - 172;
  } else {
    const [hx, hy] = F.hot;
    if (F.lato === "sopra") {
      x = hx - w / 2;
      y = hy - 70 - h;
      conn = [[hx, hy - 12], [hx, y + h]];
    } else if (F.lato === "sinistra") {
      x = hx - 56 - w;
      y = hy - h / 2;
      conn = [[hx - 12, hy], [x + w, hy]];
    } else if (F.lato === "sotto") {
      x = hx - w / 2;
      y = hy + 70;
      conn = [[hx, hy + 12], [hx, y]];
    } else {
      x = hx + 56;
      y = hy - h / 2;
      conn = [[hx + 12, hy], [x, hy]];
    }
    x = cl(x, 40, W - 40 - w);
    y = cl(y, 40, H - 40 - h);
  }
  c.save();
  c.globalAlpha = a;
  if (F.hot) {
    const [hx, hy] = F.hot;
    for (let k = 0; k < 2; k++) {
      const ph = (S.now * 0.9 + k * 0.5) % 1;
      c.strokeStyle = ora(0.85 * (1 - ph));
      c.lineWidth = 3;
      c.beginPath();
      c.arc(hx, hy, 10 + ph * 40, 0, 7);
      c.stroke();
    }
    c.fillStyle = "#fff";
    c.shadowColor = OR;
    c.shadowBlur = 18;
    c.beginPath();
    c.arc(hx, hy, 9, 0, 7);
    c.fill();
    c.shadowBlur = 0;
    c.fillStyle = OR;
    c.beginPath();
    c.arc(hx, hy, 5, 0, 7);
    c.fill();
    const pr = ease((t - 0.35) / 0.4), [[x0, y0], [x1, y1]] = conn;
    c.strokeStyle = "rgba(255,255,255,0.95)";
    c.lineWidth = 2.5;
    c.shadowColor = "rgba(0,0,0,0.45)";
    c.shadowBlur = 6;
    c.beginPath();
    c.moveTo(x0, y0);
    c.lineTo(x0 + (x1 - x0) * pr, y0 + (y1 - y0) * pr);
    c.stroke();
    c.shadowBlur = 0;
  }
  c.translate(x + w / 2, y + h / 2);
  const sc = hov ? 1.04 : 1;
  c.scale(sc, sc);
  c.translate(-(x + w / 2), -(y + h / 2));
  U.vetro(c, ui, x, y, w, h, h / 2, { scuro: hov ? 0.5 : 0.62 });
  if (hov) {
    rr(c, x + 1, y + 1, w - 2, h - 2, h / 2 - 1);
    c.strokeStyle = OR;
    c.lineWidth = 2.5;
    c.stroke();
  }
  c.save();
  c.shadowColor = ora(0.6);
  c.shadowBlur = 20;
  c.fillStyle = BTN;
  c.beginPath();
  c.arc(x + 48, y + h / 2, 30, 0, 7);
  c.fill();
  c.restore();
  freccia(x + 48, y + h / 2, F.verso, INK);
  c.shadowColor = "rgba(0,0,0,0.45)";
  c.shadowBlur = 8;
  testo(c, lab, x + 100, y + h / 2 + 11, "32px SFD", "#fff", -0.3);
  c.shadowBlur = 0;
  c.restore();
  ui.btns.push({ id: "next", r: [x, y, x + w, y + h] });
  S.pillCentro = [x + w / 2, y + h / 2];
}
// the drawn cursor of the automatic tour
function cursore(x, y, giu2) {
  c.save();
  c.translate(x, y);
  c.scale(1.5, 1.5);
  c.shadowColor = "rgba(0,0,0,0.45)";
  c.shadowBlur = 8;
  c.shadowOffsetY = 2;
  c.beginPath();
  c.moveTo(0, 0);
  c.lineTo(0, 22);
  c.lineTo(6, 17);
  c.lineTo(10, 26);
  c.lineTo(14, 24);
  c.lineTo(10, 15.5);
  c.lineTo(17, 15.5);
  c.closePath();
  c.fillStyle = "#fff";
  c.fill();
  c.shadowBlur = 0;
  c.strokeStyle = "#111";
  c.lineWidth = 1.3;
  c.stroke();
  c.restore();
  if (giu2) {
    c.save();
    c.strokeStyle = "rgba(255,255,255,0.8)";
    c.lineWidth = 3;
    c.beginPath();
    c.arc(x, y, 26, 0, 7);
    c.stroke();
    c.restore();
  }
}
const FOTOK = {};
// photos resized once to the real screen size (fast to draw, sharp on Retina)
function fotoK(k) {
  const w = Math.round(W * K), h = Math.round(H * K), f = FOTOK[k];
  if (f && f.width === w && f.height === h) return f;
  const o = document.createElement("canvas");
  o.width = w;
  o.height = h;
  const oc = o.getContext("2d");
  oc.imageSmoothingQuality = "high";
  oc.drawImage(FOTO[k], 0, 0, w, h);
  FOTOK[k] = o;
  return o;
}
function sfondoFoto(k, a = 1) {
  c.save();
  c.globalAlpha = a;
  c.drawImage(fotoK(k), 0, 0, W, H);
  c.restore();
  ui.sfondo = FOTO[k];
  ui.sfondoSfocato = SFOC[k];
}
// draw one frame for the current step
function disegna() {
  c.setTransform(K, 0, 0, K, 0, 0);
  ui.btns = [];
  S.colpi = [];
  const t = S.now - S.t0;
  if (S.fase === "pin") {
    sfondoFoto("7");
    titoloSx(CONFIG.areaTitle, TX.dropPin, ease(t / 0.6));
    const p = S.pin, tg = S.now - p.t, hs = S.hovStrada, mostra = hs || S.sel;
    if (mostra !== S.cardSt) {
      S.cardPrev = S.cardSt;
      S.cardSt = mostra;
      S.cardT = S.now;
    }
    if (hs && (hs !== S.sel || p.stato === "libero")) strisciaMorbida(hs.p, 0.55);
    if (p.stato === "giu") strisciaMorbida(stradaParziale(S.sel, p.a, easeIO((tg - 0.1) / 1)), ease((tg - 0.05) / 0.5));
    const card = cardStrada(ease((t - 0.2) / 0.6));
    if (CONFIG.mapCredit) testo(c, CONFIG.mapCredit, W - 24, H - 20, "14px SFTS", "rgba(255,255,255,0.6)", 0.2, "right");
    if (p.stato === "giu") filo([p.a[0] + 4, p.a[1] - 2], [card.x + 2, card.yNum], ease((tg - 0.5) / 0.6), ease((tg - 0.5) / 0.6));
    if (p.stato === "cade") {
      const q = easeIO(tg / 0.35), x = p.a[0], y = p.a[1];
      c.save();
      c.globalAlpha = ease(tg / 0.15);
      U.pin(c, x, y, 1.9, 2.2 * (1 - q), false);
      c.restore();
      if (tg >= 0.35) {
        p.stato = "giu";
        p.t = S.now;
      }
    }
    if (p.stato === "giu") {
      U.pin(c, p.a[0], p.a[1], 1.9, 0, tg < 1.2);
      etichettaPin(p.a[0], p.a[1], ease((tg - 0.5) / 0.45), S.sel.nome);
    }
    if (p.stato === "giu" && tg < 1.2) {
      const r = ease(tg / 1.2);
      c.save();
      c.strokeStyle = `rgba(${ORC},${1 - r})`;
      c.lineWidth = 3;
      c.beginPath();
      c.ellipse(p.a[0], p.a[1], 30 + r * 90, 12 + r * 34, 0, 0, 7);
      c.stroke();
      c.restore();
    }
  }
  if (S.fase === "villa") {
    sfondoFoto("16", 1);
    const a = ease((t - 0.15) / 0.4), [tx, ty] = D.tag27_16;
    const rc = U.cartellino(c, [tx, ty], { n: HN, libera: true, prezzo: V.price, solo: true }, a, true);
    const ac = ease((t - 0.35) / 0.55);
    c.save();
    c.translate((1 - ac) * 120, 0);
    U.cardVilla(c, ui, { comunita: V.community, n: HN, nome: V.type, urgenza: V.urgency, camere: V.bedrooms, area: V.builtUp, vista: V.view, prezzo: V.price, btn: "entra" }, ac, S.hov === "entra");
    c.restore();
    const ym = (rc[1] + rc[3]) / 2;
    filo([rc[2] + 10, ym], [W - 90 - 540 + (1 - ac) * 120 - 12, ym], ac, ac);
  }
  if (S.fase === "scendi" || S.fase === "scegli") {
    const g = S.fase === "scegli" ? STOP : S.giroT;
    c.drawImage(video, 0, 0, W, H);
    ui.sfondo = null;
    ui.sfondoSfocato = null;
    if (S.fase === "scendi" && t < 0.35 && g < 7.2) {
      c.save();
      c.globalAlpha = 1 - t / 0.35;
      c.drawImage(fotoK("7"), 0, 0, W, H);
      c.restore();
    }
    if (S.fase === "scendi" && t < 0.7 && S.sel) {
      const af = 1 - easeIO(t / 0.7);
      strisciaMorbida(stradaParziale(S.sel, S.pin.a, 1), af);
      titoloSx(CONFIG.areaTitle, TX.dropPin, af);
      cardStrada(af);
      c.save();
      c.globalAlpha = af;
      U.pin(c, S.pin.a[0], S.pin.a[1], 1.9, 0, false);
      c.restore();
      etichettaPin(S.pin.a[0], S.pin.a[1], af, S.sel.nome);
      ui.btns = [];
    }
    if (S.fase === "scegli" && (!S.sfocStop || S.sfocStop.t0 !== S.t0)) {
      const b = document.createElement("canvas");
      b.width = W;
      b.height = H;
      const bc = b.getContext("2d");
      bc.filter = "blur(34px) saturate(1.6)";
      bc.drawImage(video, 0, 0, W, H);
      S.sfocStop = { t0: S.t0, cv: b };
    }
    if (S.fase === "scegli") ui.sfondoSfocato = S.sfocStop.cv;
    S.p27 = bolliniStrada(g);
    if (S.fase === "scendi") {
      const af = ease((g - LAND + 0.3) / 0.4);
      rotella((g - LAND) / (STOP - LAND), af);
    }
  }
  if (S.fase === "stanza") {
    c.drawImage(video, 0, 0, W, H);
    ui.sfondo = null;
    ui.sfondoSfocato = vetroVideo();
    const F = FERMATE[S.stanza];
    U.chip(c, ui, { n: HN, comunita: V.community, camere: V.bedrooms, area: V.builtUp, prezzo: V.price }, 1);
    nomeStanza(F, ease((t - 0.1) / 0.5));
    bottoneView(F, ease((t - 0.35) / 0.5), t);
  }
  if (S.fase === "volo" || S.fase === "domanda" || S.fase === "fine") {
    const g = S.fase === "domanda" ? DOM : S.fase === "fine" ? 48 : S.giroT, da = S.fase === "domanda" ? 36 : S.fase === "fine" ? DOM : S.volo.da;
    let bl = 0, ve = 0, aq = 0, ac2 = 0;
    if (da === 36) {
      const v = ease((g - 39.4) / (DOM - 39.4));
      bl = 6 * v;
      ve = 0.3 * v;
      aq = S.fase === "domanda" ? 1 : ease((g - 40.4) / 1.1);
    }
    if (da === DOM) {
      const f = S.fase === "fine" ? 1 : ease((g - DOM) / 0.8);
      bl = 6 + 12 * f;
      ve = 0.3 + 0.42 * f;
      aq = 1 - ease((g - DOM) / 0.25);
      ac2 = S.fase === "fine" ? 1 : ease((g - DOM - 0.1) / 0.45);
    }
    c.drawImage(video, 0, 0, W, H);
    if (bl > 0.05) {
      c.save();
      c.globalAlpha = cl(bl / 6);
      c.drawImage(videoSfocato(Math.max(bl, 6)), -30, -30, W + 60, H + 60);
      c.restore();
    }
    if (ve > 0) {
      c.save();
      c.fillStyle = `rgba(4,5,7,${ve})`;
      c.fillRect(0, 0, W, H);
      c.restore();
    }
    ui.sfondo = null;
    ui.sfondoSfocato = vetroVideo();
    const ac = cl((g - 19.4) / 0.5) * cl((35.6 - g) / 0.5);
    if (ac > 0) U.chip(c, ui, { n: HN, comunita: V.community, camere: V.bedrooms, area: V.builtUp, prezzo: V.price }, ac);
    if (da === 36 && S.fase === "volo") {
      const ab = 1 - ease((g - 36) / 0.35);
      if (ab > 0) {
        U.burj(c, ui, D.burj_36[0], D.burj_36[1], ab);
        nomeFuori(ab);
      }
    }
    if (aq > 0) U.domanda(c, S.fase === "domanda" ? ui : { ...ui, btns: [] }, aq, { centro: true });
    if (ac2 > 0) cardFinale(ac2, S.now - S.t0);
  }
  if (S.fase === "burj") {
    sfondoFoto("36");
    const a = ease(t / 0.5);
    const [bx, by] = D.burj_36;
    if (a > 0) U.burj(c, ui, bx, by, a);
    nomeFuori(ease((t - 0.25) / 0.6));
  }
  if (AUTO && !["volo", "burj", "fine"].includes(S.fase)) cursore(S.mouse[0], S.mouse[1], S.giuMouse);
}
// what is under the mouse (buttons, then round tags)
function colpito(x, y) {
  for (const b of ui.btns) if (x >= b.r[0] && x <= b.r[2] && y >= b.r[1] && y <= b.r[3]) return b.id;
  for (const k of S.colpi) if (Math.hypot(x - k.cx, y - k.cy) <= k.r) return k.id;
  return null;
}
function giu(x, y) {
  S.mouse = [x, y];
  S.giuMouse = true;
}
// a click: what it does in each step
function su(x, y) {
  S.mouse = [x, y];
  S.giuMouse = false;
  if (S.fase === "pin") {
    const id0 = colpito(x, y);
    if (id0 === "vola") {
      if (S.sel && S.sel.attiva) scendiVia();
      return;
    }
    const st = stradaSotto(x, y);
    if (!st) return;
    if (st === S.sel && S.pin.stato === "giu") {
      if (st.attiva) scendiVia();
      return;
    }
    S.sel = st;
    S.pin = { stato: "cade", da: [x, y], a: vicino(st, x, y)[1], t: S.now };
    return;
  }
  const id = colpito(x, y);
  if (!id) return;
  if (S.fase === "scendi" && id === "avanti") S.scendi.target = Math.min(STOP, Math.max(S.scendi.target, S.giroT) + PASSO);
  else if (S.fase === "scendi" && id === "indietro") S.scendi.target = Math.max(LAND, Math.min(S.scendi.target, S.giroT) - PASSO);
  else if (S.fase === "scendi" && id === "villa:" + HN) {
    video.pause();
    video.playbackRate = 1;
    vola(S.giroT, 16, "villa");
  } else if (S.fase === "villa" && id === "entra") vola(16, FERMATE[0].t, "stanza", { stanza: 0 });
  else if (S.fase === "stanza" && id === "next") {
    const i = S.stanza;
    if (i < FERMATE.length - 1) vola(FERMATE[i].t, FERMATE[i + 1].t, "stanza", { stanza: i + 1 });
    else vola(FERMATE[i].t, 36, "burj");
  } else if (S.fase === "domanda" && id === "si") vola(DOM, 48, "fine");
  else if (S.fase === "domanda" && id === "liv:0") ricomincia();
  else if ((S.fase === "fine" || S.fase === "volo" && S.volo.da === DOM) && id === "visita") {
    if (CONFIG.bookingUrl && !AUTO) window.open(CONFIG.bookingUrl, "_blank", "noopener");
  } else if ((S.fase === "fine" || S.fase === "volo" && S.volo.da === DOM) && id === "liv:0") ricomincia();
}
function muovi(x, y) {
  S.mouse = [x, y];
  S.hov = colpito(x, y);
  S.hovStrada = S.fase === "pin" && !S.hov ? stradaSotto(x, y) : null;
}
// time-based moves: flights through the film, the pause at the Burj, the street scroll
async function avanza() {
  if (S.fase === "volo") {
    const v = S.volo, dur = v.a - v.da, t = S.now - S.t0;
    S.giroT = v.da + Math.min(t, dur);
    if (REC) await seek(S.giroT);
    else if (!v.partito) {
      await seek(v.da);
      video.play();
      v.partito = true;
    } else S.giroT = T0 + video.currentTime;
    if (REC && t >= dur || !REC && S.giroT >= v.a - 0.5 / FPS) {
      video.pause();
      vai(v.dopo, v.extra || {});
    }
  }
  if (S.fase === "burj" && S.now - S.t0 > 2.6) vola(36, DOM, "domanda");
  if (S.fase === "scendi") {
    const sc = S.scendi;
    if (!sc.partito) {
      await seek(7);
      sc.partito = true;
      S.giroT = 7;
      sc.ult = S.now;
    }
    if (REC) {
      if (S.giroT < LAND - 0.05) sc.target = Math.max(sc.target, LAND);
      const dt = S.now - (sc.ult ?? S.now);
      sc.ult = S.now;
      const v = (S.giroT < LAND - 0.05 ? 1 : 1.3) * dt;
      S.giroT = S.giroT < sc.target ? Math.min(sc.target, S.giroT + v) : Math.max(sc.target, S.giroT - v);
      await seek(S.giroT);
      return;
    }
    const cur = T0 + video.currentTime;
    S.giroT = cur;
    if (cur < LAND - 0.05) sc.target = Math.max(sc.target, LAND);
    if (cur < LAND - 0.05) {
      video.playbackRate = 1;
      if (video.paused) video.play();
    } else if (sc.target - cur > 0.02) {
      video.playbackRate = cl((sc.target - cur) * 1.6, 0.35, 2.5);
      if (video.paused) video.play();
    } else if (cur - sc.target > 0.04) {
      video.pause();
      await seek(Math.max(sc.target, cur - 0.1));
      S.giroT = T0 + video.currentTime;
    } else if (!video.paused) video.pause();
    if (cur >= STOP - 0.5 / FPS && !video.paused) {
      video.pause();
      video.playbackRate = 1;
      await seek(STOP);
    }
  }
}
// the automatic tour: where the drawn cursor goes and clicks, step by step (seconds from the start of each step)
const GIRO = {
  pin: [
    [0, 1500, 900],
    [1.3, ...vicino(STR(1086158627), 640, 566)[1]],
    [1.9, ...vicino(STR(1086158627), 700, 566)[1]],
    [2.9, ...vicino(STR(1081334064), 330, 760)[1]],
    [3.4, ...vicino(STR(1081334064), 300, 775)[1]],
    [4.3, ...vicino(PRINC, 1080, 640)[1]],
    [4.6, ...vicino(PRINC, 1080, 640)[1], "click"],
    [5.8, 1556, 851],
    [6.4, 1560, 853, "click"]
  ],
  scendi: [[0, 1560, 853], [0.8, 1300, 900]],
  villa: [[0, 1100, 560], [1.2, 1555, 826], [1.7, 1560, 830, "click"]],
  domanda: [[0, 1100, 820], [0.9, 790, 612], [1.3, 793, 615, "click"]]
  // the Yes button of the centred question card
};
const fatti = /* @__PURE__ */ new Set();
function giroAuto() {
  if (S.fase === "scendi") {
    const g = S.giroT, [fx, fy] = [1150, 760];
    if (g < LAND - 0.05) {
      muovi(S.mouse[0] + (fx - S.mouse[0]) * 0.06, S.mouse[1] + (fy - S.mouse[1]) * 0.06);
      return;
    }
    if (S.p27 && g >= 12.2) {
      if (S.vedo27 == null) S.vedo27 = S.now;
      const p2 = S.p27, q3 = easeIO((S.now - S.vedo27) / 0.45);
      muovi(S.mouse[0] + (p2[0] - S.mouse[0]) * q3, S.mouse[1] + (p2[1] - S.mouse[1]) * q3);
      if (S.now - S.vedo27 > 0.55 && !fatti.has("v27:" + S.t0)) {
        fatti.add("v27:" + S.t0);
        giu(p2[0], p2[1]);
        su(p2[0], p2[1]);
      }
      return;
    }
    const k2 = "sc:" + S.t0 + ":" + Math.floor((S.now - S.t0) / 0.35);
    if (g < STOP - 0.05 && !fatti.has(k2)) {
      fatti.add(k2);
      S.scendi.target = Math.min(STOP, S.scendi.target + 0.45);
    }
    if (g < STOP - 0.05) {
      muovi(S.mouse[0] + (fx - S.mouse[0]) * 0.1, S.mouse[1] + (fy - S.mouse[1]) * 0.1);
      return;
    }
    if (S.arrivoStop == null) S.arrivoStop = S.now;
    const p = S.p27;
    if (!p) return;
    const q2 = easeIO((S.now - S.arrivoStop - 0.3) / 0.8);
    muovi(fx + (p[0] - fx) * q2, fy + (p[1] - fy) * q2);
    if (S.now - S.arrivoStop > 1.6 && !fatti.has("v27:" + S.t0)) {
      fatti.add("v27:" + S.t0);
      giu(p[0], p[1]);
      su(p[0], p[1]);
    }
    return;
  }
  if (S.fase === "stanza") {
    const t2 = S.now - S.t0, [px, py] = S.pillCentro || [W / 2, H / 2], da = S.mouse0 || S.mouse;
    if (t2 < 0.05) S.mouse0 = [...S.mouse];
    const q2 = easeIO((t2 - 0.7) / 0.8);
    muovi(da[0] + (px - da[0]) * q2, da[1] + (py - da[1]) * q2);
    const key = S.fase + ":" + S.t0;
    if (t2 >= 1.75 && !fatti.has(key)) {
      fatti.add(key);
      giu(px, py);
      su(px, py);
    }
    return;
  }
  const k = GIRO[S.fase];
  if (!k) return;
  const t = S.now - S.t0;
  let i = 0;
  while (i < k.length - 1 && k[i + 1][0] <= t) i++;
  const a = k[i], b = k[Math.min(i + 1, k.length - 1)], q = b[0] > a[0] ? easeIO((t - a[0]) / (b[0] - a[0])) : 1;
  const x = a[1] + (b[1] - a[1]) * q, y = a[2] + (b[2] - a[2]) * q;
  muovi(x, y);
  for (const [ti, xi, yi, az] of k) {
    const key = S.fase + ":" + S.t0 + ":" + ti;
    if (az && t >= ti && !fatti.has(key)) {
      fatti.add(key);
      if (az === "giu") giu(xi, yi);
      if (az === "su") su(xi, yi);
      if (az === "click") {
        giu(xi, yi);
        su(xi, yi);
      }
    }
  }
}
// the real mouse and keyboard
const aCanvas = (e) => {
  const r = cv.getBoundingClientRect();
  return [(e.clientX - r.left) * W / r.width, (e.clientY - r.top) * H / r.height];
};
if (!AUTO) {
  cv.addEventListener("pointerdown", (e) => {
    const [x, y] = aCanvas(e);
    giu(x, y);
  });
  addEventListener("keydown", (e) => {
    if (e.key === "r" || e.key === "R") {
      video.pause();
      video.playbackRate = 1;
      ricomincia();
    }
  });
  cv.addEventListener("wheel", (e) => {
    e.preventDefault();
    const d = Math.max(-160, Math.min(160, e.deltaY)) * 6e-3;
    if (S.fase === "scendi" && T0 + video.currentTime >= LAND - 0.05) S.scendi.target = cl(S.scendi.target + d, LAND, STOP);
  }, { passive: false });
  cv.addEventListener("pointerup", (e) => {
    const [x, y] = aCanvas(e);
    su(x, y);
  });
  cv.addEventListener("pointermove", (e) => {
    const [x, y] = aCanvas(e);
    muovi(x, y);
    document.body.classList.toggle("punta", !!S.hov || !!S.hovStrada);
  });
}
// the clock: real time, or one frame at a time when recording (?auto&rec)
async function passo(dt) {
  S.now += dt;
  if (AUTO) giroAuto();
  await avanza();
  disegna();
}
// __motore.scena(name): jump straight to a still moment (for screenshots)
async function scena(nome) {
  S.now = 100;
  S.hov = null;
  if (nome === "strade") {
    vai("pin");
    S.t0 = S.now - 4;
    const q = vicino(STR(1086158627), 650, 566)[1];
    muovi(q[0], q[1] + 6);
    S.cardSt = S.hovStrada;
    S.cardPrev = null;
    S.cardT = S.now - 2;
  }
  if (nome === "strada") {
    const a = vicino(PRINC, 1080, 640)[1];
    S.sel = PRINC;
    S.cardSt = PRINC;
    S.cardPrev = null;
    S.cardT = S.now - 3;
    S.pin = { stato: "giu", da: [1080, 640], a, t: S.now - 3.2 };
    vai("pin");
    S.t0 = S.now - 6.4;
    S.mouse = [1700, 1010];
  }
  if (nome === "villa") {
    vai("villa");
    S.t0 = S.now - 3;
  }
  if (nome.startsWith("stanza")) {
    const k = +(nome.slice(6) || 0);
    await seek(FERMATE[k].t);
    vai("stanza", { stanza: k });
    S.t0 = S.now - 3;
  }
  if (nome === "burj") {
    vai("burj");
    S.t0 = S.now - 1.6;
  }
  if (nome === "scendi") {
    await seek(8);
    vai("scendi", { scendi: { target: 8, partito: true } });
    S.t0 = S.now - 1;
    S.giroT = 8;
  }
  if (nome.startsWith("via")) {
    const gv = +(nome.slice(3) || 10.6);
    await seek(gv);
    vai("scendi", { scendi: { target: gv, partito: true, ult: 100 } });
    S.t0 = S.now - 3;
    S.giroT = gv;
    S.hov = nome === "via" ? "villa:23" : null;
  }
  if (nome === "scegli") {
    const gs = 12.4;
    await seek(gs);
    vai("scendi", { scendi: { target: gs, partito: true, ult: 100 } });
    S.t0 = S.now - 6;
    S.giroT = gs;
    disegna();
    muovi(...S.p27 || [1e3, 300]);
  }
  if (nome === "gira") {
    await seek(39.6);
    S.volo = { da: 36, a: DOM, dopo: "domanda", partito: true };
    vai("volo");
    S.t0 = S.now - 3.6;
    S.giroT = 39.6;
  }
  if (nome === "domanda") {
    await seek(DOM);
    vai("domanda");
    S.t0 = S.now - 3;
  }
  if (nome === "si") {
    await seek(43.2);
    S.volo = { da: DOM, a: 48, dopo: "fine", partito: true };
    vai("volo");
    S.t0 = S.now - 1.7;
    S.giroT = 43.2;
  }
  if (nome === "fine") {
    await seek(48);
    vai("fine");
    S.t0 = S.now - 2;
  }
  disegna();
  return nome;
}
window.__motore = { scena, step: async (n = 1, fps = FPS) => {
  for (let i = 0; i < n; i++) await passo(1 / fps);
  return S.fase;
}, stato: S };
disegna();
document.body.dataset.pronto = "1";
if (AUTO && !VH) addEventListener("keydown", (e) => {
  if (e.key === "r" || e.key === "R") {
    video.pause();
    video.playbackRate = 1;
    ricomincia();
  }
});
if (!REC) {
  let ult = performance.now();
  const ciclo = async () => {
    const t = performance.now();
    await passo(Math.min(0.1, (t - ult) / 1e3));
    ult = t;
    requestAnimationFrame(ciclo);
  };
  requestAnimationFrame(ciclo);
}
