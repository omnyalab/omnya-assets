# How the Rome film works

## The 3D (blender/)

`costruisci.py` builds the whole scene in one run and saves a .blend:

| File | What it builds |
|---|---|
| `geo.py` | the Colosseum's ellipse (188 x 156 m), the 80 bays of 6.81 m, a mesh builder in bay coordinates (x along the facade, off = distance from the outer face, z = height) |
| `costruisci.py` | the four storeys (Tuscan, Ionic, Corinthian arcades, the attic with windows, bronze shields and the 240 velarium poles), the numbered gates, the stairs, the cavea at 37°, the arena 86 x 54 m with its 3.6 m podium |
| `materiali.py` | procedural materials only (no texture files), so it renders the same on a Mac and on a cloud GPU |
| `roma.py` | the hills, the Tiber, the Forum, the Capitol, the Palatine, the Circus Maximus, the aqueduct and the city: a street grid of houses instanced with Geometry Nodes (37,861 buildings in the full scene, 4,889 with `leggero`) |
| `viale.py` | the triumphal avenue before the Colosseum: 3-5 storey Roman buildings on both sides, porticoes with shops, wooden balconies full of people, coloured cloths |
| `mercato.py` | the market: stalls with awnings, carts, merchants, people walking (moving with the scene time) |
| `corteo.py` | the procession: columns with golden eagles, chariots in the dust, petals falling, and the gladiators in the arena (each pair turned to face each other) |
| `folla.py` | the crowd: simple figures with no faces on every seat (about 45,000) |
| `ambiente.py` | sky, sun, dust, the cameras for the photos |
| `regia.py` | the film camera `CAM_F` |
| `foto_extra.py` | only with `foto`: the extra detail a real photo shows (the terrace of the Temple of Claudius with Nero's nymphaeum, the Baths of Titus, the real hills on the horizon) |

Run it: `blender -b --factory-startup --python blender/costruisci.py -- rome.blend [leggero] [foto]`. On a MacBook the light scene takes about a minute.
It prints two lines you need:

- `REGIA {...}`: the camera's key frames. On our scene: `f_arco` 338 (inside gate LII), `f_cima` 460 (the top of the stairs), `f_scesa` 575, 810 frames of camera move, 834 with the hold at the end (24 fps).
- `CONTEGGIO {...}`: how many buildings, monuments, metres of street, market stalls and people. Use these numbers, not guesses, when you write about the scene.

## The camera (regia.py)

One continuous camera, each stretch one straight movement: Rome from the sky -> a straight dive toward the Colosseum -> a tilt while still -> down into the procession on the avenue and in through arch LII -> the stairs -> the mouth of the passage -> the arena. The path is a smooth spline with eased speed; the turns happen only while the camera is (almost) still. If you change it, score the preview with `tools/smooth.py` (9 or more).

## Render scripts

- `anteprima.py -- <dir> <width> <samples> [from-to] [step]`: fast EEVEE preview of `CAM_F` for `smooth.py`.
- `fotogrammi.py -- <dir> CAM_F:338,CAM_F:460`: quick 640 px stills of single frames.
- `rendi_frames.py -- <dir> <CAM:frame,...|CAM:a-b> <samples> <width> [blur]`: the key frames for the photos (Cycles).
- `rendi.py -- <dir> <cameras|giro> <EEVEE|CYCLES> <samples> <width> [frames]`: the 3D guide videos (frames, then ffmpeg at 24 fps).
- `vista_alto.py -- <dir> <scale_m> <frames>`: an orthographic map from above to find empty spots.
- `verifica.py -- out.json`: the automatic checks (nothing floating, chariots never closer than 1.2 m to a person or a column, the camera never closer than 0.6 m to a wall).

## From 3D to film

1. Key frames: the start and end of every clip. Our clips: C1 sky -> dive, C2 dive -> avenue at eye level, C3 avenue -> gate LII, C4 through the gate, C5 the passage and the stairs to the top, E6 the descent to the two gladiators, X1 the fast zoom, X2 the fight.
2. A photo for each (Seedream 5.5, 2K, the 3D frame as reference, `prompts.md`).
3. Outside clips: Kling 4.0 video edit, 3D guide video + start + end. Inside: image to video without the guide (start, middle, end for E6; start only for X2).
4. Joins: the clip after starts on the real last frame of the clip before. Our final film: 765 frames, 31.875 s.
5. Grade (`filtro_film_caldo_video.py`), joins at constant speed (`fix_join.py`), sound (`mix.py`), reels (`reel_916.py`).
