# Choose Your Floor kit · instructions for Claude Code

You are helping a member of THE 3D FUTURE (Omnya Lab's club) build an interactive "choose your floor" tower page, the way Omnya Lab builds them for real developers: a photoreal tower where buyers move over the floors, pick one and fly inside the apartment. Read this whole file before doing anything. The finished example is SAMAR (`?s=samar`): when in doubt, look at how it is done there. The member follows the SAMAR course and pastes the messages of `prompts/` one by one: do exactly what the message asks, explain in plain words what you are about to do, show the result, then stop and wait.

If the member asks "what does this kit do?": answer in a few short lines (the folder, the method below, what costs credits), no code.

## The folder
- `Start.command` (Mac) / `Start.bat` (Windows): double click → starts the local server (`tools/serve.py`) and opens Chrome on SAMAR. Same thing by hand: `python3 tools/serve.py --open`. The page must be served (http://127.0.0.1:5320/…), never opened as a file. If 5320 is busy the server takes the next free port and prints it. If Python 3 is missing (or on Windows it is only the Microsoft Store shortcut), Start says so and stops: then do the section "Setting up a new computer".
- `index.html` opens a subject: `?s=samar`, `?s=my-tower`. Add `&auto=A` to play the tour by itself, `&clean=1` to hide every button and card (the version for the guide videos), `&reale=1` for the photoreal version (photos and clips instead of the grey 3D). Keys: R starts again, Escape goes back, H hides the text.
- `engine/` + `vendor/` (three.js): draws the 3D, moves the camera, lights the floors, shows the cards, plays the real photos and clips. Don't change it unless the member asks; a new tower is a new subject.
- `subjects/` one file per tower. `samar.js` is the finished example (its shape is built by `samar-kit.js`, the apartment of level 15 by `samar-casa.js` + `samar-arredi.js`). `my-tower.js` is the starting point for the member's tower: same kit, placeholder numbers. The keys are in Italian because the engine reads them: `torri` towers, `casa.speciale` special floor, `esauriti` sold floors, `aree` m², `intorno` surroundings, `skyline`, `looks` light, `riprese` camera shots (`mondo` = the main photo), `tempi` seconds of each move, `stanze` rooms, `giri` automatic tours, `reale` photoreal version. SAMAR course states: `&passo=0|1|3` (empty / big pieces / dressed apartment), `&person=1` (1.80 m person), `&plan=1` (plan from above with the tour), `&maschera=1` (silhouette mask for the judge).
- `references/` the real material. `references/samar/`: SAMAR's photos, `MEASURES.txt` (every number with its source or ESTIMATE), `mask-tower.png`, `tour/` (SAMAR's guides, frames and scores, as an example). `references/samar-sunset.jpg` and `references/interiors/living.jpg`, `bath.jpg` are the files the course messages name: they are SAMAR's, so the messages work as they are while the member follows SAMAR.
- **The member's photos never overwrite SAMAR's.** The references of the member's tower go in their own folder `references/<name-of-the-tower>/` (e.g. `references/aurora-tower/`): the photos of the outside (and their main photo), `MEASURES.txt`, and the interior photos in `references/<name-of-the-tower>/interiors/` (`living.jpg`, `bath.jpg`…). Never save them into `references/interiors/`, `references/samar/` or over `references/samar-sunset.jpg`; if the member drops a file there, move it into their folder (ask first) and say why.
- In `prompts/`, what is in [square brackets] is SAMAR's example the member replaces with theirs. When they work on their own tower, read every `[references/...]` path as the same file in their folder: `[references/samar]` → `references/<name>/`, `[references/samar-sunset.jpg]` → their main photo, `[references/interiors/living.jpg]` → `references/<name>/interiors/living.jpg`, `references/interiors` (06-1) → `references/<name>/interiors`. If the member pasted the message unchanged while working on their tower, ask which of their files to use; never use SAMAR's photos for their tower.
- `assets/` fonts (Inter, SIL OFL), `data/dubai-skyline.json` (real towers for the skyline), `reale/<name>/` the photos (numbered 1, 2, 3…, 3840x2160) and the clips (`clips/C1.mp4`…) of the photoreal version.
- `tools/` (run from the kit folder):
  - `serve.py` local server · `photo.mjs` stills and step-recorded videos of the engine (headless Chrome) · `guides.mjs` guide videos of a tour + start/end frames
  - `smooth.py` the judge of camera moves (0-10) · `silhouette.py` 3D vs main photo (IoU 0-1) · `filter.py` the kit filter + 4K export on the computer
- `prompts/` every message of the course, numbered by step (`06-1-apartment.txt` = step 6, message 1).
- `TOUR.md` the tour written as a story (SAMAR's, the member rewrites it for their tower).

Working files you create for the member's tower, at the top of the kit (create the folders when needed): `guides/G1.mp4…`, `frames/G1-start.png`, `G1-end.png…`, `photos/nano/1.png…` (what Nano gives, untouched), `photos/1.jpg…` (approved, filtered, 4K: the photo the page and Kling use), `clips/C1.mp4…` (what Kling gives), `clips/C1-back.mp4` (reversed). Never overwrite: a new version goes next to the old one (`1-v2.jpg`).

What the tools need: Python 3 with `opencv-python numpy pillow`, Node 22+, ffmpeg, Google Chrome. How to check and install them: the next section.

## Setting up a new computer (message 02-0)
When the member sends `prompts/02-0-install.txt` (or Start says "Python 3 is missing"), check the four things below in this order, say in one short list what is there and what is missing, install only what is missing, check again, and end with "Now double click Start". Plain words, no jargon. **Never type a password for the member and never ask them to write it in the chat**: anything that asks for a password (Homebrew on Mac, `sudo`) is a line you give them to paste in their own Terminal window; they type the password there (nothing shows while they type, that is normal) and tell you when it is done.

First find out the system (`uname -s` → Darwin = Mac; on Windows `ver` or `$env:OS`).

**On Windows, `python3` is not the right command**: a real Python from python.org/winget gives `py` and `python`, while `python3` is usually the Microsoft Store shortcut. In every command of this file use `py -3` (or `python`) instead of `python3` on Windows, e.g. `py -3 tools/serve.py --open`.

### 1. Python 3
- Mac: `command -v python3`. If it says `/usr/bin/python3`, that file is only a stub until Apple's command line tools are installed: check `xcode-select -p` first. If that fails, don't run `python3` (it opens Apple's "install the command line developer tools" window): Python is missing. Otherwise `python3 --version` must print `Python 3.x`.
- Windows: `py -3 --version`, then `python --version`. If `where python` shows only `...\AppData\Local\Microsoft\WindowsApps\python.exe` and `python --version` prints nothing, "Python was not found" or opens the Store, that is only the Microsoft Store shortcut: Python is missing. Never open the Store; install with winget (below).
### 2. Node 22 or newer
`node --version` must print v22 or higher (the tools use Node's built-in WebSocket). Older or missing → install.
### 3. ffmpeg
`ffmpeg -version` prints a version on the first line. Missing → install.
### 4. Google Chrome
The tools drive Chrome itself (not Safari, not Edge). Mac: `/Applications/Google Chrome.app` (or `~/Applications/Google Chrome.app`). Windows: `chrome.exe` in `%ProgramFiles%\Google\Chrome\Application\`, `%ProgramFiles(x86)%\Google\Chrome\Application\` or `%LocalAppData%\Google\Chrome\Application\`. Missing → install.

### Installing on Mac (Homebrew)
1. `command -v brew` (also try `/opt/homebrew/bin/brew` and `/usr/local/bin/brew`). If Homebrew is missing, it needs the member's password, so don't run it: give them this official line from brew.sh to paste in the Terminal app (Applications → Utilities → Terminal), press Enter, type their Mac password when asked, press Enter again to confirm, and wait until it says "Installation successful" (several minutes; it also installs Apple's command line tools):
   `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`
   At the end Homebrew prints "Next steps" with 2-3 lines that put `brew` on the PATH (on Apple Silicon: `echo >> ~/.zprofile`, `echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile`, `eval "$(/opt/homebrew/bin/brew shellenv)"`). They need no password: you can run them yourself once the member says Homebrew is done, then check `brew --version`.
2. `brew install python node ffmpeg` (only the missing ones; no password needed). `python` is Homebrew's name for the latest Python 3.
3. Chrome if missing: `brew install --cask google-chrome` (or the member downloads it from google.com/chrome).
4. Check again with a new command (`python3 --version`, `node --version`, `ffmpeg -version`).

### Installing on Windows (winget)
1. `winget --version` (it comes with Windows 10/11 as "App Installer"; if it is missing, the member updates "App Installer" from the Microsoft Store, the only time the Store is involved).
2. Only the missing ones, one at a time:
   - `winget install -e --id Python.Python.3.12`
   - `winget install -e --id OpenJS.NodeJS.LTS`
   - `winget install -e --id Gyan.FFmpeg`
   - `winget install -e --id Google.Chrome`
   If Windows shows a "Do you want to allow this app to make changes" window, the member clicks Yes. If winget stops to ask them to accept the source or package agreements, give them the same line to paste in their own terminal so they read it and answer themselves; don't accept for them.
3. **New programs are seen only by new windows**: tell the member to close Claude Code and the terminal, open a new terminal in the kit folder, start `claude` again and send 02-0 once more, so you can check everything with fresh eyes.

### The Python libraries of the tools
Only what `tools/` imports: `smooth.py` needs `opencv-python` and `numpy`, `filter.py` and `silhouette.py` need `pillow` and `numpy` (`serve.py` needs nothing extra). Install all three with the same Python the tools use:
- Mac: `python3 -m pip install opencv-python numpy pillow`. If it stops with "externally-managed-environment" (Homebrew's Python), use `python3 -m pip install --user --break-system-packages opencv-python numpy pillow` (installs them only for this user, Homebrew's files stay untouched).
- Windows: `py -3 -m pip install opencv-python numpy pillow`.
- Check: `python3 -c "import cv2, numpy, PIL; print('ok')"` (Windows: `py -3 -c ...`).

When all four things and the libraries are there: "Everything is ready. Double click Start (Start.command on Mac, Start.bat on Windows)". The member then goes on with Higgsfield (next section).

## Higgsfield: photos and clips are made by you, through the MCP, only after the member's OK
- Connect it when the member asks ("Connect Higgsfield MCP, https://mcp.higgsfield.ai/mcp"): run `claude mcp add --transport http higgsfield https://mcp.higgsfield.ai/mcp`. Claude Code reads the new connection only when it starts, so then tell the member: close Claude Code (type `/exit` or close the window), open it again in the kit folder (`claude`), type `/mcp`, choose higgsfield and log in to their Higgsfield account in the browser (they do the login, never you). Check it works by reading their credit balance.
- **Before every single generation**: show the full prompt, the model and settings, every input image by file name, and the cost in credits (from Higgsfield's cost estimate, not from memory), then **wait for an explicit OK** ("OK", "go", "yes"). No OK, no generation. One image or one clip per OK, never a batch, never "while I'm at it". If the member already said OK for "3 more with the same prompt" (message 08-2), that OK covers exactly those 3.
- Never pay for an upscale: 4K is made at home with `tools/filter.py`. Never generate again what can be made for free (a reversed clip, a crop, a fix of one piece).
- Download every result into the kit at once (photos to `photos/nano/`, clips to `clips/`) and tell the member the file name.

### Photos: Nano Banana Pro, 16:9, 2K
- Image 1 = the clean 3D frame for the angle (`frames/Gn-start.png` or `Gn-end.png`), image 2 = the real reference (light, materials, mood), image 3 when needed = the interior reference. For the next photos: image 2 = the approved photo before, so furniture, materials, light and the view outside stay the same (one photo at a time, a chain: 1 tower, 2 living room, 3 bathroom…). The first interior photo is a zoom through the glass of the cover.
- The prompt describes only what is visible in that view, and ends with "Nothing else." Outside, the glass reflects the sky and the sea (you don't see the rooms), the tower is never alone in the void, nothing stands in front of it. SAMAR's cover prompt: `prompts/08-1-nano-prompt.txt`. About 2 credits per photo in the course: always check.
- Check up close before showing it as good: windows, balconies, number of floors, horizon, boats, people, any real brand or logo (none allowed). Say what is wrong and why.
- Approved → `python3 tools/filter.py photos/nano/N.png --out photos` → `photos/N.jpg` (3840x2160, the kit filter: same contrast and warmth on every photo). Show before/after.
- One small mistake in a good photo (a crooked lamp): crop just that area with some margin, fix only that piece with Nano (same OK rule), blend it back with a soft edge. Never remake the whole photo for one detail.

### Clips: Kling, start + end + guide, short prompt
- Clip N goes from `photos/N.jpg` (start) to `photos/N+1.jpg` (end), with `guides/GN.mp4` underneath as the camera move (motion reference), same duration as the guide (3-4 s, 16:9).
- Model: **Kling 4.0** (on Higgsfield), the one that takes a video reference: the guide goes in `video_references`, photo N as `start_image`, photo N+1 as `end_image`, and both also in `image_references` so the prompt can call them @image1 and @image2. Other Kling versions take start and end but ignore the guide. If the clips copy the grey look of the guide, add to the prompt: "the input video is only a 3D previsualization for the camera, never copy its look".
- Short prompt, nothing else: "follow the camera of the input video, same timing, start on @image1, end on @image2" + at most two words of action, the move of that clip ("zoom in", "fly in", "turn", "walk": in SAMAR G1 zoom, G2 fly in, G3 turn, G4 walk). Every extra word is something Kling will add (a described glass opening became a sliding door that doesn't exist).
- Cost in the course: about 13.5 credits for 3 s, 18 for 4 s. Always the real estimate, then wait for the OK.
- When it arrives: compare its last frame with the end photo (side by side) and run `python3 tools/smooth.py clips/CN.mp4`: ≥ 8 and the last frame on the end photo, then (after a new OK) the next clip. Wobbly or < 8: don't press generate again; fix the 3D move, record the guide again, judge it ≥ 9, then a new clip.
- The way back out of a room = the clip in played backwards, never generated: `ffmpeg -i clips/C3.mp4 -vf reverse -an -c:v libx264 -crf 14 -pix_fmt yuv420p clips/C3-back.mp4`.
- Joins: put the clips in a row, drop the doubled frame at every join (the engine already skips it), tell the member where the light jumps; small jumps go in the pause where the buyer chooses.

SAMAR's real page (`assets/reale/samar`) uses the real SAMAR photos and Kling clips (4 photos, 4 clips, C4 = the way back out as its own clip). It was made before the course tour was split into 5 stops: when the member compares, explain that the method is the same, the file count is not.

## How to work with the member (the method, in this order)
1. **References first, never imagination.** The official renders/photos from every side (facade, base, entrance, from the sea, interiors) in `references/<name>/`. One main photo: everything is measured against it. Real measures (height, floors, width) each with its source in `MEASURES.txt`; anything not published is `ESTIMATE` with how it was derived (floors counted on the photo × 3.5-4 m, checked against a car or a palm). See `references/samar/MEASURES.txt`.
2. **Build the subject**: copy `my-tower.js` (rename it to the tower's name if the member wants) and change the numbers: shape, floors, colours, podium, setting, light, the camera of the main photo. Open it and show it. The first version is always wrong somewhere: say so.
3. **Compare with the photo, not by eye.** Render the 3D from the camera of the main photo: `node tools/photo.mjs mask-3d.png "http://127.0.0.1:5320/?s=<name>&maschera=1&clean=1"` and `… color-3d.png "…&clean=1"`; trace the tower on the main photo into a white-on-black mask (1920x1080); run `python3 tools/silhouette.py mask-3d.png --photo-mask <mask> --photo <main photo> --color color-3d.png --board board.png`. Aim ≥ 0.90, fix one thing at a time (width, roof, podium, floors), show the board and the number after each fix, then stop. Then a second opinion: the member opens a new chat with zero context, gives it only the real photos and the 3D renders, and asks for a 1-10 score of outline, roof, entrance, light: move on at ≥ 8. Last, the place around it (sea, marina, palms, skyline where they are in the photo) and the evening light with the windows on.
4. **Interiors at real size** (step 6): about 3 m floor to ceiling, sofa seat 45 cm, island 90 cm, doors 2.10 m, big luxury furniture copied from the interior photos, chairs facing the table with the back to the outside, lived in (flowers, art books, candles, a brass bowl, a tall vase with branches). Then check everything for objects through walls, floating, two surfaces on top of each other, chairs turned the wrong way (in SAMAR: `window.__casa.controlla()` in the page), list what you found and fix it. A 1.80 m person for the scale; a plan from above with the rooms in colour and the tour drawn on it.
5. **The tour camera** (step 7): `TOUR.md` = the tour as a story, every line a stop (= a photo), every jump a move (= a clip). One straight move per segment, 3-4 s, turns only while standing still, never left-right swings while moving. Record the guides from the clean page: `node tools/guides.mjs guides frames "http://127.0.0.1:5320/?s=<name>&clean=1&rec=1" A` (24 fps, 1920x1080, saves `guides/G1.mp4…` and `frames/G1-start.png`, `G1-end.png…`). Judge them: `python3 tools/smooth.py guides/G*.mp4`, a table with the scores; every guide ≥ 9 before a single credit is spent. Under 9: simplify the move (split the turn from the walk, straighter, slower) and record again.
6. **Photos** (step 8) and 7. **Clips** (step 9): see the Higgsfield section above.
8. **The real page** (step 10): copy the photos (`photos/N.jpg`) and the clips into `assets/reale/<name>/` and wire them in the subject with a `reale` block exactly like `samar.js`: `foto` = the photo of every stop (by level id), `clip` = the clips of every move (`'from>to': ['clips/C1', …]`), the lit floor on the cover comes from the 3D (the 3D camera must match the cover photo; if the first frame of clip 1 is framed differently, use that frame as the photo and adjust the camera like SAMAR's `CAMR`). Clips play untouched (no recompression). Every floor gets a name and a type (residence, duplex, penthouse); the special floor a name with a story; prices "on request" unless the client gives real ones. Test `?s=<name>&reale=1` and `&auto=A` on a wide screen, a laptop and a phone (`node tools/photo.mjs` can't emulate a phone: open it on the phone too), and keep anything in the corners (logo) whole.
9. **Online**: make a `site/` folder with only `index.html`, `engine/`, `vendor/`, `subjects/`, `assets/` (no references, tools, prompts, photos, clips, guides, frames, this file); the member drags `site/` onto app.netlify.com/drop, then "Claim this site" with a free account. Updates: drag the new `site/` into Deploys, the link stays the same.
10. **The reel** (step 11): the member records the tour in one take (full screen, or the phone filming the monitor); the hook is separate text on top, two lines (a transparent 1080x1920 PNG, white text, soft shadow); caption with one sentence on how it was built, a word to comment, an honest question. First message to a developer: a tower like theirs working on the phone (link), one line on what it does for their sales, a 20-minute call, no price.

## Rules
- Never invent data: every measure has a source or says ESTIMATE; never fake prices, sales, names of real developers, or logos the member doesn't own. If you don't know, say so and ask.
- Explain each step in plain words before doing it, show the result, and ask before anything that costs money: Higgsfield photos and clips are made by you only after the member has seen prompt, inputs and cost and said OK.
- Keep the member's files: never delete references, photos or clips; save new versions next to the old ones.
- One thing at a time: one fix, one photo, one clip, then check it and show it.
