# The Dubai Villa Builder skill · Omnya Lab

Ask Claude "build me the Dubai villa page" and it rebuilds the interactive page from our reel on your computer, working, and then
makes it yours: your developer name, your villa numbers and prices, your words, your "Book a private viewing" link, your colour.
If you have them, it puts in your own photos and your own film, following the same timings.

The page: from above you drop a pin on a street, fly down and scroll along the street like Google Maps with every villa tagged,
pick the villa, the door opens, living room, dining room, kitchen, out to the pool with the Burj Khalifa on the horizon,
"Is this your home?", Yes, and the villa card with "Book a private viewing". Built with Claude Code.

## Install

**Claude Code:** unzip this into `~/.claude/skills` (you get `~/.claude/skills/dubai-villa-builder/SKILL.md`), start Claude Code
in an empty folder and ask "build me the Dubai villa page".

**claude.ai (Pro and up):** keep the zip you downloaded (`dubai-villa-builder-skill.zip`) as it is, do not unzip it. Check that
"Create and edit files" is on in Settings > Capabilities (older screens: "Code execution and file creation"). Then in the menu on
the left click Plugins, then Add (top right) > Upload plugin, choose the zip, click Upload, and ask for your villa page in a new chat.
(Older screens: Settings > Capabilities > Skills > Upload skill, same zip.)

**On a Mac, download the zip with Chrome:** Safari unzips downloads by itself and deletes the zip. If you only have a folder called
`dubai-villa-builder`, that folder is what Claude Code needs; for claude.ai right-click it, choose Compress "dubai-villa-builder" and
upload the new zip.

## Open the page (also without Claude)

The page is the folder `template/` (Claude copies it for you and changes the copy).
- Mac: double click `Start.command` (the first time: right click > Open). `Start auto tour.command` plays the tour by itself.
  `Stop.command` stops the small local server when you are done.
- Windows: double click `Start.bat` (needs Python 3 from python.org). Close the small black window to stop it.
- Anywhere: in the folder run `python3 server.py 5316` and open http://localhost:5316 (add `?auto` for the automatic tour).
It must run from a server, not by double clicking index.html. Best in Chrome or Edge, full screen. R starts again.

## What is inside

- `SKILL.md` what Claude does, step by step.
- `references/` how the tour works, the data, how to change words, prices, brand and colours, how to use your own photos and film,
  how to record the tour as a video.
- `template/` the working page: `index.html`, `app.js`, `config.js` (the one file to change), `dati.json` (streets and villa tags),
  `film.mp4` (the tour film, 1080p, 24 fps), `assets/foto/` (three photos), `assets/fonts/` (Inter), `engine/kit/` (the glass UI),
  `server.py`, the Start and Stop files.

## Good to know

- Villa numbers, which villas are free, prices and how many are left are EXAMPLES, there to show how the page works. By default every
  price reads "On request", as in the reel; set `showPrices: true` in `config.js` to show yours. Bedrooms, built-up area and the
  7.95 km to the Burj Khalifa describe the real villa type in the film.
- The page takes no payments and stores no data: "Book a private viewing" only opens the link you choose.
- Map data © OpenStreetMap contributors. The street shapes and names come from OpenStreetMap, available under the Open Database
  License (openstreetmap.org/copyright). Keep the credit on the page.
- Fonts: Inter by The Inter Project Authors, SIL Open Font License 1.1 (`template/assets/fonts/OFL.txt`).
- The photos and the film are ours: use them for your own page and your demos, do not resell them on their own.

Omnya Lab · omnyalab.com
