# Materiali procedurali (niente texture esterne: girano uguali sul Mac e sulla GPU).
import bpy


def _new(name):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    for n in list(nt.nodes):
        nt.nodes.remove(n)
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    return m, nt, out


def _bsdf(nt, col, rough=0.6, metal=0.0):
    b = nt.nodes.new('ShaderNodeBsdfPrincipled')
    b.inputs['Base Color'].default_value = (*col, 1)
    b.inputs['Roughness'].default_value = rough
    b.inputs['Metallic'].default_value = metal
    return b


def _hex(h):
    h = h.lstrip('#')
    c = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    return tuple((x / 12.92) if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4 for x in c)


def semplice(name, hexcol, rough=0.6, metal=0.0):
    m, nt, out = _new(name)
    b = _bsdf(nt, _hex(hexcol), rough, metal)
    nt.links.new(b.outputs[0], out.inputs[0])
    return m


def pietra(name, c1, c2, mortar, scala_blocchi=(1.25, 0.62), rough=0.72, pori=True, cilindro=True, bump=0.25):
    """travertino: colore a macchie + corsi di blocchi in coordinate cilindriche (seguono la curva) + pori"""
    m, nt, out = _new(name)
    N = nt.nodes; L = nt.links
    geo = N.new('ShaderNodeNewGeometry')
    sep = N.new('ShaderNodeSeparateXYZ'); L.new(geo.outputs['Position'], sep.inputs[0])
    if cilindro:
        at = N.new('ShaderNodeMath'); at.operation = 'ARCTAN2'
        L.new(sep.outputs[1], at.inputs[0]); L.new(sep.outputs[0], at.inputs[1])
        mu = N.new('ShaderNodeMath'); mu.operation = 'MULTIPLY'; mu.inputs[1].default_value = 86.0
        L.new(at.outputs[0], mu.inputs[0])
        comb = N.new('ShaderNodeCombineXYZ'); L.new(mu.outputs[0], comb.inputs[0]); L.new(sep.outputs[2], comb.inputs[1])
        uv = comb.outputs[0]
    elif cilindro == 'muro':
        ad = N.new('ShaderNodeMath'); ad.operation = 'ADD'; L.new(sep.outputs[0], ad.inputs[0]); L.new(sep.outputs[1], ad.inputs[1])
        comb = N.new('ShaderNodeCombineXYZ'); L.new(ad.outputs[0], comb.inputs[0]); L.new(sep.outputs[2], comb.inputs[1])
        uv = comb.outputs[0]
    else:
        comb = N.new('ShaderNodeCombineXYZ'); L.new(sep.outputs[0], comb.inputs[0]); L.new(sep.outputs[1], comb.inputs[1])
        uv = comb.outputs[0]
    br = N.new('ShaderNodeTexBrick')
    br.inputs['Scale'].default_value = 1.0
    br.inputs['Brick Width'].default_value = scala_blocchi[0]
    br.inputs['Row Height'].default_value = scala_blocchi[1]
    br.inputs['Mortar Size'].default_value = 0.012
    br.inputs['Mortar Smooth'].default_value = 0.3
    br.offset = 0.5
    br.inputs['Color1'].default_value = (*_hex(c1), 1)
    br.inputs['Color2'].default_value = (*_hex(c2), 1)
    br.inputs['Mortar'].default_value = (*_hex(mortar), 1)
    br.inputs['Bias'].default_value = 0.0
    L.new(uv, br.inputs['Vector'])
    no = N.new('ShaderNodeTexNoise'); no.inputs['Scale'].default_value = 0.9; no.inputs['Detail'].default_value = 8
    L.new(geo.outputs['Position'], no.inputs['Vector'])
    mix = N.new('ShaderNodeMix'); mix.data_type = 'RGBA'; mix.blend_type = 'MULTIPLY'
    mix.inputs['Factor'].default_value = 0.35
    L.new(br.outputs['Color'], mix.inputs['A'])
    ramp = N.new('ShaderNodeValToRGB')
    ramp.color_ramp.elements[0].position = 0.3; ramp.color_ramp.elements[0].color = (0.78, 0.74, 0.68, 1)
    ramp.color_ramp.elements[1].position = 0.75; ramp.color_ramp.elements[1].color = (1, 1, 1, 1)
    L.new(no.outputs['Fac'], ramp.inputs[0]); L.new(ramp.outputs[0], mix.inputs['B'])
    b = _bsdf(nt, (1, 1, 1), rough)
    L.new(mix.outputs['Result'], b.inputs['Base Color'])
    # rilievo: giunti + pori del travertino
    bump_n = N.new('ShaderNodeBump'); bump_n.inputs['Strength'].default_value = bump; bump_n.inputs['Distance'].default_value = 0.02
    if pori:
        vo = N.new('ShaderNodeTexVoronoi'); vo.inputs['Scale'].default_value = 14.0
        L.new(geo.outputs['Position'], vo.inputs['Vector'])
        mr = N.new('ShaderNodeMapRange'); mr.inputs['From Min'].default_value = 0.0; mr.inputs['From Max'].default_value = 0.12
        L.new(vo.outputs['Distance'], mr.inputs['Value'])
        mx = N.new('ShaderNodeMath'); mx.operation = 'MINIMUM'
        L.new(br.outputs['Fac'], mx.inputs[0]); L.new(mr.outputs['Result'], mx.inputs[1])
        L.new(mx.outputs[0], bump_n.inputs['Height'])
    else:
        L.new(br.outputs['Fac'], bump_n.inputs['Height'])
    L.new(bump_n.outputs['Normal'], b.inputs['Normal'])
    L.new(b.outputs[0], out.inputs[0])
    return m


def stoffa(name, palette, attr='col', sheen=0.4, rough=0.9):
    """colore per istanza dall'attributo dell'istanziatore"""
    m, nt, out = _new(name)
    N = nt.nodes; L = nt.links
    at = N.new('ShaderNodeAttribute'); at.attribute_type = 'INSTANCER'; at.attribute_name = attr
    ramp = N.new('ShaderNodeValToRGB'); ramp.color_ramp.interpolation = 'CONSTANT'
    els = ramp.color_ramp.elements
    while len(els) < len(palette):
        els.new(0.5)
    for i, h in enumerate(palette):
        els[i].position = i / len(palette); els[i].color = (*_hex(h), 1)
    L.new(at.outputs['Fac'], ramp.inputs[0])
    b = _bsdf(nt, (1, 1, 1), rough)
    try:
        b.inputs['Sheen Weight'].default_value = sheen
    except KeyError:
        pass
    L.new(ramp.outputs[0], b.inputs['Base Color'])
    L.new(b.outputs[0], out.inputs[0])
    return m


def basoli(name, c_lo='#5d5852', c_hi='#7a746b', giunto='#8f8370', scala=1.6):
    """basolato romano: poligoni di selce (basalto) con fughe chiare piene di polvere, ogni pietra un tono diverso.
    Visto da lontano è una trama a sassi grigio-bruni, mai una striscia liscia come l'asfalto"""
    m, nt, out = _new(name)
    N = nt.nodes; L = nt.links
    g = N.new('ShaderNodeNewGeometry')
    vo = N.new('ShaderNodeTexVoronoi'); vo.inputs['Scale'].default_value = scala; vo.feature = 'F1'
    L.new(g.outputs['Position'], vo.inputs['Vector'])
    ve = N.new('ShaderNodeTexVoronoi'); ve.inputs['Scale'].default_value = scala; ve.feature = 'DISTANCE_TO_EDGE'
    L.new(g.outputs['Position'], ve.inputs['Vector'])
    ramp = N.new('ShaderNodeValToRGB')
    ramp.color_ramp.elements[0].color = (*_hex(c_lo), 1); ramp.color_ramp.elements[1].color = (*_hex(c_hi), 1)
    sep = N.new('ShaderNodeSeparateColor'); L.new(vo.outputs['Color'], sep.inputs[0]); L.new(sep.outputs[0], ramp.inputs[0])
    fu = N.new('ShaderNodeMapRange'); fu.inputs['From Min'].default_value = 0.02; fu.inputs['From Max'].default_value = 0.07
    L.new(ve.outputs['Distance'], fu.inputs['Value'])
    mix = N.new('ShaderNodeMix'); mix.data_type = 'RGBA'
    mix.inputs['A'].default_value = (*_hex(giunto), 1)
    L.new(fu.outputs['Result'], mix.inputs['Factor']); L.new(ramp.outputs[0], mix.inputs['B'])
    no = N.new('ShaderNodeTexNoise'); no.inputs['Scale'].default_value = 0.25; no.inputs['Detail'].default_value = 6
    L.new(g.outputs['Position'], no.inputs['Vector'])
    m2 = N.new('ShaderNodeMix'); m2.data_type = 'RGBA'; m2.blend_type = 'MULTIPLY'; m2.inputs['Factor'].default_value = 0.3
    L.new(mix.outputs['Result'], m2.inputs['A'])
    r2 = N.new('ShaderNodeValToRGB'); r2.color_ramp.elements[0].color = (0.8, 0.77, 0.72, 1)
    L.new(no.outputs['Fac'], r2.inputs[0]); L.new(r2.outputs[0], m2.inputs['B'])
    b = _bsdf(nt, (1, 1, 1), 0.78)
    L.new(m2.outputs['Result'], b.inputs['Base Color'])
    bu = N.new('ShaderNodeBump'); bu.inputs['Strength'].default_value = 0.6; bu.inputs['Distance'].default_value = 0.03
    L.new(fu.outputs['Result'], bu.inputs['Height']); L.new(bu.outputs['Normal'], b.inputs['Normal'])
    L.new(b.outputs[0], out.inputs[0])
    return m


def crea_tutti():
    M = {}
    M['trav'] = pietra('trav', '#cfbf9e', '#bba886', '#a6957a')
    M['trav2'] = pietra('trav2', '#d4c4a3', '#cab896', '#b0a084', bump=0.15)
    M['lastre'] = pietra('lastre', '#d4c6a8', '#c8b897', '#a89a7e', (1.6, 0.9), 0.8, cilindro=False)
    M['sedili'] = pietra('sedili', '#d5c9b0', '#cabd a2'.replace(' ',''), '#ab9d83', (1.5, 0.4), 0.75, pori=False, bump=0.1)
    M['marmo'] = semplice('marmo', '#e6dfd2', 0.35)
    M['marmo2'] = semplice('marmo2', '#8d6a52', 0.4)
    M['colonna'] = pietra('colonna', '#d1c1a0', '#c9b896', '#b9a886', (40.0, 1.1), 0.7, bump=0.12)
    M['muro_int'] = pietra('muro_int', '#d6c6a6', '#cfbe9d', '#c4b392', (6.0, 4.0), 0.9, pori=False, bump=0.03)
    M['capelli'] = stoffa('capelli', ['#1d1612', '#2b1f17', '#3a2a1e', '#15110e', '#4a3826', '#6b6158'], sheen=0.2, rough=0.7)
    M['lastre2'] = pietra('lastre2', '#85735c', '#7f6e58', '#6b5c4a', (1.8, 1.2), 0.85, pori=False, cilindro=False, bump=0.2)
    M['muro'] = pietra('muro', '#a8876a', '#9a7a5e', '#6d5a48', (0.9, 0.45), 0.85, pori=False)
    M['buio'] = semplice('buio', '#0d0b09', 0.95)
    M['numero'] = semplice('numero', '#7a1f17', 0.7)
    M['bronzo'] = semplice('bronzo', '#c79a4b', 0.28, 1.0)
    M['legno'] = semplice('legno', '#6b4a30', 0.8)
    M['porpora'] = semplice('porpora', '#4a1238', 0.75)
    M['corda'] = semplice('corda', '#8a7a5c', 0.9)
    # sabbia con righe di rastrello
    m, nt, out = _new('sabbia'); N = nt.nodes; L = nt.links
    no = N.new('ShaderNodeTexNoise'); no.inputs['Scale'].default_value = 0.4
    wv = N.new('ShaderNodeTexWave'); wv.inputs['Scale'].default_value = 1.2; wv.inputs['Distortion'].default_value = 6
    b = _bsdf(nt, _hex('#cfae7c'), 0.95)
    mix = N.new('ShaderNodeMix'); mix.data_type = 'RGBA'; mix.inputs['Factor'].default_value = 0.25
    mix.inputs['A'].default_value = (*_hex('#d3b384'), 1); mix.inputs['B'].default_value = (*_hex('#b38f5e'), 1)
    L.new(no.outputs['Fac'], mix.inputs['Factor']); L.new(mix.outputs['Result'], b.inputs['Base Color'])
    bu = N.new('ShaderNodeBump'); bu.inputs['Strength'].default_value = 0.15
    L.new(wv.outputs['Fac'], bu.inputs['Height']); L.new(bu.outputs['Normal'], b.inputs['Normal'])
    L.new(b.outputs[0], out.inputs[0]); M['sabbia'] = m
    # telo del velario: lino traslucido (colore STIMA)
    for nome, hx in (('telo', '#efe4cf'), ('telo2', '#e6d6b8')):
        m, nt, out = _new(nome); N = nt.nodes; L = nt.links
        b = _bsdf(nt, _hex(hx), 0.85)
        tr = N.new('ShaderNodeBsdfTranslucent'); tr.inputs['Color'].default_value = (*_hex('#f2c98a'), 1)
        mx = N.new('ShaderNodeMixShader'); mx.inputs[0].default_value = 0.4
        L.new(b.outputs[0], mx.inputs[1]); L.new(tr.outputs[0], mx.inputs[2]); L.new(mx.outputs[0], out.inputs[0])
        M[nome] = m
    # folla: lana non tinta, ocra, rosso robbia, blu spento, qualche porpora
    M['stoffa'] = stoffa('stoffa', ['#e9e2d3', '#ddd3bf', '#cdbf a3'.replace(' ', ''), '#efe9dc', '#b9a27c', '#8f6c49',
                                    '#8e3a2a', '#d8cdb6', '#6e7d8c', '#c79a52', '#e4dccb', '#5a2a3c', '#ebe4d5', '#9b8a6c'])
    M['pelle'] = stoffa('pelle', ['#8d5a3f', '#a8714f', '#b98262', '#7a4a33', '#c4906e'], sheen=0.1, rough=0.6)
    M['terra'] = pietra('terra', '#7a6248', '#735c43', '#6b553f', (3, 3), 0.95, pori=False, cilindro=False, bump=0.05)
    M['basolato'] = basoli('basolato')                      # strade della città: basoli di selce (Nico 25/11: niente «asfalto»)
    M['viale_trav'] = pietra('viale_trav', '#d3c6aa', '#c7b89a', '#958771', (2.4, 1.2), 0.75, pori=True, cilindro=False, bump=0.3)   # viale del trionfo: grandi lastre bianche di travertino
    M['tegole'] = pietra('tegole', '#8a5440', '#7f4d3a', '#6a4132', (0.5, 0.4), 0.8, pori=False, cilindro=False, bump=0.3)
    M['intonaco'] = pietra('intonaco', '#c4a882', '#bca079', '#b39770', (4, 3), 0.9, pori=False, cilindro='muro', bump=0.05)
    M['intonaco2'] = pietra('intonaco2', '#b07b55', '#a9744f', '#9d6b48', (4, 3), 0.9, pori=False, cilindro='muro', bump=0.05)
    M['intonaco3'] = pietra('intonaco3', '#d2bc98', '#c9b28e', '#bea784', (4, 3), 0.9, pori=False, cilindro='muro', bump=0.05)
    M['mattoni'] = pietra('mattoni', '#8c5a3e', '#82533a', '#6e4a36', (0.45, 0.12), 0.9, pori=False, cilindro='muro', bump=0.15)
    M['foglie'] = semplice('foglie', '#3b4a2a', 0.8)
    M['tronco'] = semplice('tronco', '#4a3a2c', 0.9)
    M['petalo'] = semplice('petalo', '#b3141e', 0.6)
    M['stendardo'] = semplice('stendardo', '#7c1220', 0.8)
    M['oro'] = semplice('oro', '#d4a548', 0.25, 1.0)
    m, nt, out = _new('fuoco'); e = nt.nodes.new('ShaderNodeEmission'); e.inputs['Color'].default_value = (1.0, 0.38, 0.08, 1); e.inputs['Strength'].default_value = 5.0
    nt.links.new(e.outputs[0], out.inputs[0]); M['fuoco'] = m
    M['muri_citta'] = stoffa('muri_citta', ['#c9ab82', '#b98d64', '#d7c3a0', '#a8714e', '#c4a27a', '#d9cdb3', '#9c6a4b', '#c7b08c'], sheen=0.0, rough=0.9)
    M['acqua'] = semplice('acqua', '#2f4a45', 0.08)
    M['scudo'] = semplice('scudo', '#8a2a1c', 0.5)
    M['cavallo'] = semplice('cavallo', '#4e3424', 0.6)
    m, nt, out = _new('orizzonte'); e = nt.nodes.new('ShaderNodeEmission'); e.inputs['Color'].default_value = (0.66, 0.6, 0.55, 1); e.inputs['Strength'].default_value = 1.0
    nt.links.new(e.outputs[0], out.inputs[0]); M['orizzonte'] = m
    m, nt, out = _new('monti'); e = nt.nodes.new('ShaderNodeEmission'); e.inputs['Color'].default_value = (0.58, 0.54, 0.52, 1); e.inputs['Strength'].default_value = 1.0
    nt.links.new(e.outputs[0], out.inputs[0]); M['monti'] = m
    M['cavallo_bianco'] = semplice('cavallo_bianco', '#d8d2c6', 0.6)
    M['tunica_bianca'] = semplice('tunica_bianca', '#e8e0cf', 0.85)
    M['pelle_g'] = semplice('pelle_g', '#9a6446', 0.6)
    return M
