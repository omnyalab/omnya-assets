#!/bin/bash
# Double-click to start the Remote Kit on a Mac.
# It starts the server and opens the big screen in your browser. Keep this window open while you use it.
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo ""
  echo "  Python 3 is not installed. Install it from https://www.python.org/downloads/ and double-click Start.command again."
  echo ""
  read -n 1 -s -r -p "  Press any key to close."
  exit 1
fi
python3 server.py "$@"
