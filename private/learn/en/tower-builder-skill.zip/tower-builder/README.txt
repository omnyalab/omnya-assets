TOWER BUILDER · a skill for Claude
==================================

What it does
Claude builds you a complete website with a 3D residential tower where people choose their floor:
the tower in its setting with a price on every floor, a straight flight to the chosen level, the
residences on that floor, the real view from inside the residence at its height, the offer to
upgrade to the penthouse, and a reservation card. It works on phones and you can put it online
for free.

What you need
- A paid Claude plan that includes skills (Pro or above) on claude.ai or in the Claude app,
  or Claude Code on your computer.
- The file tower-builder-skill.zip. Keep it zipped.
- Chrome. Internet the first time the page opens (it loads the 3D library, three.js, from a public CDN).


INSTALL ON CLAUDE.AI OR THE CLAUDE APP (checked on 23 November 2026)
Download the zip first:
  - On a Mac, download it with Chrome, because Safari unzips files by itself.
    (If you only have a folder, not a .zip, download it again with Chrome.)
  - On Windows the downloaded .zip is fine as it is.
1. In claude.ai click your name, then Settings, then Capabilities, and make sure file creation is on.
2. Click Plugins in the left menu.
3. Click Add (top right), then Upload plugin, and choose tower-builder-skill.zip.
4. Make sure Tower Builder is switched on.
   (On Team and Enterprise plans an owner may need to allow plugins first.)

INSTALL IN CLAUDE CODE
1. Unzip tower-builder-skill.zip (on Windows: right click, Extract all). You get a folder called tower-builder.
2. Move that folder into the skills folder of your user:
     macOS / Linux:  ~/.claude/skills/tower-builder
     Windows:        %USERPROFILE%\.claude\skills\tower-builder
3. Start a new Claude Code session. Type /skills to check it is listed.


YOUR FIRST MESSAGE
Copy this and change the parts in brackets:

  Build me a tower where people choose their floor, for [project name] in [city],
  [number] floors by the [sea / river / city / desert / park], colours [colour] and [colour],
  prices in [currency] from [lowest] to [highest], penthouse upgrade [price]. Page in [language].

Short works too, for example:
  "Build me a residential tower by the sea in Valencia, white and gold"
Claude asks what it needs, or picks sensible defaults and tells you which ones.


WHAT YOU GET
A folder with three files: index.html, tower.js and ui.css. No installation, no build step.
To change prices, names, colours or floors later, ask Claude, or edit the CONFIG part at the top
of tower.js yourself (every field is explained in the skill, references/config.md).

To open it on your computer
- The only file you double click is index.html. Open it with Chrome
  (on a Mac: right click > Open With > Google Chrome). It needs internet for the 3D library.
- On Windows, first right click the zip Claude gave you and choose Extract all, then double click
  index.html in the extracted folder.
- Claude Code: Claude can also start a small local server and give you the address.
- If the page stays on the loading screen, open a terminal in the folder and run
      python3 -m http.server 8080
  then open http://localhost:8080 in Chrome.


PUT IT ONLINE FOR FREE
Netlify Drop
  1. Go to app.netlify.com/drop
  2. Drag the folder with index.html inside onto the page.
  3. You get a link right away. Make a free account to keep it online and choose its name.
Vercel
  1. Make a free Hobby account at vercel.com
  2. Add New > Project, then drag the folder in (or import it from GitHub).
  3. Framework "Other", no build command. Deploy.
  (No folder upload in your dashboard? Put the folder on GitHub and import it, or ask Claude
  to run the Vercel command line for you.)
Both give you an https link that works on phones. To update, drag the new folder again.


GOOD TO KNOW
- Prices, sizes and sold residences are sample data made from your settings, the same every
  time. The card says so in a small line; ask Claude to remove it if your data is real.
- There is no payment inside the page. If you have a payment or booking link, give it to Claude:
  the Reserve button will open it with the chosen floor and residence.
- Phones automatically get a lighter version (smaller shadows, fewer buildings around).
  Try it on your own phone before you share it.
- Only use names and logos you own or have permission to use. The skill never uses the names
  of real towers or developers.
