MIAMI BUILDER · a skill for Claude
==================================

What it does
Claude builds you a "Build <City>" page like Build Miami, for any real city: the city in 3D made
from real map data (buildings with their heights, streets, coastline, rivers, parks), a glass
panel on the right with seven buttons that build it piece by piece while the camera flies down
and around it, a Day/Night switch with lit windows and neon, and a self-playing version with a
cursor for screen recordings. One folder, no installation, and you can put it online for free.

What you need
- A paid Claude plan that includes Skills (Pro or above) on claude.ai or in the Claude app,
  or Claude Code on your computer.
- On claude.ai, "Create and edit files" switched on in Settings > Capabilities
  (Skills run on it; older screens call it "Code execution and file creation").
- A browser. Internet the first time the page opens (it loads the 3D library, three.js, from a public CDN).
- The city data is downloaded for free from OpenStreetMap, no account or key. If Claude's sandbox
  cannot go online, Claude gives you one command to run on your computer (Python 3, already on
  every Mac; on Windows get it free from python.org).


INSTALL ON CLAUDE.AI OR THE CLAUDE APP
1. Keep the zip you downloaded (miami-builder-skill.zip) as it is. Do not unzip it.
   On a Mac, download it with Chrome: Safari unzips downloads by itself and deletes
   the zip. If you only have a folder called miami-builder, right-click it, choose
   Compress "miami-builder" and use the new miami-builder.zip.
2. Open Settings > Capabilities and check that "Create and edit files" is on.
3. In the menu on the left click Plugins, then Add (top right) > Upload plugin,
   choose the zip and click Upload.
4. Claude says "Miami builder is added and ready to use" and lists it under Your
   plugins as a Skill. Start a new chat and send your first message (below).
   (Older screens: Settings > Capabilities > Skills > Upload skill, same zip.
   On Team and Enterprise plans an owner may need to allow skills first.)

INSTALL IN CLAUDE CODE
1. Unzip miami-builder-skill.zip. You get a folder called miami-builder.
2. Move that folder into the skills folder of your user:
     macOS / Linux:  ~/.claude/skills/miami-builder
     Windows:        %USERPROFILE%\.claude\skills\miami-builder
   (or into .claude/skills/ inside one project, to use it only there).
3. Start a new Claude Code session. Type /skills to check it is listed.


YOUR FIRST MESSAGE
One line is enough:

  Build me Lisbon like Build Miami
  Build me Monaco
  Build me Dubai Marina, at night

Or with details (change the parts in brackets):

  Build me [city] like Build Miami. Show [the old town / the skyline / the waterfront],
  the district button should build [district], and the two "Go to" buttons should go to
  [place] and [place].

Claude picks the area, the district, the places and the real colours of the city, downloads the
map, builds the page, checks it in a browser and tells you what it chose.


WHAT YOU GET
A folder build-<city> with two files: index.html (the page) and city-data.js (the city).
To change names, colours, the buttons or the camera views later, ask Claude, or edit the CONFIG
part at the top of index.html yourself (every field is explained in the skill, references/config.md).

To open it on your computer
- Claude Code: Claude starts a small local server and gives you the address.
- Otherwise: double click index.html (works in Chrome, needs internet for the 3D library).
  If a browser stays on the loading screen, open a terminal in the folder and run
      python3 -m http.server 8080
  then open http://localhost:8080 in your browser.

Using it
- Click the buttons in order. Each one builds its piece while the camera flies.
- Day / Night switches the light. Drag to turn the view, scroll to zoom.
- Keys: Space next button · R start over · N day/night · H hide the panel · F full screen
        P save a picture of the 3D · K print the current camera view (to change a button's view)
- Add ?auto=1 to the address for the self-playing version with the cursor (for screen
  recordings), ?night=1 to open at night, ?clean=1 to hide everything but the 3D.


PUT IT ONLINE FOR FREE
Netlify Drop
  1. Go to app.netlify.com/drop
  2. Drag the folder with index.html inside onto the page.
  3. You get a link right away. Make a free account to keep it online and choose its name.
Vercel
  1. Make a free Hobby account at vercel.com
  2. Add New > Project, then drag the folder in (or import it from GitHub).
  3. Framework "Other", no build command. Deploy.
Both give you an https link that works on phones. To update, drag the new folder again.


FROM THE 3D TO PHOTO-REAL PICTURES AND CLIPS
The page is also the camera for realistic images, the way Build Miami was made:
  1. Open the page with ?clean=1 and the step you want (for example ?clean=1&step=4),
     set the window to 1920 x 1080 and press P: you get a clean frame of the 3D.
  2. Give that frame to an image model that edits images (Seedream, Nano Banana Pro or similar)
     with a prompt that keeps the same camera and geometry and changes only materials and light.
  3. Make two such pictures, the start and the end of one camera move, and give them to a video
     model with start and end frames (Kling or similar) to get the clip between them.
     Even steadier: record the 3D flight of the page and use it as the base video.
Ask Claude: it knows the steps (references/photoreal.md in the skill). The full prompts, the colour
recipe and the clip-by-clip plan are in the Full Miami Blueprint.
Image and video models are paid services of their own; Claude asks before using any.


GOOD TO KNOW
- The city is real OpenStreetMap data. Where a building has no height in the map, its height is
  estimated from its neighbours and its type, so it is close to reality but not exact.
- The ground is flat: hills are not modelled. Bridges lie flat on the water.
- Keep the small line "Map data © OpenStreetMap contributors" in the corner when the page is
  public: it is the licence of the map data.
- Big areas are heavy 3D. Phones get a lighter version by themselves. Try it on your own phone
  before you share it.
- Only use names and logos you own or have permission to use.
