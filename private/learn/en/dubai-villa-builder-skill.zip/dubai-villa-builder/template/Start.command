#!/bin/zsh
# Choose your villa. Double click: starts a small local server and opens the page (best in Chrome).
# The first time macOS may block it: right click > Open. To stop the server: double click Stop.command.
cd "$(dirname "$0")"
PORT=5316
URL="http://localhost:$PORT/index.html${1:-}"
if ! lsof -ti tcp:$PORT >/dev/null 2>&1; then
  ( nohup python3 server.py $PORT >/dev/null 2>&1 & )
fi
for i in {1..60}; do curl -s -o /dev/null "http://localhost:$PORT/" && break; sleep 0.2; done
if ! curl -s -o /dev/null "http://localhost:$PORT/"; then
  echo "The server did not start. Check that Python 3 is installed (type: python3 --version)."
  read -k1 "?Press a key to close"; exit 1
fi
if [ -d "/Applications/Google Chrome.app" ]; then open -a "Google Chrome" "$URL"; else open "$URL"; fi
echo "The villa is open in your browser ($URL). R starts again. You can close this window."
