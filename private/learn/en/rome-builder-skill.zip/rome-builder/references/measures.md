# The Colosseum in 80 AD: the measures we used

Sources (read on 24/11/2026): TC-D the-colosseum.net/wp/en/description · TC-N the-colosseum.net/wp/en/numbers · UC penelope.uchicago.edu (Encyclopaedia Romana) · ARL ancientromelive.org (Platner & Ashby 1929) · WH worldhistory.org/Colosseum · ST structurae.net · Britannica. The full table with notes is `blender/MISURE.md` (Italian).

| Measure | Value used | Source |
|---|---|---|
| Long axis outside | 188 m (UC and WH say 189) | TC-N, TC-D, ARL |
| Short axis outside | 156 m | TC-D, TC-N, ARL, WH |
| Perimeter | 545 m: 80 equal bays of 6.81 m | ARL, UC |
| Total height with attic | 48.5 m | TC-D, TC-N, ARL |
| Storeys | 3 arcades + attic: Tuscan / Ionic / Corinthian / Corinthian pilasters | TC-D, ARL, UC |
| Arches per storey | 80: 76 numbered (I-LXXVI) + 4 axial entrances | TC-D, UC, ARL |
| Ground-floor arch | 4.20 x 7.05 m (2nd and 3rd: 4.20 x 6.45 and 6.40 m) | TC-D, TC-N, ARL |
| Pier | 2.40 m wide, 2.70 m deep | ARL |
| Cornice heights 10.5 / 22.3 / 33.6 / 48.5 m | ESTIMATE from the ARL measures | no source gives them |
| Attic | a small window every 2 bays, gilded bronze shields between, 3 corbels per bay | ARL, UC, TC-D |
| Velarium poles | 240 (colour of the awning unknown: ESTIMATE natural linen) | TC-D, TC-N, UC, Britannica |
| Arena | 86 x 54 m | ARL |
| Podium above the arena | 3.6 m | TC-N |
| Slope of the stands | 37° | TC-D, TC-N |
| Spectators | 50,000-75,000 (about 45,000 figures in the 3D) | TC-D, ARL |
| Paving around | 17.5 m of travertine | ARL |
| Orientation | long axis about WSW-ENE | TC-D |

## Not there in 80 AD (do not add them)
The Arch of Constantine (315 AD), the Arch of Titus (after 81 AD), the Flavian Meta Sudans (89-96 AD), the Temple of Venus and Roma (121 AD), the Ludus Magnus. The Colossus of Nero stood in the vestibule of the Domus Aurea on the Velia, not next to the Colosseum (Hadrian moved it in 128): far to the west, as a silhouette only. The Baths of Titus opened the same year, on the Oppian hill to the north.
The columns with golden eagles on the avenue are a film look (like Gladiator II), not history: we took the light and the dust from it.
