# Regia del giro da film: Roma dall'alto -> tuffo dritto verso il Colosseo -> inclinazione da ferma ->
# discesa nel corteo e dentro l'arco LII -> scala -> bocca del vomitorio -> inclinazione da ferma verso l'arena
# -> A: al proprio posto / B: in volo sopra le gradinate verso i gladiatori. Ogni tratto un solo movimento dritto.
import math, json, os
try:
    import bpy
    from mathutils import Vector, Euler
except ImportError:
    bpy = None
import numpy as np
from geo import frame, bay_s

FPS = 24


def fcurves_of(obj):
    act = obj.animation_data.action
    try:
        return list(act.fcurves)
    except AttributeError:
        from bpy_extras import anim_utils
        cb = anim_utils.action_get_channelbag_for_slot(act, obj.animation_data.action_slot)
        return list(cb.fcurves) if cb else []


def _ss(x):
    x = min(1.0, max(0.0, x)); return x * x * (3 - 2 * x)


def _catmull(P, n_per=300):
    P = [np.array(p, float) for p in P]
    ext = [P[0] + (P[0] - P[1])] + P + [P[-1] + (P[-1] - P[-2])]
    pts = []
    for i in range(1, len(ext) - 2):
        p0, p1, p2, p3 = ext[i - 1], ext[i], ext[i + 1], ext[i + 2]
        tj = lambda ti, a, b: ti + np.linalg.norm(b - a) ** 0.5
        t0 = 0; t1 = tj(t0, p0, p1); t2 = tj(t1, p1, p2); t3 = tj(t2, p2, p3)
        for t in np.linspace(t1, t2, n_per, endpoint=False):
            A1 = (t1 - t) / (t1 - t0) * p0 + (t - t0) / (t1 - t0) * p1
            A2 = (t2 - t) / (t2 - t1) * p1 + (t - t1) / (t2 - t1) * p2
            A3 = (t3 - t) / (t3 - t2) * p2 + (t - t2) / (t3 - t2) * p3
            B1 = (t2 - t) / (t2 - t0) * A1 + (t - t0) / (t2 - t0) * A2
            B2 = (t3 - t) / (t3 - t1) * A2 + (t - t1) / (t3 - t1) * A3
            pts.append((t2 - t) / (t2 - t1) * B1 + (t - t1) / (t2 - t1) * B2)
    pts.append(P[-1])
    return np.array(pts)


def _path_frames(pts, vfun, l_in=14.0, l_out=9.0):
    """campiona il percorso a velocità v(z), con partenza e arrivo morbidi in metri; posizioni per fotogramma"""
    seg = np.linalg.norm(np.diff(pts, axis=0), axis=1)
    s = np.concatenate([[0], np.cumsum(seg)]); L = s[-1]
    out = [pts[0]]; d = 0.0
    while d < L - 1e-3:
        i = min(max(np.searchsorted(s, d), 1), len(s) - 1)
        a = (d - s[i - 1]) / max(1e-9, s[i] - s[i - 1]); p = pts[i - 1] * (1 - a) + pts[i] * a
        k = min(1.0, max(0.1, _ss(d / l_in)), max(0.06, _ss((L - d) / l_out)))
        d = min(L, d + vfun(p[2]) * k / FPS)
        i = min(max(np.searchsorted(s, d), 1), len(s) - 1)
        a = (d - s[i - 1]) / max(1e-9, s[i] - s[i - 1]); out.append(pts[i - 1] * (1 - a) + pts[i] * a)
    return out


CENTRO_GLAD_ALONG = -82.0      # gladiatori sull'asse della camera, 82 m dentro la facciata (verso il centro dell'arena)
K_AR, P2_OFF, C_AR = 220.0, 140.0, 0.85
P0_OFF = 480.0
V_TOP, PIT_TOP, K_SCALA = 1.6, -13.0, 0.45
V_LOW, U_FRENO = 7.0, 0.62


def _bez(P, n=400):
    P = [np.array(p, float) for p in P]
    t = np.linspace(0, 1, n)[:, None]
    return (1 - t) ** 3 * P[0] + 3 * (1 - t) ** 2 * t * P[1] + 3 * (1 - t) * t ** 2 * P[2] + t ** 3 * P[3]


def _smooth1d(a, sig):
    if sig <= 0:
        return np.array(a, float)
    a = np.array(a, float); r = int(3 * sig); k = np.exp(-0.5 * (np.arange(-r, r + 1) / sig) ** 2); k /= k.sum()
    ap = np.concatenate([np.full(r, a[0]), a, np.full(r, a[-1])])
    return np.convolve(ap, k, mode='valid')


def _hermite_keys(tk, vk, t):
    """curva per chiavi (tempo, valore) con tangenti zero agli estremi e Catmull in mezzo: niente strappi"""
    tk = np.array(tk, float); vk = np.array(vk, float); out = np.empty_like(t, dtype=float)
    m = np.zeros(len(tk))
    for i in range(1, len(tk) - 1):
        a, b = vk[i] - vk[i - 1], vk[i + 1] - vk[i]
        m[i] = 0.0 if a * b <= 0 else (vk[i + 1] - vk[i - 1]) / (tk[i + 1] - tk[i - 1])
    for j, tt in enumerate(t):
        i = min(max(np.searchsorted(tk, tt) - 1, 0), len(tk) - 2)
        h = tk[i + 1] - tk[i]; u = min(1.0, max(0.0, (tt - tk[i]) / h))
        h00 = 2 * u ** 3 - 3 * u ** 2 + 1; h10 = u ** 3 - 2 * u ** 2 + u; h01 = -2 * u ** 3 + 3 * u ** 2; h11 = u ** 3 - u ** 2
        out[j] = h00 * vk[i] + h10 * h * m[i] + h01 * vk[i + 1] + h11 * h * m[i + 1]
    return out


def percorso_film(CAM_BAY, RAMP, walks):
    """Giro da film (Nico 25/11): parte già vicino, scende senza mai fermarsi dritta sulla strada piena di gente,
    entra dall'arco LII, sale una scala più corta stando più staccata dai gradini, esce in cima, guarda a destra
    e poi a sinistra tutto il Colosseo aperto e scende verso i gladiatori. Restituisce fotogrammi (pos, yaw, pitch) e i tempi."""
    sc = bay_s(CAM_BAY); pc, nc = frame(sc); tc = np.array([-nc[1], nc[0]])
    yaw0 = math.atan2(-nc[1], -nc[0]) - math.pi / 2

    def W(off, z, lat=0.0):
        q = pc + nc * off + tc * lat
        return np.array([float(q[0]), float(q[1]), float(z)])
    dw, zw = walks[1]
    d_in, d_top = RAMP['d_in'], RAMP['d_top']
    slope = (zw + 0.4) / (d_in - d_top)
    zs = lambda d: -0.4 + slope * (d_in - d)                   # piano dei gradini
    # 1) volo: Bézier nel piano verticale del viale (niente destra-sinistra), tangente orizzontale all'arrivo in strada
    p0 = np.array([P0_OFF, 314.0 - (740.0 - P0_OFF) * 299.0 / 825.0]); tgt = np.array([-85.0, 15.0]); d0 = (tgt - p0) / np.linalg.norm(tgt - p0)
    aria = _bez([p0, p0 + d0 * K_AR, (P2_OFF, 2.7), (62.0, 2.7)], 600)
    # 2) strada, arco, corridoio, scala, uscita in cima, sopra le gradinate
    E_d = dw - 2.6
    dentro = _catmull([(62.0, 2.7), (34.0, 2.6), (10.0, 2.5), (-6.0, 2.45), (-12.0, 2.7),
                       (34.6 - 51, zs(34.6) + 2.5), (25.0 - 51, zs(25.0) + 2.6), (d_top - 51 - 0.6, zw + 2.1),
                       (E_d - 51, zw + 2.5), (10.5 - 51, zw + 4.6), (6.0 - 51, zw + 5.4)], 160)
    ga = CENTRO_GLAD_ALONG
    G_off, G_z = 6.0 - 51, zw + 5.4
    H_off, H_z = ga + 10.0, 3.4
    scesa = _bez([(G_off, G_z), (G_off - 5.0, G_z - 0.6), (H_off + 6.0, H_z + 1.6), (H_off, H_z)], 200)
    pts2 = np.vstack([aria, dentro[1:], scesa[1:]])
    P3 = np.array([W(o, z) for o, z in pts2])
    seg = np.linalg.norm(np.diff(P3, axis=0), axis=1); S = np.concatenate([[0], np.cumsum(seg)])
    L_aria = float(np.sum(np.linalg.norm(np.diff(aria, axis=0), axis=1)))
    # distanze delle «stazioni» lungo il percorso
    def s_at(off_target, start=0):
        i = start + int(np.argmin(np.abs(pts2[start:, 0] - off_target))); return S[i], i
    s_arco, i_arco = s_at(0.0, len(aria))
    s_E, i_E = s_at(E_d - 51, i_arco)
    s_G, i_G = s_at(G_off, i_E)
    L = S[-1]
    # velocità: in volo cresce con la quota (flusso costante), in strada 10,5 m/s, in scala 9, in cima rallenta a 2,2 per guardarsi intorno
    def vel(s):
        i = min(max(np.searchsorted(S, s), 1), len(S) - 1); z = P3[i][2]
        if s <= L_aria:
            return 10.5 + C_AR * max(0.0, z - 2.7) + V_LOW * min(1.0, max(0.0, z - 2.7) / 7.0)
        if s <= s_E:
            return 10.5 + (9.0 - 10.5) * _ss((s - L_aria) / max(1.0, s_arco - L_aria)) + (3.0 - 9.0) * _ss((s - (s_E - 9.0)) / 9.0)
        if s <= s_G:
            return 3.0 + (V_TOP - 3.0) * _ss((s - s_E) / max(1.0, s_G - s_E))
        u = (s - s_G) / (L - s_G)
        return V_TOP + (6.0 - V_TOP) * _ss(min(1.0, u / 0.3)) - (6.0 - 0.9) * _ss((u - U_FRENO) / (1 - U_FRENO))
    pos = []; d = 0.0; ss_ = []
    while d < L - 1e-3:
        i = min(max(np.searchsorted(S, d), 1), len(S) - 1); a = (d - S[i - 1]) / max(1e-9, S[i] - S[i - 1])
        pos.append(P3[i - 1] * (1 - a) + P3[i] * a); ss_.append(d)
        d = min(L, d + max(0.12, vel(d)) / FPS)
    pos.append(P3[-1]); ss_.append(L)
    ss_ = np.array(ss_); n = len(pos); t = np.arange(n) / FPS
    f_arco = int(np.searchsorted(ss_, s_arco)); f_E = int(np.searchsorted(ss_, s_E)); f_G = int(np.searchsorted(ss_, s_G))
    pos = np.array(pos)
    # pitch: in volo guarda dentro il Colosseo (punto fisso sull'asse), in strada e in scala guarda avanti lungo il percorso
    T_air = W(-60.0, 10.0)
    def look(p, q):
        dv = q - p; return math.degrees(math.atan2(dv[2], math.hypot(dv[0], dv[1])))
    pit_air = np.array([look(p, T_air) for p in pos])
    ahead = []
    for k in range(n):
        j = int(np.searchsorted(ss_, ss_[k] + 14.0)); j = min(j, n - 1)
        ahead.append(K_SCALA * look(pos[k], pos[j]) + 2.5 if j > k else 2.5)
    ahead = np.array(ahead)
    off_cam = np.array([(p[:2] - pc) @ nc for p in pos])
    w_in = np.array([_ss((10.0 - o) / 18.0) for o in off_cam])
    pitch = pit_air * (1 - w_in) + ahead * w_in
    # in cima: guarda sopra l'arena (-9°), poi i gladiatori
    C_g = W(ga, 1.0)
    pit_g = np.array([look(p, C_g) for p in pos])
    pitch = np.where(np.arange(n) < f_E, pitch, pitch)
    tE = f_E / FPS
    w_top = np.array([_ss((tt - (tE - 0.6)) / 1.6) for tt in t])
    pitch = pitch * (1 - w_top) + PIT_TOP * w_top
    tG = f_G / FPS
    w_g = np.array([_ss((tt - tG) / max(1.0, t[-1] - tG)) for tt in t])
    pitch = pitch * (1 - w_g) + pit_g[-1] * w_g
    # yaw: dritto fino in cima; poi un po' a destra, un po' a sinistra, di nuovo dritto e giù verso i gladiatori
    A = math.radians(13.0)
    yaw_off = _hermite_keys([0, tE + 0.3, tE + 2.3, tE + 4.6, tE + 6.6, t[-1] + 5],
                            [0, 0, -A, A * 0.9, 0, 0], t)        # destra = yaw negativo
    yaw = yaw0 + yaw_off
    pitch = _smooth1d(pitch, 5.0)
    info = dict(fotogrammi=n, secondi=round(n / FPS, 2), f_arco=f_arco, f_cima=f_E, f_scesa=f_G,
                s_arco=round(f_arco / FPS, 2), s_cima=round(tE, 2), s_scesa=round(tG, 2))
    return pos, yaw, pitch, info, dict(pc=pc, nc=nc, tc=tc, W=W)


def giro_film(scn, CAM_BAY, RAMP, walks, folla_esclusioni=None, hold_s=1.0):
    pos, yaw, pitch, info, _ = percorso_film(CAM_BAY, RAMP, walks)
    nh = int(hold_s * FPS)
    cd = bpy.data.cameras.new('CAM_F'); cd.lens = 24; cd.sensor_width = 36; cd.clip_start = 0.1; cd.clip_end = 120000
    cam = bpy.data.objects.new('CAM_F', cd); scn.collection.objects.link(cam)
    allk = list(zip(pos, yaw, pitch)) + [(pos[-1], yaw[-1], pitch[-1])] * nh
    for f, (p, yw, pt) in enumerate(allk, start=1):
        cam.location = Vector(p); cam.rotation_euler = Euler((math.radians(90 + pt), 0, yw), 'XYZ')
        cam.keyframe_insert('location', frame=f); cam.keyframe_insert('rotation_euler', frame=f)
    for fc in fcurves_of(cam):
        for kp in fc.keyframe_points:
            kp.interpolation = 'LINEAR'
    tot = len(allk)
    scn.frame_start = 1; scn.frame_end = tot; scn.render.fps = FPS
    scn.camera = cam
    info.update(totale=tot, secondi_tot=round(tot / FPS, 2))
    print('REGIA', json.dumps(info))
    return info, []


if __name__ == '__main__':
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
