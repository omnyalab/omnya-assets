# Make it yours: config.js

Everything below is in `template/config.js` (in the user's copy). Save, reload the page.

| Field | What it changes |
|---|---|
| `pageTitle`, `loading` | browser tab and the "loading" line |
| `developer` | empty = nothing (like the reel); set = "Presented by ..." under the last card |
| `bookingUrl` | where "Book a private viewing" opens (new tab). https page, `https://wa.me/<number>?text=...`, or `mailto:` |
| `mapCredit` | the OpenStreetMap credit, bottom right from above. Keep it |
| `areaTitle`, `area` | "Dubai Hills Estate" above "Drop your pin"; "Dubai Hills" on the cards |
| `currency`, `showPrices`, `priceText` | prices are written `AED 38.9M` or `AED 950,000`; with `showPrices: false` all read "On request" |
| `villa` | number, community, street, type, urgency line, bedrooms, built-up, view (short and long), price, status |
| `landmark` | the label at the pool ("Burj Khalifa", "7.95 km from your pool") and the last card row |
| `text` | every other word, step by step, plus the column labels |
| `rooms` | room names and the "View ..." button of the three stops (keep three: the stops are fixed seconds of the film) |
| `colors` | `accent` (pin, lit street, dots, lines), `accentLight` (small coloured words), `button` + `buttonText` (filled buttons), `accentOnWhite`, `available` (green dot) |

Rules for colours: black page and one accent. Pick a `button` dark enough for white text (4.5:1 contrast or more); `accent` can be
brighter. Do not add a second bright colour.

Languages: translate `text`, `rooms`, `villa` and `landmark`. Long words can overflow buttons: look at every step after changing
them (the cards are 540 px wide, buttons fit about 24 characters at their size). The font (Inter) covers Latin alphabets only;
for Arabic, Cyrillic or Chinese add a font file to `assets/fonts/` and register it in `app.js` (the `fonti` list).

Street names, villa numbers and their prices: `dati.json` (see data.md).
