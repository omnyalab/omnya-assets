# Colosseo 80 d.C. — costruzione procedurale in Blender (gira uguale sul Mac e sulla GPU Higgsfield).
# blender -b --factory-startup --python costruisci.py -- <out.blend> [leggero]
import bpy, bmesh, math, random, sys, os
from mathutils import Vector, Matrix
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import geo
from geo import M, Builder, BAYW, NBAY, PERIM, bay_s, frame
import materiali, folla, ambiente, roma, corteo, regia
import json
import numpy as np

argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
OUT = argv[0] if argv else '/tmp/colosseo.blend'
LEGGERO = 'leggero' in argv
FOTO = 'foto' in argv           # copia per le foto ultra realistiche (mercato disordinato, ninfeo, colline...)
random.seed(80)

for o in list(bpy.data.objects):
    bpy.data.objects.remove(o, do_unlink=True)
scn = bpy.context.scene
MAT = materiali.crea_tutti()


def mesh_obj(name, verts, faces, mat, coll=None, smooth=False):
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)
    me.validate(clean_customdata=False)
    bm = bmesh.new(); bm.from_mesh(me)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.0005)
    bm.to_mesh(me); bm.free()
    ob = bpy.data.objects.new(name, me)
    (coll or scn.collection).objects.link(ob)
    if isinstance(mat, str):
        ob.data.materials.append(MAT[mat])
    if smooth:
        for p in me.polygons:
            p.use_smooth = True
    return ob


def flush(b, prefix, coll=None):
    obs = []
    for mat, (V, F) in b.parts.items():
        if V:
            obs.append(mesh_obj(f'{prefix}_{mat}', V, F, mat, coll))
    return obs


def colle(name):
    c = bpy.data.collections.new(name); scn.collection.children.link(c); return c


C_STRUT = colle('Colosseo'); C_FUORI = colle('Fuori'); C_FOLLA = colle('Folla')
W = BAYW; hw = W / 2; AW = 4.2
CAM_BAY = 34                     # arco LII: il biglietto
TH = [0.6, 12.85, 24.25]         # soglie archi
ZS = [0.6 + 7.05 - 2.1, 12.85 + 6.45 - 2.1, 24.25 + 6.40 - 2.1]  # imposte
ZE = [8.15, 20.2, 31.6]          # base trabeazioni
COLR = [0.66, 0.6, 0.55]
CO = -0.05                       # centro semicolonna quasi sul filo del pilastro
FT = -2.7                        # spessore facciata

# ------------------------------------------------------------------ FACCIATA
b = Builder()
for k in range(NBAY):
    s0 = bay_s(k)
    num = geo.bay_number(k)
    for L in range(3):
        th, zs, ze, r = TH[L], ZS[L], ZE[L], COLR[L]
        b.box('trav', s0, -hw, -AW / 2, FT, 0, th, ze, 2)
        b.box('trav', s0, AW / 2, hw, FT, 0, th, ze, 2)
        b.spandrel('trav', s0, AW, zs, ze, FT, 0)
        b.box('trav2', s0, -hw + 0.6, -AW / 2, 0, 0.1, zs - 0.28, zs, 1)
        b.box('trav2', s0, AW / 2, hw - 0.6, 0, 0.1, zs - 0.28, zs, 1)
        b.arch_ring('trav2', s0, AW, zs, 0, 0.1, 0.32)
        # semicolonna sul pilastro sinistro (la destra è della campata dopo)
        b.cyl('colonna', s0, -hw, CO, th + 0.36, ze - (0.5 if L < 2 else 0.95), r, 24, r * 0.9)
        b.cyl('colonna', s0, -hw, CO, th, th + 0.2, r * 1.3, 24)
        b.cyl('colonna', s0, -hw, CO, th + 0.2, th + 0.36, r * 1.15, 24, r * 1.0)
        if L == 0:      # tuscanico
            b.cyl('colonna', s0, -hw, CO, ze - 0.5, ze - 0.38, r * 0.92, 24, r * 0.98)
            b.cyl('colonna', s0, -hw, CO, ze - 0.38, ze - 0.22, r * 0.98, 24, r * 1.3)
            b.box('colonna', s0, -hw - r * 1.4, -hw + r * 1.4, -0.3, CO + r * 1.4, ze - 0.22, ze, 1)
        elif L == 1:    # ionico: echino + volute
            b.cyl('colonna', s0, -hw, CO, ze - 0.5, ze - 0.36, r * 0.95, 24, r * 1.12)
            b.box('colonna', s0, -hw - r * 1.5, -hw + r * 1.5, -0.3, CO + r * 1.2, ze - 0.36, ze - 0.12, 1)
            for sx in (-1, 1):
                b.cyl('colonna', s0, -hw + sx * r * 1.45, CO + r * 0.9, ze - 0.62, ze - 0.1, 0.27, 14)
            b.box('colonna', s0, -hw - r * 1.45, -hw + r * 1.45, -0.3, CO + r * 1.35, ze - 0.12, ze, 1)
        else:           # corinzio: campana svasata + abaco
            b.cyl('colonna', s0, -hw, CO, ze - 0.95, ze - 0.55, r * 0.92, 24, r * 1.12)
            b.cyl('colonna', s0, -hw, CO, ze - 0.55, ze - 0.18, r * 1.12, 24, r * 1.48)
            for sx in (-1, 1):
                b.box('colonna', s0, -hw + sx * r * 1.3 - 0.12, -hw + sx * r * 1.3 + 0.12, CO, CO + r * 1.45, ze - 0.5, ze - 0.18, 1)
            b.box('colonna', s0, -hw - r * 1.6, -hw + r * 1.6, -0.3, CO + r * 1.6, ze - 0.18, ze, 1)
        if L > 0:       # plinto della statua dentro l'arco
            b.box('trav2', s0, -0.55, 0.55, -1.4, -0.3, th, th + 0.45, 1)
    if num:
        geo.numeral(b, 'numero', s0, geo.roman(num), 8.58, 0.6, 0.955, 0.962)
    # ATTICO
    b.box('colonna', s0, -hw - 0.55, -hw + 0.55, 0, 0.4, 35.7, 45.0, 1)
    b.box('colonna', s0, -hw - 0.7, -hw + 0.7, 0, 0.55, 45.0, 45.6, 1)
    if k % 2:
        b.box('trav', s0, -hw, -0.65, FT, 0, 35.7, 45.6, 2)
        b.box('trav', s0, 0.65, hw, FT, 0, 35.7, 45.6, 2)
        b.box('trav', s0, -0.65, 0.65, FT, 0, 35.7, 37.6, 1)
        b.box('trav', s0, -0.65, 0.65, FT, 0, 39.9, 45.6, 1)
        b.box('trav2', s0, -0.8, 0.8, 0, 0.12, 37.45, 37.6, 1)
    else:
        b.box('trav', s0, -hw, hw, FT, 0, 35.7, 45.6, 4)
        b.disk('bronzo', s0, 0, 0.0, 39.9, 0.9)
    for xc in (-W / 3, 0.0, W / 3):
        b.box('trav2', s0, xc - 0.3, xc + 0.3, 0, 0.95, 43.8, 44.6, 1)
        b.cyl('legno', s0, xc, 0.62, 44.6, 54.4, 0.15, 8, 0.11)

# cornici continue (profili off,z)
PROF = {
    'gradini': [(-14.0, 0.0), (1.0, 0.0), (1.0, 0.3), (0.5, 0.3), (0.5, 0.6), (-14.0, 0.6)],
    'E1': [(FT, 8.15), (0.92, 8.15), (0.92, 8.3), (0.96, 8.3), (0.96, 9.0), (0.84, 9.0), (0.84, 9.7), (1.02, 9.72), (1.02, 9.9), (1.32, 10.15), (1.45, 10.3), (1.45, 10.5), (FT, 10.5)],
    'P2': [(FT, 10.5), (0.86, 10.5), (0.86, 10.72), (0.74, 10.85), (0.74, 12.55), (0.88, 12.68), (0.88, 12.85), (FT, 12.85)],
    'E2': [(FT, 20.2), (0.86, 20.2), (0.86, 20.35), (0.9, 20.35), (0.9, 20.95), (0.78, 20.95), (0.78, 21.55), (0.95, 21.58), (1.22, 21.98), (1.35, 22.12), (1.35, 22.3), (FT, 22.3)],
    'P3': [(FT, 22.3), (0.8, 22.3), (0.8, 22.48), (0.68, 22.6), (0.68, 24.02), (0.82, 24.13), (0.82, 24.25), (FT, 24.25)],
    'E3': [(FT, 31.6), (0.82, 31.6), (0.82, 31.75), (0.86, 31.75), (0.86, 32.3), (0.74, 32.3), (0.74, 32.9), (0.9, 32.93), (1.18, 33.3), (1.3, 33.42), (1.3, 33.6), (FT, 33.6)],
    'PA': [(FT, 33.6), (0.72, 33.6), (0.72, 33.8), (0.58, 33.92), (0.58, 35.5), (0.72, 35.7), (FT, 35.7)],
    'TOP': [(FT, 45.6), (0.62, 45.6), (0.62, 46.3), (0.5, 46.3), (0.5, 47.2), (0.75, 47.3), (1.4, 47.95), (1.8, 48.2), (1.8, 48.5), (FT, 48.5)],
}
for key, pr in PROF.items():
    b.sweep('trav2' if key != 'gradini' else 'lastre', pr, n=1440)

# ------------------------------------------------------------------ CORRIDOI E MURO 2
LV = [(0.6, 10.75, 11.85), (11.85, 22.15, 23.25), (23.25, 32.5, 33.6)]   # pavimento, chiave volta, piano sopra
for f0, crown, f1 in LV:
    b.sweep('muro_int', [(FT, crown), (-14.0, crown), (-14.0, f1), (FT, f1)], n=720)
    for oo, oi in ((FT, -7.6), (-9.5, -14.0)):
        oc = (oo + oi) / 2; r = (oo - oi) / 2; zs = crown - r
        arc = [(oc + r * math.cos(math.pi * i / 12), zs + r * math.sin(math.pi * i / 12)) for i in range(13)]
        b.sweep('muro_int', arc + [(oi, crown), (oo, crown)], n=720)
for k in range(NBAY):
    s0 = bay_s(k)
    for f0, crown, f1 in LV:
        zsp = f0 + 4.2
        b.box('muro_int', s0, -hw, -AW / 2, -9.5, -7.6, f0, crown, 2)
        b.box('muro_int', s0, AW / 2, hw, -9.5, -7.6, f0, crown, 2)
        b.spandrel('muro_int', s0, AW, zsp, crown, -9.5, -7.6)
        if not (k == CAM_BAY and f0 < 1):   # porte buie nel muro della cavea (finte, tranne la nostra)
            b.box('buio', s0, -1.4, 1.4, -14.02, -14.0, f0, f0 + 4.6, 1)

# PORTA (Nico 25/11: «dove si entra si deve vedere»): archi del piano terra chiusi da cancelli di bronzo,
# l'arco LII aperto coi battenti spalancati, due bracieri accesi, stendardi rossi e luce calda dentro il passaggio
_zs0 = ZS[0]; _r0 = AW / 2
for k in range(NBAY):
    s0 = bay_s(k)
    if k == CAM_BAY:
        continue
    x = -_r0 + 0.12
    while x < _r0 - 0.08:
        top = _zs0 + math.sqrt(max(0.0, _r0 ** 2 - x ** 2)) - 0.06
        b.box('bronzo', s0, x - 0.025, x + 0.025, -1.45, -1.37, TH[0], top, 1)
        x += 0.28
    for zr in (TH[0] + 0.9, TH[0] + 3.2):
        b.box('bronzo', s0, -_r0, _r0, -1.47, -1.35, zr, zr + 0.08, 1)
s0 = bay_s(CAM_BAY)
for sg in (-1, 1):                                       # battenti aperti contro i fianchi del passaggio
    o = -1.5
    while o > -3.5:
        b.box('bronzo', s0, sg * (_r0 - 0.12) - 0.025, sg * (_r0 - 0.12) + 0.025, o - 0.03, o + 0.03, TH[0], _zs0 + 0.4, 1)
        o -= 0.28
    for zr in (TH[0] + 0.9, TH[0] + 3.2):
        b.box('bronzo', s0, sg * (_r0 - 0.12) - 0.04, sg * (_r0 - 0.12) + 0.04, -3.5, -1.45, zr, zr + 0.08, 1)
    xb = sg * 3.35                                        # bracieri su tripode davanti ai pilastri
    for a3 in range(3):
        aa = 2 * math.pi * a3 / 3
        b.cyl('bronzo', s0, xb + 0.28 * math.cos(aa), 1.3 + 0.28 * math.sin(aa), TH[0], TH[0] + 1.25, 0.04, 6, 0.03)
    b.cyl('bronzo', s0, xb, 1.3, TH[0] + 1.2, TH[0] + 1.55, 0.22, 16, 0.5)
    b.cyl('fuoco', s0, xb, 1.3, TH[0] + 1.5, TH[0] + 2.4, 0.42, 12, 0.02)
    b.box('porpora', s0, sg * 2.75 - 0.75, sg * 2.75 + 0.75, 0.35, 0.42, 9.6, 17.6, 1)     # stendardi
    b.box('oro', s0, sg * 2.75 - 0.78, sg * 2.75 + 0.78, 0.33, 0.44, 9.3, 9.6, 1)
    b.box('oro', s0, sg * 2.75 - 0.8, sg * 2.75 + 0.8, 0.3, 0.46, 17.6, 17.75, 1)
flush(b, 'facciata', C_STRUT)
print('facciata ok', flush and len(b.parts))

# ------------------------------------------------------------------ CAVEA
def righe(d0, z0, n, rise, tread):
    pts = []
    d, z = d0, z0
    for i in range(n):
        pts.append((d, z + rise)); d += tread; z += rise; pts.append((d, z))
    return pts, d, z


prof = [(0.0, 0.0), (0.0, 3.6), (2.4, 3.6)]
d, z = 2.4, 3.6
for i in range(3):
    prof += [(d, z + 0.35), (d + 1.0, z + 0.35)]; d += 1.0; z += 0.35
prof += [(d, z + 1.4)]; z += 1.4; prof += [(d + 1.2, z)]; d += 1.2
SEZ = []
p1, d, z = righe(d, z, 20, 0.38, 0.57); prof += p1; SEZ.append((6.6, 6.05, 20, 0.38, 0.57))
W1 = (d, z)
prof += [(d + 1.4, z)]; d += 1.4; prof += [(d, z + 1.5)]; z += 1.5
SEZ.append((d, z, 16, 0.40, 0.55)); p2, d, z = righe(d, z, 16, 0.40, 0.55); prof += p2
W2 = (d, z)
prof += [(d + 1.32, z)]; d += 1.32; prof += [(d, z + 1.5)]; z += 1.5
SEZ.append((d, z, 16, 0.42, 0.46)); p3, d, z = righe(d, z, 16, 0.42, 0.46); prof += p3
TOPCAV = (d, z)
prof += [(d, z + 5.0), (37.0, z + 5.0), (37.0, 0.0)]
print('cavea: walk1', W1, 'walk2', W2, 'cima', TOPCAV)
Z_LEGNO0 = z + 5.0
BALTEI = [(5.4, 6.05), (W1[0] + 1.4, W1[1] + 1.5), (W2[0] + 1.32, W2[1] + 1.5)]
cav_prof = [(dd - geo.D_TOT, zz) for dd, zz in prof]
bc = Builder(); bc.sweep('sedili', cav_prof, n=1440)
V, F = bc.parts['sedili']
cavea = mesh_obj('cavea', V, F, 'sedili', C_STRUT)

# tagli: vomitori (ogni 2 campate, sfalsati per livello) + rampa della camera
cut = Builder()
VOM = []   # (bay, d_bocca, d_fondo, z_pavimento)
walks = [(5.4 + 0.6, 6.05), (W1[0] + 0.7, W1[1]), (W2[0] + 0.66, W2[1])]
for lev, (dw, zw) in enumerate(walks):
    for k in range(NBAY):
        if (k + lev) % 2 or k % 20 == 0:
            continue
        VOM.append((k, dw, dw + 6.5, zw))
        s0 = bay_s(k)
        cut.box('c', s0, -1.3, 1.3, dw + 6.5 - 51, dw - 51, zw, zw + 3.1, 2)
# rampa sotto la cavea verso il vomitorio del livello 2 nella campata della camera
dw, zw = walks[1]
RAMP = dict(d_in=37.6, d_top=dw + 3.0, z_top=zw)
s0 = bay_s(CAM_BAY)
d_in, d_top = RAMP['d_in'], RAMP['d_top']
pts = [(d_in, -0.4), (d_top, zw), (d_top, zw + 4.6), (d_in, -0.4 + 4.6)]
# prisma radiale: costruito in (d, z) con larghezza in x
Vr = []; Fr = []
for x in (-2.4, 2.4):
    for dd, zz in pts:
        Vr.append(M(s0 + x, dd - 51, zz))
Fr = [(0, 1, 2, 3), (7, 6, 5, 4), (0, 4, 5, 1), (1, 5, 6, 2), (2, 6, 7, 3), (3, 7, 4, 0)]
cut.raw('c', Vr, Fr)
cut.box('c', s0, -2.4, 2.4, d_top + 0.2 - 51, walks[1][0] - 51 - 0.3, zw, zw + 4.6, 2)
Vc, Fc = cut.parts['c']
cutter = mesh_obj('tagli', Vc, Fc, None, C_STRUT)
_bm = bmesh.new(); _bm.from_mesh(cutter.data); bmesh.ops.recalc_face_normals(_bm, faces=_bm.faces); _bm.to_mesh(cutter.data); _bm.free()
_bm = bmesh.new(); _bm.from_mesh(cavea.data); bmesh.ops.recalc_face_normals(_bm, faces=_bm.faces); _bm.to_mesh(cavea.data); _bm.free()
mod = cavea.modifiers.new('tagli', 'BOOLEAN'); mod.operation = 'DIFFERENCE'; mod.object = cutter
mod.solver = 'EXACT'; mod.use_self = True; mod.use_hole_tolerant = True
dg = bpy.context.evaluated_depsgraph_get()
newme = bpy.data.meshes.new_from_object(cavea.evaluated_get(dg))
cavea.modifiers.clear(); old = cavea.data; cavea.data = newme; bpy.data.meshes.remove(old)
bpy.data.objects.remove(cutter, do_unlink=True)
cavea.data.materials.clear(); cavea.data.materials.append(MAT['sedili'])
print('cavea tagliata', len(cavea.data.polygons))

# gradini nella rampa (pietra) — 0,3 m di alzata
bs = Builder()
slope = (zw + 0.4) / (d_in - d_top)
nst = int((zw + 0.4) / 0.30)
for i in range(nst):
    zz0 = -0.4 + i * 0.30; dd = d_in - (zz0 + 0.4) / slope
    if zz0 + 0.3 < 0.6:
        continue
    bs.box('lastre', s0, -2.38, 2.38, dd - 51 - (0.30 / slope), dd - 51, max(0.6, zz0 - 0.3), zz0 + 0.3, 2)
flush(bs, 'scala', C_STRUT)

# legno in cima (maenianum summum in ligneis) + portico + tetto
bl = Builder()
pl = [(37.0, 33.6), (37.0, Z_LEGNO0)]
dd, zz = 37.0, Z_LEGNO0
for i in range(10):
    pl += [(dd, zz + 0.42), (dd + 0.6, zz + 0.42)]; dd += 0.6; zz += 0.42
Z_GALL = zz
pl += [(48.3, zz), (48.3, 33.6)]
bl.sweep('legno', [(a - 51, c) for a, c in pl], n=1440)
bl.sweep('trav2', [(43.0 - 51, 44.5), (48.3 - 51, 44.5), (48.3 - 51, 45.3), (42.7 - 51, 45.3), (42.7 - 51, 44.9)], n=1440)
for k in range(120):
    s0c = k * PERIM / 120
    bl.cyl('marmo', s0c, 0, 43.3 - 51, Z_GALL, 44.5, 0.44, 16, 0.38)
    bl.cyl('marmo', s0c, 0, 43.3 - 51, 44.2, 44.5, 0.5, 16, 0.56)
flush(bl, 'portico', C_STRUT)
LEGNO = (37.0, Z_LEGNO0, 10, 0.42, 0.6)

# podio: parapetto, rivestimento marmo, palchi
bp = Builder()
bp.sweep('marmo', [(-51.0 - 0.02, 0.0), (-51.0 - 0.02, 3.62), (-50.4, 3.62), (-50.4, 4.7), (-50.75, 4.7), (-50.75, 3.6), (-51.0, 3.6), (-51.0, 0.0)], n=1440)
PALCHI = []
for kb, big in ((60, True), (20, False)):
    s0 = bay_s(kb); half = 9.5 if big else 6.0
    o_f = -51.0 - 0.35                                    # fronte del palco a filo del podio
    bp.box('marmo', s0, -half - 0.2, half + 0.2, o_f - 0.15, o_f + 0.35, 3.6, 5.1, 6)   # parapetto
    xs = [(-half + 0.5) + i * (2 * half - 1.0) / 5 for i in range(6)]
    for x in xs:
        bp.cyl('marmo', s0, x, o_f + 0.65, 5.0, 9.0, 0.3, 16, 0.26)
    bp.box('marmo', s0, -half - 0.4, half + 0.4, o_f - 0.3, o_f + 0.6, 9.0, 9.5, 6)
    geo.prism(bp, 'porpora', s0, [(-half - 0.6, 9.5), (half + 0.6, 9.5), (half + 0.6, 9.62), (-half - 0.6, 9.62)], o_f - 0.4, o_f + 0.1)
    _tela = []
    for i in range(13):
        for j in range(5):
            xx = -half - 0.6 + (2 * half + 1.2) * i / 12; oo = (o_f + 0.1) + ((-51.0 + 4.4) - (o_f + 0.1)) * j / 4
            _tela.append(M(s0 + xx, oo, 9.62 + 0.3 * (j / 4) - 0.2 * math.sin(math.pi * j / 4)))
    bp.raw('porpora', _tela, [(j * 13 + i, j * 13 + i + 1, (j + 1) * 13 + i + 1, (j + 1) * 13 + i) for j in range(4) for i in range(12)])
    V3 = []
    for x0 in (-half - 0.4, half + 0.4):
        pass
    # frontone basso
    bp.box('marmo', s0, -half, half, -51.0 + 4.0, -51.0 + 4.4, 5.0, 9.9, 6)          # parete di fondo
    for sx in (-1, 1):                                                                 # fianchi chiusi
        bp.box('marmo', s0, sx * half - 0.2, sx * half + 0.2, o_f + 0.35, -51.0 + 4.4, 5.0, 9.0, 1)

    bp.box('marmo', s0, -half, half, o_f + 0.35, -51.0 + 4.4, 4.4, 5.0, 6)    # pavimento del palco
    PALCHI.append((s0, half, o_f + 0.35, 5.0))
# pali di bronzo con funi davanti al parapetto del podio (protezione)
NP = 0
for i in range(NP):
    s0 = PERIM * i / NP
    if any(abs((s0 - pp[0] + PERIM / 2) % PERIM - PERIM / 2) < pp[1] + 1 for pp in PALCHI):
        continue
    bp.cyl('bronzo', s0, 0, -50.55, 4.7, 6.4, 0.05, 6)

# cimase dei baltei
for dd, zz in BALTEI:
    bp.sweep('marmo', [(dd - 51 - 0.12, zz), (dd - 51 + 0.35, zz), (dd - 51 + 0.35, zz + 0.16), (dd - 51 - 0.12, zz + 0.16)], n=1440)
# pannelli scuri dipinti sul fronte del podio
bp.sweep('marmo2', [(-51.05, 0.0), (-51.05, 0.45), (-51.0, 0.45), (-51.0, 0.0)], n=1440)
bp.sweep('marmo2', [(-51.05, 3.2), (-51.05, 3.62), (-51.0, 3.62), (-51.0, 3.2)], n=1440)
flush(bp, 'podio', C_STRUT)

# arena di sabbia (niente ipogeo nell'80 d.C.)
V, F = geo.ellipse_disk_mesh(-51.0, 0.03)
mesh_obj('arena', V, F, 'sabbia', C_STRUT)

# statue negli archi del 2° e 3° piano
statue = [folla.figura('statua%d' % i, p, br, gesto=g) for i, (p, br, g) in enumerate((('in_piedi', False, None), ('in_piedi', False, 'braccia'), ('in_piedi', False, None), ('in_piedi', False, 'braccia')))]
bst = Builder()
SV = [([v.co.copy() for v in st.data.vertices], [tuple(p.vertices) for p in st.data.polygons]) for st in statue]
for k in range(NBAY):
    s0 = bay_s(k)
    for L in (1, 2):
        sc = 1.75
        sv, sf = SV[(k * 3 + L * 7) % 4]
        rot = random.uniform(-0.5, 0.5)
        cs, sn = math.cos(rot), math.sin(rot)
        V2 = []
        for co in sv:
            x = co.x * cs - co.y * sn; y = co.x * sn + co.y * cs
            V2.append(M(s0 + x * sc, -0.85 + y * sc, TH[L] + 0.45 + co.z * sc))
        bst.raw('marmo', V2, sf)
[bpy.data.objects.remove(st, do_unlink=True) for st in statue]
for o in flush(bst, 'statue', C_STRUT):
    for p in o.data.polygons:
        p.use_smooth = True

# VELARIO: teli arrotolati (Nico 25/11: Colosseo tutto aperto). Restano solo i 240 alberi di legno sull'attico.

# ------------------------------------------------------------------ FUORI, FOLLA, LUCE, CAMERA
ambiente.CITTA = True
ambiente._quota = roma.quota
roma.AV = ambiente.AV
_sc = bay_s(CAM_BAY); _pc, _nc = frame(_sc); _tc = np.array([-_nc[1], _nc[0]])
ambiente.AV.update(pc=_pc, nc=_nc, tc=_tc)
roma.FLAT[:] = [(roma.BR(208, 640), 230), (roma.BR(296, 720), 170)]
ambiente.ESC = roma.escludi_fn(ambiente.AV)
ambiente.costruisci(scn, MAT, C_FUORI, mesh_obj, CAM_BAY, LEGGERO)
C_ROMA = colle('Roma')
br = Builder(); roma.monumenti(br, ambiente.AV)
_ra = random.Random(31)
for gx, gy, gr, gn in roma.GIARDINI:                     # alberi nei giardini (Palatino, terrazza di Claudio)
    k = 0; tent = 0
    while k < gn and tent < gn * 20:
        tent += 1; a = _ra.uniform(0, 2 * math.pi); r = gr * math.sqrt(_ra.random()); x = gx + r * math.cos(a); y = gy + r * math.sin(a)
        hit = bpy.context.scene  # quota del tetto/terrazza: sulla terrazza di Claudio gli alberi stanno sopra (z + 9,4)
        z = roma.quota(x, y) + (9.4 if abs(x - 0) < 84 and abs(y + 330) < 94 else 0.0)
        if gx == 0.0 and not (abs(x) < 80 and abs(y + 330) < 90 and not (abs(x) < 16 and -310 < y + 0 < -250)):
            continue
        ambiente._albero(br, x, y, z, _ra); k += 1
flush(br, 'roma', C_ROMA)
roma.citta(scn, MAT, C_ROMA, ambiente.ESC, random.Random(753), LEGGERO)
C_COR = colle('Corteo')
n_col = corteo.colonne(scn, MAT, C_COR, _pc, _nc, _tc)
corteo.polvere_viale(scn, _pc, _nc, _tc)
corteo.polvere_arena(scn)
_cg = _pc + _nc * regia.CENTRO_GLAD_ALONG
_dg = _pc + _nc * (regia.CENTRO_GLAD_ALONG + 3.0) - _tc * 0.8   # coppia che combatte dove arriva la camera
corteo.gladiatori(scn, MAT, C_COR, (float(_cg[0]), float(_cg[1])), fronte=(float(_tc[0]), float(_tc[1])), duello=(float(_dg[0]), float(_dg[1])))
folla.PALCHI = PALCHI
_dw, _zw = walks[1]
_E = np.array([*(_pc + _nc * (_dw - 51 - 2.6)), _zw + 2.3]); _SA = np.array([*(_pc + _nc * (12.0 - 51)), 6.05 + (12.0 - 6.6) / 0.57 * 0.38 + 1.15])
folla.ESCLUSI = [(_SA, 0.65), ((_E + _SA) / 2, 1.0), (_SA + (_SA - _E) * 0.12, 0.6)]
folla.costruisci(scn, MAT, C_FOLLA, SEZ, LEGNO, VOM, CAM_BAY, LEGGERO)
import mercato
mercato.DISORDINE = FOTO
n_merc = mercato.costruisci(scn, MAT, C_FOLLA, ambiente.AV, LEGGERO)
import viale
viale.FOTO = FOTO
n_viale = viale.costruisci(scn, MAT, C_FOLLA, ambiente.AV, LEGGERO)
ambiente.luce_e_camera(scn, MAT, CAM_BAY, RAMP, walks, LEGGERO)
for _sg in (-1, 1):                                     # luce dei bracieri
    ambiente._lucerna(scn, M(bay_s(CAM_BAY) + _sg * 3.35, 1.3, TH[0] + 2.6), 260.0)
for _o in (-4.5, -10.0):                                # passaggio d'ingresso illuminato (si vede che è la porta)
    ambiente._lucerna(scn, M(bay_s(CAM_BAY), _o, 4.6), 420.0)
info, _ = regia.giro_film(scn, CAM_BAY, RAMP, walks)
nfo = info['totale']
_pa = bpy.data.objects['polvere_arena']          # polvere dell'arena accesa solo quando si entra (risparmia GPU)
_fa = info['f_arco']
_pa.hide_render = True; _pa.keyframe_insert('hide_render', frame=1); _pa.keyframe_insert('hide_render', frame=_fa - 1)
_pa.hide_render = False; _pa.keyframe_insert('hide_render', frame=_fa)
# bighe verso il Colosseo al passo (4,5 m/s) nelle corsie a ±3 m: la camera le sorpassa in strada (secondi 9,5-12,5)
corteo.bighe_film(scn, MAT, C_COR, _pc, _nc, _tc, info['totale'], [(-3.0, 54.0, 8.4, 34.0), (3.0, 45.0, 9.3, 31.0), (-3.0, 35.0, 10.3, 22.0), (3.0, 26.0, 11.2, 19.0)])
corteo.petali(scn, MAT, C_COR, _pc, _nc, _tc, info['totale'])
if FOTO:
    import foto_extra
    foto_extra.applica(scn, MAT, mesh_obj, C_ROMA)
cont = dict(roma.STATS); cont['colosseo'] = 1; cont['colonne_corteo'] = n_col
cont['totale_edifici'] = cont['edifici_citta'] + cont['monumenti'] + 1
cont['mercato'] = dict(banchi=n_merc[0], persone=n_merc[1], botteghe=n_merc[2])
cont['regia'] = info
json.dump(cont, open(os.path.splitext(OUT)[0] + '_conteggio.json', 'w'), indent=1)
print('CONTEGGIO', json.dumps(cont))

bpy.ops.wm.save_as_mainfile(filepath=OUT, compress=True)
print('SALVATO', OUT)
