HOUSE BUILDER · a skill for Claude
==================================

What it does
Claude builds you a complete website where a house builds itself while people scroll or hold a
button: from the blueprint to the stake-out, the foundation, the frame, the roof, the walls and the
garden, with a big caption for every phase and your button at the end. It works on phones and you
can put it online for free.

You bring the pictures of your house: one photo per phase (stills mode), or the clips between the
phases (frames mode, the house really rises and the camera turns, like our demo). If you do not have
them yet, the skill gives Claude our prompts to make them, the same ones in the Full Build Blueprint.

What you need
- A paid Claude plan that includes Skills (Pro or above) on claude.ai or in the Claude app,
  or Claude Code on your computer.
- On claude.ai, "Create and edit files" switched on in Settings > Capabilities
  (older screens call it "Code execution and file creation").
- For frames mode (clips): Claude Code on your computer, with ffmpeg installed
  (macOS: brew install ffmpeg). Stills mode works everywhere.


INSTALL ON CLAUDE.AI OR THE CLAUDE APP
1. Keep the zip you downloaded (house-builder-skill.zip) as it is. Do not unzip it.
   On a Mac, download it with Chrome: Safari unzips downloads by itself and deletes
   the zip. If you only have a folder called house-builder, right-click it, choose
   Compress "house-builder" and use the new house-builder.zip.
2. Open Settings > Capabilities and check that "Create and edit files" is on.
3. In the menu on the left click Plugins, then Add (top right) > Upload plugin,
   choose the zip and click Upload.
4. Claude says "House builder is added and ready to use" and lists it under Your
   plugins as a Skill. Start a new chat and send your first message (below).
   (Older screens: Settings > Capabilities > Skills > Upload skill, same zip.)

INSTALL IN CLAUDE CODE
1. Unzip house-builder-skill.zip. You get a folder called house-builder.
2. Move it into your skills folder:
     macOS / Linux:  ~/.claude/skills/house-builder
     Windows:        %USERPROFILE%\.claude\skills\house-builder
3. Start a new Claude Code session. Type /skills to check it is listed.


YOUR FIRST MESSAGE
Put your phase photos (or clips) in a folder, open Claude there and write, changing the brackets:

  Build me a hold to build page for [brand] with these photos, in order.
  The last button opens [your link]. Page in [language], accent colour [colour].

No pictures yet? Ask:
  "Help me make the pictures for a hold to build house: a [style] house in [place]."


WHAT YOU GET
A folder with index.html, build.js, ui.css, frames.js and your pictures. No installation, no build
step. To change words, colours or the button later, ask Claude, or edit the CONFIG part at the top
of build.js yourself (every field is explained in references/config.md).

To open it on your computer: in the folder run   python3 -m http.server 8080
and open http://localhost:8080 in your browser.


PUT IT ONLINE FOR FREE
Netlify Drop: go to app.netlify.com/drop and drag the folder onto the page. Free account to keep it.
Vercel: free Hobby account, Add New > Project, drag the folder in. Framework "Other", no build command.
Both give an https link that works on phones. To update, drag the new folder again.


GOOD TO KNOW
- Every picture must be the same view of the same house, or the fades jump. The prompts lock the camera.
- Frames mode is heavier: about 40 to 60 MB for nine 5-second clips. Try it on your phone before sharing.
- Only use pictures you made or own, and only your own brand and claims.
