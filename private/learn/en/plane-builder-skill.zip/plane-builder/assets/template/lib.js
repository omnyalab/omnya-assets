// pezzi presi dal reel (film.js): utilità, biglietto piccolo, titoli di classe, pill e barra oro
const W = 1920, H = 1080, FPS = 24, CQ = 19.2;              // 1cqw = 19.2 px come i biglietti dello stadio
const ROUTE = { from: FLIGHT.from, to: FLIGHT.to, fromN: FLIGHT.fromName, toN: FLIGHT.toName, cur: FLIGHT.currency };
const cv = document.getElementById('c'), ctx = cv.getContext('2d');
ctx.imageSmoothingQuality = 'high';
const off = document.createElement('canvas'); off.width = 1400; off.height = 640; const ox = off.getContext('2d');

// ---------------- utilità ----------------
const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const ss = x => { x = clamp(x); return x * x * (3 - 2 * x); };
const ramp = (r, a, b) => clamp((r - a) / (b - a));
const spring = t => t <= 0 ? 0 : t >= 1 ? 1 : 1 - Math.exp(-6 * t) * Math.cos(7 * t);
const q = v => v * CQ;
const PAPER = '#fbfaf7', INK = '#121317', MUTE = '#8a8f99', ORC = '#ff7a12', OKC = '#21a35b', FEW = '#e07a00', NO = '#d23b3b';
const DARK0 = '#17171b', DARK1 = '#2b2520', GOLD = '#d8b27a', CREAM = '#f3e7d6';
const font = (f, cqw) => `${Math.round(q(cqw))}px ${f}`;
function caps(c, x, y, t, cqw, col, track = 0.12) { c.font = font('SFTS', cqw); c.letterSpacing = `${(track * q(cqw)).toFixed(2)}px`; c.fillStyle = col; c.fillText(t.toUpperCase(), x, y); const w = c.measureText(t.toUpperCase()).width; c.letterSpacing = '0px'; return w; }
function capsW(c, t, cqw, track = 0.12) { c.font = font('SFTS', cqw); c.letterSpacing = `${(track * q(cqw)).toFixed(2)}px`; const w = c.measureText(t.toUpperCase()).width; c.letterSpacing = '0px'; return w; }
function txt(c, x, y, t, f, cqw, col) { c.font = font(f, cqw); c.fillStyle = col; c.fillText(t, x, y); return c.measureText(t).width; }
function tw(c, t, f, cqw) { c.font = font(f, cqw); return c.measureText(t).width; }
function dashV(c, x, y0, y1, col) { c.save(); c.strokeStyle = col; c.lineWidth = Math.max(1, q(0.18)); c.setLineDash([q(0.55), q(0.4)]); c.beginPath(); c.moveTo(x, y0); c.lineTo(x, y1); c.stroke(); c.restore(); }
function bars(c, x, y, h, len, col) {   // codice a barre verticale come lo stadio
  const n = 30, ws = []; for (let i = 1; i <= n; i++) ws.push(i % 3 === 0 ? 0.45 : i % 5 === 0 ? 0.1 : i % 7 === 0 ? 0.32 : 0.2);
  const tot = ws.reduce((a, b) => a + b, 0) + 0.2 * (n - 1), k = len / q(tot); let p = y; c.fillStyle = col;
  for (const w of ws) { const b = Math.max(1, q(w * k)); c.fillRect(x, p, h, b); p += b + q(0.2 * k); }
}
function cover(c, im, x, y, w, h, fx = 0.5, fy = 0.5) {
  const iw = im.naturalWidth || 1, ih = im.naturalHeight || 1, r = Math.max(w / iw, h / ih), sw = w / r, sh = h / r;
  c.drawImage(im, (iw - sw) * fx, (ih - sh) * fy, sw, sh, x, y, w, h);
}

// ---------------- biglietto piccolo (come lo stadio) ----------------
function smallTicket(eyebrow, title, price, avail) {   // testi centrati sull'altezza delle maiuscole
  const c = ox, pad = 26, rE = 24, rT = 48, rA = avail ? 30 : 0;
  const wTxt = Math.max(tW(c, eyebrow, 'SFTS', 16, 0.14, true), tW(c, title, 'SFD', 40), avail ? tW(c, avail[0], 'SFTB', 20) + 24 : 0);
  const wA = Math.round(pad * 2 + wTxt), wS = Math.round(Math.max(128, tW(c, price, 'SFD', 36) + 56)), w = wA + wS, h = Math.round(pad * 2 + rE + rT + rA - 6);
  c.clearRect(0, 0, off.width, off.height); c.save();
  c.fillStyle = PAPER; c.beginPath(); c.roundRect(0, 0, w, h, 20); c.fill();
  let y = pad - 3 + rE / 2; tText(c, eyebrow, pad, y, 'SFTS', 16, MUTE, 'left', 0.14, true);
  y += rE / 2 + rT / 2; tText(c, title, pad, y, 'SFD', 40, INK);
  if (avail) { y += rT / 2 + rA / 2; const col = { ok: OKC, few: FEW, no: NO }[avail[1]]; c.fillStyle = col; c.beginPath(); c.arc(pad + 7, y, 7, 0, 7); c.fill(); tText(c, avail[0], pad + 24, y, 'SFTB', 20, col); }
  dashV(c, wA, 10, h - 10, '#c9ccd3');
  tText(c, ROUTE.cur, wA + wS / 2, h / 2 - 20, 'SFTS', 16, MUTE, 'center', 0.14, true);
  tText(c, price, wA + wS / 2, h / 2 + 16, 'SFD', 36, ORC, 'center');
  c.restore(); return { w, h };
}
function putSmall(sz, ax, ay, t, out = 0, below = false) {   // ax,ay = punta del biglietto; t = tempo dall'entrata
  const e = spring(t * 1.6), op = ss(t / 0.4) * (1 - ss(out)); if (op <= 0.003) return;
  let x = ax - sz.w / 2, y = below ? ay + q(1.6) - (1 - e) * 23 : ay - sz.h - q(1.6) + (1 - e) * 23;
  x = clamp(x, 16, W - sz.w - 16); y = clamp(y, 16, H - sz.h - 16);
  ctx.save(); ctx.globalAlpha = op; ctx.shadowColor = 'rgba(0,0,0,0.38)'; ctx.shadowBlur = q(1.6); ctx.shadowOffsetY = q(0.9);
  ctx.drawImage(off, 0, 0, sz.w, sz.h, x, y, sz.w, sz.h); ctx.restore();
}

// ---------------- titolo di classe a ogni cambio (stile film, non retro): velo scuro leggero + titolo grande al centro ----------------
const TITLES = {
  K2: { n: '01', name: 'Economy', sub: '3-4-3  ·  From $' + FLIGHT.price.E, tint: [0, 0, 0], line: '#ff7a12' },
  K3: { n: '02', name: 'Premium Economy', sub: '2-3-2  ·  From $' + FLIGHT.price.P, tint: [0, 0, 0], line: '#ff7a12' },
  K5: { n: '03', name: 'First', sub: '6 private suites  ·  From $' + FLIGHT.price.F, tint: [8, 8, 10], line: '#c9a46a' },
  K6: { n: '04', name: 'The Residence', sub: 'One per flight  ·  $' + FLIGHT.price.R, tint: [22, 15, 6], line: 'gold', gold: true },
};
function classTitle(T, r) {   // tutto morbido: curve ease, il velo arriva prima e va via dopo, i testi entrano/escono sfumati e un filo sfocati, uno dopo l'altro
  const D = 2.0, eio = x => { x = clamp(x); return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; };   // ease in-out cubica
  const veil = eio(ramp(r, 0.0, 0.5)) * (1 - eio(ramp(r, D - 0.55, D))); if (veil <= 0.003) return;
  const inT = (d) => eio(ramp(r, 0.12 + d, 0.62 + d)), outT = eio(ramp(r, D - 0.62, D - 0.12));   // entrata a scaletta, uscita insieme
  ctx.save();
  const [tr, tg, tb] = T.tint;
  ctx.globalAlpha = veil; ctx.fillStyle = `rgba(${tr},${tg},${tb},0.5)`; ctx.fillRect(0, 0, W, H);
  const g = ctx.createRadialGradient(W / 2, H / 2, H * 0.25, W / 2, H / 2, H * 1.05); g.addColorStop(0, `rgba(${tr},${tg},${tb},0)`); g.addColorStop(1, `rgba(${tr},${tg},${tb},0.55)`);
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  const item = (d, fn) => {   // ogni testo: sale piano entrando, sale ancora uscendo, sfocato ai bordi del movimento
    const ei = inT(d), a = ei * (1 - outT); if (a <= 0.003) return;
    const dy = (1 - ei) * 16 - outT * 10, bl = (1 - ei) * 6 + outT * 5;
    ctx.save(); ctx.globalAlpha = a; ctx.filter = bl > 0.3 ? `blur(${bl.toFixed(1)}px)` : 'none'; fn(dy, ei); ctx.restore();
  };
  const cy = H / 2;
  ctx.shadowColor = 'rgba(0,0,0,0.35)'; ctx.shadowBlur = 24;
  item(0, dy => tText(ctx, 'Class ' + T.n + ' / 04', W / 2, cy - 92 + dy, 'SFTS', 20, 'rgba(255,255,255,0.78)', 'center', 0.32, true));
  item(0.07, (dy, ei) => { const track = 0.02 + (1 - ei) * 0.05; let fill = '#ffffff';
    if (T.gold) { const tw0 = tW(ctx, T.name, 'SFD', 112, track); fill = metal(ctx, W / 2 - tw0 / 2, cy - 50, W / 2 + tw0 / 2, cy + 50); }
    tText(ctx, T.name, W / 2, cy + dy, 'SFD', 112, fill, 'center', track); });
  item(0.14, (dy, ei) => { ctx.shadowColor = 'transparent'; const lw = 140 * ei; ctx.fillStyle = T.line === 'gold' ? metal(ctx, W / 2 - lw / 2, 0, W / 2 + lw / 2, 0) : T.line; ctx.fillRect(W / 2 - lw / 2, cy + 74 + dy, lw, 3); });
  item(0.2, dy => { ctx.shadowColor = 'rgba(0,0,0,0.35)'; ctx.shadowBlur = 16; tText(ctx, T.sub, W / 2, cy + 116 + dy, 'SFTS', 26, 'rgba(255,255,255,0.9)', 'center', 0.04); });
  ctx.restore();
}

// ---------------- pill premium della Residence: vetro scuro, bordo d'oro, testi centrati ----------------
function chipGold(eyebrow, tx, op) {
  if (op <= 0.003) return; ctx.save(); ctx.globalAlpha = op;
  const pe = 17, pt = 25, gap = 18, we = tW(ctx, eyebrow, 'SFTB', pe, 0.22, true), wt = tW(ctx, tx, 'SFTS', pt), w = 44 + we + gap + 1 + gap + wt + 44, h = 64, x = W / 2 - w / 2, y = 54;
  ctx.fillStyle = 'rgba(14,11,8,0.66)'; ctx.beginPath(); ctx.roundRect(x, y, w, h, h / 2); ctx.fill();
  ctx.strokeStyle = metal(ctx, x, y, x + w, y + h); ctx.lineWidth = 1.6; ctx.stroke();
  const cy = y + h / 2; let xx = x + 44;
  tText(ctx, eyebrow, xx, cy, 'SFTB', pe, metal(ctx, xx, cy - 10, xx + we, cy + 10), 'left', 0.22, true); xx += we + gap;
  ctx.fillStyle = 'rgba(217,177,112,0.5)'; ctx.fillRect(xx, cy - 14, 1, 28); xx += 1 + gap;
  tText(ctx, tx, xx, cy, 'SFTS', pt, '#f4e8d2'); ctx.restore();
}
function goldBar(c, q, btn, cyBar, op, press) {   // barra scura con bordo d'oro: domanda + bottone oro, centrata sullo schermo; ritorna il centro del bottone
  const qpx = 19, bpx = 27, pad = 36, inL = 34, inR = 9, gapQ = 24, bh = 70;
  const wq = tW(c, q, 'SFTB', qpx, 0.14, true), wb = tW(c, btn, 'SFTB', bpx) + pad * 2, barW = inL + wq + gapQ + wb + inR, barH = bh + inR * 2, bx0 = W / 2 - barW / 2;
  const bcx = bx0 + inL + wq + gapQ + wb / 2; if (op <= 0.003) return [bcx, cyBar];
  c.save(); c.globalAlpha = op;
  c.fillStyle = 'rgba(14,11,8,0.66)'; c.beginPath(); c.roundRect(bx0, cyBar - barH / 2, barW, barH, barH / 2); c.fill();
  c.strokeStyle = 'rgba(217,177,112,0.55)'; c.lineWidth = 1.4; c.stroke();
  const s = press ? 0.94 : 1, pw = wb * s, ph = bh * s;
  c.save(); c.shadowColor = 'rgba(0,0,0,0.3)'; c.shadowBlur = 12; c.shadowOffsetY = 4; c.fillStyle = metal(c, bcx - pw / 2, cyBar - ph / 2, bcx + pw / 2, cyBar + ph / 2);
  c.beginPath(); c.roundRect(bcx - pw / 2, cyBar - ph / 2, pw, ph, ph / 2); c.fill(); c.restore();
  tFont(c, 'SFTB', bpx * s); const base = cyBar + tCap(c) / 2;
  tFont(c, 'SFTB', bpx * s); c.fillStyle = '#17120a'; c.fillText(btn, bcx - tW(c, btn, 'SFTB', bpx * s) / 2, base);
  tFont(c, 'SFTB', qpx); c.letterSpacing = `${(0.14 * qpx).toFixed(2)}px`; c.fillStyle = '#e2c48a'; c.fillText(q.toUpperCase(), bx0 + inL, base); c.letterSpacing = '0px';
  c.restore(); window.__gbtn = [bcx - wb / 2, cyBar - bh / 2, bcx + wb / 2, cyBar + bh / 2]; return [bcx, cyBar];
}
