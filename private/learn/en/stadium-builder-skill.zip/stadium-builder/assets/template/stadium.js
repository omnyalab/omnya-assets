/* =====================================================================
   Stadium Builder · stadium.js
   Part 1 is CONFIG, the only part you normally edit (every field is in references/config.md).
   Part 2 is the ENGINE: it builds the 3D stadium in three.js and runs the seat picker.
   ===================================================================== */

window.STADIUM_CONFIG = {
  // ---- the venue ----
  name: 'Your Stadium',                 // shown in the page header, on the screens and on the ticket
  shortName: 'YOUR STADIUM',            // short text for the LED boards around the field
  event: { title: 'Opening night', date: 'Sat 12 Dec', time: '20:00' },
  lang: 'en',                           // <html lang>, also used for number formatting if locale is empty
  locale: 'en-IE',                      // number and price format, e.g. 'it-IT', 'pt-PT', 'en-US'
  currency: 'EUR',                      // ISO code: EUR, USD, GBP, AED, CHF...

  // ---- the shape ----
  field: 'football',                    // football | basketball | tennis | padel | plain
  size: null,                           // optional { length, width, corner } of the inner bowl in metres
  tiers: [                              // from the bottom up. More rows = more seats (check stadium.info())
    { name: 'Lower tier', rows: 34, priceFactor: 1.2 },
    { name: 'Middle tier', rows: 22, priceFactor: 1.0 },
    { name: 'Upper tier', rows: 36, priceFactor: 0.7 },
  ],
  seatWidth: 0.5,                       // metres per seat along the row
  aisleEvery: 9.4,                      // metres between aisles; every gap between two aisles is a block

  // ---- the look ----
  colors: {
    seat: '#c2304a',                    // main seat colour
    seat2: '#2459b8',                   // second seat colour, scattered
    seat2Share: 0.05,                   // 0 to 1, how many seats use seat2
    pattern: 'mixed',                   // mixed (more seat2 in front rows and bands) | scatter | solid
    brand: '#1f4fa8',                   // fascia bands, LED lines, facade glass, screens
    facade: '#d9e8fb',                  // outer diagonal fins
    accent: '#ff8a1f',                  // highlight of the stand, block and seat, and the buttons
    taken: '#a3a7ad',                   // taken seats in the block view
  },
  roof: 'ring',                         // ring (open in the middle) | closed (arena) | none
  scoreboard: 'ends',                   // ends (two screens) | center (hanging cube) | none
  surroundings: 'park',                 // park | city | desert
  look: 'day',                          // day | sunset | night

  // ---- what people buy ----
  zones: [                              // clockwise from the north long side. 8 = sides + corners, 4 = sides
    { name: 'North Stand', price: 95 },
    { name: 'North-East Corner', price: 70 },
    { name: 'East Stand', price: 55 },
    { name: 'South-East Corner', price: 70 },
    { name: 'South Stand', price: 95 },
    { name: 'South-West Corner', price: 70 },
    { name: 'West Stand', price: 55, soldOut: true },
    { name: 'North-West Corner', price: 70 },
  ],
  occupancy: 0.32,                      // share of seats already taken (sample data)
  soldOutBlocks: 0.08,                  // share of blocks fully sold out (sample data)
  vip: {
    name: 'VIP Skybox',
    upgrade: 180,                       // price added to the seat
    perks: ['Private box behind glass', 'Leather armchairs', 'Lounge, food and drinks'],
  },
  boards: [],                           // extra words for the LED boards, e.g. sponsor names
  checkoutUrl: '',                      // optional payment link; Confirm opens it with the seat in the query
  quality: 'auto',                      // auto | high | low (low = lighter for old phones)

  // ---- every word on the page (translate here) ----
  text: {
    stepPlan: 'Choose your stand', stepZone: 'Choose a block', stepBlock: 'Choose your seat',
    stepSeat: 'Your view', stepUpgrade: 'Upgrade', stepTicket: 'Your ticket',
    planHint: 'Tap a stand to see its blocks.',
    zoneHint: 'Tap a block to see its seats.',
    blockHint: 'Tap a free seat. Grey seats are taken.',
    from: 'from', left: 'seats left', soldOut: 'Sold out', taken: 'Taken', few: 'Few left',
    stand: 'Stand', tier: 'Tier', block: 'Block', row: 'Row', seat: 'Seat', box: 'Box', price: 'Price', total: 'Total',
    seeSeats: 'See the seats', takeSeat: 'Take this seat', continue: 'Continue', changeSeat: 'Change seat',
    upgradeTitle: 'Do you want an upgrade?', upgradeYes: 'Upgrade to VIP', upgradeNo: 'No thanks, keep my seat',
    yourView: 'Your view', yourBoxView: 'Your view from the box',
    confirm: 'Confirm', pay: 'Continue to payment', booked: 'Reserved', anotherSeat: 'Choose another seat', back: 'Back',
    loading: 'Building the stadium…', loadError: 'The 3D library did not load. Check the internet connection and reload.',
    note: 'Prices and availability shown are examples.',
  },
};

/* =====================================================================
   ENGINE · you rarely need to edit below this line
   ===================================================================== */
window.buildStadium = function (THREE, { OrbitControls, Sky, mergeGeometries }) {
  const C = window.STADIUM_CONFIG, COL = C.colors || {}, TX = C.text || {};
  const $ = id => document.getElementById(id);
  const Q = new URLSearchParams(location.search);
  const PHONE = matchMedia('(pointer: coarse)').matches || Math.min(innerWidth, innerHeight) < 600;
  const QUAL = Q.get('q') || C.quality || 'auto';
  const LOW = QUAL === 'low' || (QUAL === 'auto' && PHONE);
  const REDUCED = matchMedia('(prefers-reduced-motion: reduce)').matches;

  let seed = 11;
  const rnd = () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  const hash = n => { let x = (n | 0) ^ 0x9e3779b9; x = Math.imul(x ^ x >>> 16, 0x85ebca6b); x = Math.imul(x ^ x >>> 13, 0xc2b2ae35); return ((x ^ x >>> 16) >>> 0) / 4294967296; };
  const V = (x, y, z) => new THREE.Vector3(x, y, z);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const money = new Intl.NumberFormat(C.locale || C.lang || 'en', { style: 'currency', currency: C.currency || 'EUR', maximumFractionDigits: 0 });
  const num = new Intl.NumberFormat(C.locale || C.lang || 'en');
  const fmt = v => money.format(v);

  // ---------------- field presets: playing area, inner bowl, first row, front wall, LED boards ----------------
  const FIELDS = {
    football: { court: [105, 68], base: [60, 40, 16], row0: [5, 1.6], wall: 4.6, boards: [5, 4.5] },
    basketball: { court: [28, 15], base: [20, 13.5, 7], row0: [3, 0.9], wall: 2.6, boards: [3.4, 2.6] },
    tennis: { court: [23.77, 10.97], base: [24, 14, 7], row0: [3, 1.0], wall: 2.6, boards: [6.2, 3.6] },
    padel: { court: [20, 10], base: [16, 11, 6], row0: [3, 0.9], wall: 2.6, boards: [3.2, 2.8] },
    plain: { court: [70, 45], base: [45, 30, 12], row0: [4, 1.2], wall: 3.6, boards: null },
  };
  const FT = FIELDS[C.field] ? C.field : 'football', F = FIELDS[FT];
  const A0 = C.size ? C.size.length / 2 : F.base[0], B0 = C.size ? C.size.width / 2 : F.base[1];
  const R0 = clamp(C.size && C.size.corner != null ? C.size.corner : F.base[2], 2, B0 - 1);
  const WALL = F.wall, WALL_H = F.row0[1] + 0.15;

  // ---------------- the base curve: a rounded rectangle around the field ----------------
  // axes: y up, metres. x along the field (east +), z across (south +). t = metres along the base curve.
  function segments(A, B, R) {
    const a = A - R, b = B - R, H = Math.PI / 2;
    return [
      { l: 1, x0: A, z0: -b, dx: 0, dz: 1, len: 2 * b, nx: 1, nz: 0 },
      { l: 0, cx: a, cz: b, a0: 0, len: H * R },
      { l: 1, x0: a, z0: B, dx: -1, dz: 0, len: 2 * a, nx: 0, nz: 1 },
      { l: 0, cx: -a, cz: b, a0: H, len: H * R },
      { l: 1, x0: -A, z0: b, dx: 0, dz: -1, len: 2 * b, nx: -1, nz: 0 },
      { l: 0, cx: -a, cz: -b, a0: 2 * H, len: H * R },
      { l: 1, x0: -a, z0: -B, dx: 1, dz: 0, len: 2 * a, nx: 0, nz: -1 },
      { l: 0, cx: a, cz: -b, a0: 3 * H, len: H * R },
    ];
  }
  const SEG = segments(A0, B0, R0);
  let acc = 0; for (const s of SEG) { s.t0 = acc; acc += s.len; }
  const L0 = acc;
  function base(t) {
    t = ((t % L0) + L0) % L0;
    for (const s of SEG) if (t < s.t0 + s.len + 1e-9) {
      const u = t - s.t0;
      if (s.l) return { x: s.x0 + s.dx * u, z: s.z0 + s.dz * u, nx: s.nx, nz: s.nz, arc: false };
      const a = s.a0 + u / R0, c = Math.cos(a), si = Math.sin(a);
      return { x: s.cx + R0 * c, z: s.cz + R0 * si, nx: c, nz: si, arc: true };
    }
    return base(0);
  }
  const scaleAt = (t, d) => base(t).arc ? (R0 + d) / R0 : 1;
  const off = (t, d, y) => { const p = base(t); return V(p.x + p.nx * d, y, p.z + p.nz * d); };
  const segOf = t => { let k = 0; while (k < SEG.length - 1 && t >= SEG[k + 1].t0) k++; return k; };
  const SAMP = [];
  for (const s of SEG) { if (s.l) SAMP.push(s.t0); else for (let k = 0; k < 28; k++) SAMP.push(s.t0 + s.len * k / 28); }

  // sweep a profile [d, y] around the whole curve (closed ring)
  function sweep(profile, closed = false, uScale = 10, samples = SAMP) {
    const pos = [], uv = [], np = profile.length, ns = samples.length;
    const P = (i, j) => off(samples[i % ns], profile[j % np][0], profile[j % np][1]);
    const U = i => (i >= ns ? L0 : samples[i]) / uScale, Vv = j => j / (np - 1);
    const jMax = closed ? np : np - 1;
    for (let i = 0; i < ns; i++) for (let j = 0; j < jMax; j++) {
      const a = P(i, j), b = P(i + 1, j), c = P(i + 1, j + 1), d = P(i, j + 1);
      pos.push(a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z, a.x, a.y, a.z, c.x, c.y, c.z, d.x, d.y, d.z);
      const u0 = U(i), u1 = U(i + 1), v0 = Vv(j), v1 = Vv(j + 1);
      uv.push(u0, v0, u1, v0, u1, v1, u0, v0, u1, v1, u0, v1);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    g.computeVertexNormals();
    return g;
  }

  // ---------------- the tiers ----------------
  const RAKE = [[0.30, 0.50], [0.50, 0.64], [0.62, 0.80]];
  function tier(n, d0, y0, T, r0, r1) {
    const rows = []; let d = d0, y = y0;
    for (let i = 0; i < n; i++) { rows.push({ d, y, T }); d += T; y += r0 + (r1 - r0) * Math.pow(n > 1 ? i / (n - 1) : 0, 1.2); }
    return { rows, dEnd: d, yEnd: rows[n - 1].y };
  }
  const TIERS = []; {
    let prev = null;
    (C.tiers && C.tiers.length ? C.tiers : [{ name: 'Tier', rows: 20 }]).forEach((t, i) => {
      const T = t.depth || (i ? 0.85 : 0.8), rk = t.rake || RAKE[Math.min(i, 2)], n = clamp(Math.round(t.rows || 10), 2, 80);
      const d0 = i ? prev.dEnd + 0.9 : F.row0[0], y0 = i ? prev.yEnd + (i === 1 ? 5.6 : 3.6) : F.row0[1];
      prev = tier(n, d0, y0, T, rk[0], rk[1]); prev.cfg = t; TIERS.push(prev);
    });
  }
  const T1 = TIERS[0], LAST = TIERS[TIERS.length - 1];
  const SKY_D0 = T1.dEnd, SKY_Y = T1.yEnd + 0.5;
  const TOP_D = TIERS.length > 1 ? LAST.dEnd : SKY_D0 + 8.4;
  const TOP_Y = TIERS.length > 1 ? LAST.yEnd + 1.2 : SKY_Y + 4.8;
  const SITE = clamp((A0 + TOP_D + 54) / 197, 0.45, 1.6);   // scale of the surroundings, 1 = the football default

  // ---------------- renderer, scene, light ----------------
  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance', logarithmicDepthBuffer: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, LOW ? 1.5 : 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  $('scene').appendChild(renderer.domElement);
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, innerWidth / innerHeight, 0.3, 30000);

  const LOOKS = {
    day: { el: 38, az: 145, exp: 0.55, turb: 3, ray: 1.2, sunI: 4.6, sunC: 0xfff4e6, hemi: [0xdfeaff, 0x8c7a62, 0.85], fog: 0xdfe6ee, fogD: 0.00022, night: 0 },
    sunset: { el: 6, az: 120, exp: 0.5, turb: 6, ray: 2.2, sunI: 2.6, sunC: 0xffb070, hemi: [0xbfc8ee, 0x6a4a3a, 0.9], fog: 0xe6c4a0, fogD: 0.00028, night: 0.6 },
    night: { el: 22, az: 210, exp: 0.62, turb: 2, ray: 0.3, sunI: 0.22, sunC: 0x9fb6ff, hemi: [0x2a3a66, 0x0e0c0a, 0.22], fog: 0x0a1020, fogD: 0.00018, night: 1 },
  };
  const LK = LOOKS[Q.get('look') || C.look] || LOOKS.day;
  renderer.toneMappingExposure = LK.exp;
  const sunDir = new THREE.Vector3().setFromSphericalCoords(1, THREE.MathUtils.degToRad(90 - LK.el), THREE.MathUtils.degToRad(LK.az));
  const sky = new Sky(); sky.scale.setScalar(15000);
  const su = sky.material.uniforms;
  su.turbidity.value = LK.turb; su.rayleigh.value = LK.ray; su.mieCoefficient.value = 0.004; su.mieDirectionalG.value = 0.8; su.sunPosition.value.copy(sunDir);
  scene.add(sky);
  scene.fog = new THREE.FogExp2(LK.fog, LK.fogD);
  { const pm = new THREE.PMREMGenerator(renderer), sc = new THREE.Scene(), s2 = new Sky(); s2.scale.setScalar(1000);
    for (const k of ['turbidity', 'rayleigh', 'mieCoefficient', 'mieDirectionalG']) s2.material.uniforms[k].value = su[k].value;
    s2.material.uniforms.sunPosition.value.copy(sunDir); sc.add(s2); scene.environment = pm.fromScene(sc, 0, 1, 2000).texture; }
  const sun = new THREE.DirectionalLight(LK.sunC, LK.sunI);
  sun.position.copy(sunDir).multiplyScalar(500 * Math.max(1, SITE));
  sun.castShadow = LK.sunI > 0;
  sun.shadow.mapSize.set(LOW ? 2048 : 4096, LOW ? 2048 : 4096);
  const SHE = (A0 + TOP_D + 40) * 1.15;
  Object.assign(sun.shadow.camera, { left: -SHE, right: SHE, top: SHE, bottom: -SHE, near: 20, far: 1600 * Math.max(1, SITE) });
  sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.06;
  scene.add(sun, sun.target);
  scene.add(new THREE.HemisphereLight(LK.hemi[0], LK.hemi[1], LK.hemi[2]));

  // ---------------- materials ----------------
  const M = (c, r = 0.85, m = 0, extra = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, envMapIntensity: m > 0.3 ? 0.8 : 0.35, ...extra });
  const BRAND = new THREE.Color(COL.brand || '#1f4fa8'), ACCENT = new THREE.Color(COL.accent || '#ff8a1f');
  const mConcrete = M(0xc9c5bd, 0.92), mStep = M(0xb8b3aa, 0.95);
  const mBrand = M(BRAND, 0.55, 0.1), mWhite = M(0xf2f3f4, 0.6), mSteel = M(0xc3c9d0, 0.35, 0.6), mSteelDark = M(0x4a5260, 0.5, 0.5);
  const mGlass = new THREE.MeshPhysicalMaterial({ color: 0xbfd8e8, roughness: 0.05, metalness: 0, transparent: true, opacity: 0.16, side: THREE.DoubleSide, depthWrite: false });
  const mMembrane = M(0xf7f7f5, 0.75, 0, { side: THREE.DoubleSide, emissive: 0xffffff, emissiveIntensity: 0.18 });
  const mDark = M(0x141619, 0.8);
  const mLed = M(0x0b1220, 0.4, 0, { emissive: BRAND.clone().lerp(new THREE.Color(0xffffff), 0.25), emissiveIntensity: 0.9 });
  const mWarm = M(0x332211, 0.4, 0, { emissive: 0xff8a3a, emissiveIntensity: 1.4 });

  const bowl = new THREE.Group(), roofG = new THREE.Group(); scene.add(bowl, roofG);
  const addMesh = (g, m, cast = true, rec = true, parent = bowl) => { m.side = THREE.DoubleSide; const o = new THREE.Mesh(g, m); o.castShadow = cast; o.receiveShadow = rec; parent.add(o); return o; };
  const inst = (geo, mat, list, parent = scene, cast = false, rec = true) => { const im = new THREE.InstancedMesh(geo, mat, Math.max(1, list.length)); list.forEach((m, i) => im.setMatrixAt(i, m)); im.count = list.length; im.castShadow = cast; im.receiveShadow = rec; parent.add(im); return im; };
  const faceIn = (p) => Math.atan2(-p.nx, -p.nz);

  // ---------------- the stepped tiers, fascia bands, back wall ----------------
  function stepsProfile(t, frontBottom, backBottom) {
    const p = [frontBottom, [t.rows[0].d, t.rows[0].y]];
    t.rows.forEach((r, i) => { p.push([r.d + r.T, r.y]); const nx = t.rows[i + 1]; if (nx) p.push([r.d + r.T, nx.y]); });
    p.push(backBottom); return p;
  }
  addMesh(sweep(stepsProfile(T1, [T1.rows[0].d, 0], [T1.dEnd, 0]), true), mStep);
  addMesh(sweep([[WALL, 0], [WALL, WALL_H], [WALL + 0.4, WALL_H]]), mBrand);
  TIERS.slice(1).forEach((t, k) => addMesh(sweep(stepsProfile(t, [t.rows[0].d, t.rows[0].y - 1.4], [t.dEnd, t.yEnd - 3 - k]), true), mStep));
  for (const t of TIERS.slice(1)) {
    const d = t.rows[0].d - 0.05, y = t.rows[0].y;
    addMesh(sweep([[d, y - 1.4], [d, y + 0.15]]), mBrand);
    addMesh(sweep([[d - 0.02, y - 0.95], [d - 0.02, y - 0.75]]), mLed, false, false);
    addMesh(sweep([[d + 0.05, y + 0.15], [d + 0.05, y + 1.05]]), mGlass, false, false);
  }
  addMesh(sweep([[TOP_D, LAST.yEnd], [TOP_D, TOP_Y + 6.2]]), mWhite);
  addMesh(sweep([[TOP_D - 0.05, TOP_Y + 1.6], [TOP_D - 0.05, TOP_Y + 1.9]]), mLed, false, false);

  // ---------------- the skybox band between the first and the second tier ----------------
  { const d0 = SKY_D0 + 0.2, d1 = SKY_D0 + 8, y0 = SKY_Y, y1 = SKY_Y + 3.6;
    addMesh(sweep([[d0, y0], [d1, y0]]), M(0x8a6a4e, 0.6));
    addMesh(sweep([[d1, y0], [d1, y1]]), M(0xd8c8ae, 0.85));
    addMesh(sweep([[d0, y1], [d1, y1]]), M(0xeeeae2, 0.9));
    addMesh(sweep([[SKY_D0, T1.yEnd], [SKY_D0, y0], [d0 + 1, y0]]), mConcrete);
    addMesh(sweep([[d0 + 1.2, y0 + 0.02], [d0 + 1.2, y1]]), mGlass, false, false);
    addMesh(sweep([[d0 + 1.15, y0], [d0 + 1.15, y0 + 0.12]]), mSteelDark);
    addMesh(sweep([[SKY_D0 + 3.3, SKY_Y + 0.35], [SKY_D0 + 7.9, SKY_Y + 0.35]]), M(0x7a5c42, 0.6)); }

  // ---------------- aisles, blocks and zones ----------------
  const AISLE_STEP = C.aisleEvery || 9.4, SW = C.seatWidth || 0.5;
  const AISLES = [];
  for (const s of SEG) { const n = Math.max(2, Math.round(s.len / AISLE_STEP)); for (let k = 0; k < n; k++) AISLES.push(s.t0 + s.len * k / n); }
  AISLES.sort((a, b) => a - b);
  const NSEC = AISLES.length;
  const sectorOf = t => { let k = 0; while (k < NSEC - 1 && t >= AISLES[k + 1]) k++; return k; };
  const secMid = k => (AISLES[k] + (k + 1 < NSEC ? AISLES[k + 1] : L0)) / 2;
  const nearAisle = (t, hw) => { for (const a of AISLES) { let dd = Math.abs(t - a); dd = Math.min(dd, L0 - dd); if (dd < hw) return true; } return false; };
  const VOM = AISLES.filter((_, i) => i % 2 === 0);
  const VOM_ROWS = T1.rows.length >= 14 ? [Math.round(T1.rows.length * 0.38), Math.round(T1.rows.length * 0.53)] : null;
  const inVom = (t, sc, ri) => { if (!VOM_ROWS || ri < VOM_ROWS[0] || ri > VOM_ROWS[1]) return false; for (const a of VOM) { const u = t - a; if (u > 0.7 / sc && u < 4.1 / sc) return true; } return false; };

  const ZONES = (C.zones && C.zones.length ? C.zones : [{ name: 'Main Stand', price: 50 }]).map((z, i) => ({ ...z, i }));
  const NZ = ZONES.length, t6 = SEG[6].t0 + SEG[6].len / 2;
  function zoneOfT(t) {   // 8 zones = 4 sides + 4 corners, 4 zones = sides (corners split in half), other counts = equal arcs
    const s = segOf(t);
    if (NZ === 8) return (s - 6 + 8) % 8;
    if (NZ === 4) { const k = (s - 6 + 8) % 8; if (k % 2 === 0) return k / 2; const u = (t - SEG[s].t0) / SEG[s].len; return (u < 0.5 ? (k - 1) / 2 : ((k + 1) / 2) % 4); }
    return Math.floor(((((t - t6 + L0 / (2 * NZ)) % L0) + L0) % L0) / (L0 / NZ)) % NZ;
  }
  const SECZONE = Array.from({ length: NSEC }, (_, k) => zoneOfT(secMid(k)));
  const BNUM = NSEC >= 99 ? 1000 : 100;
  const blockNo = (ti, sec) => (ti + 1) * BNUM + sec + 1;
  const priceOf = (ti, z) => Math.round(ZONES[z].price * (TIERS[ti].cfg.priceFactor != null ? TIERS[ti].cfg.priceFactor : 1));

  // ---------------- every seat as one instance ----------------
  const seatGeo = (() => {
    const pan = new THREE.BoxGeometry(0.46, 0.07, 0.40); pan.translate(0, 0.42, 0.02);
    const back = new THREE.BoxGeometry(0.46, 0.42, 0.06); back.rotateX(-0.14); back.translate(0, 0.68, -0.2);
    if (LOW) return mergeGeometries([pan, back]);
    const stem = new THREE.BoxGeometry(0.08, 0.38, 0.08); stem.translate(0, 0.2, -0.05);
    return mergeGeometries([pan, back, stem]);
  })();
  const sX = [], sY = [], sZ = [], sR = [], sT = [], sTier = [], sRow = [], sSec = [], sNo = [], sTwo = [];
  { const counter = new Map();
    TIERS.forEach((tr, ti) => tr.rows.forEach((r, ri) => {
      const ds = r.d + r.T * 0.42; let t = 0;
      while (t < L0) {
        const sc = scaleAt(t, ds);
        if (!nearAisle(t, 0.62 / sc) && !(ti === 0 && inVom(t, sc, ri))) {
          const p = base(t), sec = sectorOf(t), key = (ti * 200 + ri) * 2000 + sec, n = (counter.get(key) || 0) + 1; counter.set(key, n);
          sX.push(p.x + p.nx * ds); sT.push(t); sY.push(r.y); sZ.push(p.z + p.nz * ds); sR.push(faceIn(p));
          sTier.push(ti); sRow.push(ri); sSec.push(sec); sNo.push(n);
          const share = COL.seat2Share != null ? COL.seat2Share : 0.05, pat = COL.pattern || 'mixed';
          let two = rnd() < share;
          if (pat === 'mixed') {
            if (ti === 0 && ri < 3) two = rnd() < Math.min(0.55, share * 11);
            if (ti === 2 && ri % 9 === 4) two = rnd() < Math.min(0.7, share * 14);
            if (ti === 1 && sec % 7 === 3 && ri > 4 && ri < 16) two = rnd() < Math.min(0.35, share * 7);
          }
          if (pat === 'solid' || !COL.seat2) two = false;
          sTwo.push(two ? 1 : 0);
        }
        t += SW / sc;
      }
    }));
  }
  const N = sX.length;
  const seatZone = new Uint8Array(N), seatBlock = new Int32Array(N), taken = new Uint8Array(N);
  const base3 = new Float32Array(N * 3);
  const shades = (c, k) => [0, 0.025, -0.03, 0.012].slice(0, k).map(o => new THREE.Color(c).offsetHSL(0, 0, o));
  const P1 = shades(COL.seat || '#c2304a', 4), P2 = shades(COL.seat2 || '#2459b8', 2);
  const GREY = new THREE.Color(COL.taken || '#a3a7ad'), ACC = ACCENT, ACC_SOFT = ACCENT.clone().lerp(new THREE.Color(0xffffff), 0.45);
  const BLOCKS = new Map();   // id -> { id, ti, sec, zone, list:[], free }
  const blockSold = (id, z) => !!ZONES[z].soldOut || hash(id * 7 + 3) < (C.soldOutBlocks || 0);
  for (let i = 0; i < N; i++) {
    const z = SECZONE[sSec[i]], id = sTier[i] * 1000 + sSec[i];
    seatZone[i] = z; seatBlock[i] = id;
    let b = BLOCKS.get(id); if (!b) { b = { id, ti: sTier[i], sec: sSec[i], zone: z, list: [], free: 0, sold: blockSold(id, z) }; BLOCKS.set(id, b); }
    b.list.push(i);
    taken[i] = b.sold || hash(i * 2654435761 + 17) < (C.occupancy != null ? C.occupancy : 0.3) ? 1 : 0;
    if (!taken[i]) b.free++;
    const c = sTwo[i] ? P2[(rnd() * P2.length) | 0] : P1[(rnd() * P1.length) | 0];
    base3[i * 3] = c.r; base3[i * 3 + 1] = c.g; base3[i * 3 + 2] = c.b;
  }
  const ZINFO = ZONES.map(z => ({ free: 0, seats: 0, tiers: new Set(), blocks: [] }));
  for (const b of BLOCKS.values()) { const zi = ZINFO[b.zone]; zi.free += b.free; zi.seats += b.list.length; zi.tiers.add(b.ti); zi.blocks.push(b); }
  ZINFO.forEach((zi, z) => { zi.from = Math.min(...[...zi.tiers].map(ti => priceOf(ti, z))); });

  const seats = new THREE.InstancedMesh(seatGeo, M(0xffffff, 0.55), N);
  { const m = new THREE.Matrix4(), q = new THREE.Quaternion(), up = V(0, 1, 0), one = V(1, 1, 1), p = V(0, 0, 0);
    for (let i = 0; i < N; i++) { q.setFromAxisAngle(up, sR[i]); p.set(sX[i], sY[i], sZ[i]); m.compose(p, q, one); seats.setMatrixAt(i, m); }
    seats.setColorAt(0, new THREE.Color()); seats.instanceColor.array.set(base3); }
  seats.receiveShadow = true; seats.castShadow = !LOW;
  scene.add(seats);

  // aisle steps
  { const stair = [];
    for (const a of AISLES) TIERS.forEach(tr => tr.rows.forEach((r, ri) => {
      if (ri % 2) return; const p = base(a), d = r.d + r.T * 0.5, m = new THREE.Matrix4().makeRotationY(faceIn(p));
      m.setPosition(p.x + p.nx * d, r.y + 0.02, p.z + p.nz * d); stair.push(m); }));
    inst(new THREE.BoxGeometry(1.1, 0.04, 0.8), M(0xd9d6cf, 0.9), stair); }
  // tunnel mouths in the lower tier
  if (VOM_ROWS) {
    const box = new THREE.BoxGeometry(1, 1, 1), list = [], gl = [];
    const mTop = M(0xbdb8af, 0.92);
    for (const a of VOM) {
      const t = a + 2.4, p = base(t), r0 = T1.rows[VOM_ROWS[0]], r1 = T1.rows[VOM_ROWS[1]];
      const dF = r0.d, dB = r1.d + r1.T, top = r1.y + 0.02, bot = r0.y - 2.3, dm = (dF + dB) / 2, q = new THREE.Quaternion().setFromAxisAngle(V(0, 1, 0), faceIn(p));
      list.push(new THREE.Matrix4().compose(V(p.x + p.nx * dm, (top + bot) / 2, p.z + p.nz * dm), q, V(3.2, top - bot, dB - dF)));
      gl.push(new THREE.Matrix4().compose(V(p.x + p.nx * (dF + 0.05), r1.y + 0.55, p.z + p.nz * (dF + 0.05)), q, V(3.2, 1.05, 0.04)));
    }
    const vm = new THREE.InstancedMesh(box, [mTop, mTop, mTop, mTop, mDark, mTop], list.length); list.forEach((m, i) => vm.setMatrixAt(i, m)); vm.receiveShadow = true; scene.add(vm);
    inst(box, mGlass, gl);
  }

  // ---------------- VIP boxes on the two long sides ----------------
  const BOXES = [];   // { no, side, x, t }
  { const geo = mergeGeometries([new THREE.BoxGeometry(0.7, 0.45, 0.7).translate(0, 0.35, 0), new THREE.BoxGeometry(0.7, 1.1, 0.18).translate(0, 0.95, -0.3), new THREE.BoxGeometry(0.12, 0.3, 0.7).translate(0.36, 0.7, 0), new THREE.BoxGeometry(0.12, 0.3, 0.7).translate(-0.36, 0.7, 0)]);
    const half = A0 - R0, nb = Math.max(1, Math.floor(2 * half / 12.5)), bw = 2 * half / nb, per = clamp(Math.floor((bw - 1.4) / 1.38), 2, 8);
    const ch = [], walls = []; let no = 1;
    for (const side of [-1, 1]) for (let k = 0; k < nb; k++) {
      const x0 = -half + k * bw, xc = x0 + bw / 2, seg = side < 0 ? SEG[6] : SEG[2];
      BOXES.push({ no: no++, side, x: xc, t: side < 0 ? seg.t0 + (xc + half) : seg.t0 + (half - xc) });
      for (let j = 0; j < per; j++) for (const [dd, yy] of [[SKY_D0 + 2.4, SKY_Y], [SKY_D0 + 3.8, SKY_Y + 0.35]]) {
        const x = xc + (j - (per - 1) / 2) * 1.38, m = new THREE.Matrix4().makeRotationY(side > 0 ? Math.PI : 0); m.setPosition(x, yy, side * (B0 + dd)); ch.push(m); }
      walls.push(new THREE.Matrix4().compose(V(x0 + (k === 0 ? 0.08 : 0), SKY_Y + 1.8, side * (B0 + SKY_D0 + 4.6)), new THREE.Quaternion(), V(0.15, 3.6, 6.8)));
      if (k === nb - 1) walls.push(new THREE.Matrix4().compose(V(half - 0.08, SKY_Y + 1.8, side * (B0 + SKY_D0 + 4.6)), new THREE.Quaternion(), V(0.15, 3.6, 6.8)));
    }
    inst(geo, M(0x3b2a22, 0.5, 0.05), ch, scene, true);
    inst(new THREE.BoxGeometry(1, 1, 1), M(0xd8c8ae, 0.85), walls);
  }

  // ---------------- canvas textures for screens and LED boards ----------------
  const FONT = '-apple-system, "SF Pro Display", "Helvetica Neue", Arial, sans-serif';
  const brandHex = '#' + BRAND.getHexString(), seatHex = '#' + new THREE.Color(COL.seat || '#c2304a').getHexString();
  function screenTex(w, h, big) {
    const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d');
    const gr = g.createLinearGradient(0, 0, w, h); gr.addColorStop(0, '#0b0f18'); gr.addColorStop(0.55, brandHex); gr.addColorStop(1, seatHex); g.fillStyle = gr; g.fillRect(0, 0, w, h);
    g.fillStyle = 'rgba(255,255,255,.08)'; for (let i = 0; i < 9; i++) g.fillRect(i * w / 8, 0, w / 17, h);
    g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle';
    let fs = h * 0.3; g.font = `800 ${fs}px ${FONT}`; while (g.measureText(big).width > w * 0.86 && fs > 8) { fs -= 2; g.font = `800 ${fs}px ${FONT}`; }
    g.fillText(big, w / 2, h * 0.44);
    g.font = `600 ${h * 0.11}px ${FONT}`; g.globalAlpha = 0.8; g.fillText((C.event && C.event.title) || '', w / 2, h * 0.72);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t;
  }
  function boardTex() {
    const words = [C.shortName || C.name || '', ...(C.boards || [])].filter(Boolean);
    const c = document.createElement('canvas'); c.width = 2048; c.height = 64; const g = c.getContext('2d');
    g.fillStyle = '#0b0f18'; g.fillRect(0, 0, 2048, 64);
    let x = 0, k = 0; g.textBaseline = 'middle'; g.font = `800 40px ${FONT}`;
    while (x < 2048) { const w = words[k % words.length] || ''; const tw = g.measureText(w).width + 120;
      g.fillStyle = k % 2 ? brandHex : seatHex; g.fillRect(x, 0, tw, 64); g.fillStyle = '#fff'; g.fillText(w, x + 60, 34); x += tw; k++; }
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = THREE.RepeatWrapping; t.anisotropy = 8; return t;
  }

  // ---------------- roof ----------------
  const ROOF = C.roof === 'none' || C.roof === false ? 'none' : C.roof === 'closed' ? 'closed' : 'ring';
  const ROOF_IN = Math.min(6, F.row0[0] + 1), ROOF_OUT = TOP_D + 5;
  const roofY = d => { const u = (d - ROOF_IN) / (ROOF_OUT - ROOF_IN); return TOP_Y + 3 + 6.5 * Math.pow(clamp(u, 0, 1), 0.8); };
  if (ROOF !== 'none') {
    const closed = ROOF === 'closed', cast = !closed;
    const roofProf = []; for (let k = 0; k <= 14; k++) { const d = ROOF_IN + (ROOF_OUT - ROOF_IN) * k / 14; roofProf.push([d, roofY(d)]); }
    addMesh(sweep(roofProf), mMembrane, cast, true, roofG);
    const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d');
    g.fillStyle = '#e9edf1'; g.fillRect(0, 0, 256, 256);
    const gr = g.createRadialGradient(128, 128, 10, 128, 128, 140); gr.addColorStop(0, '#ffffff'); gr.addColorStop(1, '#b9c3cf');
    g.fillStyle = gr; g.beginPath(); g.moveTo(128, 6); g.lineTo(250, 128); g.lineTo(128, 250); g.lineTo(6, 128); g.closePath(); g.fill();
    g.strokeStyle = '#8f9aa8'; g.lineWidth = 6; g.stroke();
    const tx = new THREE.CanvasTexture(c); tx.wrapS = tx.wrapT = THREE.RepeatWrapping; tx.repeat.set(1, 9); tx.colorSpace = THREE.SRGBColorSpace; tx.anisotropy = 8;
    const topProf = roofProf.map(([d, y]) => [d, y + 2.2 + 1.2 * Math.sin(Math.PI * (d - ROOF_IN) / (ROOF_OUT - ROOF_IN))]);
    addMesh(sweep(topProf, false, 7), M(0xffffff, 0.45, 0.1, { map: tx }), cast, true, roofG);
    addMesh(sweep([[ROOF_IN, roofY(ROOF_IN)], [ROOF_IN, roofY(ROOF_IN) + 2.2]]), mSteel, cast, true, roofG);
    addMesh(sweep([[ROOF_OUT, roofY(ROOF_OUT)], [ROOF_OUT, topProf.at(-1)[1]]]), mSteel, cast, true, roofG);
    // radial trusses and rings
    const bars = [], cyl = new THREE.CylinderGeometry(1, 1, 1, 6), up = V(0, 1, 0);
    const bar = (a, b, r) => { const dir = b.clone().sub(a), L = dir.length(); bars.push(new THREE.Matrix4().compose(a.clone().add(b).multiplyScalar(0.5), new THREE.Quaternion().setFromUnitVectors(up, dir.normalize()), V(r, L, r))); };
    const nT = Math.round(L0 / 7.2);
    for (let k = 0; k < nT; k++) {
      const t = k * L0 / nT, P = 12;
      for (let i = 0; i <= P; i++) {
        const d = ROOF_IN + (ROOF_OUT - ROOF_IN) * i / P, depth = 1.2 + 4.2 * i / P;
        const top = off(t, d, roofY(d) - 0.1), bot = off(t, d, roofY(d) - depth); bar(top, bot, 0.09);
        if (i < P) { const d2 = ROOF_IN + (ROOF_OUT - ROOF_IN) * (i + 1) / P, dep2 = 1.2 + 4.2 * (i + 1) / P;
          const top2 = off(t, d2, roofY(d2) - 0.1), bot2 = off(t, d2, roofY(d2) - dep2);
          bar(bot, bot2, 0.16); bar(top, top2, 0.12); bar(i % 2 ? top : bot, i % 2 ? bot2 : top2, 0.07); }
      }
      bar(off(t, ROOF_OUT - 2, roofY(ROOF_OUT - 2) - 5), off(t, TOP_D + 0.5, TOP_Y + 1.5), 0.25);
    }
    for (const f of [0, 0.25, 0.5, 0.75, 1]) { const d = ROOF_IN + (ROOF_OUT - ROOF_IN) * f, y = roofY(d) - (1.2 + 4.2 * f);
      for (let i = 0; i < SAMP.length; i++) bar(off(SAMP[i], d, y), off(SAMP[(i + 1) % SAMP.length], d, y), f === 0 ? 0.35 : 0.12); }
    inst(cyl, mSteel, bars, roofG, cast);
    const lamps = []; for (let t = 0; t < L0; t += 2.2) { const p = base(t), m = new THREE.Matrix4().makeRotationY(faceIn(p)); m.setPosition(p.x + p.nx * (ROOF_IN + 1), roofY(ROOF_IN) - 1.6, p.z + p.nz * (ROOF_IN + 1)); lamps.push(m); }
    inst(new THREE.BoxGeometry(1.4, 0.5, 0.35), M(0xffffff, 0.3, 0, { emissive: 0xfff6e8, emissiveIntensity: LK.night ? 3 : 0.8 }), lamps, roofG);
    if (closed) {   // arena: fill the opening with a ceiling, rows of lights underneath
      const pts = SAMP.map(t => off(t, ROOF_IN, 0)).map(p => new THREE.Vector2(p.x, -p.z));
      const sh = new THREE.Shape(pts), y = roofY(ROOF_IN);
      const under = new THREE.Mesh(new THREE.ShapeGeometry(sh), M(0x2b2f36, 0.9, 0.2, { side: THREE.DoubleSide })); under.rotation.x = -Math.PI / 2; under.position.y = y + 0.4; roofG.add(under);
      const over = new THREE.Mesh(new THREE.ShapeGeometry(sh), M(0xf2f3f4, 0.6, 0, { side: THREE.DoubleSide })); over.rotation.x = -Math.PI / 2; over.position.y = y + 2.4; roofG.add(over);
      const lg = []; for (let x = -A0 - ROOF_IN + 3; x < A0 + ROOF_IN - 3; x += 4) for (let z = -B0 - ROOF_IN + 3; z < B0 + ROOF_IN - 3; z += 4) if (Math.abs(x) < A0 + ROOF_IN - 4 && Math.abs(z) < B0 + ROOF_IN - 4) lg.push(new THREE.Matrix4().makeTranslation(x, y + 0.2, z));
      inst(new THREE.BoxGeometry(0.9, 0.2, 0.9), new THREE.MeshBasicMaterial({ color: 0xfff6ea, toneMapped: false }), lg, roofG);
      const bars2 = []; for (let x = -A0; x <= A0; x += 8) bars2.push(new THREE.Matrix4().compose(V(x, y - 0.4, 0), new THREE.Quaternion(), V(0.4, 1.2, 2 * (B0 + ROOF_IN))));
      for (let z = -B0; z <= B0; z += 8) bars2.push(new THREE.Matrix4().compose(V(0, y - 0.4, z), new THREE.Quaternion(), V(2 * (A0 + ROOF_IN), 1.2, 0.4)));
      inst(new THREE.BoxGeometry(1, 1, 1), mSteelDark, bars2, roofG);
    }
  }

  // ---------------- screens ----------------
  const SCB = C.scoreboard || 'ends';
  if (SCB === 'center') {
    const w = clamp(B0 * 0.75, 6, 16), h = w * 0.6, yc = (ROOF !== 'none' ? roofY(ROOF_IN) : TOP_Y + 14) - h / 2 - 4;
    const tx = screenTex(1024, 614, C.shortName || C.name), face = new THREE.MeshBasicMaterial({ map: tx, toneMapped: false });
    const cube = new THREE.Mesh(new THREE.BoxGeometry(w, h, w * 0.8), [face, face, mDark, mDark, face, face]); cube.position.set(0, yc, 0); roofG.add(cube);
    const ring = new THREE.Mesh(new THREE.BoxGeometry(w * 0.9, 0.8, w * 0.72), mLed); ring.position.set(0, yc - h / 2 - 0.6, 0); roofG.add(ring);
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) { const cb = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 6), mSteelDark); cb.position.set(sx * w * 0.4, yc + h / 2 + 3, sz * w * 0.3); roofG.add(cb); }
  } else if (SCB === 'ends') {
    const w = clamp(B0 * 0.65, 8, 26), h = w * 0.35;
    for (const sx of [-1, 1]) {
      const onRoof = ROOF !== 'none', x = sx * (onRoof ? A0 + 8 : A0 + TOP_D - 1), y = onRoof ? roofY(8) - 9 : TOP_Y + h / 2 + 3;
      const scr = new THREE.Mesh(new THREE.BoxGeometry(0.8, h, w), M(0x10141c, 0.5)); scr.position.set(x, y, 0); (onRoof ? roofG : scene).add(scr);
      const face = new THREE.Mesh(new THREE.PlaneGeometry(w - 0.8, h - 0.8), new THREE.MeshBasicMaterial({ map: screenTex(1040, 360, C.name), toneMapped: false }));
      face.position.set(x - sx * 0.45, y, 0); face.rotation.y = -sx * Math.PI / 2; (onRoof ? roofG : scene).add(face);
      if (!onRoof) { const leg = new THREE.Mesh(new THREE.BoxGeometry(0.6, y, 0.6), mSteelDark); leg.position.set(x + sx * 0.5, y / 2, 0); scene.add(leg); }
    }
  }

  // ---------------- outside: diagonal fins, warm light bands, podium ----------------
  const FAC0 = TOP_D + 2, FAC_H = ROOF !== 'none' ? roofY(ROOF_OUT) + 2.2 : TOP_Y + 6.2, BULGE = 9 * clamp(TOP_D / 83, 0.4, 1);
  const facD = y => FAC0 + BULGE * Math.sin(Math.PI * Math.min(1, y / FAC_H)) - 3 * (y / FAC_H);
  { const prof = []; for (let k = 0; k <= 16; k++) { const y = 4 + (FAC_H - 4) * k / 16; prof.push([facD(y), y]); }
    addMesh(sweep(prof), M(BRAND.clone().multiplyScalar(0.5), 0.25, 0.25, { envMapIntensity: 0.6, emissive: BRAND.clone().multiplyScalar(0.35), emissiveIntensity: 0.25 + LK.night }), true, true);
    const fins = [], g = new THREE.BoxGeometry(0.24, 1, 0.16), up = V(0, 1, 0);
    const nF = Math.round((L0 + 2 * Math.PI * FAC0) / 4.15), steps = 18, twist = 26 * clamp(SITE, 0.6, 1);
    for (let f = 0; f < nF; f++) for (let s = 0; s < steps; s++) {
      const y0 = 4 + (FAC_H - 4) * s / steps, y1 = 4 + (FAC_H - 4) * (s + 1) / steps;
      const ta = f * L0 / nF + twist * s / steps, tb = f * L0 / nF + twist * (s + 1) / steps;
      const a = off(ta, facD(y0) + 0.6, y0), b = off(tb, facD(y1) + 0.6, y1), dir = b.clone().sub(a), L = dir.length();
      fins.push(new THREE.Matrix4().compose(a.clone().add(b).multiplyScalar(0.5), new THREE.Quaternion().setFromUnitVectors(up, dir.clone().normalize()), V(1, L * 1.02, 1)));
    }
    inst(g, M(COL.facade || '#d9e8fb', 0.25, 0.85, { emissive: BRAND.clone().lerp(new THREE.Color(0xffffff), 0.3), emissiveIntensity: LK.night * 0.6 }), fins, scene, !LOW);
    for (const y of [7.5, 9.2]) addMesh(sweep([[facD(y) + 0.9, y], [facD(y) + 1.6, y + 0.5]]), mWarm, false, false);
    addMesh(sweep([[facD(4) - 1, 4], [facD(4) + 3, 4], [facD(4) + 3, 6.8], [facD(6.8) + 1.2, 6.8]]), M(0xe8e4dc, 0.8)); }
  const PODW = 30 * clamp(SITE, 0.6, 1);
  { addMesh(sweep([[0, 0.02], [FAC0 + PODW, 0.02], [FAC0 + PODW, 4], [FAC0 - 1, 4]]), M(0xd6d0c4, 0.9));
    addMesh(sweep([[FAC0 + PODW, 4], [FAC0 + PODW, 0]]), M(0xbdb6a8, 0.9));
    const steps = [], sg = new THREE.BoxGeometry(18 * clamp(SITE, 0.6, 1), 0.25, 0.45);
    for (const t0 of [0, 2, 4, 6].map(k => SEG[k].t0 + SEG[k].len / 2))
      for (let i = 0; i < 16; i++) { const p = base(t0), d = FAC0 + PODW + 0.45 * (16 - i), m = new THREE.Matrix4().makeRotationY(faceIn(p)); m.setPosition(p.x + p.nx * d, 0.25 * i + 0.12, p.z + p.nz * d); steps.push(m); }
    inst(sg, M(0xe0dbd0, 0.85), steps); }

  // ---------------- surroundings: park | city | desert ----------------
  const SURR = ['park', 'city', 'desert'].includes(C.surroundings) ? C.surroundings : 'park';
  const ROADPTS = [];
  const plazaOut = t => FAC0 + PODW + 22 * clamp(SITE, 0.6, 1) + 10 * Math.sin(t / L0 * Math.PI * 6 + 1) + 6 * Math.sin(t / L0 * Math.PI * 10);
  const CLEAR_A = A0 + FAC0 + PODW + 44, CLEAR_B = B0 + FAC0 + PODW + 44;   // nothing tall inside this ellipse
  const noiseTex = (base, w, h, dots, a, b, rep) => { const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d'); g.fillStyle = base; g.fillRect(0, 0, w, h);
    for (let i = 0; i < dots; i++) { g.fillStyle = rnd() < .5 ? a : b; g.fillRect(rnd() * w, rnd() * h, 2 + rnd() * 4, 2 + rnd() * 4); }
    const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; if (rep) t.repeat.set(rep, rep); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t; };
  { // ground
    const near = SURR === 'park' ? '#6f9a48' : SURR === 'city' ? '#9c9a95' : '#d9b98a';
    const tex = noiseTex(near, 512, 512, 9000, SURR === 'park' ? 'rgba(52,86,34,.18)' : 'rgba(0,0,0,.06)', SURR === 'park' ? 'rgba(150,180,90,.14)' : 'rgba(255,255,255,.06)', 160);
    const gg = new THREE.PlaneGeometry(9000, 9000, LOW ? 160 : 260, LOW ? 160 : 260); gg.rotateX(-Math.PI / 2);
    const pa = gg.attributes.position, colA = new Float32Array(pa.count * 3), cg = new THREE.Color(0xffffff);
    const far = new THREE.Color(SURR === 'city' ? 0xb8b6ae : 0xe8c896).multiplyScalar(SURR === 'park' ? 1.55 : 1.0);
    const R1 = SURR === 'desert' ? 0.45 : 1, ex = 980 * SITE, ez = 820 * SITE;
    for (let i = 0; i < pa.count; i++) {
      const x = pa.getX(i), z = pa.getZ(i), e = Math.hypot(x / ex, z / ez) + 0.06 * Math.sin(x / 90) * Math.cos(z / 120);
      const k = clamp((e - R1) / 0.25, 0, 1), kd = SURR === 'city' ? 0 : clamp((e - R1 - 0.15) / 0.6, 0, 1);
      pa.setY(i, -0.06 + kd * (8 * Math.sin(x / 140 + Math.sin(z / 260) * 2) + 5 * Math.sin(z / 95 + x / 300) + 2 * Math.sin((x + z) / 47)));
      const c = cg.clone().lerp(far, SURR === 'park' ? k : k * 0.5); colA.set([c.r, c.g, c.b], i * 3);
    }
    gg.setAttribute('color', new THREE.BufferAttribute(colA, 3)); gg.computeVertexNormals();
    const ground = new THREE.Mesh(gg, M(0xffffff, 0.97, 0, { map: tex, vertexColors: true })); ground.receiveShadow = true; scene.add(ground);
  }
  { // plaza in light concrete slabs
    const c = document.createElement('canvas'); c.width = c.height = 512; const g = c.getContext('2d');
    g.fillStyle = '#ddd6c8'; g.fillRect(0, 0, 512, 512); for (let i = 0; i < 6000; i++) { g.fillStyle = rnd() < .5 ? 'rgba(0,0,0,.05)' : 'rgba(255,255,255,.07)'; g.fillRect(rnd() * 512, rnd() * 512, 2, 2); }
    g.strokeStyle = 'rgba(120,110,95,.35)'; g.lineWidth = 2; for (let k = 0; k <= 512; k += 64) { g.beginPath(); g.moveTo(k, 0); g.lineTo(k, 512); g.stroke(); g.beginPath(); g.moveTo(0, k); g.lineTo(512, k); g.stroke(); }
    const tx = new THREE.CanvasTexture(c); tx.wrapS = tx.wrapT = THREE.RepeatWrapping; tx.colorSpace = THREE.SRGBColorSpace; tx.anisotropy = 8;
    const pos = [], uv = []; const st = []; for (let t = 0; t < L0; t += 2) st.push(t);
    for (let k = 0; k < st.length; k++) { const t0 = st[k], t1 = k + 1 < st.length ? st[k + 1] : L0;
      const a = off(t0, FAC0 + PODW - 1, 0.05), b = off(t1, FAC0 + PODW - 1, 0.05), cc = off(t1, plazaOut(t1), 0.05), d = off(t0, plazaOut(t0), 0.05);
      pos.push(a.x, a.y, a.z, b.x, b.y, b.z, cc.x, cc.y, cc.z, a.x, a.y, a.z, cc.x, cc.y, cc.z, d.x, d.y, d.z);
      for (const q of [a, b, cc, a, cc, d]) uv.push(q.x / 16, q.z / 16); }
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); geo.computeVertexNormals();
    const m = new THREE.Mesh(geo, M(0xffffff, 0.9, 0, { map: tx, side: THREE.DoubleSide })); m.receiveShadow = true; scene.add(m);
  }
  const roadTex = (() => { const c = document.createElement('canvas'); c.width = 1024; c.height = 256; const g = c.getContext('2d');
    g.fillStyle = '#3b3e43'; g.fillRect(0, 0, 1024, 256); for (let i = 0; i < 5000; i++) { g.fillStyle = rnd() < .5 ? 'rgba(0,0,0,.12)' : 'rgba(255,255,255,.05)'; g.fillRect(rnd() * 1024, rnd() * 256, 2, 2); }
    g.fillStyle = '#f2f2ee'; g.fillRect(0, 12, 1024, 6); g.fillRect(0, 238, 1024, 6); for (let x = 0; x < 1024; x += 128) g.fillRect(x, 125, 64, 6);
    const t = new THREE.CanvasTexture(c); t.wrapS = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t; })();
  const mRoad = M(0xffffff, 0.85, 0, { map: roadTex, side: THREE.DoubleSide }), mCurb = M(0xd9d4ca, 0.9, 0, { side: THREE.DoubleSide });
  const V2 = (x, z) => new THREE.Vector2(x, z);
  const ribbon = (ctrl, closed, w, y, mat, uLen, keep = true) => {
    const curve = new THREE.CatmullRomCurve3(ctrl.map(p => V(p.x, 0, p.y)), closed, 'centripetal');
    const n = Math.max(60, Math.round(curve.getLength() / 3)), pts = curve.getSpacedPoints(n), pos = [], uv = []; let a2 = 0;
    for (let k = 0; k < n; k++) { const p0 = pts[k], p1 = pts[k + 1]; const tg = p1.clone().sub(p0); const L = tg.length(); tg.normalize(); const nn = V(-tg.z, 0, tg.x).multiplyScalar(w / 2);
      const a = p0.clone().add(nn), b = p1.clone().add(nn), c = p1.clone().sub(nn), d = p0.clone().sub(nn);
      for (const q of [a, b, c, a, c, d]) pos.push(q.x, y, q.z);
      const u0 = a2 / uLen, u1 = (a2 + L) / uLen; uv.push(u0, 0, u1, 0, u1, 1, u0, 0, u1, 1, u0, 1); a2 += L;
      if (keep) ROADPTS.push([p0.x, p0.z, w / 2]); }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.computeVertexNormals();
    const m = new THREE.Mesh(g, mat); m.receiveShadow = true; scene.add(m); return curve; };
  const nearRoad = (x, z, pad) => { for (const [rx, rz, hw] of ROADPTS) { const dx = x - rx, dz = z - rz; if (dx * dx + dz * dz < (hw + pad) * (hw + pad)) return true; } return false; };
  const trees = [], palms = [];
  const lp = a => { const r = 1 + 0.07 * Math.sin(3 * a + 1) + 0.05 * Math.sin(5 * a + 2); return V2(Math.cos(a) * 395 * SITE * r, Math.sin(a) * 315 * SITE * r); };
  // short curved boulevards from the outside to the plaza
  const boulevards = () => { for (const a of [0.9, 2.35, 4.0, 5.45]) { const p0 = lp(a), d = plazaOut(0) - 2, ang = Math.atan2(p0.y, p0.x); const e = V2(Math.cos(ang) * (A0 + d), Math.sin(ang) * (B0 + d));
    const mid = V2((p0.x + e.x) / 2 + 30 * SITE * Math.sin(a * 3), (p0.y + e.y) / 2 + 30 * SITE * Math.cos(a * 2)); ribbon([p0, mid, e], false, 10, 0.065, mRoad, 22); } };
  if (SURR !== 'city') {
    const loop = []; for (let k = 0; k < 18; k++) loop.push(lp(k / 18 * Math.PI * 2));
    ribbon(loop, true, 17.5, 0.05, mCurb, 30, false); ribbon(loop, true, 15, 0.07, mRoad, 22);
    const S = SITE, avenues = [[lp(0.15), V2(560 * S, 90 * S), V2(760 * S, 40 * S), V2(980 * S, 160 * S), V2(1400 * S, 120 * S)], [lp(Math.PI + 0.2), V2(-560 * S, -150 * S), V2(-780 * S, -90 * S), V2(-1000 * S, -230 * S), V2(-1400 * S, -200 * S)], [lp(-Math.PI / 2 + 0.25), V2(150 * S, -470 * S), V2(260 * S, -680 * S), V2(180 * S, -900 * S), V2(320 * S, -1400 * S)]];
    for (const av of avenues) { ribbon(av, false, 15.5, 0.05, mCurb, 30, false); ribbon(av, false, 13, 0.07, mRoad, 22); }
    boulevards();
    if (SURR === 'park') { const pathTex = noiseTex('#d9cdb4', 256, 256, 3000, 'rgba(0,0,0,.06)', 'rgba(255,255,255,.08)');
      for (const [rx, rz, ph] of [[520, 420, 0.4], [640, 520, 1.7]]) { const ring = []; for (let k = 0; k < 16; k++) { const a = k / 16 * Math.PI * 2, r = 1 + 0.12 * Math.sin(4 * a + ph) + 0.06 * Math.sin(7 * a); ring.push(V2(Math.cos(a) * rx * S * r, Math.sin(a) * rz * S * r)); } ribbon(ring, true, 4.5, 0.06, M(0xffffff, 0.95, 0, { map: pathTex, side: THREE.DoubleSide }), 8); } }
    // parking far away with scattered cars
    const carGeo = mergeGeometries([new THREE.BoxGeometry(1.85, 0.75, 4.5).translate(0, 0.55, 0), new THREE.BoxGeometry(1.65, 0.6, 2.3).translate(0, 1.2, -0.2)]);
    const cars = [], carCol = [], CC = [0xf4f4f2, 0xf4f4f2, 0xe9e9e6, 0xc9cdd2, 0x9aa0a6, 0x1c1d20, 0x2b3a55, 0x6b6e72];
    for (const [cx0, cz0, w, l, rot] of [[1060, 330, 220, 140, 0.25], [-1080, -420, 240, 150, -0.3]]) {
      const cx = cx0 * S, cz = cz0 * S, lot = new THREE.Mesh(new THREE.PlaneGeometry(w, l), M(0x47494d, 0.9)); lot.rotation.set(-Math.PI / 2, 0, rot); lot.position.set(cx, 0.08, cz); lot.receiveShadow = true; scene.add(lot);
      const c = Math.cos(rot), sn = Math.sin(rot);
      for (let zz = -l / 2 + 6; zz < l / 2 - 6; zz += 16) for (let xx = -w / 2 + 4; xx < w / 2 - 4; xx += 2.7) { if (rnd() > 0.55) continue;
        const m = new THREE.Matrix4().makeRotationY(rot + (rnd() < .5 ? 0 : Math.PI)); m.setPosition(cx + xx * c + zz * sn, 0.08, cz - xx * sn + zz * c); cars.push(m); carCol.push(CC[(rnd() * CC.length) | 0]); }
      if (SURR === 'park') for (let k = 0; k < 40; k++) { const xx = (rnd() - .5) * w, zz = (rnd() - .5) * l; trees.push([cx + xx * c + zz * sn, cz - xx * sn + zz * c, 3 + rnd() * 1.5]); }
    }
    const cm = inst(carGeo, M(0xffffff, 0.35, 0.4), cars); carCol.forEach((h, i) => cm.setColorAt(i, new THREE.Color(h)));
    if (SURR === 'park') {
      const field = (x, z) => Math.sin(x / 61 + 1.3) * Math.cos(z / 47 - 0.7) + 0.6 * Math.sin((x + z) / 33) + 0.4 * Math.cos((x - 2 * z) / 71);
      const maxT = Math.round((LOW ? 3000 : 7000) * clamp(SITE * SITE, 0.35, 1));
      for (let k = 0; k < 26000 && trees.length < maxT; k++) {
        const x = (-1150 + rnd() * 2300) * S, z = (-900 + rnd() * 1800) * S;
        if (Math.hypot(x / (1000 * S), z / (830 * S)) > 1.02) continue;
        if (Math.hypot(x / (A0 + plazaOut(0) + 6), z / (B0 + plazaOut(0) + 6)) < 1.08) continue;
        if (field(x, z) < -0.15 + 0.45 * rnd() || nearRoad(x, z, 6)) continue;
        trees.push([x, z, 3 + rnd() * 3.5]);
      }
    }
    for (const [rx, rz, hw] of ROADPTS) if (rnd() < (SURR === 'desert' ? 0.22 : 0.16)) { const a = rnd() * 6.28, x = rx + Math.cos(a) * (hw + 4), z = rz + Math.sin(a) * (hw + 4); if (!nearRoad(x, z, 2)) palms.push([x, z]); }
  } else {
    // city: a street grid with blocks of buildings, windows drawn in the shader so they keep their size on any height
    const cell = 110, streetW = 16, span = 1500, segs = [];
    const inClear = (x, z, pad = 0) => Math.hypot(x / (CLEAR_A + pad), z / (CLEAR_B + pad)) < 1;
    for (let gx = -span; gx <= span; gx += cell) for (let gz = -span; gz < span; gz += cell) {
      if (!inClear(gx, gz + cell / 2, -20)) segs.push(new THREE.Matrix4().compose(V(gx, 0.07, gz + cell / 2), new THREE.Quaternion(), V(streetW, 1, cell)));
      if (!inClear(gz + cell / 2, gx, -20)) segs.push(new THREE.Matrix4().compose(V(gz + cell / 2, 0.071, gx), new THREE.Quaternion(), V(cell, 1, streetW)));
    }
    const pl = new THREE.PlaneGeometry(1, 1); pl.rotateX(-Math.PI / 2);
    inst(pl, M(0x3b3e43, 0.85), segs);
    boulevards();
    const bm = M(0xffffff, 0.6, 0.15);
    bm.onBeforeCompile = sh => {
      sh.uniforms.uNight = { value: LK.night };
      sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWP; varying vec3 vWN;')
        .replace('#include <project_vertex>', '#include <project_vertex>\n vec4 wp4 = vec4(transformed, 1.0);\n#ifdef USE_INSTANCING\n wp4 = instanceMatrix * wp4;\n#endif\n vWP = (modelMatrix * wp4).xyz; vWN = normalize(objectNormal);');
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vWP; varying vec3 vWN; uniform float uNight;\nfloat hh(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }')
        .replace('#include <color_fragment>', '#include <color_fragment>\n float side = step(abs(vWN.y), 0.5);\n vec2 gq = vec2((abs(vWN.x) > 0.5 ? vWP.z : vWP.x) / 3.2, vWP.y / 3.6);\n vec2 fq = fract(gq);\n float win = step(0.16, fq.x) * step(fq.x, 0.84) * step(0.22, fq.y) * step(fq.y, 0.82) * side * step(4.0, vWP.y);\n float lit = step(0.55, hh(floor(gq) + floor(vWP.xz / 40.0)));\n diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.10, 0.13, 0.17), win * 0.82);')
        .replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\n totalEmissiveRadiance += win * lit * uNight * vec3(1.0, 0.78, 0.5) * 1.6;');
    };
    const bl = [], bcol = [], BC = [0xd8d4cc, 0xc9c3b8, 0xe6e2da, 0xb9bec4, 0xa7b0b8, 0xd2c6b4, 0x8f98a2];
    for (let gx = -span; gx < span; gx += cell) for (let gz = -span; gz < span; gz += cell) for (const [ox, oz] of [[0.27, 0.27], [0.73, 0.27], [0.27, 0.73], [0.73, 0.73]]) {
      const x = gx + ox * cell, z = gz + oz * cell; if (inClear(x, z, 30) || rnd() < 0.18) continue;
      const dist = Math.hypot(x / CLEAR_A, z / CLEAR_B), w = 26 + rnd() * 16, d = 26 + rnd() * 16;
      const h = 12 + rnd() * 30 * Math.min(1, dist / 2) + (rnd() < 0.12 * Math.min(1, dist / 2.5) ? 50 + rnd() * 110 : 0);
      bl.push(new THREE.Matrix4().compose(V(x, h / 2, z), new THREE.Quaternion(), V(w, h, d))); bcol.push(BC[(rnd() * BC.length) | 0]);
      if (rnd() < 0.5) trees.push([x + (rnd() < .5 ? -1 : 1) * (cell / 2 - 4) * 0.5, z + cell * 0.48 - oz * cell * 0.9, 2.5 + rnd() * 1.5]);
    }
    const bi = inst(new THREE.BoxGeometry(1, 1, 1), bm, bl, scene, !LOW); bcol.forEach((c, i) => bi.setColorAt(i, new THREE.Color(c)));
  }
  for (let t = 0; t < L0; t += 7) { const pp = off(t, plazaOut(t) - 6, 0); (SURR === 'city' ? trees : palms).push(SURR === 'city' ? [pp.x, pp.z, 3] : [pp.x, pp.z]); }
  if (LK.night) {   // warm street lamps
    const lamps = []; let k = 0; for (const [x, z, hw] of ROADPTS) { if ((k++ % 9) || hw < 3) continue; lamps.push(new THREE.Matrix4().makeTranslation(x + hw + 1.5, 7, z)); }
    inst(new THREE.SphereGeometry(0.9, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffc98a, toneMapped: false }), lamps);
    const pools = lamps.map(m => { const q = new THREE.Matrix4().makeRotationX(-Math.PI / 2); q.setPosition(m.elements[12], 0.1, m.elements[14]); return q; });
    inst(new THREE.CircleGeometry(9, 16), new THREE.MeshBasicMaterial({ color: 0xffb36b, transparent: true, opacity: 0.16, depthWrite: false, toneMapped: false }), pools);
  }
  { // round trees and palms
    const GC = [0x3f6b2e, 0x4a7a34, 0x365f2a, 0x55853a];
    const cn = inst(new THREE.IcosahedronGeometry(1, 1), M(0xffffff, 0.9), trees.map(([x, z, r]) => new THREE.Matrix4().compose(V(x, r * 1.2 + r * 0.9, z), new THREE.Quaternion(), V(r, r * 0.85, r))), scene, !LOW);
    trees.forEach((_, i) => cn.setColorAt(i, new THREE.Color(GC[(rnd() * 4) | 0])));
    inst(new THREE.CylinderGeometry(0.18, 0.28, 1, 6), M(0x6b5844, 0.9), trees.map(([x, z, r]) => new THREE.Matrix4().compose(V(x, r * 0.6, z), new THREE.Quaternion(), V(1, r * 1.2, 1))), scene, !LOW);
    const leaves = []; for (let k = 0; k < 9; k++) { const l = new THREE.BoxGeometry(0.5, 0.06, 4.2).translate(0, 0, 2.1); l.rotateX(0.35); l.rotateY(k / 9 * Math.PI * 2); leaves.push(l); }
    const ph = palms.map(() => 8 + rnd() * 4);
    inst(mergeGeometries(leaves), M(0x4f7d32, 0.85), palms.map(([x, z], i) => new THREE.Matrix4().compose(V(x, ph[i], z), new THREE.Quaternion().setFromAxisAngle(V(0, 1, 0), rnd() * 6), V(1, 1, 1))), scene, !LOW);
    inst(new THREE.CylinderGeometry(0.22, 0.32, 1, 7), M(0x8a7458, 0.9), palms.map(([x, z], i) => new THREE.Matrix4().compose(V(x, ph[i] / 2, z), new THREE.Quaternion(), V(1, ph[i], 1))), scene, !LOW);
  }

  // ---------------- the field ----------------
  { const EX = A0 + WALL, EZ = B0 + WALL, cw = 2048, k = cw / (2 * EX), ch = Math.round(2 * EZ * k);
    const c = document.createElement('canvas'); c.width = cw; c.height = ch; const g = c.getContext('2d');
    const X = x => (x + EX) * k, Z = z => (z + EZ) * k, [CL, CW] = F.court, hl = CL / 2, hw = CW / 2;
    const line = (w = 0.08) => { g.strokeStyle = 'rgba(255,255,255,.92)'; g.lineWidth = w * k; };
    const rect = (x0, z0, x1, z1) => g.strokeRect(X(x0), Z(z0), (x1 - x0) * k, (z1 - z0) * k);
    const seg = (x0, z0, x1, z1) => { g.beginPath(); g.moveTo(X(x0), Z(z0)); g.lineTo(X(x1), Z(z1)); g.stroke(); };
    const fillR = (x0, z0, x1, z1, col) => { g.fillStyle = col; g.fillRect(X(x0), Z(z0), (x1 - x0) * k, (z1 - z0) * k); };
    if (FT === 'football') {
      for (let i = 0; i < 24; i++) fillR(-EX + i * 2 * EX / 24, -EZ, -EX + (i + 1) * 2 * EX / 24 + 0.1, EZ, i % 2 ? '#3f8f3a' : '#4d9e44');
      line(0.12); rect(-hl, -hw, hl, hw); seg(0, -hw, 0, hw);
      g.beginPath(); g.arc(X(0), Z(0), 9.15 * k, 0, 7); g.stroke();
      for (const s of [-1, 1]) { const gx = s * hl;
        g.strokeRect(Math.min(X(gx), X(gx - s * 16.5)), Z(-20.16), 16.5 * k, 40.32 * k);
        g.strokeRect(Math.min(X(gx), X(gx - s * 5.5)), Z(-9.16), 5.5 * k, 18.32 * k);
        g.beginPath(); g.arc(X(gx - s * 11), Z(0), 9.15 * k, s > 0 ? Math.PI * 0.705 : -Math.PI * 0.295, s > 0 ? Math.PI * 1.295 : Math.PI * 0.295); g.stroke();
        g.fillStyle = '#fff'; g.beginPath(); g.arc(X(gx - s * 11), Z(0), 0.2 * k, 0, 7); g.fill(); }
    } else if (FT === 'basketball') {
      fillR(-EX, -EZ, EX, EZ, '#1c1f25'); fillR(-hl - 2, -hw - 2, hl + 2, hw + 2, brandHex);
      fillR(-hl, -hw, hl, hw, '#c9935c');
      g.globalAlpha = 0.18; for (let x = -hl; x < hl; x += 0.25) { g.fillStyle = hash(Math.round(x * 4)) < 0.5 ? '#7a4a22' : '#f0c08a'; g.fillRect(X(x), Z(-hw), 0.12 * k, CW * k); } g.globalAlpha = 1;
      for (const s of [-1, 1]) { fillR(Math.min(s * hl, s * (hl - 5.8)), -2.45, Math.max(s * hl, s * (hl - 5.8)), 2.45, brandHex); }
      line(0.06); rect(-hl, -hw, hl, hw); seg(0, -hw, 0, hw);
      g.beginPath(); g.arc(X(0), Z(0), 1.8 * k, 0, 7); g.stroke();
      for (const s of [-1, 1]) { const bx = s * (hl - 1.575);
        rect(Math.min(s * hl, s * (hl - 5.8)), -2.45, Math.max(s * hl, s * (hl - 5.8)), 2.45);
        g.beginPath(); g.arc(X(s * (hl - 5.8)), Z(0), 1.8 * k, 0, 7); g.stroke();
        const zc = hw - 0.9, ang = Math.asin(zc / 6.75); g.beginPath();
        if (s > 0) g.arc(X(bx), Z(0), 6.75 * k, Math.PI - ang, Math.PI + ang); else g.arc(X(bx), Z(0), 6.75 * k, -ang, ang);
        g.stroke(); const xe = bx - s * 6.75 * Math.cos(ang); seg(s * hl, -zc, xe, -zc); seg(s * hl, zc, xe, zc); }
      g.fillStyle = 'rgba(255,255,255,.9)'; g.textAlign = 'center'; g.textBaseline = 'middle'; let fs = 1.1 * k; g.font = `800 ${fs}px ${FONT}`;
      while (g.measureText(C.shortName || '').width > 3.2 * k && fs > 6) { fs -= 1; g.font = `800 ${fs}px ${FONT}`; } g.fillText(C.shortName || '', X(0), Z(0));
    } else if (FT === 'tennis' || FT === 'padel') {
      fillR(-EX, -EZ, EX, EZ, FT === 'tennis' ? '#3d7a5a' : '#1d2b45'); fillR(-hl, -hw, hl, hw, FT === 'tennis' ? '#2d5f9e' : '#2a6fb3');
      line(0.06); rect(-hl, -hw, hl, hw); seg(0, -hw - 0.5, 0, hw + 0.5);
      if (FT === 'tennis') { rect(-hl, -4.115, hl, 4.115); seg(-6.4, -4.115, -6.4, 4.115); seg(6.4, -4.115, 6.4, 4.115); seg(-6.4, 0, 6.4, 0); }
      else { seg(-6.95, -hw, -6.95, hw); seg(6.95, -hw, 6.95, hw); seg(-6.95, 0, 6.95, 0); }
    } else {
      fillR(-EX, -EZ, EX, EZ, '#8d8f93'); g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 2; for (let x = -EX; x < EX; x += 4) seg(x, -EZ, x, EZ); for (let z = -EZ; z < EZ; z += 4) seg(-EX, z, EX, z);
      g.strokeStyle = brandHex; g.lineWidth = 0.6 * k; g.beginPath(); g.arc(X(0), Z(0), Math.min(hw, 10) * k, 0, 7); g.stroke();
    }
    const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; tx.anisotropy = 16;
    const pts = SAMP.map(t => off(t, WALL, 0)).map(p => new THREE.Vector2(p.x, -p.z));
    const geo = new THREE.ShapeGeometry(new THREE.Shape(pts)); const pa = geo.attributes.position, uv = geo.attributes.uv;
    for (let i = 0; i < pa.count; i++) uv.setXY(i, (pa.getX(i) + EX) / (2 * EX), (EZ + pa.getY(i)) / (2 * EZ));
    const floor = new THREE.Mesh(geo, M(0xffffff, FT === 'basketball' ? 0.6 : 0.95, 0, { map: tx })); floor.rotation.x = -Math.PI / 2; floor.position.y = 0.03; floor.receiveShadow = true; scene.add(floor);

    const mw = M(0xffffff, 0.3);
    if (FT === 'football') for (const s of [-1, 1]) {
      const gp = new THREE.Group(), post = new THREE.CylinderGeometry(0.06, 0.06, 2.44, 10);
      for (const z of [-3.66, 3.66]) { const p = new THREE.Mesh(post, mw); p.position.set(0, 1.22, z); gp.add(p); }
      const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 7.44, 10), mw); bar.rotation.x = Math.PI / 2; bar.position.set(0, 2.44, 0); gp.add(bar);
      const net = new THREE.Mesh(new THREE.BoxGeometry(2, 2.44, 7.32), new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.28, roughness: 1, side: THREE.DoubleSide, depthWrite: false })); net.position.set(s * 1, 1.22, 0); gp.add(net);
      gp.position.x = s * hl; gp.traverse(o => o.castShadow = true); scene.add(gp);
    }
    if (FT === 'basketball') for (const s of [-1, 1]) {
      const gp = new THREE.Group();
      const pole = new THREE.Mesh(new THREE.BoxGeometry(0.35, 3.4, 0.35), mDark); pole.position.set(s * 1.6, 1.7, 0); gp.add(pole);
      const arm = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.18, 0.18), mDark); arm.position.set(s * 0.8, 3.4, 0); gp.add(arm);
      const pad = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.0, 1.2), mBrand); pad.position.set(s * 1.6, 0.5, 0); gp.add(pad);
      const board = new THREE.Mesh(new THREE.BoxGeometry(0.05, 1.05, 1.8), mGlass); board.position.set(0, 3.45, 0); gp.add(board);
      const rim = new THREE.Mesh(new THREE.TorusGeometry(0.225, 0.02, 8, 24), M(0xff5a1f, 0.4, 0.4)); rim.rotation.x = Math.PI / 2; rim.position.set(-s * 0.38, 3.05, 0); gp.add(rim);
      gp.position.x = s * (hl - 1.2); gp.traverse(o => o.castShadow = true); scene.add(gp);
    }
    if (FT === 'tennis' || FT === 'padel') {
      const net = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.95, CW + 1), new THREE.MeshStandardMaterial({ color: 0x111111, transparent: true, opacity: 0.6, side: THREE.DoubleSide })); net.position.set(0, 0.48, 0); scene.add(net);
      if (FT === 'padel') { const gl = [], posts = [];
        for (const s of [-1, 1]) { gl.push(new THREE.Matrix4().compose(V(s * hl, 2, 0), new THREE.Quaternion(), V(0.05, 4, CW))); for (const z of [-1, 1]) gl.push(new THREE.Matrix4().compose(V(s * (hl - 2), 1.5, z * hw), new THREE.Quaternion(), V(4, 3, 0.05))); }
        for (let x = -hl; x <= hl; x += 2) for (const z of [-hw, hw]) posts.push(new THREE.Matrix4().compose(V(x, 2, z), new THREE.Quaternion(), V(0.08, 4, 0.08)));
        inst(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshPhysicalMaterial({ color: 0xcfe3ee, roughness: 0.05, transparent: true, opacity: 0.22, depthWrite: false, side: THREE.DoubleSide }), gl);
        inst(new THREE.BoxGeometry(1, 1, 1), mDark, posts); }
    }
    if (F.boards) { const btx = boardTex(), bm = new THREE.MeshBasicMaterial({ map: btx, toneMapped: false });
      const bx = hl + F.boards[0], bz = hw + F.boards[1], lenS = Math.min(2 * hl * 0.88, 2 * (A0 + WALL) - 6), lenE = Math.min(2 * hw * 0.74, 2 * (B0 + WALL) - 6);
      btx.repeat.set(lenS / 46, 1);
      for (const s of [-1, 1]) {
        const b = new THREE.Mesh(new THREE.BoxGeometry(lenS, 0.9, 0.2), [mDark, mDark, mDark, mDark, bm, bm]); b.position.set(0, 0.45, s * bz); scene.add(b);
        const e = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.9, lenE), [bm, bm, mDark, mDark, mDark, mDark]); e.position.set(s * bx, 0.45, 0); scene.add(e);
      } }
  }

  // ---------------- night lights ----------------
  if (LK.night || ROOF === 'closed') {
    const n1 = LOW ? 8 : 16, small = clamp(A0 / 60, 0.3, 1), inten = (LK.night ? 5.5 : 2.5) * small * (FT === 'basketball' || FT === 'plain' ? 0.75 : 1);   // smaller venues and light floors need less light
    for (let k = 0; k < n1; k++) {
      const t = k / n1 * L0, p = ROOF !== 'none' ? off(t, ROOF_IN + 1, roofY(ROOF_IN) - 2) : off(t, TOP_D - 1, TOP_Y + 14);
      const sp = new THREE.SpotLight(0xf4f7ff, inten, 0, 0.55, 0.5, 0); sp.position.copy(p);
      const tt = new THREE.Object3D(); tt.position.set(p.x * 0.15, 0, p.z * 0.15); scene.add(tt); sp.target = tt; scene.add(sp);
    }
    if (!LOW) for (let k = 0; k < 16; k++) {
      const t = (k + 0.5) / 16 * L0, p = off(t, ROOF_IN + 3, (ROOF !== 'none' ? roofY(ROOF_IN) : TOP_Y + 12) - 3), q = off(t, (T1.rows[0].d + TOP_D) / 2, TOP_Y * 0.5);
      const sp = new THREE.SpotLight(0xfff1dc, (LK.night ? 0.75 : 0.5) * small, 0, 0.7, 0.8, 0); sp.position.copy(p);
      const tt = new THREE.Object3D(); tt.position.copy(q); scene.add(tt); sp.target = tt; scene.add(sp);
    }
    scene.add(new THREE.AmbientLight(0x8aa0d0, LK.night ? 0.12 : 0.2));
  }

  /* =====================================================================
     SEAT PICKER: plan > zone > block > seat > upgrade > ticket
     ===================================================================== */
  const ui = { top: $('top'), sheet: $('sheet'), chips: $('chips'), tip: $('tip'), toast: $('toast'), ticket: $('ticket'), title: $('stepTitle') };
  document.documentElement.lang = C.lang || 'en';
  document.title = (C.name || 'Stadium') + ' · ' + (TX.stepPlan || 'Choose your seat');
  $('venue').textContent = C.name || '';
  const root = document.documentElement.style;
  root.setProperty('--accent', '#' + ACCENT.getHexString());
  { const c = ACCENT, l = 0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b; root.setProperty('--on-accent', l > 0.35 ? '#111' : '#fff'); }
  root.setProperty('--brand', brandHex);

  const S = { step: 'plan', zone: -1, block: -1, seat: -1, vip: false, hoverZone: -1, hoverBlock: -1, hoverSeat: -1, thumb: '', box: null };
  const STEPS = ['plan', 'zone', 'block', 'seat', 'upgrade', 'ticket'];
  const TITLES = { plan: TX.stepPlan, zone: TX.stepZone, block: TX.stepBlock, pick: TX.stepBlock, seat: TX.stepSeat, upgrade: TX.stepUpgrade, ticket: TX.stepTicket };
  const blockOf = id => BLOCKS.get(id);
  const seatLabel = i => `${TX.row} ${sRow[i] + 1} · ${TX.seat} ${sNo[i]}`;
  const availTxt = n => n <= 0 ? [TX.soldOut, 'no'] : n <= 20 ? [`${num.format(n)} ${TX.left}`, 'few'] : [`${num.format(n)} ${TX.left}`, 'ok'];

  // ---- colours of the seats for the current step ----
  function repaint() {
    const a = seats.instanceColor.array, st = S.step, put = (i, c) => { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; };
    a.set(base3);
    if (st === 'plan') { for (let i = 0; i < N; i++) { const z = seatZone[i]; if (z === S.hoverZone && !ZONES[z].soldOut) put(i, ACC); else if (ZONES[z].soldOut) put(i, GREY); } }
    else if (st === 'zone') { for (let i = 0; i < N; i++) { const b = seatBlock[i]; if (b === S.block || b === S.hoverBlock) put(i, ACC); else if (seatZone[i] === S.zone && BLOCKS.get(b).sold) put(i, GREY); } }
    else if (st === 'block') { for (let k = 0; k < N * 3; k++) a[k] *= 0.42; const bl = blockOf(S.block).list; for (const i of bl) { if (taken[i]) put(i, GREY); else { a[i * 3] = base3[i * 3]; a[i * 3 + 1] = base3[i * 3 + 1]; a[i * 3 + 2] = base3[i * 3 + 2]; } } if (S.hoverSeat >= 0 && S.hoverSeat !== S.seat) put(S.hoverSeat, ACC_SOFT); if (S.seat >= 0) put(S.seat, ACC); }
    else if (S.seat >= 0) put(S.seat, ACC);
    seats.instanceColor.needsUpdate = true;
    pin.visible = st === 'block' && S.seat >= 0; if (pin.visible) pin.position.set(sX[S.seat], sY[S.seat] + 2.1, sZ[S.seat]);
  }
  const pin = new THREE.Mesh(new THREE.ConeGeometry(0.32, 0.9, 20).rotateX(Math.PI), new THREE.MeshBasicMaterial({ color: ACC, toneMapped: false }));
  pin.add(new THREE.Mesh(new THREE.SphereGeometry(0.34, 20, 12).translate(0, 0.5, 0), pin.material)); pin.visible = false; scene.add(pin);

  // ---- picking: the seat closest to the pointer ray ----
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  function pick(cx, cy, list, opt = {}) {
    const r = renderer.domElement.getBoundingClientRect(); ndc.set((cx - r.left) / r.width * 2 - 1, -(cy - r.top) / r.height * 2 + 1);
    ray.setFromCamera(ndc, camera); const o = ray.ray.origin, v = ray.ray.direction;
    let best = -1, bt = 1e9, bp = 1e9; const tolK = opt.tol || 0.006, n = list ? list.length : N;
    for (let k = 0; k < n; k++) {
      const i = list ? list[k] : k; if (opt.free && taken[i]) continue;
      const dx = sX[i] - o.x, dy = sY[i] + 0.5 - o.y, dz = sZ[i] - o.z, t = dx * v.x + dy * v.y + dz * v.z; if (t <= 0) continue;
      const ex = dx - v.x * t, ey = dy - v.y * t, ez = dz - v.z * t, p2 = ex * ex + ey * ey + ez * ez;
      if (opt.nearest) { if (p2 < bp) { bp = p2; best = i; } continue; }
      const tol = Math.max(0.45, t * tolK); if (p2 < tol * tol && t < bt) { best = i; bt = t; }
    }
    if (opt.nearest && best >= 0) { const d = Math.hypot(sX[best] - o.x, sY[best] - o.y, sZ[best] - o.z); if (Math.sqrt(bp) > Math.max(2, d * 0.08)) return -1; }
    return best;
  }

  // ---- cameras: fit a set of points in the free part of the screen ----
  const fitCam = new THREE.PerspectiveCamera();
  function pads() { return { top: ui.top.offsetHeight + 14, bottom: (ui.sheet.classList.contains('on') ? ui.sheet.offsetHeight : 0) + 20 }; }
  function fit(points, dir, fov, mx = 0.9) {
    const w = innerWidth, h = innerHeight, pd = pads(), oy = (pd.bottom - pd.top) / 2;
    const tgt = V(0, 0, 0); points.forEach(p => tgt.add(p)); tgt.multiplyScalar(1 / points.length);
    fitCam.fov = fov; fitCam.aspect = w / h; fitCam.near = 0.3; fitCam.far = 30000; fitCam.setViewOffset(w, h, 0, oy, w, h); fitCam.updateProjectionMatrix();
    const yT = 1 - 2 * pd.top / h, yB = -1 + 2 * pd.bottom / h, yc = (yT + yB) / 2, yh = (yT - yB) / 2 * mx, d = dir.clone().normalize(), p = V(0, 0, 0);
    const ok = dist => { fitCam.position.copy(tgt).addScaledVector(d, dist); fitCam.lookAt(tgt); fitCam.updateMatrixWorld();
      for (const q of points) { p.copy(q).project(fitCam); if (p.z > 1 || Math.abs(p.x) > mx || Math.abs(p.y - yc) > yh) return false; } return true; };
    let lo = 2, hi = 20000; for (let k = 0; k < 40; k++) { const m = (lo + hi) / 2; if (ok(m)) hi = m; else lo = m; }
    return { p: tgt.clone().addScaledVector(d, hi), q: tgt, fov, oy };
  }
  const sample = (list, n) => { const out = [], st = Math.max(1, Math.floor(list.length / n)); for (let k = 0; k < list.length; k += st) { const i = list[k]; out.push(V(sX[i], sY[i] + 0.4, sZ[i])); } return out; };
  const zoneCentre = z => { let sx = 0, sz = 0, sy = 0, n = 0; for (const b of ZINFO[z].blocks) for (let k = 0; k < b.list.length; k += 9) { const i = b.list[k]; sx += sX[i]; sz += sZ[i]; sy += sY[i]; n++; } return V(sx / n, sy / n, sz / n); };
  const ZC = ZONES.map((_, z) => zoneCentre(z));
  const zoneLabelPos = z => { const b = ZINFO[z].blocks, s = [...new Set(b.map(x => x.sec))]; const ang = s.map(k => 2 * Math.PI * secMid(k) / L0); const t = (Math.atan2(ang.reduce((a, x) => a + Math.sin(x), 0), ang.reduce((a, x) => a + Math.cos(x), 0)) + 2 * Math.PI) % (2 * Math.PI) * L0 / (2 * Math.PI);
    const ti = Math.min(1, TIERS.length - 1), r = TIERS[ti].rows[Math.floor(TIERS[ti].rows.length / 2)]; return off(t, r.d, r.y + 1); };
  const blockCentre = b => { const r = TIERS[b.ti].rows[Math.floor(TIERS[b.ti].rows.length / 2)]; return off(secMid(b.sec), r.d + r.T * 0.4, r.y + 0.8); };
  function viewOf(step) {
    const w = innerWidth, h = innerHeight, portrait = w < h;
    if (step === 'plan') {
      const pts = []; for (let k = 0; k < SAMP.length; k += 2) { pts.push(off(SAMP[k], FAC0 + 4, 0)); pts.push(off(SAMP[k], TOP_D, TOP_Y)); }
      return fit(pts, portrait ? V(0.16, 1, 0) : V(0, 1, 0.16), 40, 0.94);
    }
    if (step === 'zone') { const c = ZC[S.zone], n = V(c.x, 0, c.z).normalize(); return fit(sample(ZINFO[S.zone].blocks.flatMap(b => b.list), 400), V(-n.x, 1.15, -n.z), 42, 0.92); }
    if (step === 'block' || step === 'pick') { const b = blockOf(S.block), c = blockCentre(b), n = V(c.x, 0, c.z).normalize(); return fit(sample(b.list, 300), V(-n.x, 0.62, -n.z), 40, 0.8); }
    const pd = pads(), oy = (pd.bottom - pd.top) / 2;
    if (step === 'seat' || (step === 'ticket' && !S.vip)) {
      const i = S.seat, n = V(sX[i], 0, sZ[i]).normalize();
      return { p: V(sX[i] + n.x * 0.1, sY[i] + 1.15, sZ[i] + n.z * 0.1), q: V(sX[i] * 0.1, 1, sZ[i] * 0.1), fov: portrait ? 70 : 58, oy };
    }
    const bx = S.box || nearestBox(S.seat), side = bx.side;
    return { p: V(bx.x - 0.6, SKY_Y + 2.75, side * (B0 + SKY_D0 + 5.6)), q: V(bx.x * 0.5 + 6, 1.5, side * B0 * 0.15), fov: portrait ? 78 : 62, oy };
  }
  function nearestBox(i) { const side = sZ[i] < 0 ? -1 : 1; let best = BOXES[0], bd = 1e9; for (const b of BOXES) { const d = (b.side === side ? 0 : 1e6) + Math.abs(b.x - sX[i]); if (d < bd) { bd = d; best = b; } } return best; }

  // ---- camera moves ----
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true; controls.dampingFactor = 0.08; controls.maxPolarAngle = Math.PI * 0.495; controls.screenSpacePanning = true;
  let tw = null, curOY = 0;
  const ease = x => x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
  function applyCam(p, q, fov, oy) { camera.position.copy(p); camera.fov = fov; curOY = oy; camera.setViewOffset(innerWidth, innerHeight, 0, oy, innerWidth, innerHeight); camera.updateProjectionMatrix(); controls.target.copy(q); camera.lookAt(q); }
  function moveTo(v, instant, done) {
    const roofOn = ['seat', 'upgrade', 'ticket'].includes(S.step); roofG.visible = roofOn || Q.get('roof') === '1';
    if (instant || REDUCED) { tw = null; applyCam(v.p, v.q, v.fov, v.oy); controls.update(); controls.enabled = !roofOn; done && done(); return; }
    const dist = camera.position.distanceTo(v.p);
    tw = { t0: performance.now(), dur: clamp(700 + dist * 3, 900, 1900), p0: camera.position.clone(), q0: controls.target.clone(), f0: camera.fov, o0: curOY, v, done };
    controls.enabled = false;
  }
  function stepTween(now) {
    if (!tw) return; const k = clamp((now - tw.t0) / tw.dur, 0, 1), e = ease(k), v = tw.v;
    const p = tw.p0.clone().lerp(v.p, e), q = tw.q0.clone().lerp(v.q, e);
    const lift = Math.sin(Math.PI * e) * Math.min(40, tw.p0.distanceTo(v.p) * 0.12); p.y += lift;
    applyCam(p, q, tw.f0 + (v.fov - tw.f0) * e, tw.o0 + (v.oy - tw.o0) * e);
    if (k >= 1) { const d = tw.done; tw = null; controls.enabled = !['seat', 'upgrade', 'ticket'].includes(S.step); controls.update(); d && d(); }
  }

  // ---- floating labels ----
  let chipList = [];
  function setChips(items) {
    ui.chips.innerHTML = ''; chipList = items.map(it => { const b = document.createElement('button'); b.className = 'chip ' + (it.cls || ''); b.innerHTML = it.html; b.onclick = e => { e.stopPropagation(); it.onClick(e); }; ui.chips.appendChild(b); return { el: b, pos: it.pos }; });
  }
  const tmpV = V(0, 0, 0);
  function placeChips() {
    const w = innerWidth, h = innerHeight;
    for (const c of chipList) { tmpV.copy(c.pos).project(camera); const vis = tmpV.z < 1 && Math.abs(tmpV.x) < 1.05 && Math.abs(tmpV.y) < 1.05;
      c.x = (tmpV.x + 1) / 2 * w; c.y = (1 - tmpV.y) / 2 * h; c.vis = vis; if (!c.w) { c.w = c.el.offsetWidth; c.h = c.el.offsetHeight; } }
    // labels never sit on top of each other: push overlapping pairs apart, keep them inside the free part of the screen
    const pd = { t: ui.top.offsetHeight + 4, b: h - (ui.sheet.classList.contains('on') ? ui.sheet.offsetHeight + 20 : 0) - 4 };
    for (let it = 0; it < 6; it++) for (let i = 0; i < chipList.length; i++) for (let j = i + 1; j < chipList.length; j++) {
      const a = chipList[i], b = chipList[j]; if (!a.vis || !b.vis) continue;
      const ox = (a.w + b.w) / 2 + 3 - Math.abs(a.x - b.x), oy = (a.h + b.h) / 2 + 3 - Math.abs(a.y - b.y);
      if (ox > 0 && oy > 0) { if (ox < oy) { const s = a.x < b.x ? -1 : 1; a.x += s * ox / 2; b.x -= s * ox / 2; } else { const s = a.y < b.y ? -1 : 1; a.y += s * oy / 2; b.y -= s * oy / 2; } }
    }
    for (const c of chipList) { const x = clamp(c.x, c.w / 2 + 4, w - c.w / 2 - 4), y = clamp(c.y, pd.t + c.h / 2, pd.b - c.h / 2);
      c.el.style.transform = `translate(${x}px, ${y}px) translate(-50%, -50%)`; c.el.style.visibility = c.vis && Math.abs(y - c.y) < 60 ? 'visible' : 'hidden'; }
  }

  // ---- the bottom sheet ----
  const esc = s => String(s).replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
  function sheet(html, actions = {}) {
    ui.sheet.innerHTML = html; ui.sheet.classList.toggle('on', !!html);
    ui.sheet.querySelectorAll('[data-a]').forEach(b => b.onclick = e => { e.stopPropagation(); actions[b.dataset.a] && actions[b.dataset.a](); });
  }
  let toastT = 0;
  function toast(t) { ui.toast.textContent = t; ui.toast.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => ui.toast.classList.remove('on'), 1800); }
  function header() {
    ui.title.textContent = TITLES[S.step] || ''; $('back').hidden = S.step === 'plan';
    const idx = Math.max(0, STEPS.indexOf(S.step === 'pick' ? 'block' : S.step));
    document.querySelectorAll('#dots li').forEach((li, k) => { li.classList.toggle('on', k <= idx); });
  }

  // ---- the steps ----
  function enterPlan(instant) {
    S.step = 'plan'; S.zone = S.block = S.seat = S.hoverZone = S.hoverBlock = S.hoverSeat = -1; S.vip = false; S.box = null; hideTicket(); header();
    const lo = Math.min(...ZINFO.map(z => z.from)), hi = Math.max(...ZINFO.map(z => z.from));
    sheet(`<h2>${esc(TX.stepPlan)}</h2><p>${esc(TX.planHint)}</p><p class="range">${esc(TX.from)} <b>${fmt(lo)}</b>${hi > lo ? ` · ${fmt(hi)}` : ''}</p>`);
    setChips(ZONES.map((z, k) => ({ pos: zoneLabelPos(k), cls: z.soldOut ? 'zone sold' : 'zone', html: `<b>${esc(z.name)}</b><small>${z.soldOut ? esc(TX.soldOut) : esc(TX.from) + ' ' + fmt(ZINFO[k].from)}</small>`, onClick: () => tapZone(k) })));
    repaint(); moveTo(viewOf('plan'), instant);
  }
  function tapZone(z) { if (ZONES[z].soldOut) { toast(`${ZONES[z].name} · ${TX.soldOut}`); return; } enterZone(z); }
  function zoneSheet() {
    const z = ZONES[S.zone], zi = ZINFO[S.zone];
    if (S.block < 0) {
      const rows = [...zi.tiers].sort().map(ti => `<li><span>${esc(TIERS[ti].cfg.name || TX.tier + ' ' + (ti + 1))}</span><b>${fmt(priceOf(ti, S.zone))}</b></li>`).join('');
      sheet(`<p class="kick">${esc(z.name)}</p><h2>${esc(TX.stepZone)}</h2><p>${esc(TX.zoneHint)}</p><ul class="tiers">${rows}</ul>`);
    } else {
      const b = blockOf(S.block), [at, ac] = availTxt(b.free);
      sheet(`<p class="kick">${esc(z.name)} · ${esc(TIERS[b.ti].cfg.name || '')}</p><h2>${esc(TX.block)} ${blockNo(b.ti, b.sec)}</h2><p class="av ${ac}">${esc(at)}</p><div class="row"><b class="price">${fmt(priceOf(b.ti, S.zone))}</b><button class="btn" data-a="go">${esc(TX.seeSeats)}</button></div>`, { go: () => enterBlock(S.block) });
    }
  }
  function enterZone(z, instant) {
    S.step = 'zone'; S.zone = z; S.block = -1; S.seat = -1; S.hoverBlock = -1; header(); zoneSheet();
    setChips(ZINFO[z].blocks.map(b => ({ pos: blockCentre(b), cls: 'blk' + (b.sold ? ' sold' : ''), html: String(blockNo(b.ti, b.sec)), onClick: e => tapBlock(b.id, e && e.pointerType === 'mouse' ? 'mouse' : 'touch') })));
    repaint(); moveTo(viewOf('zone'), instant);
  }
  function tapBlock(id, type) {
    const b = blockOf(id); if (!b) return; if (b.zone !== S.zone) { if (!ZONES[b.zone].soldOut) enterZone(b.zone); return; }
    if (b.sold || b.free <= 0) { toast(`${TX.block} ${blockNo(b.ti, b.sec)} · ${TX.soldOut}`); return; }
    if (type === 'mouse' || S.block === id) { enterBlock(id); return; }
    S.block = id; zoneSheet(); repaint(); chipList.forEach(c => c.el.classList.toggle('sel', c.el.textContent === String(blockNo(b.ti, b.sec))));
  }
  function blockSheet() {
    const b = blockOf(S.block), z = ZONES[b.zone];
    if (S.seat < 0) { sheet(`<p class="kick">${esc(z.name)} · ${esc(TX.block)} ${blockNo(b.ti, b.sec)}</p><h2>${esc(TX.stepBlock)}</h2><p>${esc(TX.blockHint)}</p>`); return; }
    sheet(`<p class="kick">${esc(TX.block)} ${blockNo(b.ti, b.sec)} · ${esc(TIERS[b.ti].cfg.name || '')}</p><h2>${esc(seatLabel(S.seat))}</h2>
      <div class="row"><div class="nav"><button class="icon" data-a="prev" aria-label="Previous seat">‹</button><button class="icon" data-a="next" aria-label="Next seat">›</button></div><b class="price">${fmt(priceOf(b.ti, b.zone))}</b></div>
      <button class="btn wide" data-a="take">${esc(TX.takeSeat)}</button>`, { prev: () => stepSeat(-1), next: () => stepSeat(1), take: () => enterSeat() });
  }
  function enterBlock(id, instant) {
    S.step = 'block'; S.block = id; S.seat = -1; S.hoverSeat = -1; header(); setChips([]); blockSheet(); repaint();
    moveTo(viewOf('block'), instant);
  }
  function selectSeat(i) { if (i < 0) return; if (taken[i]) { toast(TX.taken); return; } S.seat = i; blockSheet(); repaint(); }
  function stepSeat(dir) {   // next free seat along the row
    const b = blockOf(S.block), i0 = S.seat, row = b.list.filter(i => sRow[i] === sRow[i0] && !taken[i]).sort((a, c) => sNo[a] - sNo[c]);
    const k = row.indexOf(i0), j = row[(k + dir + row.length) % row.length]; if (j != null) selectSeat(j);
  }
  function enterSeat(instant) {
    S.step = 'seat'; S.vip = false; S.thumb = ''; header(); setChips([]);
    const b = blockOf(S.block), z = ZONES[b.zone];
    sheet(`<p class="kick">${esc(TX.yourView)}</p><h2>${esc(seatLabel(S.seat))}</h2><p>${esc(TX.block)} ${blockNo(b.ti, b.sec)} · ${esc(TIERS[b.ti].cfg.name || '')} · ${esc(z.name)}</p>
      <div class="row"><b class="price">${fmt(priceOf(b.ti, b.zone))}</b><button class="btn" data-a="go">${esc(TX.continue)}</button></div><button class="ghost wide" data-a="change">${esc(TX.changeSeat)}</button>`,
      { go: () => enterUpgrade(), change: () => enterBlock(S.block) });
    repaint(); moveTo(viewOf('seat'), instant, () => { S.thumb = snap(); });
  }
  function enterUpgrade(instant) {
    if (!S.thumb && !tw) S.thumb = snap(); S.step = 'upgrade'; S.vipThumb = ''; S.box = nearestBox(S.seat); header(); setChips([]);
    const vip = C.vip || {}, perks = (vip.perks || []).map(p => `<li>${esc(p)}</li>`).join('');
    sheet(`<p class="kick">${esc(vip.name || 'VIP')} ${S.box.no}</p><h2>${esc(TX.upgradeTitle)}</h2>${perks ? `<ul class="perks">${perks}</ul>` : ''}
      <div class="row"><b class="price">+${fmt(vip.upgrade || 0)}</b><button class="btn" data-a="yes">${esc(TX.upgradeYes)}</button></div><button class="ghost wide" data-a="no">${esc(TX.upgradeNo)}</button>`,
      { yes: () => { S.vip = true; if (!S.vipThumb) S.vipThumb = snap(); enterTicket(); }, no: () => { S.vip = false; enterTicket(); } });
    repaint(); moveTo(viewOf('upgrade'), instant, () => { S.vipThumb = snap(); });
  }
  function enterTicket(instant) {
    S.step = 'ticket'; header(); setChips([]); sheet('');
    const b = blockOf(S.block), z = ZONES[b.zone], vip = C.vip || {}, price = priceOf(b.ti, b.zone) + (S.vip ? (vip.upgrade || 0) : 0), ev = C.event || {};
    const f = (k, v) => `<div class="fld"><span>${esc(k)}</span><b>${esc(v)}</b></div>`;
    const fields = S.vip ? [f(TX.box, `${vip.name || 'VIP'} ${S.box.no}`), f(TX.stand, z.name), f(TX.block, blockNo(b.ti, b.sec)), f(TX.row, sRow[S.seat] + 1), f(TX.seat, sNo[S.seat])]
      : [f(TX.stand, z.name), f(TX.tier, TIERS[b.ti].cfg.name || ''), f(TX.block, blockNo(b.ti, b.sec)), f(TX.row, sRow[S.seat] + 1), f(TX.seat, sNo[S.seat])];
    const img = S.vip ? S.vipThumb : S.thumb;
    ui.ticket.innerHTML = `<div class="tk${S.vip ? ' vip' : ''}" role="dialog" aria-label="${esc(TX.stepTicket)}">
      <div class="tk-view">${img ? `<img src="${img}" alt="">` : ''}<span class="tag"><i></i>${esc(S.vip ? TX.yourBoxView : TX.yourView)}</span></div>
      <div class="tk-body"><p class="kick">${esc([ev.title, ev.date, ev.time].filter(Boolean).join(' · '))}</p><h2>${esc(C.name || '')}</h2><div class="grid">${fields.join('')}</div></div>
      <div class="tk-stub"><div class="bars" aria-hidden="true">${'<i></i>'.repeat(34)}</div><div class="tot"><span>${esc(TX.total)}</span><b>${fmt(price)}</b></div></div>
      <div class="tk-act"><button class="btn wide" data-t="ok">${esc(C.checkoutUrl ? TX.pay : TX.confirm)}</button><button class="ghost wide" data-t="again">${esc(TX.anotherSeat)}</button></div>
      ${TX.note ? `<p class="tk-note">${esc(TX.note)}</p>` : ''}<div class="stamp">${esc(TX.booked)}</div></div>`;
    ui.ticket.hidden = false; requestAnimationFrame(() => ui.ticket.classList.add('on'));
    ui.ticket.querySelector('[data-t=ok]').onclick = () => {
      if (C.checkoutUrl) { const u = new URL(C.checkoutUrl, location.href); Object.entries({ stand: z.name, block: blockNo(b.ti, b.sec), row: sRow[S.seat] + 1, seat: sNo[S.seat], vip: S.vip ? 1 : 0, price }).forEach(([k, v]) => u.searchParams.set(k, v)); location.href = u.toString(); return; }
      ui.ticket.querySelector('.tk').classList.add('booked'); };
    ui.ticket.querySelector('[data-t=again]').onclick = () => enterPlan();
    repaint(); moveTo(viewOf('ticket'), instant);
  }
  function hideTicket() { ui.ticket.classList.remove('on'); ui.ticket.hidden = true; ui.ticket.innerHTML = ''; }
  function back() {
    if (S.step === 'zone') enterPlan(); else if (S.step === 'block') enterZone(S.zone); else if (S.step === 'seat') enterBlock(S.block);
    else if (S.step === 'upgrade') enterSeat(); else if (S.step === 'ticket') { hideTicket(); enterUpgrade(); }
  }
  $('back').onclick = back;
  addEventListener('keydown', e => { if (e.key === 'Escape') back(); if ((e.key === 'p' || e.key === 'P') && !e.metaKey && !e.ctrlKey) savePng(); });

  // the view from the seat, as a small picture for the ticket
  function snap() {
    renderer.render(scene, camera); const src = renderer.domElement, w = 720, h = 405, c = document.createElement('canvas'); c.width = w; c.height = h;
    const sw = src.width, sh = src.height, k = Math.min(sw / w, sh / h), ty = (1 - tmpV.copy(controls.target).project(camera).y) / 2 * sh;   // crop around what the camera looks at
    c.getContext('2d').drawImage(src, (sw - w * k) / 2, clamp(ty - h * k * 0.42, 0, sh - h * k), w * k, h * k, 0, 0, w, h);
    try { return c.toDataURL('image/jpeg', 0.82); } catch (e) { return ''; }
  }
  // P saves a clean frame of the 3D (no interface) for the photoreal step
  function savePng() { renderer.render(scene, camera); const a = document.createElement('a'); a.download = `stadium-${S.step}.png`; a.href = renderer.domElement.toDataURL('image/png'); a.click(); }

  // ---- pointer: hover with the mouse, tap with the finger ----
  let pend = null, down = null;
  const cvs = renderer.domElement;
  cvs.addEventListener('pointermove', e => { if (e.pointerType === 'mouse') pend = [e.clientX, e.clientY]; });
  cvs.addEventListener('pointerleave', () => { ui.tip.classList.remove('on'); });
  cvs.addEventListener('pointerdown', e => { down = [e.clientX, e.clientY]; });
  cvs.addEventListener('pointerup', e => { if (!down || Math.hypot(e.clientX - down[0], e.clientY - down[1]) > 8 || tw) return; tap(e.clientX, e.clientY, e.pointerType); });
  function showTip(x, y, a, b) { ui.tip.innerHTML = `<b>${esc(a)}</b><small>${esc(b)}</small>`; ui.tip.style.transform = `translate(${x}px, ${y}px) translate(-50%, calc(-100% - 18px))`; ui.tip.classList.add('on'); }
  function hover(x, y) {
    if (tw) return; let changed = false, tipOn = false;
    if (S.step === 'plan') { const i = pick(x, y, null, { tol: 0.008 }), z = i >= 0 ? seatZone[i] : -1; if (z !== S.hoverZone) { S.hoverZone = z; changed = true; }
      if (z >= 0) { tipOn = true; showTip(x, y, ZONES[z].name, ZONES[z].soldOut ? TX.soldOut : `${TX.from} ${fmt(ZINFO[z].from)} · ${availTxt(ZINFO[z].free)[0]}`); } }
    else if (S.step === 'zone') { const i = pick(x, y, null, { tol: 0.006 }), b = i >= 0 ? seatBlock[i] : -1, bo = b >= 0 ? blockOf(b) : null, hb = bo && bo.zone === S.zone ? b : -1;
      if (hb !== S.hoverBlock) { S.hoverBlock = hb; changed = true; }
      if (hb >= 0) { tipOn = true; showTip(x, y, `${TX.block} ${blockNo(bo.ti, bo.sec)}`, `${TIERS[bo.ti].cfg.name || ''} · ${fmt(priceOf(bo.ti, bo.zone))} · ${availTxt(bo.sold ? 0 : bo.free)[0]}`); } }
    else if (S.step === 'block') { const i = pick(x, y, blockOf(S.block).list, { tol: 0.004 }); if (i !== S.hoverSeat) { S.hoverSeat = i; changed = true; }
      if (i >= 0) { tipOn = true; showTip(x, y, seatLabel(i), taken[i] ? TX.taken : fmt(priceOf(sTier[i], seatZone[i]))); } }
    if (!tipOn) ui.tip.classList.remove('on');
    cvs.style.cursor = tipOn ? 'pointer' : '';
    if (changed) repaint();
  }
  function tap(x, y, type) {
    if (S.step === 'plan') { const i = pick(x, y, null, { tol: 0.012 }); if (i >= 0) tapZone(seatZone[i]); }
    else if (S.step === 'zone') { const i = pick(x, y, null, { tol: 0.01 }); if (i >= 0) tapBlock(seatBlock[i], type); }
    else if (S.step === 'block') { const i = pick(x, y, blockOf(S.block).list, { nearest: true, free: true }); if (i >= 0) selectSeat(i); }
  }

  // ---- render loop ----
  function frame(now) {
    if (pend) { hover(pend[0], pend[1]); pend = null; }
    stepTween(now); if (!tw) controls.update();
    renderer.render(scene, camera); placeChips();
  }
  function resize() {
    const w = innerWidth, h = innerHeight; renderer.setSize(w, h); camera.aspect = w / h;
    if (!tw) { const v = viewOf(S.step); if (['plan', 'zone', 'block'].includes(S.step)) applyCam(v.p, v.q, v.fov, v.oy); else applyCam(camera.position.clone(), controls.target.clone(), v.fov, v.oy); }
  }
  addEventListener('resize', resize); renderer.setSize(innerWidth, innerHeight);

  // ---- first step, or jump to one for tests: ?step=plan|zone|block|pick|seat|upgrade|ticket|vip ----
  function defaults() {
    const zq = +Q.get('zone'); let z = Number.isInteger(zq) && Q.get('zone') !== null && ZONES[zq] && !ZONES[zq].soldOut ? zq : ZONES.findIndex(x => !x.soldOut);
    if (z < 0) z = 0;
    const tierPick = Math.min(1, TIERS.length - 1), c = ZC[z];
    const cands = ZINFO[z].blocks.filter(b => !b.sold && b.free > 0).sort((a, b) => (a.ti === tierPick ? 0 : 1) - (b.ti === tierPick ? 0 : 1) || V(sX[a.list[0]], 0, sZ[a.list[0]]).distanceTo(V(c.x, 0, c.z)) - V(sX[b.list[0]], 0, sZ[b.list[0]]).distanceTo(V(c.x, 0, c.z)));
    const b = cands[0] || ZINFO[z].blocks[0], rowT = Math.floor(TIERS[b.ti].rows.length * 0.4), tm = secMid(b.sec);
    let s = -1, bd = 1e9; for (const i of b.list) { if (taken[i]) continue; const d = Math.abs(sRow[i] - rowT) * 3 + Math.abs(sT[i] - tm) * 2; if (d < bd) { bd = d; s = i; } }
    return { z, b: b.id, s };
  }
  const startAt = Q.get('step');
  enterPlan(true);
  if (startAt && startAt !== 'plan') {
    const d = defaults(); enterZone(d.z, true);
    if (startAt !== 'zone') { enterBlock(d.b, true); if (startAt !== 'block') { selectSeat(d.s); if (startAt !== 'pick') {
      enterSeat(true); if (startAt !== 'seat') { enterUpgrade(true); if (startAt === 'ticket') enterTicket(true); if (startAt === 'vip') { S.vip = true; enterTicket(true); } } } } }
  }
  if (Q.get('clean') === '1') document.body.classList.add('clean');
  if (Q.get('shot') === '1') document.body.classList.add('shot');   // test screenshots: no transitions
  setTimeout(() => { const l = $('loader'); if (l) l.remove(); }, 700);
  renderer.setAnimationLoop(frame);
  document.body.classList.add('ready');

  const info = () => ({ seats: N, tiers: TIERS.map((t, i) => ({ name: t.cfg.name, rows: t.rows.length, seats: sTier.filter(x => x === i).length })), zones: ZONES.map((z, k) => ({ name: z.name, seats: ZINFO[k].seats, free: ZINFO[k].free, from: ZINFO[k].from })), blocks: BLOCKS.size, vipBoxes: BOXES.length, bowl: { length: 2 * A0, width: 2 * B0, outer: [2 * (A0 + FAC0), 2 * (B0 + FAC0)].map(Math.round), height: Math.round(FAC_H) } });
  window.stadium = { info, go: s => { const d = defaults(); ({ plan: () => enterPlan(), zone: () => enterZone(d.z), block: () => enterBlock(d.b) })[s]?.(); }, state: S, config: C };
  console.log('stadium ready', JSON.stringify(info()));
};
