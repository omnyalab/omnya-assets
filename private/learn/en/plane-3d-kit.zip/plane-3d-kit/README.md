# The 3D Plane · pick your seat

The interactive plane from our reels: a white jet over the clouds, the glass fuselage seen from above, four classes that light up,
every Economy and Premium seat you can pick (booked seats are dark and say "Booked"), the ride down to the window, the boarding
pass, the upgrade to the next class, the First suite and The Residence with its bedroom and shower.

## Open it
- Mac: double click `Start (Mac).command` (the first time: right click → Open). It opens http://localhost:5313 in your browser.
- Windows: double click `Start (Windows).bat` (needs Python from python.org).
- Or any static server in this folder: `python3 -m http.server 5313`, then open http://localhost:5313.
It must run from a server, not by opening index.html directly (the browser blocks the videos and seats.json from file://).
Best in Chrome or Safari, full screen. R starts again from the beginning.

## Make it yours
- `config.js` is the one file to change: flight number, date, cities, airport codes, times, currency and the four prices.
- `assets/seats.json`: every Economy and Premium seat with its place on the plan and whether it is booked.
- `assets/`: the real photos (s_*.jpg start, f_*.jpg end of each clip), the Kling 4.0 clips (*.mp4) and the orange layers (*.png).
  To put in your own plane, replace them with your own photos and clips with the same names and the same 1920x1080 size.
- `app.js` is the page (states, clicks, timing), `tickets.js` the boarding passes and cards, `lib.js` the small tickets and titles.

The Full Plane Blueprint (PDF) explains how every photo, clip and layer was made, with the real prompts.

## Fonts
The text uses Inter (SIL Open Font License, https://rsms.me/inter), included in `fonts/`.

Omnya Lab · omnyalab.com
