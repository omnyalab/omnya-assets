# controlla_clip.py CLIP.mp4 START.(jpg|png) END.(jpg|png) FOGLIO.jpg ULTIMO.png
# primo/ultimo fotogramma della clip contro start/end (differenza media 0-255 su immagini 480x270 sfocate: sotto ~6 = uguale),
# salva l'ultimo fotogramma vero a piena risoluzione (sarà lo start della clip dopo) e un foglio di confronto
import subprocess, sys, numpy as np
from PIL import Image, ImageFilter, ImageDraw
clip, st, en, foglio, ultimo = sys.argv[1:6]
n = int(subprocess.run(['ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=nb_read_frames','-of','csv=p=0',clip],capture_output=True,text=True).stdout.strip())
def fr(i, out):
    subprocess.run(['ffmpeg','-v','error','-y','-i',clip,'-vf',f"select=eq(n\\,{i})",'-vframes','1',out],check=True); return Image.open(out).convert('RGB')
p = fr(0, '/tmp/_primo.png'); u = fr(n - 1, ultimo)
def d(a, b):
    a = np.asarray(a.resize((480, 270)).filter(ImageFilter.GaussianBlur(2))).astype(float); b = np.asarray(b.resize((480, 270)).filter(ImageFilter.GaussianBlur(2))).astype(float)
    return float(np.abs(a - b).mean())
S, E = Image.open(st).convert('RGB'), Image.open(en).convert('RGB')
d0, d1 = d(p, S), d(u, E)
im = Image.new('RGB', (960, 600), 'white'); g = ImageDraw.Draw(im)
for k, (x, t) in enumerate(((S, 'start'), (p, f'primo {d0:.1f}'), (E, 'end'), (u, f'ultimo {d1:.1f}'))):
    im.paste(x.resize((480, 270)), ((k % 2) * 480, (k // 2) * 300 + 30)); g.text(((k % 2) * 480 + 6, (k // 2) * 300 + 8), t, fill='black')
im.save(foglio, quality=85)
print(f'fotogrammi {n}  primo vs start {d0:.1f}  ultimo vs end {d1:.1f}  ->', 'OK' if d0 < 8 and d1 < 8 else 'DA GUARDARE')
