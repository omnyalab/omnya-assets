/* House Builder · the engine of a "hold to build" page.
   A house goes from the blueprint to the finished home while people scroll the page or hold the button.
   Change only BUILD_CONFIG for a normal build. The engine below it reads the config once, when the page loads. */

window.BUILD_CONFIG = {
  // ---------- the house and the brand ----------
  brand: 'Omnya Lab',               // shown top left, in the page title and at the end
  brandTag: 'Homes',                // small word next to the brand, '' to hide it
  title: 'From blueprint to front door', // the page title in the browser tab, with the brand
  lang: 'en',

  // ---------- the pictures ----------
  // 'stills': one photo per phase in phases/ (made with the phase prompt, camera locked). The page fades from one
  //           photo to the next while it moves in slowly. Needs nothing but the photos.
  // 'frames': every frame of the clips between the phases, made by tools/make_frames.py into frames/ and frames.js.
  //           The house really rises and the camera turns, like omnyalab.com/demo/hold-to-build.
  mode: 'stills',
  stills: [
    'phases/00.jpg', 'phases/01.jpg', 'phases/02.jpg', 'phases/03.jpg', 'phases/04.jpg',
    'phases/05.jpg', 'phases/06.jpg', 'phases/07.jpg', 'phases/08.jpg', 'phases/09.jpg',
  ],
  // in 'frames' mode the folder, count and the frame where every phase ends come from frames.js (window.BUILD_FRAMES)

  // ---------- the words, one per phase, in the same order as the pictures ----------
  phases: [
    { tag: 'The plan',   a: 'From blueprint', b: 'to front door',  p: 'Every home starts on paper, drawn for your land, your family, your light.' },
    { tag: 'Site',       a: 'Staked on',      b: 'your lot',       p: 'We mark the footprint before a single shovel moves.' },
    { tag: 'Foundation', a: 'Rock-solid',     b: 'foundation',     p: 'Poured concrete, cured and checked.' },
    { tag: 'Framing',    a: 'The walls',      b: 'go up',          p: 'Floor deck down, first-floor walls standing.' },
    { tag: 'Framing',    a: 'Fully',          b: 'framed',         p: 'Second floor, rafters and dormers in place.' },
    { tag: 'Sheathing',  a: 'Closed in,',     b: 'sheathed tight', p: 'Every wall and roof wrapped in structural panels.' },
    { tag: 'Dried in',   a: 'Dried in.',      b: 'Weather-tight',  p: 'House wrap on, windows set, roof shingled.' },
    { tag: 'Masonry',    a: 'Brick',          b: 'by brick',       p: 'A real masonry chimney, laid by hand.' },
    { tag: 'Exterior',   a: 'Exterior',       b: 'complete',       p: 'Siding, trim and shutters. Now it looks like home.' },
    { tag: 'Landscape',  a: 'The final',      b: 'touches',        p: 'Lawn, gravel drive and gardens.' },
  ],

  // ---------- how it moves ----------
  pxPerPhase: 700,      // 'stills': how much scroll one phase takes
  pxPerFrame: 9,        // 'frames': how much scroll one frame takes
  zoom: 0.035,          // a very slow zoom in along the whole build (0 = none)
  focus: [0.5, 0.5],    // where to keep the house when the screen is narrower than the photo (0..1, 0..1)
  hold: true,           // the "Hold to build" button: holding it plays the build forward
  holdSpeed: 1,         // phases per second while holding ('stills'); frames mode plays about 3 s per phase

  // ---------- the end ----------
  cta: { label: 'Get this for your project', url: '' }, // url '' hides the button
  ending: 'Welcome home',                               // the last line over the finished house

  // ---------- the look ----------
  colors: { accent: '#22d35e', ink: '#ffffff', bg: '#0b0d0c' },
  fonts: { display: 'Poppins', body: 'Inter' },         // Google Fonts names, loaded in index.html

  text: {
    loading: 'Loading the build',
    hold: 'Hold to build',
    holding: 'Building…',
    scroll: 'or scroll',
    again: 'Build it again',
  },
};

/* ================================ the engine, no need to change below ================================ */
(function () {
  const C = window.BUILD_CONFIG, F = window.BUILD_FRAMES || null;
  const $ = (s) => document.querySelector(s);
  const root = document.documentElement;
  root.lang = C.lang || 'en';
  document.title = (C.title ? C.title + ' · ' : '') + C.brand;
  root.style.setProperty('--accent', C.colors.accent); root.style.setProperty('--ink', C.colors.ink); root.style.setProperty('--bg', C.colors.bg);
  root.style.setProperty('--fd', `"${C.fonts.display}", system-ui, sans-serif`); root.style.setProperty('--fb', `"${C.fonts.body}", system-ui, sans-serif`);
  const lum = (h) => { const n = parseInt(h.slice(1), 16), r = n >> 16 & 255, g = n >> 8 & 255, b = n & 255; return (0.299 * r + 0.587 * g + 0.114 * b) / 255; };
  root.style.setProperty('--on-accent', lum(C.colors.accent) > 0.6 ? '#0b0d0c' : '#ffffff');

  const MODE = C.mode === 'frames' && F ? 'frames' : 'stills';
  if (C.mode === 'frames' && !F) console.warn('[house-builder] mode is "frames" but frames.js is missing: showing the stills');
  const SRC = MODE === 'frames' ? Array.from({ length: F.count }, (_, i) => `${F.folder}/${String(i).padStart(4, '0')}.${F.ext}`) : C.stills.slice();
  const N = SRC.length, LAST = N - 1;
  const BOUNDS = MODE === 'frames' ? F.bounds.slice() : SRC.map((_, i) => i);   // the picture where every phase is complete
  const PH = C.phases.slice(0, BOUNDS.length);
  if (C.phases.length !== BOUNDS.length) console.warn(`[house-builder] ${C.phases.length} phases in the config, ${BOUNDS.length} in the pictures`);
  const PX = MODE === 'frames' ? C.pxPerFrame : C.pxPerPhase;

  // ---------- header, captions, dots ----------
  $('#brand').innerHTML = `<b>${C.brand}</b>${C.brandTag ? `<i></i><span>${C.brandTag}</span>` : ''}`;
  $('#endBrand').textContent = C.brand; $('#endLine').textContent = C.ending || '';
  $('#loadTxt').textContent = C.text.loading;
  const cta = $('#cta'); if (C.cta && C.cta.url) { cta.textContent = C.cta.label; cta.href = C.cta.url; } else cta.remove();
  $('#again').textContent = C.text.again;
  const caps = $('#caps'), rail = $('#rail');
  const capEls = PH.map((ph, i) => {
    const d = document.createElement('div'); d.className = 'cap';
    d.innerHTML = `<small>${String(i).padStart(2, '0')} · ${ph.tag}</small><h2>${ph.a}<em>${ph.b}</em></h2><p>${ph.p}</p>`;
    caps.appendChild(d);
    const dot = document.createElement('button'); dot.type = 'button'; dot.title = ph.tag; dot.setAttribute('aria-label', ph.tag);
    dot.onclick = () => go(BOUNDS[i]); rail.appendChild(dot);
    return d;
  });
  const dots = [...rail.children];

  // ---------- the length of the page ----------
  const build = $('#build');
  const span = () => LAST * PX;
  const setH = () => { build.style.height = (span() + innerHeight * 1.6) + 'px'; };
  setH(); addEventListener('resize', setH);
  const progress = () => { const r = build.getBoundingClientRect(); return Math.min(1, Math.max(0, -r.top / span())); };
  const topOf = () => build.getBoundingClientRect().top + scrollY;
  function go(f) { scrollTo({ top: topOf() + f * PX + 2, behavior: 'smooth' }); }

  // ---------- loading: the end of every phase first, then denser passes ----------
  const MOB = /iPhone|Android.+Mobile/i.test(navigator.userAgent) || (matchMedia('(pointer: coarse)').matches && Math.min(screen.width, screen.height) < 600);
  const imgs = new Array(N), ok = new Uint8Array(N), order = [], seen = new Set();
  const push = (i) => { if (MODE === 'frames' && MOB) i -= i % 2; if (i >= 0 && i < N && !seen.has(i)) { seen.add(i); order.push(i); } };
  BOUNDS.forEach(push); for (const st of [24, 12, 6, 3, 2, 1]) for (let i = 0; i < N; i += st) push(i);
  const readySet = new Set(); BOUNDS.forEach((i) => readySet.add(i));
  if (MODE === 'frames') for (const st of (MOB ? [24, 12, 6] : [24, 12, 6, 3])) for (let i = 0; i < N; i += st) readySet.add(MOB ? i - i % 2 : i);
  const READY = MODE === 'frames' ? readySet.size : N;
  let loaded = 0, qi = 0, ready = false;
  const pct = $('#pct');
  function tick() {
    if (ready) return;
    pct.textContent = Math.min(100, Math.floor(loaded / READY * 100));
    if (loaded >= READY) { ready = true; pct.textContent = 100; setTimeout(() => { root.classList.remove('loading'); console.log(`house ready · ${MODE} · ${N} pictures · ${PH.length} phases`); }, 300); }
  }
  const tries = new Uint8Array(N);
  function next(again) {
    if (again === undefined && qi >= order.length) return;
    const i = again === undefined ? order[qi++] : again, im = new Image(); im.decoding = 'async';
    im.onload = () => { imgs[i] = im; ok[i] = 1; if (MODE === 'frames' && MOB && i + 1 < N) { imgs[i + 1] = im; ok[i + 1] = 1; } loaded++; tick(); dirty = true; next(); };
    im.onerror = () => {
      if (!tries[i]++) { setTimeout(() => next(i), 700); return; }   // one more try: a busy host sometimes drops a file
      console.warn('[house-builder] missing picture', SRC[i]); loaded++; tick(); next();
    };
    im.src = SRC[i];
  }
  for (let k = 0; k < 6; k++) next();

  // ---------- drawing ----------
  const cv = $('#c'), ctx = cv.getContext('2d');
  let dirty = true;
  function size() { const r = Math.min(devicePixelRatio || 1, MOB ? 1.5 : 2); cv.width = innerWidth * r; cv.height = innerHeight * r; dirty = true; }
  addEventListener('resize', size); size();
  const nearest = (i) => { if (ok[i]) return i; for (let d = 1; d < N; d++) { if (ok[i - d]) return i - d; if (ok[i + d]) return i + d; } return -1; };
  function paint(im, alpha, z) {
    const W = cv.width, H = cv.height, s = Math.max(W / im.width, H / im.height) * z, w = im.width * s, h = im.height * s;
    const x = (W - w) * C.focus[0], y = (H - h) * C.focus[1];
    ctx.globalAlpha = alpha; ctx.drawImage(im, x, y, w, h); ctx.globalAlpha = 1;
  }
  function draw(f) {
    const z = 1 + (C.zoom || 0) * (f / Math.max(1, LAST));
    if (MODE === 'frames') { const i = nearest(Math.round(f)); if (i >= 0) paint(imgs[i], 1, z); return; }
    const k = Math.min(LAST, Math.floor(f)), t = f - k, a = nearest(k); if (a < 0) return;
    paint(imgs[a], 1, z);
    if (t > 0.001 && k < LAST && ok[k + 1]) { const e = t * t * (3 - 2 * t); paint(imgs[k + 1], e, z); }
  }

  // ---------- captions follow the phase ----------
  function captions(f) {
    let on = 0;
    capEls.forEach((el, i) => {
      const b = BOUNDS[i], prev = i ? BOUNDS[i - 1] : b - (BOUNDS[1] - BOUNDS[0] || 1), nx = i < BOUNDS.length - 1 ? BOUNDS[i + 1] : b + (b - prev);
      const inS = b - (b - prev) * 0.42, inE = b - (b - prev) * 0.12, outS = b + (nx - b) * 0.18, outE = b + (nx - b) * 0.45;
      let o = 0;
      if (i === 0 && f <= b) o = 1;
      else if (f >= inS && f < inE) o = (f - inS) / (inE - inS);
      else if (f >= inE && f <= outS) o = 1;
      else if (f > outS && f < outE) o = 1 - (f - outS) / (outE - outS);
      if (i === BOUNDS.length - 1 && f >= inE) o = 1;
      el.style.opacity = o; el.style.transform = `translateY(${(1 - o) * 14}px)`;
      if (f >= b - (b - prev) * 0.5) on = i;
    });
    dots.forEach((d, i) => d.classList.toggle('on', i === on));
    $('#meter').textContent = PH[on] ? PH[on].tag : '';
    $('#bar').style.transform = `scaleX(${f / Math.max(1, LAST)})`;
  }

  // ---------- the end: a soft blur and the brand ----------
  function ending() {
    const r = build.getBoundingClientRect(), k = Math.min(1, Math.max(0, (-r.top - span()) / (innerHeight * 0.6)));
    root.style.setProperty('--end', k.toFixed(3));
    root.classList.toggle('ended', k > 0.6);
  }

  // ---------- hold to build ----------
  const holdBtn = $('#hold');
  let holding = false, lastT = 0;
  if (!C.hold) holdBtn.remove(); else {
    $('#holdTxt').textContent = C.text.hold; $('#scrollTxt').textContent = C.text.scroll;
    const start = (e) => { e.preventDefault(); if (e.pointerId !== undefined && holdBtn.setPointerCapture) try { holdBtn.setPointerCapture(e.pointerId); } catch (_) {} holding = true; holdBtn.classList.add('on'); $('#holdTxt').textContent = C.text.holding; lastT = performance.now(); };
    const stop = () => { holding = false; holdBtn.classList.remove('on'); $('#holdTxt').textContent = C.text.hold; };
    holdBtn.addEventListener('pointerdown', start); addEventListener('pointerup', stop); addEventListener('pointercancel', stop); holdBtn.addEventListener('lostpointercapture', stop); addEventListener('blur', stop);
    holdBtn.addEventListener('contextmenu', (e) => e.preventDefault());
    addEventListener('keydown', (e) => { if (e.code === 'Space' && !e.repeat) start(e); }); addEventListener('keyup', (e) => { if (e.code === 'Space') stop(); });
  }
  $('#again').onclick = () => scrollTo({ top: 0, behavior: 'smooth' });

  // ---------- the loop ----------
  let target = 0, cur = 0;
  addEventListener('scroll', () => { target = progress() * LAST; }, { passive: true });
  function loop(t) {
    if (holding) {
      const dt = Math.min(0.05, (t - lastT) / 1000); lastT = t;
      const perSec = MODE === 'frames' ? (LAST / Math.max(1, BOUNDS.length - 1)) / 3 : C.holdSpeed;
      scrollBy(0, perSec * dt * PX);
    }
    const before = cur; cur += (target - cur) * 0.12; if (Math.abs(target - cur) < 0.002) cur = target;
    if (dirty || Math.abs(cur - before) > 0.0005) { draw(cur); captions(cur); dirty = false; }
    ending();
    requestAnimationFrame(loop);
  }
  scrollTo(0, 0); requestAnimationFrame(loop);

  // for checks: house.info() in the console, ?f=4.5 opens on that picture
  window.house = { info: () => ({ mode: MODE, pictures: N, phases: PH.length, bounds: BOUNDS, scroll: span() }), go };
  const q = new URLSearchParams(location.search).get('f');
  if (q !== null) { const f = Math.max(0, Math.min(LAST, parseFloat(q) || 0)); const jump = () => { scrollTo(0, topOf() + f * PX); target = cur = f; dirty = true; }; addEventListener('load', jump); setTimeout(jump, 50); }
})();
