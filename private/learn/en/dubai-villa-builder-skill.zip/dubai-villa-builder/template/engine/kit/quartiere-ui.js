// Small drawing helpers shared by app.js and quartiere-ui2.js: rounded rectangle, text, text width, price (reads config.js).
import CONFIG from "../../config.js";
const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
function rr(c, x, y, w, h, r) {
  c.beginPath();
  c.moveTo(x + r, y);
  c.arcTo(x + w, y, x + w, y + h, r);
  c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r);
  c.arcTo(x, y, x + w, y, r);
  c.closePath();
}
function testo(c, t, x, y, font, col, ls = 0, al = "left") {
  c.font = font;
  c.fillStyle = col;
  c.textAlign = al;
  c.letterSpacing = ls + "px";
  c.fillText(t, x, y);
  c.letterSpacing = "0px";
  c.textAlign = "left";
}
function largo(c, t, font, ls = 0) {
  c.font = font;
  c.letterSpacing = ls + "px";
  const w = c.measureText(t).width;
  c.letterSpacing = "0px";
  return w;
}
const soldi = (v) => !CONFIG.showPrices ? CONFIG.priceText : v >= 1e6 ? `${CONFIG.currency} ${(Math.round(v / 1e5) / 10).toLocaleString("en-US")}M` : `${CONFIG.currency} ${v.toLocaleString("en-US")}`;
export {
  clamp,
  largo,
  rr,
  soldi,
  testo
};
