---
name: miami-builder
description: Builds a "Build <City>" page like Build Miami - any real city in 3D in three.js, made from live OpenStreetMap data (real buildings with heights, streets, coastline, water, parks), with an Apple-style glass panel on the right whose buttons build the city piece by piece while the camera flies down and around it, a Day/Night switch with lit windows and neon, and an auto mode with a fake cursor for screen recordings. One folder, no build step, goes online for free. Use it whenever someone asks to "build me <city>", "build <city> like Build Miami", a 3D city that builds itself, a city flyover page, a speed-build of a real city, or wants real map data of a city turned into a 3D page or into frames for photo-real images and video clips, even if they only write one line like "build me Monaco".
---

# Miami Builder

You build a one-folder web page that shows a real city in 3D and builds it piece by piece, exactly like the Build Miami page: the bare land and the water first, then a glass panel on the right with seven buttons ("Build the streets", "Build the city", "Bring the nature", "Build <district>", "Go to: <place>", "Go to: <place>", "View the full city") and a Day/Night switch. Each button makes its piece rise while the camera flies to a new view.

Everything already works in the template. Your job: download the city, fill the CONFIG block, check the result with your own eyes, and hand over the folder.

Files in this skill:
- `assets/fetch_city.py` - downloads the city from OpenStreetMap (free, no key, Python 3 standard library) and writes `city-data.js`.
- `assets/template/index.html` - the whole page. The `CONFIG` block at the top is the only part a normal build touches.
- `references/config.md` - every CONFIG field, the shot format, colour palettes for common city types.
- `references/overpass.md` - what is downloaded, how heights are estimated, sizes, servers, limits.
- `references/troubleshooting.md` - what to do when something looks wrong.
- `references/photoreal.md` - turning frames of the page into photo-real stills and video clips.

## 1. Ask only what you cannot decide

If the user gave a city, do not stop to ask: pick sensible defaults, build, and list your choices at the end. Ask (in one short message, with defaults) only if the city is ambiguous ("Springfield") or they mention things you cannot infer. The decisions you make yourself:

1. **The area.** The centre that best shows the city (old town, downtown, waterfront, skyline) and the size: 2,500-3,500 m for a dense old centre, 4,000-6,000 m for a skyline + beach city. Use your knowledge of the city to put the iconic part and the water in the frame. Write down the centre as `lat,lon`.
2. **The district** for "Build <district>": the part with the tallest or most famous buildings (Brickell, Marina, Larvotto, Baixa, Midtown). It rises on its own button, so before that click it is an empty space in the city: pick something worth the reveal.
3. **Two places** for the "Go to" buttons: famous squares, waterfronts, castles, avenues. `fetch_city.py` prints named places with coordinates; prefer those, or your own knowledge.
4. **Colours**: the real look of the city (white towers and turquoise water for Miami, terracotta roofs and pastel walls for Lisbon, cream and red roofs for Monaco). Palettes in `references/config.md`. Real colours, never a pink or purple tint on the buildings.

## 2. Build

1. **Make the folder.** Copy `assets/template/` to a new folder named `build-<city>` (lowercase, dashes). Never edit the template itself.
   - On claude.ai: create the folder in your sandbox. If the sandbox has no internet, `fetch_city.py` cannot download: tell the user to run the one command in step 2 on their computer (Python 3 is on every Mac; on Windows install it from python.org) and to drop `city-data.js` into the folder. Give them the exact command.
2. **Download the city:**
   ```
   python3 <skill>/assets/fetch_city.py "Lisbon" --center 38.7105,-9.1390 --size 3200 --out build-lisbon
   ```
   It takes 20-90 s and prints counts and suggestions (tallest cluster, tallest buildings, named places). Without `--center` it geocodes the name, which often lands off the interesting part: prefer your own centre. Read `references/overpass.md` if it fails or the area is huge.
3. **Fill the CONFIG** at the top of `build-<city>/index.html` (every field: `references/config.md`):
   - `city` - the name as people write it. The panel shows "Build <city>".
   - `colors`, `pitchedShare`, `trees`, `sun`.
   - `district` - name, lat/lon (or null for the tallest cluster), radius, minHeight (0 if the district has no towers: then every building inside rises).
   - `buttons` - the seven labels and their `shot`s. Keep the order and the wording style of Build Miami: "Build the streets", "Build the city", "Bring the nature", "Build <district>", "Go to: <place>", "Go to: <place>", "View the full city". Translate only if the user asks.
   - `start` - leave null (straight down, north up, the whole area) unless the city reads better from another side.
4. **Shots.** A shot is `{ look: [lat, lon], heading, dist, height }`: the camera looks at `look` from `dist` metres away on the ground and `height` metres up, facing `heading` (0 north, 90 east, 180 south, 270 west). Null = a sensible default. Rules that make it look good:
   - Look from the water toward the city when there is a waterfront (Lisbon from the river: heading 330-20; Monaco from the sea: heading 270-320).
   - Keep the sun to the side of the camera, not in front (`sun.azimuth` about 90 degrees away from most headings). Into the sun every facade is in shadow.
   - Each button's view should be lower and closer than the one before, then "View the full city" goes high and wide again.
   - The camera never enters a building: the page lifts it above anything tall nearby.
5. **Serve and look.** Inside the folder run `python3 -m http.server 8080` and open `http://localhost:8080`. Check the console line `city ready {...}` (buildings, roads, trees, draw calls) and that there are no errors.
   - `?step=n` opens with the first n buttons already done and the camera on that view (for screenshots), `?night=1` at night, `?auto=1` the self-playing version with the fake cursor, `?clean=1` without any interface.
   - With a browser tool or headless Chrome (playwright with Chrome is fine) at 1920 x 1080: screenshot `?step=0` to `?step=7` by day and `?step=4`, `?step=7` with `&night=1`. Then click through the real flow once and screenshot one frame in the middle of a flight.
   - Press **K** in the page to print the current camera as a shot (copied to the clipboard): the fastest way to tune a view. Drag to turn, wheel to zoom.
6. **Fix and repeat** until every screenshot passes the checklist in section 4. Typical fixes are in `references/troubleshooting.md`.

## 3. Rules

- **Real data, honest words.** The city comes from OpenStreetMap. Heights without a tag are estimated (tagged neighbours, building type); say so. Never claim the 3D is exact, never invent buildings, never put other brands' logos or names on the page.
- **The credit stays.** OpenStreetMap's licence (ODbL) requires the small line "Map data © OpenStreetMap contributors" whenever the page is shown publicly. It is in the bottom-left corner; keep it. `?clean=1` hides it only for frames used as image references.
- **One folder, no build step.** `index.html` + `city-data.js`. three.js comes from jsDelivr pinned to `three@0.160.0`; do not change the version or add a bundler. It opens with a double click in Chrome, or via the small local server.
- **Look rules from Build Miami.** Panel on the right, Apple glass, system font, buttons that stay glass when done (never solid fills), real city colours, clean shadows, no checkerboard ground, no z-fighting, night windows small and warm (never white slabs), only a few neon accents.
- **No names that are not yours.** No game titles, logos or fonts of video games or studios, no "AI" in the titles. "Build <City>" is the title.
- **Performance.** Keep the area at most 6,000 m (the script caps it). Over about 40,000 buildings the page gets heavy on laptops; use a smaller area. Phones get lighter shadows and fewer trees automatically (`quality: 'auto'`).

## 4. Before handing over, check every screenshot

- [ ] `city ready` in the console, no errors, buildings count in the thousands for a real city.
- [ ] Start view: land and water only, clean shorelines, the sea is on the right side (not land where the sea is, see troubleshooting if the water is missing).
- [ ] Streets draw outward from the focus; the city rises; the district stays empty until its button and then rises.
- [ ] No pink or purple tint on buildings by day, no flickering surfaces, no grid or checkerboard on the ground or water.
- [ ] Night: dark blue sky, warm small windows, orange street glow, a few neon crowns. Panel readable.
- [ ] Every button's view shows something worth seeing (not a field, not the inside of a hill, not the edge of the data).
- [ ] Panel text fits (long place names: shorten the label, "Go to: Castle" not "Go to: Castelo de São Jorge e Muralhas").
- [ ] The credit line is visible.

## 5. Put it online for free

Tell the user, in plain words:

**Netlify Drop:** go to app.netlify.com/drop, drag the `build-<city>` folder onto the page, get a link in seconds; a free account keeps it online and lets you rename it.

**Vercel:** free Hobby account, Add New > Project, drag the folder in (or import it from GitHub), framework "Other", no build command, Deploy.

Both give an https link that works on phones. To update, drag the folder again.

## 6. Recording and photo-real versions (only when asked)

- Screen recording: open `?auto=1`, full screen (F), and record. The cursor presses every button with the click sound; `C` hides the cursor, `H` the panel, `N` switches day and night, `R` restarts, Space presses the next button by hand. `auto.nightAfter` in the CONFIG makes the cursor click Night after a given button.
- Photo-real stills and clips from the 3D: `references/photoreal.md` (frames with `?clean=1` and P, image model on the frame, start/end clips). The full prompts are in the Full Miami Blueprint.

## What to say at the end

Short: the folder name, what is in the frame (area, number of buildings, how many heights were estimated), the district and the two places you chose, the colours, how to open it locally, the keys, and the free publishing steps. Show two or three screenshots (start, district, night) if you made them.
