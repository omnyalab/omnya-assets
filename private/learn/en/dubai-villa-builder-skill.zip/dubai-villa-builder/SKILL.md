---
name: dubai-villa-builder
description: Builds the interactive "Choose your villa" page from the Omnya Lab Dubai Hills reel - from above you drop a pin on a street, fly down and scroll along it like Google Maps with every villa tagged (number and price), pick the villa, the door opens, walk through the living room, dining room and kitchen, step out to the pool with the Burj Khalifa on the horizon, answer "Is this your home?" and get the villa card with "Book a private viewing". One folder, runs on any computer with Python 3, goes online for free. Use it whenever someone asks for "the Dubai villa page", "build me the Dubai villa page", a choose-your-villa or choose-your-home page, an interactive villa or real estate walkthrough like Google Maps, a property page for a developer, or wants to rebuild the villa from the reel with their own brand, prices, photos or film.
---

# Dubai Villa Builder

You rebuild the working page in `template/` on the user's computer, exactly like the reel, then adapt it to them. The template already does everything: the view from above with the streets you can pick, the pin, the flight down, the street you scroll with the villa tags, the villa card, the three stops inside, the pool with the Burj Khalifa label, the question, the final card. Your job is to copy it, fit it to the user's brand and villa, check it, and hand over a folder they can open or put online.

Most builds only touch `config.js`. Change `dati.json` for street names, villa numbers and prices along the street. Change `app.js` only for what the config cannot do, and read `references/how-it-works.md` first.

## 1. Ask first, in one short message

Ask everything you do not know yet in one message, with a default for each, and say they can answer "use the defaults" (the defaults give the exact page from the reel):

1. **Developer or brand name** (small "Presented by ..." line on the last card, and the browser tab).
2. **The villa**: number, community, street, type, bedrooms, built-up area, view.
3. **Prices**: show them, or "On request" like the reel? Currency (AED, USD, EUR...).
4. **Booking link** for "Book a private viewing" (a web page, a WhatsApp link like https://wa.me/971..., or mailto:).
5. **One accent colour** (the reel uses orange #ff7a12 with buttons #c24a00).
6. Optional: their **own photos and film** of a villa (see `references/your-own-photos-and-film.md`).

If the first message already says enough ("rebuild the Dubai villa for Emerald Estates, prices in USD"), do not stop: build with sensible defaults and list them at the end.

## 2. Build

1. **Copy the template.** Copy the whole `template/` folder to a new folder, e.g. `~/Desktop/dubai-villa/` or a folder named after the brand. Never edit the template itself. Keep `film.mp4`, `assets/` and `engine/` as they are.
2. **Fill `config.js`** (every field is explained in `references/customising.md`): brand, booking link, villa, prices and currency, words, colours.
3. **Streets and villa tags** (optional): names, numbers, free/sold and sample prices in `dati.json` (`references/data.md`). Never move the points: they are measured on the film.
4. **Open it.** Mac: double click `Start.command` (first time: right click > Open). Windows: `Start.bat`. Or in the folder: `python3 server.py 5316` and open http://localhost:5316. It must run from a server, not from index.html directly.
5. **Look at every step.** With a browser tool: open `http://localhost:5316/?auto` (the tour plays by itself, about 60 s) and screenshot from above, the street, the villa card, a room, the pool, "Is this your home?" and the last card. Or jump straight to a moment: in the console `await __motore.scena('villa')` (names: `strade`, `strada`, `scendi`, `scegli`, `villa`, `stanza0`, `stanza1`, `stanza2`, `burj`, `domanda`, `fine`). Then click the real flow once with the mouse. Check the console has no errors.

## 3. Rules

- **One folder, no build step.** Plain HTML and JavaScript, no npm, no framework. `server.py` uses only the Python 3 standard library.
- **Keep the timings.** The page plays seconds 7 to 48 of the tour from `film.mp4` and stops at fixed seconds (street 9.6 to 13.04, villa 16, rooms 26 / 29 / 31.5, pool 36, question 41.5, end 48). A new film must follow the same seconds (`references/your-own-photos-and-film.md`).
- **Honest data.** Villa numbers, which villas are free, prices and "4 left on this street" are EXAMPLES. Bedrooms (6), built-up area (8,531 ft²) and the 7.95 km to the Burj Khalifa describe the real villa type in the film. The page takes no payments and stores nothing: the booking button only opens the user's link. Say so in the hand-over.
- **Keep the map credit.** The street shapes come from OpenStreetMap: keep "Map data © OpenStreetMap contributors" (config `mapCredit`) on the page and in the README.
- **No names you were not given.** Use only the user's brand. Do not put a real developer's name or logo on the page unless the user says it is theirs.
- **Best in Chrome or Edge.** Safari draws the glass cards without the blur.

## 4. Before handing over, check

- [ ] Brand, villa number, community, street and every word are the user's, in their language.
- [ ] Prices: either all "On request" or the user's prices with the right currency, on the street card, the tags, the villa card, the chip and the last card.
- [ ] The villa tag is clickable in the street and leads to the villa card; "Enter the villa", the three "View ..." buttons, the pool, "Is this your home?", Yes and No all work.
- [ ] "Book a private viewing" opens the user's link; "Start again" and the R key go back to the start.
- [ ] The accent colour shows on the pin, the lit street, the chosen villa and the buttons; white text on buttons is readable.
- [ ] "Map data © OpenStreetMap contributors" is visible from above. No errors in the console.

## 5. Put it online for free

**Netlify Drop:** go to app.netlify.com/drop, drag the whole folder (the one with `index.html`) onto the page; in a few seconds there is a link. Sign in with a free account to keep it.
**Vercel:** vercel.com, Add New, Project, drag the folder or import it from GitHub, framework "Other", no build command, Deploy.
The film is about 22 MB: the page shows "loading" until it is in memory (a few seconds on a normal connection).
