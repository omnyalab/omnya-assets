# Photo-real stills and clips from the 3D

The 3D page gives the real geography and the camera. An image model turns a frame into a photograph; a video model then animates between two such photographs. This is the method behind Build Miami. The complete prompts, the colour recipe and the clip-by-clip plan are in the **Full Miami Blueprint**; this file is the short version. Never generate anything paid without the user's explicit yes, and say first what it costs.

## 1. Frames from the page

1. Open the page with `?clean=1` (no panel, no cursor, no credit) and the state you want, e.g. `?clean=1&step=4` (district built) or `?clean=1&step=7&night=1`.
2. Set the browser window to the final format (1920 x 1080 for 16:9). Use the mouse and K to fine-tune the view, put the shot in the CONFIG so it can be repeated.
3. Press **P**: the page saves a PNG of the 3D frame only.
4. For a clip you need two frames of the same flight: the start of a button's flight and its end (or the same view before and after a piece is built: `?step=3` and `?step=4` from the same shot).

Rules that come from Build Miami:
- Always a finished, full frame: the city reaches the horizon, no empty sky-only or sea-only frames, no edge of the data.
- Sun from the side, never straight behind the subject.
- The frame is the only geometry reference. Do not add photos of other places as references: the model copies their shapes. Real photos may only be used as colour samples, said so in the prompt.

## 2. Stills (Seedream, Nano Banana Pro or any image-edit model)

Give the frame as Image 1 and a prompt that locks the camera and lists what is in the frame:

```
Turn Image 1 into an ultra-photorealistic aerial photograph of <city>, same camera, same framing,
same geometry: keep every building, street, shoreline, pier and park exactly where it is.
Change only materials, light and realism, add nothing.
Buildings: <real facade materials of the city: white stucco and glass towers / pastel lime-washed
facades with terracotta tile roofs / ...>, real windows, balconies, rooftop details.
Water: <colour of the real water>, natural reflections. Streets with real asphalt and markings,
a few cars. Trees and parks as in the frame.
Light: <one sun direction, e.g. sun high on the left, every shadow short and falling to the right>.
Camera: full-frame, 35 mm, f/8, crisp, natural colours. No text, no logos, no watermarks.
```

For night frames: "blue hour, deep blue sky, warm lit windows, orange street lights, a few coloured LED crowns on the towers" and nothing more (no extra neon).

Check before using, item by item: same horizon and coastline, same number of towers in the same places, nothing added, no invented text or logos. If something fails, run again from the same 3D frame naming the failing item. Never feed a generated image back as the new geometry reference. Pass every output through a light contrast / vibrance / sharpening filter and look at it at 100% before sending it.

## 3. Clips (Kling, start and end frames)

- Photo-real start frame + photo-real end frame of the same flight, 5 s, image-to-video with start and end image. Describe the movement in one sentence ("the camera glides down and to the right toward the towers, the city stays fixed").
- Better and steadier: video-to-video with the screen recording of the same 3D flight underneath (record `?clean=1&auto=1`, or one button's flight), plus start and end frames.
- One clip at a time. Check the first and last frame against the start and end images, then the next clip starts from the true last frame of the previous one.
- A reverse move (flying back up) is the same clip reversed with ffmpeg, never a new generation.
- Fast or top-down movements without an end photo stay looking "3D": split them with a photo in the middle.

## 4. Putting it together

Build Miami plays the clips behind the same glass panel: each button press starts its clip and the page waits on the last frame for the next click. The panel and the cursor of this page can be reused over a video by replacing the 3D canvas with a `<video>` and driving the button fills from the video time. Ask before building that: it is a separate page.
