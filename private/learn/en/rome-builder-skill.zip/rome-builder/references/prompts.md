# Every prompt of the Rome film

These are the exact prompts we used on Higgsfield on 25/11/2026, copied from the generation history (also in `prompts.json`).
Photos: Seedream 5.5 at 2K, 16:9, with the 3D frame of the same moment attached as reference. Clips: Kling 4.0 at 1080p.
Use them as they are for our film; for your own scene change only the words that describe what is in the picture.

## K1 · Photo 1: Rome from the sky, 220 m over the triumphal avenue (start of clip C1)

model `seedream_5_5`, 2k, attachments: image_references

```text
Turn this 3D render into a real aerial photograph of ancient Rome in 80 AD, keeping the exact composition, camera angle, perspective and every building in its place. A drone photograph from 220 metres above the triumphal avenue looking toward the Colosseum in the centre. The Colosseum is newly built, its four-storey facade of warm cream travertine with crisp arches, marble statues in the upper arches and a row of wooden masts along the top; the oval interior is open to the sky and packed with spectators. Around it a wide plaza of large pale travertine slabs crowded with people walking, and a busy irregular market of wooden stalls with sun-faded canvas awnings in madder red, ochre, cream and woad blue, baskets, amphorae and carts. The avenue in front is paved in pale travertine slabs and lined with three- to five-storey Roman insulae with terracotta roof tiles and plaster walls in ochre, warm cream and Pompeian red, wooden balconies and tall white columns topped by gilded bronze eagles. A colossal gilded bronze statue of the sun god stands on a marble base beside the avenue. The city spreads to the horizon in a dense grid of terracotta roofs and dark basalt-paved streets, umbrella pines and cypresses on the Palatine with its colonnaded palaces, a great arcaded terrace with a temple and garden on the right. Clear deep blue sky, the Alban Hills soft and blue on the far horizon. Bright afternoon sun 28 degrees from the west-southwest, crisp long shadows, rich saturated natural colour in the terracotta, plaster and canvas, tack-sharp stone texture, the people small and slightly motion-blurred. Aerial photograph in the style of Iwan Baan, natural colour, fine natural grain.
```

## K2 · Photo 2: the dive toward the Colosseum (end of C1, start of C2)

model `seedream_5_5`, 2k, attachments: image_references

```text
Turn this 3D render into a real aerial photograph of ancient Rome in 80 AD, keeping the exact composition, camera angle, perspective and every building in its place, the Colosseum with exactly the same size, shape and position. A drone photograph descending toward the Colosseum over the triumphal avenue. The Colosseum is newly built: four storeys of clean warm cream travertine with crisp fresh edges, marble statues in the upper arches and a row of wooden masts along the top, the oval interior open to the sky and packed with spectators. The avenue of large pale travertine slabs runs straight to it between tall white columns topped by gilded bronze eagles and green festoons, crowds along both sides and chariots in the middle, lined by three- to five-storey Roman insulae with terracotta tile roofs, ochre, warm cream and Pompeian red plaster and wooden balconies full of people. Left and right, the wide plaza of pale travertine slabs crowded with people and a busy irregular market of wooden stalls with sun-faded canvas awnings in madder red, ochre, cream and woad blue, carts, baskets and amphorae. On the right a long arcaded travertine terrace with umbrella pines on top. Low faint blue hills far away on the horizon, clear deep blue sky. Bright afternoon sun 28 degrees from the west-southwest, crisp long shadows, rich saturated natural colour, tack-sharp texture, the people small and slightly motion-blurred. Aerial photograph in the style of Iwan Baan, natural colour, fine natural grain.
```

## K3 · Photo 3: eye level on the triumphal avenue (end of C2, start of C3)

model `seedream_5_5`, 2k, attachments: image_references

```text
Turn this 3D render into a real photograph keeping the exact composition, camera height, perspective and every column, building, chariot and person in its place, the Colosseum with exactly the same size, shape and position. A photograph taken at eye level in the middle of the triumphal avenue of ancient Rome, 80 AD, looking straight at the newly built Colosseum at the end of the street: four storeys of clean warm cream travertine with crisp fresh edges, marble statues in the arches and long red banners; its ground-floor arches are open with cool shadowed stone passages inside. On both sides tall white marble columns with gilded capitals and gilded bronze eagles, linked by heavy green laurel festoons. Lining the avenue, Roman insulae of three to five storeys in ochre, warm cream and Pompeian red plaster, wooden balconies crowded with people leaning over the railings, laundry, potted plants and hanging cloth banners, shops under arcaded porticoes. Dense crowds of Romans in wool tunics and cloaks of madder red, woad blue, saffron, sage and cream fill both sides with arms raised; chariots with gilded panels drawn by pairs of white and dark horses stand in the lanes facing the Colosseum. Large pale travertine paving slabs dusted with straw and petals. Bright afternoon sun 25 degrees from the west-southwest, crisp shadows, clear deep blue sky, rich saturated natural colour, tack-sharp texture, faces small and soft. Photograph in the style of Fernando Guerra, natural colour, fine natural grain.
```

## K4 · Photo 4: in front of gate LII (end of C3, start of C4)

model `seedream_5_5`, 2k, attachments: image_references

```text
Turn this 3D render into a real photograph taken at street level in ancient Rome in 80 AD, keeping the exact composition, camera height, perspective and every element in its place, the Colosseum facade with exactly the same size, shape and position. In front, the ground-floor arcade of the newly built Colosseum in clean warm cream travertine with crisp fresh edges and fine pores, Doric half columns, the Roman numerals XLIX L LI LII LIII LIV carved above the arches, marble statues standing in the upper arches and long red banners hanging between them. Arch LII in the centre is the open entrance: its bronze gate leaves are swung open inward, warm lamplight glows deep inside the passage, and two bronze tripod braziers with live orange flames stand on either side. The other arches are closed by tall bronze grilles with a soft patina. The plaza is paved with large pale travertine slabs, dusty, scattered with straw. Romans in wool tunics and cloaks in madder red, woad blue, saffron yellow, sage green and undyed cream stand and walk in loose groups, seen from behind and slightly motion-blurred; on the right two dark horses with a chariot with gilded panels. Bright afternoon sun 25 degrees from the west-southwest raking across the facade, deep crisp shadows inside the arches, clear blue sky, rich saturated natural colour, tack-sharp texture of the stone, bronze and wool. Photograph in the style of Fernando Guerra, natural colour, fine natural grain.
```

## K5 · Photo 5: inside the gate (end of C4, start of C5)

model `seedream_5_5`, 2k, attachments: image_references

```text
Turn this 3D render into a real photograph keeping the exact composition, camera position, lens, perspective and every arch, gate and wall in its place with exactly the same size and shape. A photograph taken just inside entrance arch LII of the newly built Colosseum in 80 AD. On the left and right the tall bronze gate leaves swung fully open against the walls, made of vertical bronze bars with a soft green-brown patina catching the light. Ahead, a high vaulted passage of large clean warm cream travertine blocks with crisp joints and fine pores, the floor of big pale stone slabs dusted with sand and straw. At the end of the passage an inner arch opens onto a steep stone staircase rising toward bright daylight. Small bronze oil lamps on the walls glow orange, warm lamplight on the stone mixing with cool daylight from the arch, deep soft shadows in the vault. Rich natural colour, tack-sharp texture of stone and bronze. Photograph in the style of Hélène Binet, natural colour, fine natural grain.
```

## K6 · Photo 6: the top of the stairs, the arena opens (end of C5, start of E6)

model `seedream_5_5`, 2k, attachments: image_references

```text
Turn this 3D render into a real photograph keeping the exact composition, camera position, height, lens and perspective, with the cavea, the podium wall, the imperial box and the arena exactly where they are and with exactly the same size and shape. A photograph taken at the top of the entrance stair, stepping out into the newly built Colosseum in 80 AD: the vast oval cavea of clean warm cream travertine seats rising in three tiers to the marble colonnade and the row of wooden masts against the sky, completely filled with fifty thousand spectators in wool tunics of madder red, woad blue, saffron, sage and cream, a living texture of colour; the marble podium wall with the imperial box under its red awning; the arena of fine golden sand below with gladiators fighting in pairs, small and in motion, each with a long shadow, a fallen gladiator lying beside his red shield, attendants in white tunics by the wall. The interior is open to the sky. Bright afternoon sun 25 degrees from the west-southwest: half of the cavea in bright sun and half in deep clean shadow with a crisp diagonal edge, a light haze of dust above the sand, clear deep blue sky. Rich saturated natural colour, tack-sharp texture of stone and crowd. Photograph in the style of Iwan Baan, natural colour, fine natural grain.
```

## K8 · Photo 8: from just above the podium wall, the middle of the descent

model `seedream_5_5`, 2k, attachments: image_references

```text
Turn this 3D render into a real photograph keeping the exact composition, camera position, height, lens and perspective, with the arena, the podium wall, the imperial box and every figure exactly where they are and with exactly the same size and shape. A photograph from just above the podium wall of the newly built Colosseum in 80 AD, the camera starting to descend toward the arena: the arena floor of fine golden sand fills most of the frame, the curved podium wall painted deep red with a marble coping crosses the frame above it, the imperial box with white columns and a red awning at the top, the packed cavea of clean warm cream travertine seats full of spectators in wool tunics of madder red, woad blue, saffron, sage and cream along the top edge. On the sand, pairs of gladiators fighting exactly where the figures are in the render: a murmillo with a large curved red shield and a crested bronze helmet against a thraex with a small square shield and a curved sword, a retiarius with net and trident, a fallen gladiator lying beside his red shield, every fighter casting a long sharp shadow, sand kicked up around their feet, attendants in white tunics by the wall. Bright afternoon sun 25 degrees from the west-southwest, a light haze of dust in the sunlight. Rich saturated natural colour, tack-sharp texture of sand, bronze and leather, fighters in motion. Photograph in the style of Iwan Baan, natural colour, fine natural grain.
```

## K9 · Photo 9: the arena photo edited so the two gladiators fight face to face (3 references)

model `seedream_5_5`, 2k, attachments: image_references, image_references, image_references

```text
The first photograph, identical in framing, camera height, lens, arena, red podium wall, imperial box, crowd, sand, light and colour, with one change: the two gladiators in the foreground now stand face to face in the middle of a fight, seen from the side exactly where the two central figures stand in the second image, dressed and posed like the two fighters in the third photograph: on the left the gladiator in the red tunic and crested bronze helmet lunging behind his tall curved red shield, on the right the gladiator in the bronze helmet and dark leather armour blocking with a small round bronze shield, their swords crossing, sand kicked up at their feet, long sharp shadows. Every other gladiator, the fallen gladiator, the attendants and the crowd stay as they are in the first photograph.
```

## K10 · Photo 10: the same edit, second version with each gladiator described (2 references)

model `seedream_5_5`, 2k, attachments: image_references, image_references

```text
The first photograph, identical in framing, camera height, lens, arena, red podium wall, imperial box, crowd, sand, light and colour, with one change: the two gladiators in the foreground now stand face to face in the middle of a fight, seen from the side exactly where the two central figures stand in the second image. On the left the gladiator in the red tunic and crested bronze helmet lunges forward behind his tall curved red shield and thrusts his short sword; on the right the gladiator in the bronze helmet and dark leather armour blocks with a small round bronze shield and swings his sword, their blades crossing between them, sand kicked up at their feet, long sharp shadows on the sand. Every other gladiator, the fallen gladiator, the attendants and the crowd stay as they are in the first photograph.
```

## K12 · Photo 12: the close-up at chest height of the two fighting (the start of the duel)

model `seedream_5_5`, 2k, attachments: image_references, image_references

```text
A close-up photograph at chest height, framed like the second photograph, of the exact two gladiators fighting in the centre of the first photograph, in the same arena, same golden sand, same deep red podium wall with marble coping, same light. On the left the gladiator in the red wool tunic and the bronze helmet with a tall red horsehair crest lunges forward, his single tall curved red rectangular shield with bronze boss held on his left arm in front of his body and his short sword thrusting in his right hand; on the right the gladiator in dark brown leather armour with a leather skirt and a bronze helmet with cheek guards blocks with his single small round bronze shield on his left arm and swings his short sword in his right hand, their blades meeting between them. Each fighter holds exactly one shield and one sword, strong arms and legs in a wide fighting stance, sandals and greaves digging into the sand, sand bursting up around their feet, dust in the sunlight, sweat and grit on skin, worn leather and dented bronze, their faces mostly hidden in the shadow of the helmets. Behind them, softly out of focus, the deep red podium wall and the packed crowd in madder red, woad blue, saffron and cream tunics cheering with raised arms. Bright afternoon sun from the west-southwest raking across the fighters, long sharp shadows on the sand. Rich saturated natural colour, tack-sharp texture of bronze, leather, skin and sand, 85 mm lens. Photograph in the style of Iwan Baan, natural colour, fine natural grain.
```

## K12fix · Fix of photo 12: the approved photo edited with the new 3D as second reference

model `seedream_5_5`, 2k, attachments: image_references

```text
The same photograph, identical in every detail: same framing, same two gladiators in the same poses, same hands, swords, helmets, crowd, wall, sand, light and colour. The only change is behind the back of the gladiator on the left: his back shows only his red wool tunic, his leather belt and his bare shoulder, with the out-of-focus deep red podium wall and the crowd visible behind him; he carries just the one tall curved red shield in front of his body.
```

## C1 · Clip C1 (4 s): sky to the dive, video edit with the 3D guide

model `kling4_0`, mode `video-edit`, 4 s, 1080p, attachments: video_references, start_image, end_image

```text
A real cinematic drone shot over ancient Rome in 80 AD. Use the input video only as the guide for the camera movement: one smooth continuous dive forward and down toward the Colosseum, never stopping, no turning, no shaking. The Colosseum and every building are solid stone and stay rigid with exactly the same shape, size and proportions the whole time; only the camera moves, so the Colosseum simply grows larger as we approach it. The look comes only from the start and end frames: a real photograph, clean warm cream travertine, terracotta roofs, deep blue sky, bright afternoon sun. Life everywhere: thousands of tiny people walking across the plaza and the market, canvas awnings rippling in the breeze, chariots rolling along the avenue, banners moving gently. Natural motion, real physics, sharp detail. No particles, no sparkles, no glitter, no magic effects.
```

## C2 · Clip C2 (4 s): down onto the avenue

model `kling4_0`, mode `video-edit`, 4 s, 1080p, attachments: video_references, start_image, end_image

```text
A real cinematic drone shot in ancient Rome, 80 AD. Use the input video only as the guide for the camera movement: one smooth continuous descent forward and down between the buildings into the triumphal avenue, landing at eye level in the middle of the street, never stopping, no turning, no shaking. The Colosseum, the columns and every building are solid stone and stay rigid with exactly the same shape and proportions the whole time; only the camera moves. The look comes only from the start and end frames: a real photograph, clean warm cream travertine, terracotta roofs, deep blue sky, bright afternoon sun. Life everywhere: crowds cheering along the avenue with arms raised, people leaning from the wooden balconies, market awnings rippling, laurel festoons swaying. Chariots drawn by pairs of white and dark horses trot along the paved avenue toward the Colosseum with a natural horse gait, legs moving correctly, manes and tails flying, a little dust at the hooves, wheels turning. Natural motion, real physics, sharp detail. No particles, no sparkles, no glitter, no magic effects.
```

## C3 · Clip C3 (4 s): along the avenue to gate LII

model `kling4_0`, mode `video-edit`, 4 s, 1080p, attachments: video_references, start_image, end_image

```text
A real cinematic steadicam shot at eye level in ancient Rome, 80 AD. Use the input video only as the guide for the camera movement: one smooth continuous glide forward along the end of the triumphal avenue and out onto the paved square in front of the Colosseum, arriving facing entrance LII with its open bronze gates and burning braziers, never stopping, no turning, no shaking. The Colosseum, the columns and every building are solid stone and stay rigid with exactly the same shape and proportions the whole time; only the camera moves. The look comes only from the start and end frames: a real photograph, clean warm cream travertine, deep blue sky, bright afternoon sun. Life everywhere: the crowd cheering and walking toward the entrance, togas and tunics moving, banners swaying, fire flickering in the braziers. Chariots drawn by pairs of horses trot past toward the Colosseum with a natural horse gait, legs moving correctly, manes and tails flying, dust at the hooves, wheels turning. Natural motion, real physics, sharp detail. No particles, no sparkles, no glitter, no magic effects.
```

## C4 · Clip C4 (4 s): through the gate

model `kling4_0`, mode `video-edit`, 4 s, 1080p, attachments: video_references, start_image, end_image

```text
A real cinematic steadicam shot at eye level, Colosseum, 80 AD. Use the input video only as the guide for the camera movement: one smooth continuous glide straight forward across the square and in through entrance LII, between the open bronze gate leaves, into the cool stone passage that leads to the staircase, never stopping, no turning, no shaking. The Colosseum arches, the gates and the stone walls are solid and stay rigid with exactly the same shape and proportions the whole time; only the camera moves. The look comes only from the start and end frames: a real photograph, clean warm cream travertine, bright afternoon sun outside, warm firelight from the oil lamps and braziers inside the passage. Life: spectators walking in through the gate ahead of the camera, tunics and togas moving, flames flickering in the braziers and lamps, horses by the entrance shifting their weight and swishing their tails. Natural motion, real physics, sharp detail. No particles, no sparkles, no glitter, no magic effects.
```

## C5 · Clip C5 (5 s): up the stairs to the top

model `kling4_0`, mode `video-edit`, 5 s, 1080p, attachments: video_references, start_image, end_image

```text
A real cinematic steadicam shot inside the Colosseum, 80 AD. Use the input video only as the guide for the camera movement: one smooth continuous glide forward along the stone passage and up the staircase toward the bright opening, then out at the top into the open amphitheatre, never stopping, no turning, no shaking. The stone walls, the steps, the arches and the whole amphitheatre are solid and stay rigid with exactly the same shape and proportions the whole time; only the camera moves. The look comes only from the start and end frames: a real photograph, clean warm cream travertine, warm firelight from the oil lamps in the passage, then the bright afternoon sun and deep blue sky over the arena. Life: spectators climbing the steps ahead of the camera, flames flickering in the lamps; at the top the packed cavea of spectators in red, blue, saffron and cream tunics cheering with raised arms, gladiators moving on the golden sand far below. Natural motion, real physics, sharp detail. No particles, no sparkles, no glitter, no magic effects.
```

## E6 · Clip E6 (5 s): the descent from the top of the stairs to the two gladiators, no 3D guide, start + middle + end photos

model `kling4_0`, mode `image-to-video`, 5 s, 1080p, attachments: start_image, image_references, end_image

```text
A real cinematic crane shot inside the Colosseum, 80 AD, one single continuous take. From the top of the cavea the camera immediately starts one smooth descent forward and down over the podium wall toward the arena, gliding low over the golden sand and arriving close to two gladiators locked in a fight, moving the whole time until the last frame, no turning left or right, horizon always level. The red podium wall, the imperial box and every tier of seats are solid stone and stay rigid with exactly the same shape and proportions; only the camera moves. The two gladiators in the centre fight face to face for the whole shot: the one in the red tunic and crested bronze helmet keeps his tall curved red shield and lunges with his short sword, the one in dark leather armour keeps his small round bronze shield and parries and strikes back, swords clashing, feet digging into the sand, dust bursting up. Around them the other gladiators fight in pairs and fifty thousand spectators cheer and wave. Real photograph look, deep blue sky, bright afternoon sun, long sharp shadows. Natural motion, real physics, sharp detail. No particles, no sparkles, no glitter, no magic effects.
```

## X1 · Clip X1 (3 s, we used 1.2 s): the camera rushes low over the sand to the two

model `kling4_0`, mode `image-to-video`, 3 s, 1080p, attachments: start_image, end_image

```text
A real cinematic shot in the Colosseum arena, 80 AD, one continuous take: the camera rushes forward fast and low over the golden sand straight toward the two gladiators fighting in the centre, ending in a close shot at chest height beside them as their swords clash. The gladiator in the red tunic and crested bronze helmet keeps his one tall curved red shield on his left arm and thrusts with his short sword; the gladiator in dark leather armour keeps his one small round bronze shield and parries, sparks where the blades meet, sand bursting at their feet. The red podium wall and the cheering crowd behind, bright afternoon sun, long sharp shadows. Real photograph look, natural motion, real physics, sharp detail. No particles, no sparkles, no glitter, no magic effects.
```

## X2 · Clip X2 (5 s): the fight, the camera circling slowly at chest height, start photo only

model `kling4_0`, mode `image-to-video`, 5 s, 1080p, attachments: start_image

```text
A real cinematic fight in the Colosseum arena, 80 AD, one continuous take with the camera at chest height slowly circling around the two gladiators. The gladiator in the red tunic and crested bronze helmet keeps his one tall curved red shield on his left arm and his short sword in his right hand the whole time; the gladiator in dark leather armour and bronze helmet keeps his one small round bronze shield on his left arm and his short sword in his right hand the whole time. They fight hard with real weight and speed: blades clash with sparks, a heavy blow lands on the red shield, a shove with the shield, a quick step back, another thrust parried on the round shield, feet digging into the sand, sand bursting up, dust in the sunlight, faces in the shadow of the helmets. The deep red podium wall and the roaring crowd out of focus behind, bright afternoon sun, long sharp shadows. Real photograph look, natural motion, real physics, sharp detail. No particles, no sparkles, no glitter, no magic effects.
```
