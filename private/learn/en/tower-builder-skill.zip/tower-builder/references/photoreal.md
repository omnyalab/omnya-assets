# Optional: realistic stills from the 3D

The 3D page is the product. When the user also wants realistic pictures of the same tower (for posts, a landing page or a brochure), use the 3D as the camera and the shapes, and let an image model only change the materials and the light. This works with any image model that accepts an input image and edits it (image-to-image or "edit" mode). Do not tell the user they need a specific paid service, and do not run paid generations without asking first.

## 1. Take clean frames

1. Open the site with the interface hidden: `index.html?clean=1&shot=1&step=tower` (or `unit`, `penthouse`, `floor`). Add `&level=32` to pick the floor.
2. Set the browser window to the final format (for example 1920 x 1080 for 16:9, or 1080 x 1350 for a 4:5 post) and press **P**. The page saves a PNG of the 3D frame only.
3. Save one frame per picture you want. Name them by step (`tower.png`, `view-32D.png`, `penthouse.png`).

The frame is the only reference. Do not add photos of real towers as references: the model will copy their shapes and the result will no longer match the page.

## 2. The prompt

Give the model the frame and a prompt that locks the camera and lists what is in the frame. Change only materials, light and realism. Template for the tower:

```
Turn this 3D render into an ultra-photorealistic architectural photograph of the same residential tower, same camera, same framing and same geometry. Keep every element exactly where it is: [the tower with N floors of white slab edges and dark glass between them, the glass balconies, the roof canopy, the lobby at the base, the plaza with palms, the coastline, the sea, the distant skyline]. Change only materials, light and realism, add nothing.
Facade: [smooth white slab edges | stone-coloured slab edges], dark reflective glass with warm lights in some rooms, clear glass balustrades with slim handrails.
Light: [golden hour, the sun low over the sea, soft warm haze | bright midday | blue hour with every window lit], high dynamic range, physically correct exposure.
Camera: full-frame camera, [35 | 50] mm lens, f/8, crisp detail, natural colours, a true photograph.
No CGI look, no toy look, no text, no logos, no people close to the camera.
```

For the view from a residence:

```
Turn this 3D render into an ultra-photorealistic interior photograph, same camera, same framing. A living room on a high floor with floor-to-ceiling glass and slim bronze mullions: [light oak floor | travertine floor], warm white ceiling with a hidden warm light line, [sofa colour] sofa, walnut and stone coffee table, floor lamp. Outside: the balcony with a glass balustrade, then [the sea at sunset with a skyline on the left | the river and the far bank | the city]. Keep the horizon, the mullions and the furniture exactly where they are. Add nothing.
```

## 3. Check before using

Put the result next to the frame and check, one by one:

- Same camera: horizon, slab lines and the edge of the roof in the same place.
- Same number of floors and the same crown. Nothing added (no extra towers next to it, no extra balconies, no people, no cars in the foreground).
- Facade colours as in the 3D.
- No text or logos invented by the model.

If one of these fails, run it again from the same frame with the failing item named in the prompt ("keep exactly 40 floors", "no people"). Do not feed a generated picture back in as the new reference: always start again from the 3D frame.

## 4. Lighting a floor in the stills

Keep the highlight out of the prompt. Take two frames from the same camera: one with `?clean=1&shot=1&step=tower`, and one with `?clean=1&shot=1&step=tower&level=32`, where that floor glows in the accent colour. Use the lit frame as a mask in any photo editor to light the same floor on the realistic picture. The shapes match because both come from the same 3D.
