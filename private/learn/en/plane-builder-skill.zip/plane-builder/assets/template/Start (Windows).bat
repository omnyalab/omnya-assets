@echo off
rem The 3D Plane · pick your seat. Double click: starts a small local server (needs Python) and opens the page.
cd /d "%~dp0"
start "" /min python -m http.server 5313 --bind 127.0.0.1
timeout /t 2 >nul
start "" http://localhost:5313/
