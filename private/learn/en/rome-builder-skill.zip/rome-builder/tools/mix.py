#!/usr/bin/env python3
"""mix.py SOUNDS_DIR OUT.wav [--intro] [--cut A B]
The sound of the Rome film (the version in our reel), rebuilt from free sounds. Put these files in SOUNDS_DIR
(download them from freesound.org, CC0, free account; the wind from mixkit.co, free):
  wind.wav        a desert or open-air wind (Mixkit «wind desert»)
  tunnel.wav      wind in a tunnel (Mixkit «wind tunnel»)
  crowd.wav       a big stadium crowd                         Freesound 829453
  roar.wav        a roaring crowd                             Freesound 130568
  market.wav      a market crowd                              Freesound 173013
  street.wav      a crowded medieval street                   Freesound 424790
  cart.wav        a horse with an old cart                    Freesound 538438
  carriage.wav    horse and carriage                          Freesound 137843
  swoosh.wav      a soft swoosh                               Freesound 169867
  woosh.wav       a quick woosh                               Freesound 683101
  sword.wav       a sword swing                               Freesound 37596
  clash.wav       a sword clash                               Freesound 471095
How it works: each bed (wind, crowd, street, chariots) is looped, levelled to the same loudness and given a volume curve
on the film's seconds; then the whole mix follows one loudness curve (TARGET) so it grows step by step with the camera:
sky, street, muffled gate, stairs growing, the roar at the top, the descent, the duel. Change the seconds in KEYS
if your film is timed differently. --intro adds 2 s of the duel at the start (the reel that opens on the fight).
--cut A B removes the film seconds A..B from the sound with a 0.1 s crossfade: use the same cut fix_join.py removed from
the pictures (our film: --cut 7.67 7.945, the 774-frame timing becomes the final 765 frames)."""
import sys, os, subprocess, numpy as np
SR = 48000; FPS = 24
D, OUT = sys.argv[1], sys.argv[2]
INTRO = 2.0 if '--intro' in sys.argv else 0.0
S = lambda n: os.path.join(D, n)
# the film's moments in seconds (our film, 24 fps): street 3-12.5, gate 12.5-16, stairs 16-21, top 20.4,
# descent 21-26, fast zoom 26-27.2, duel from 27.2 (frame 653) to the end
FILM = 774 / FPS; X2 = 653 / FPS
DUR = INTRO + FILM; N = int(DUR * SR); tt = np.arange(N) / SR - INTRO
def load(p, ss=0.0, t=None, af=None):
    a = ['ffmpeg', '-v', 'error', '-ss', str(ss)] + (['-t', str(t)] if t else []) + ['-i', p] + (['-af', af] if af else []) + ['-vn', '-ac', '2', '-ar', str(SR), '-f', 'f32le', '-']
    return np.frombuffer(subprocess.run(a, capture_output=True, check=True).stdout, np.float32).reshape(-1, 2).copy()
def loop(x, n):
    if len(x) >= n: return x[:n]
    xf = int(0.8 * SR); out = x.copy()
    while len(out) < n:
        w = np.linspace(0, 1, xf)[:, None]; out[-xf:] = out[-xf:] * (1 - w) + x[:xf] * w; out = np.concatenate([out, x[xf:]])
    return out[:n]
def norm(x, db=-20.0): return x * (10 ** (db / 20) / (np.sqrt((x ** 2).mean()) + 1e-9))
def env(keys): k = np.array(keys, np.float32); return np.interp(tt, k[:, 0], k[:, 1])[:, None]
mix = np.zeros((N, 2), np.float32)
def put(x, t, g=1.0, fi=0.02, fo=0.05):
    i = int((t + INTRO) * SR); x = x * g
    n = min(len(x), int(fi * SR)); x[:n] *= np.linspace(0, 1, n)[:, None]
    n = min(len(x), int(fo * SR)); x[-n:] *= np.linspace(1, 0, n)[:, None]
    if i < 0: x = x[-i:]; i = 0
    x = x[:max(0, N - i)]; mix[i:i + len(x)] += x
bed = lambda n, ss=0, af=None: norm(loop(load(S(n), ss, af=af), N))
KEYS = {
    'wind':   [(-9, 0), (0, 0.5), (3.2, 0.45), (5, 0.06), (12, 0.04), (14, 0.12), (16, 0.18), (20.4, 0.22), (21.2, 0.16), (26, 0.12), (27.2, 0.06), (40, 0.06)],
    'tunnel': [(-9, 0), (12.5, 0), (14, 0.10), (19.5, 0.16), (20.8, 0.0), (40, 0)],
    'crowd':  [(-9, 0), (12.6, 0), (16, 0.02), (18.6, 0.15), (19.6, 0.7), (20.3, 0.95), (24, 1.0), (40, 1.0)],
    'muffled':[(-9, 0), (11.8, 0), (12.8, 0.18), (16, 0.16), (18.5, 0.3), (20.4, 0.5), (21.2, 0.0), (40, 0)],
    'roar':   [(-9, 0), (20.4, 0), (22, 0.2), (24.5, 0.45), (26, 0.65), (27.2, 0.7), (32.25, 0.75), (40, 0.75)],
    'street': [(-9, 0), (1.5, 0), (3.2, 0.06), (4.5, 0.35), (6.5, 0.6), (11.5, 0.6), (12.8, 0.08), (14, 0), (40, 0)],
    'carts':  [(-9, 0), (4.5, 0), (6, 0.35), (8, 0.55), (11.5, 0.5), (12.8, 0.05), (14, 0), (40, 0)],
}
mix += bed('wind.wav') * env(KEYS['wind'])
mix += bed('tunnel.wav') * env(KEYS['tunnel'])
mix += bed('crowd.wav') * env(KEYS['crowd'])                                  # the crowd: one bed, muffled behind the gate,
mix += bed('crowd.wav', af='lowpass=f=700,lowpass=f=700') * env(KEYS['muffled'])  # full when you step out at the top
mix += bed('roar.wav') * env(KEYS['roar'])
mix += (bed('market.wav', 20) + 0.6 * bed('street.wav')) * env(KEYS['street'])   # outside: only people talking, horses and carts
mix += (bed('cart.wav') + 0.8 * bed('carriage.wav', 10)) * env(KEYS['carts'])
put(load(S('swoosh.wav')), 3.6, 0.18, 0.3, 0.6); put(load(S('swoosh.wav')), 21.0, 0.22, 0.4, 0.8); put(load(S('woosh.wav')), 25.95, 0.32, 0.1, 0.5)
# swords on the hits of the duel, low under the crowd (time in the duel clip, file, peak inside the file, gain)
HITS = [(0.95, 'sword.wav', 0.10, 0.17), (1.80, 'clash.wav', 1.00, 0.22), (2.45, 'sword.wav', 0.10, 0.17), (3.05, 'clash.wav', 1.00, 0.22), (3.60, 'sword.wav', 0.10, 0.17)]
for c, f, pk, g in HITS: put(load(S(f), 0, 1.6), X2 + c - pk, g, 0.005, 0.3)
if INTRO:
    for c, f, pk, g in HITS[:3]: put(load(S(f), 0, 1.4), c - pk - INTRO, g, 0.005, 0.3)
    i = int(INTRO * SR); mix[:i] += loop(load(S('roar.wav'), 4), i) * 0.5
    mix[i - int(0.25 * SR):i] *= np.linspace(1, 0.6, int(0.25 * SR))[:, None]
# one loudness curve for the whole film (dB): it grows with the camera
TARGET = [(-9, -16), (0, -25), (3, -22), (5, -21), (6.5, -16), (11, -16), (12.5, -27), (16, -27), (18.2, -22), (19.6, -15), (20.4, -13), (24, -12), (26, -11), (27.2, -11), (40, -11)]
k = np.array(TARGET, np.float32); tgt = 10 ** (np.interp(tt, k[:, 0], k[:, 1]) / 20)
def avg(x, w):
    c = np.concatenate([[0.0], np.cumsum(x, dtype=np.float64)]); n = len(x); i = np.arange(n); a = np.clip(i - w // 2, 0, n); b = np.clip(i + w // 2, 0, n)
    return ((c[b] - c[a]) / np.maximum(1, b - a)).astype(np.float32)
rms = np.sqrt(avg((mix ** 2).mean(1), int(0.5 * SR))) + 1e-6
mix *= avg(np.clip(tgt / rms, 0.2, 5.0), int(0.8 * SR))[:, None]
mix /= max(1e-6, np.abs(mix).max()) / 0.9
raw = OUT + '.raw.wav'
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'f32le', '-ar', str(SR), '-ac', '2', '-i', '-', '-c:a', 'pcm_s16le', raw], input=mix.tobytes(), check=True)
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', raw, '-af', 'volume=6dB,alimiter=limit=0.89:attack=3:release=60', '-c:a', 'pcm_s16le', OUT], check=True)
os.remove(raw)
if '--cut' in sys.argv:
    i = sys.argv.index('--cut'); a, b = float(sys.argv[i + 1]) + INTRO, float(sys.argv[i + 2]) + INTRO
    tmp = OUT + '.cut.wav'
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', OUT, '-filter_complex',
                    f'[0:a]atrim=0:{a},asetpts=N/SR/TB[x];[0:a]atrim={b},asetpts=N/SR/TB[y];[x][y]acrossfade=d=0.1[o]', '-map', '[o]', '-c:a', 'pcm_s16le', tmp], check=True)
    os.replace(tmp, OUT)
print(OUT, 'ok')
