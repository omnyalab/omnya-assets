# Your own photos and film

The page needs one film and three photos that follow the same tour. The simplest way: keep our tour and timings, and make your
film so that the same moments happen at the same seconds.

## What the page expects

- `film.mp4`: H.264, 1920x1080, 24 fps constant, no audio, starting at tour second 7 and ending at 48 (41 s, 985 frames).
  At these tour seconds the film must show: 7 view from above (same as the photo), 9.6 camera low in the street, 9.6 to 13.04 driving
  down the street, 16 in front of the villa (same as the photo), 19 to 26 through the door to the living room, 26 living room
  (stop), 29 dining room (stop), 31.5 kitchen (stop), 36 by the pool facing the landmark (same as the photo), 36 to 41.5 the camera
  turns back to the house, 41.5 to 48 slow move (darkened under the final card).
- `assets/foto/F07.jpg` (7 s), `F16.jpg` (16 s), `F36.jpg` (36 s): the exact frames of the film at those seconds, ideally sharper
  (2720x1536 in ours; any 16:9 size from 1920 wide works). The page fades between photo and film at these seconds, so they must match.

Encode with ffmpeg:
`ffmpeg -i your_tour.mp4 -an -c:v libx264 -preset slow -tune film -crf 28 -r 24 -g 24 -pix_fmt yuv420p -movflags +faststart film.mp4`
(lower crf = sharper and heavier; 23 is about twice the size).

## How we made ours (so you can do the same)

1. The street, the villas and the sun in 3D, built with Claude Code from the real map (OpenStreetMap) and real measures, and one camera
   path for the whole tour.
2. At each key moment (from above, street, villa front, door, living room, dining, kitchen, pool, back of the house) a frame from
   the 3D, turned into a realistic photo with an image model, using the 3D frame as the first reference so nothing moves.
3. Short clips (3-4 s) between those photos with a video model, each clip starting from the last real frame of the clip before, so
   the film has no jumps. Joined at 24 fps into one film.

## When your timings are different

Change the seconds in `app.js` and `dati.json` together: `LAND`, `stop`, the `FERMATE` t values, 16 (villa), 36 (pool), `DOM`, 48 (end),
`film.da`. Then the positions measured on frames have to be redone: `tag27_16`, `burj_36`, the `hot` points of the rooms, and the
street tags (`strada_tag`, one point per frame, follow each house; the street lines in `strade_sel` are drawn on the 7 s photo).
For a new street without tags, set `strada_tag` to `[]`: the scroll still works, then add one tag for the chosen villa with
`hero: true` (a few points by hand, a straight line between them is enough for a slow camera).
