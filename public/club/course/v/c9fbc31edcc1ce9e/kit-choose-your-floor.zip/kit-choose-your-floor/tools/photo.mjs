// photo.mjs · stills and step-recorded videos of the engine with headless Chrome, no window opens. Needs Node 22+, Chrome, ffmpeg, and the kit server running (Start).
// node tools/photo.mjs out.png "http://127.0.0.1:5320/?s=samar&clean=1"            → one still, 1920x1080 (--dsf 2 = 3840x2160)
// node tools/photo.mjs --giro A out.mp4 "http://127.0.0.1:5320/?s=samar&clean=1"    → records tour A frame by frame (24 fps, fake time) into an mp4
// Options: --dsf 2 (4K) · --crf 16 · --fps 24 · --dur seconds · --png (lossless frames) · --js "code" (runs before the shot)
import { spawn } from 'node:child_process';
import { writeFileSync, mkdtempSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const args = process.argv.slice(2); let giro = null, dur = null, fps = 24, js = null, frames = 0, pre = null, crf = 16, dsf = 1, png = false, x265 = false;   
for (let i = 0; i < args.length;) { if (!args[i].startsWith('--')) { i++; continue; } const k = args.splice(i, 1)[0], v = () => args.splice(i, 1)[0]; if (k === '--giro') giro = v(); if (k === '--dur') dur = +v(); if (k === '--fps') fps = +v(); if (k === '--js') js = v(); if (k === '--dsf') dsf = +v(); if (k === '--png') png = true; if (k === '--x265') x265 = true; if (k === '--trasp') { png = true; globalThis.TRASP = true; } if (k === '--frames') frames = +v(); if (k === '--pre') pre = v(); if (k === '--crf') crf = +v(); }
const [out, url] = args; const W = 1920, H = 1080;
const CHROME = process.env.CHROME || [
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  `${process.env.ProgramFiles}\\Google\\Chrome\\Application\\chrome.exe`, `${process.env['ProgramFiles(x86)']}\\Google\\Chrome\\Application\\chrome.exe`, `${process.env.LOCALAPPDATA}\\Google\\Chrome\\Application\\chrome.exe`,
  '/usr/bin/google-chrome', '/usr/bin/chromium'].find(p => { try { return existsSync(p); } catch { return false; } });
if (!CHROME) { console.error('Google Chrome not found: install it, or set CHROME=/path/to/chrome'); process.exit(1); }
const GPU = process.platform === 'darwin' ? ['--use-angle=metal'] : [];
const port = 9300 + Math.floor(Math.random() * 400), prof = mkdtempSync(join(tmpdir(), 'cyf-'));
const ch = spawn(CHROME, ['--headless=new', ...GPU, '--enable-gpu', '--ignore-gpu-blocklist', `--remote-debugging-port=${port}`, `--user-data-dir=${prof}`, `--window-size=${W},${H}`, '--hide-scrollbars', '--autoplay-policy=no-user-gesture-required', 'about:blank'], { stdio: 'ignore' });
const sleep = ms => new Promise(r => setTimeout(r, ms));
let ws; for (let i = 0; i < 60; i++) { try { const l = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json(); const p = l.find(t => t.type === 'page'); if (p) { ws = new WebSocket(p.webSocketDebuggerUrl); break; } } catch { } await sleep(150); }
await new Promise(r => ws.onopen = r);
let id = 0; const pend = new Map(), logs = [];
ws.onmessage = m => { const d = JSON.parse(m.data); if (d.id && pend.has(d.id)) { pend.get(d.id)(d); pend.delete(d.id); } else if (d.method === 'Runtime.consoleAPICalled' && /error|warn/.test(d.params.type)) logs.push(d.params.args.map(a => a.value ?? a.description).join(' ')); else if (d.method === 'Runtime.exceptionThrown') logs.push('EXC ' + (d.params.exceptionDetails.exception?.description || d.params.exceptionDetails.text)); };
const send = (method, params = {}) => new Promise(r => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
const ev = async e => { const r = (await send('Runtime.evaluate', { expression: e, awaitPromise: true, returnByValue: true })).result; if (r?.exceptionDetails) console.error('JS ERR', r.exceptionDetails.exception?.description || r.exceptionDetails.text); return r?.result?.value; };
await send('Runtime.enable'); await send('Page.enable');
await send('Emulation.setDeviceMetricsOverride', { width: W, height: H, deviceScaleFactor: dsf, mobile: false });
if (globalThis.TRASP) await send('Emulation.setDefaultBackgroundColorOverride', { color: { r: 0, g: 0, b: 0, a: 0 } });   /* --trasp: PNG with a transparent background (UI only) */
await send('Page.navigate', { url });
let ok = false; for (let i = 0; i < 240; i++) { await sleep(250); if (await ev('document.body && document.body.dataset.pronto === "1"')) { ok = true; break; } }
if (!ok) { console.error('PAGE NOT READY (is the server running? is the address right?)', logs.join('\n')); finish(1); }
if (js) { const r = await ev(`(async () => { ${js} })()`); if (r !== undefined) console.log('js:', JSON.stringify(r)); }
const shot = async () => Buffer.from((await send('Page.captureScreenshot', png ? { format: 'png' } : { format: 'jpeg', quality: 94 })).result.data, 'base64');
if (frames) {   // --frames N: records N frames step by step after --js (which sets the scene up); --pre runs before every frame
  const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-i', '-', '-vf', 'scale=out_range=tv:out_color_matrix=bt709', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-color_range', 'tv', '-colorspace', 'bt709', '-crf', String(crf), '-preset', 'slow', '-movflags', '+faststart', out], { stdio: ['pipe', 'inherit', 'inherit'] });
  for (let f = 0; f < frames; f++) { if (f) await ev(`__motore.step(1, ${fps})`); if (pre) await ev(pre); ff.stdin.write(await shot()); }
  ff.stdin.end(); await new Promise(r => ff.on('close', r)); console.log('ok', out, frames, 'frame', logs.length ? '\n' + logs.join('\n') : ''); finish(0);
} else if (!giro) {
  await ev('new Promise(r => { let n = 0; const f = () => (++n > 30 ? r() : requestAnimationFrame(f)); f(); })');
  writeFileSync(out, await shot()); console.log('ok', out, logs.length ? '\n' + logs.join('\n') : '');
  finish(0);
} else {
  // record: ffmpeg reads the frames from stdin, no files on disk
  const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-i', '-', ...(x265 ? ['-c:v', 'libx265', '-tag:v', 'hvc1', '-x265-params', 'log-level=error'] : ['-c:v', 'libx264']), '-pix_fmt', 'yuv420p', '-crf', String(crf), '-preset', 'slow', '-movflags', '+faststart', out], { stdio: ['pipe', 'inherit', 'inherit'] });
  await ev(`__motore.avviaGiro(${JSON.stringify(giro)})`);
  const maxF = Math.round((dur || 90) * fps); let f = 0;
  for (; f < maxF; f++) { await ev(`__motore.step(1, ${fps})`); ff.stdin.write(await shot()); if (!dur && f > fps && !(await ev('__motore.giroAcceso()'))) { for (let k = 0; k < fps; k++) { await ev(`__motore.step(1, ${fps})`); ff.stdin.write(await shot()); } break; } }
  ff.stdin.end(); await new Promise(r => ff.on('close', r)); console.log('ok', out, f, 'frame', logs.length ? '\n' + logs.join('\n') : ''); finish(0);
}
function finish(code) { try { ws.close(); } catch { } ch.kill('SIGKILL'); setTimeout(() => { try { rmSync(prof, { recursive: true, force: true }); } catch { } process.exit(code); }, 300); }
