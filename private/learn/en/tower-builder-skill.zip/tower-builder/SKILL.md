---
name: tower-builder
description: Builds a complete one-folder website with a 3D residential tower in three.js where buyers choose their floor and their apartment - the tower in its setting with a price on every floor, a straight camera move to the chosen level, the residences on that floor, the real view from inside that apartment at its height, an offer to upgrade to the penthouse, and a reservation card. Works on phones, needs no build step and goes online for free. Use it whenever someone asks for a tower, residential tower, skyscraper, condo or apartment building, an off-plan launch page, a "choose your floor" or "pick an apartment" page, a building where buyers choose a floor or a unit in 3D, an interactive 3D tower for a developer, broker or real-estate brand, even if they only say "build me a tower for my project".
---

# Tower Builder

You build a 3D "choose your floor" website for one residential tower, starting from the working template in `assets/template/`. The template already does everything: the tower in three.js with white slab edges and dark glass, its setting (sea, river, city, desert or park), the five steps of the choice, the view from inside each residence, the penthouse upgrade, the reservation card, phone layout and loading screen. Your job is to fit it to the user's tower by editing the config object, check it, and hand over a folder they can put online.

Most builds only touch `window.TOWER_CONFIG` at the top of `tower.js`. Change the engine only when the user asks for something the config cannot do, and then read `references/customising.md` first.

## 1. Ask first, in one short message

Before building, ask the user for what you do not already know. Ask everything in one message, offer a default for each, and say they can answer "use the defaults". Do not ask again for anything they already said.

1. **Name** of the tower or project, exactly as it should appear, and the city.
2. **Setting**: by the sea, by a river, in the city, in the desert or in a park. This sets what the residences look out at.
3. **Size**: number of floors (or the height in metres), and the shape: rectangular, rounded, oval or tapered. Optional: the top (flat, slanted glass crown, spire) and the facade (white bands with balconies, flush glass, vertical fins).
4. **Colours**: the glass, the slab edges, and an accent for the lit floor and the buttons. Defaults: dark glass, warm white bands, soft yellow.
5. **Prices**: currency and the range (cheapest to most expensive), and the penthouse upgrade price.
6. **Residences**: how many per floor (default 6) and the sizes on offer (default 1, 2 and 3 bedrooms).
7. **Language** of the page.
8. Optional: golden hour, day or night; floors to show as sold out; a payment link for the Reserve button.

If the user gave enough in the first message (for example "a 32-floor tower for Aurora Residences in Lisbon by the river, white and sand, prices from 450,000 to 2 million euros, penthouse upgrade 900,000"), do not stop to ask: pick sensible defaults for the rest, build, and list the defaults you chose at the end so they can change them.

## 2. Build

1. **Copy the template.** Copy the whole `assets/template/` folder to a new folder named after the tower in lowercase with dashes, e.g. `aurora-residences/`. It holds `index.html`, `tower.js` and `ui.css`. Never edit the template itself.
   - On claude.ai (no local terminal), create the same three files in your sandbox with the template's content and give them back as a zip at the end.
2. **Fill the config** at the top of `tower.js`. Every field is in `references/config.md`. In order:
   - `name`, `shortName` (1 to 3 letters for the monogram), `city`, `lang`, `locale`, `currency`. Use the name exactly as the user wrote it ("Aurora Residences", not an invented "Aurora Tower"). `locale` = page language + the tower's country: English page in Portugal with euros = `en-IE` (`€450,000`), Italian page = `it-IT` (`450.000 €`).
   - `floors`, `floorHeight` (or `height`), `podiumFloors` (2 is usual; 1 for towers under 20 floors).
   - `footprint`, `crown`, `facade`. "White" towers usually want `facade: 'bands'`; "all glass" wants `glass`; "vertical lines" wants `fins`.
   - `colors`: `glass` dark, `frame` the light colour the user named ("white and sand" = frame `#efe6d6`, a warm sand), `accent` a colour that is not the glass, not the frame and not grey.
   - `surroundings`: sea, river, city, desert or park; `look`: golden by default.
   - `zones`: two to four groups of levels from the first residential level (`podiumFloors + 1`) to the level under the penthouse, each with the price of its cheapest residence. Spread the user's range: the lowest zone starts at the user's lowest price.
   - `unitsPerFloor`, `unitTypes`, `occupancy`, `soldOutFloors` (only if the user wants some).
   - `penthouse` name, upgrade price and 2 or 3 short perks; `penthouse: null` if the user does not want one. `checkoutUrl` if given.
   - Translate every string in `text` if the page is not in English, and set `viewFront` / `viewSide` / `viewBack` to match the setting (see `references/config.md`, e.g. "River view" for a river).
3. **Check the numbers.** Serve the folder (see step 4) and read the `tower ready` line in the console, or run `tower.info()`. Adjust the zone prices until `priceRange` matches the user's range (within about 5%) and the floors and height are right. Tell the user the measured numbers. Never claim a number you did not measure.
4. **Look at every step.** Serve the folder locally, e.g. `python3 -m http.server 8080` inside it, and open:
   - `index.html?shot=1&step=tower`, `&step=tower&level=N` (a lit floor with its label), `step=floor`, `step=unit`, `step=upgrade`, `step=penthouse`, `step=card`,
   - at phone size (390 x 844) and desktop size (1440 x 900).
   With a browser tool, screenshot each one. Without one, use headless Chrome, e.g.
   `"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless=new --use-angle=metal --enable-gpu --ignore-gpu-blocklist --hide-scrollbars --window-size=1440,900 --virtual-time-budget=25000 --screenshot=tower.png "http://localhost:8080/index.html?shot=1&step=tower"`
   and look at every picture. Then click through the real flow once: a floor, a residence, Continue, Yes upgrade, Continue, Reserve.

## 3. Rules

- **One folder, no build step.** Three files: `index.html`, `tower.js`, `ui.css`. No npm, no bundler, no framework. Images you add go in the same folder with relative paths.
- **three.js from the CDN, pinned.** Keep the import map on `three@0.160.0` from jsDelivr. Do not use `latest` or an unpinned version, and do not switch to another library. The page needs internet only for that; everything else is local.
- **The engine is a plain script.** `tower.js` is loaded with a normal `<script>` and receives three.js from the small module in `index.html`. Keep it that way: it is what lets the page also open with a double click in Chrome. Do not turn `tower.js` into an ES module with imports.
- **Phone first.** Every control is at least 44 px, the sheet sits at the bottom within thumb reach, nothing needs hover. On a phone the first tap on a floor or a residence selects it and shows its price, the second tap (or the button) goes in. Check the phone screenshots before the desktop ones.
- **One floor lit at a time.** The accent light covers exactly one level's glass. Never add lights or glows that spill over two floors.
- **Calm camera.** Moves between steps are straight (no orbit, no left-right swing, no roll) and everything inside a residence changes with a soft fade. If you add a step, use `moveTo` or `cut` from the engine, never a new kind of move.
- **Performance limits.** The tower is a few merged meshes; never create one mesh per floor or per residence. Keep the pixel ratio capped (already in the engine), the shadow map at 4096 or less, and `floors` at 120 or less. Phones get the light version automatically.
- **Honest data.** Prices, sizes and sold residences are sample data generated from the config, the same on every load. Keep `text.note` on the card unless the user connects real data. There is no booking or payment inside the page; `checkoutUrl` only hands the choice to a payment link the user owns.
- **No names you were not given.** Use the user's tower, developer and city names only. Do not invent developers, architects, real towers, awards, completion dates or amenities the user did not mention. Never model a real existing tower or use its name.
- **Keep the user out of trouble.** Do not use logos or trademarks of other developers or brands unless the user says they own them or have permission.

## 4. Before handing over, check

- [ ] Console shows `tower ready` with floors, units, height and `priceRange`, and no errors.
- [ ] All steps look right on phone and desktop: labels readable and not on top of each other, the sheet never covers the lit floor or the chosen residence, the card fits the screen.
- [ ] The lit floor is clearly visible and covers one level only; sold residences are grey on the open floor.
- [ ] The view from the residence shows the setting (water, river or city) through the glass, not a wall.
- [ ] Prices use the right currency and format; the zone "from" prices and `priceRange` match what you told the user.
- [ ] The penthouse view shows the terrace and the view; the penthouse card shows the upgrade in the total.
- [ ] Back button and Esc go one step back; "Choose another floor" goes to the tower.
- [ ] Every visible word is in the user's language.

## 5. Put it online for free

Tell the user these steps in plain words (in the user's language if the page is):

**Netlify Drop (no account needed to try, free account to keep it):**
1. Go to app.netlify.com/drop.
2. Drag the whole folder (the one with `index.html` inside) onto the page.
3. In a few seconds you get a link like `something.netlify.app`. Sign in with a free account to keep it online and to rename it.

**Vercel (free Hobby account):**
1. Sign in at vercel.com and choose Add New, then Project.
2. Drag the folder onto the upload area (or push it to a GitHub repository and import it).
3. No settings to change: framework "Other", no build command. Deploy, and the link is ready.
4. If the dashboard does not offer a folder upload, run `npx vercel` inside the folder (it asks to log in once) or push the folder to GitHub and import it.

Both give HTTPS, which phones need. To update later, drag the folder again (Netlify: Deploys, then drag; Vercel: a new deployment). A custom domain can be added in either dashboard.

## 6. More, only when asked

- Change the shape beyond the config, colours of parts, the interiors, the light, the camera: `references/customising.md`.
- Turn frames of the 3D into realistic stills for posts or a brochure: `references/photoreal.md`.
- What every config field does: `references/config.md`.

## What to say at the end

Short and concrete: the folder name, the measured floors, height and number of residences, the zones with their from-prices and the measured price range, the penthouse upgrade, the defaults you chose that the user did not specify, how to open it locally (double click `index.html` in Chrome, or the local server address), and the free publishing steps. Attach or show three screenshots (the tower with a lit floor, the view from a residence, the card) if you have them.
