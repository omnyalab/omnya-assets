# Mercato e vita intorno al Colosseo (Nico 25/11: «come nel Gladiatore, con i mercanti»).
# Bancarelle con tende nei colori della terra, botteghe lungo il viale, carretti, mercanti dietro i banchi
# e gente che cammina davvero (Geometry Nodes col tempo della scena). Persone solo come sagome lontane o in moto.
import bpy, math, random
import numpy as np
import geo
from geo import frame, PERIM, Builder
import roma, materiali

TENDE = ['#a8432f', '#c27a3a', '#d9c7a1', '#7d5a3c', '#5f6e74', '#b89a5b', '#8a2f2a', '#e6dcc4', '#9b5a2e', '#6f7a5a']
FRUTTA = ['#c4572a', '#d8962f', '#8a2b26', '#6d7a2c', '#b9a24a', '#a0442c']


def _mats(MAT):
    if 'tenda' not in MAT:
        MAT['tenda'] = materiali.stoffa('tenda', TENDE, sheen=0.3, rough=0.85)
        MAT['frutta'] = materiali.stoffa('frutta', FRUTTA, sheen=0.0, rough=0.7)
        MAT['terracotta'] = materiali.semplice('terracotta', '#a5583a', 0.8)
        MAT['cesta'] = materiali.semplice('cesta', '#9c7a4a', 0.95)
        MAT['sacco'] = materiali.semplice('sacco', '#bfa77f', 0.95)
    return MAT


def _bx(b, mat, cx, cy, z0, z1, hx, hy):
    b.raw(mat, [(cx + sx * hx, cy + sy * hy, zz) for zz in (z0, z1) for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))],
          [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)])


def _cil(b, mat, x, y, z0, z1, r, n=10, r1=None):
    r1 = r if r1 is None else r1
    V = [(x + rr * math.cos(2 * math.pi * i / n), y + rr * math.sin(2 * math.pi * i / n), zz) for zz, rr in ((z0, r), (z1, r1)) for i in range(n)]
    F = [(i, (i + 1) % n, n + (i + 1) % n, n + i) for i in range(n)] + [tuple(range(n - 1, -1, -1)), tuple(range(n, 2 * n))]
    b.raw(mat, V, F)


def _telo(b, x0, x1, y0, y1, z0, z1, sag=0.08, nu=6):
    """tenda inclinata da (y0, z0) dietro a (y1, z1) davanti, un po' cedevole, con mantovana davanti"""
    V = []; F = []
    for j in range(nu + 1):
        t = j / nu; y = y0 + (y1 - y0) * t; z = z0 + (z1 - z0) * t - sag * math.sin(math.pi * t)
        V += [(x0, y, z), (x1, y, z)]
    for j in range(nu):
        F.append((2 * j, 2 * j + 1, 2 * j + 3, 2 * j + 2))
    o = len(V)
    V += [(x0, y1, z1), (x1, y1, z1), (x1, y1, z1 - 0.28), (x0, y1, z1 - 0.28)]
    F.append((o, o + 1, o + 2, o + 3))
    b.raw('tenda', V, F)


def _mucchio(nome, MAT, rnd):
    """mucchio di merce a terra: ceste, anfore, sacchi, casse (solo foto)"""
    b = Builder()
    for k in range(rnd.randint(5, 9)):
        x, y = rnd.uniform(-1.0, 1.0), rnd.uniform(-0.8, 0.8); r = rnd.random()
        if r < 0.35:
            _cil(b, 'cesta', x, y, 0, rnd.uniform(0.3, 0.5), rnd.uniform(0.22, 0.32), 10, 0.3); _cil(b, 'frutta', x, y, 0.32, 0.4, 0.26, 10, 0.12)
        elif r < 0.65:
            _cil(b, 'terracotta', x, y, 0, rnd.uniform(0.6, 0.95), rnd.uniform(0.16, 0.22), 10, 0.07)
        elif r < 0.85:
            _bx(b, 'sacco', x, y, 0, rnd.uniform(0.4, 0.6), 0.25, 0.2)
        else:
            _bx(b, 'legno', x, y, 0, 0.5, 0.35, 0.3)
    V = []; F = []; mi = []; ordine = ['legno', 'tenda', 'terracotta', 'cesta', 'frutta', 'sacco']
    for k, mat in enumerate(ordine):
        if mat in b.parts:
            vv, ff = b.parts[mat]; o = len(V); V += vv; F += [tuple(o + i for i in f) for f in ff]; mi += [k] * len(ff)
    me = bpy.data.meshes.new(nome); me.from_pydata(V, [], F)
    for p, k in zip(me.polygons, mi):
        p.material_index = k
    for m in ordine:
        me.materials.append(MAT[m])
    return bpy.data.objects.new(nome, me)


def _asino(nome, MAT):
    """asino: il cavallo del corteo più piccolo e grigio-bruno (solo foto)"""
    import corteo
    me = corteo._cavallo().copy(); me.name = nome
    me.materials.clear()
    if 'asino' not in MAT:
        MAT['asino'] = materiali.semplice('asino', '#7a6a5c', 0.85)
    me.materials.append(MAT['asino'])
    return bpy.data.objects.new(nome, me)


def _variante(nome, tipo, MAT, rnd):
    """bancarella 3 x 2,4 m, origine a terra, banco verso +y"""
    b = Builder()
    if tipo == 'carro':
        _bx(b, 'legno', 0, 0, 0.7, 0.82, 0.75, 1.4)
        for sx in (-1, 1):
            _bx(b, 'legno', sx * 0.75, 0, 0.82, 1.15, 0.04, 1.4)
            V = [(sx * 0.82, 0.3 * 0 + 0.55 * math.cos(2 * math.pi * k / 14), 0.58 + 0.55 * math.sin(2 * math.pi * k / 14)) for k in range(14)]
            V2 = [(sx * 0.9, v[1], v[2]) for v in V]
            b.raw('legno', V + V2, [(k, (k + 1) % 14, 14 + (k + 1) % 14, 14 + k) for k in range(14)] + [tuple(range(13, -1, -1))])
            _bx(b, 'legno', sx * 0.45, 2.3, 0.75, 0.82, 0.04, 1.0)
        for k in range(rnd.randint(3, 6)):
            _bx(b, 'sacco', rnd.uniform(-0.45, 0.45), rnd.uniform(-1.1, 1.1), 0.82, 1.15 + rnd.uniform(0, 0.25), 0.28, 0.35)
        if rnd.random() < 0.5:
            _telo(b, -0.85, 0.85, -1.45, 1.45, 1.75, 1.75, sag=-0.35)
    else:
        L = 3.0 if tipo != 'tettoia' else 6.0
        hx = L / 2
        _bx(b, 'legno', 0, 0.45, 0.0, 0.92, hx - 0.15, 0.42)                     # banco
        for sx in (-1, 1):
            _cil(b, 'legno', sx * (hx - 0.05), -1.0, 0, 2.6, 0.05, 6)
            _cil(b, 'legno', sx * (hx - 0.05), 1.15, 0, 2.2, 0.05, 6)
        _telo(b, -hx - 0.1, hx + 0.1, -1.15, 1.45, 2.62, 2.18)
        n = int(L / 0.55)
        for i in range(n):                                                         # merce sul banco
            x = -hx + 0.35 + i * (L - 0.7) / max(1, n - 1)
            if tipo == 'anfore':
                _cil(b, 'terracotta', x, 0.45 + rnd.uniform(-0.15, 0.15), 0.92, 1.45, 0.16, 10, 0.07)
            elif tipo == 'frutta':
                _cil(b, 'cesta', x, 0.45, 0.92, 1.1, 0.24, 10, 0.27)
                _cil(b, 'frutta', x, 0.45, 1.1, 1.18, 0.25, 10, 0.12)
            else:
                _bx(b, 'tenda', x, 0.45, 0.92, 1.0 + rnd.uniform(0.05, 0.2), 0.22, 0.3)
        for k in range(rnd.randint(2, 5)):                                         # sacchi e anfore a terra
            x = rnd.uniform(-hx + 0.3, hx - 0.3)
            if rnd.random() < 0.5:
                _cil(b, 'terracotta', x, -0.5, 0, 0.85, 0.2, 10, 0.08)
            else:
                _bx(b, 'sacco', x, -0.55, 0, 0.55, 0.25, 0.22)
    V = []; F = []; mi = []
    ordine = ['legno', 'tenda', 'terracotta', 'cesta', 'frutta', 'sacco']
    for k, mat in enumerate(ordine):
        if mat in b.parts:
            vv, ff = b.parts[mat]; o = len(V); V += vv
            F += [tuple(o + i for i in f) for f in ff]; mi += [k] * len(ff)
    me = bpy.data.meshes.new(nome); me.from_pydata(V, [], F)
    for p, k in zip(me.polygons, mi):
        p.material_index = k
    for m in ordine:
        me.materials.append(MAT[m])
    return bpy.data.objects.new(nome, me)


TIPI = ['anfore', 'frutta', 'stoffe', 'anfore', 'frutta', 'stoffe', 'tettoia', 'carro']
DISORDINE = False      # solo per le foto (Nico 25/11): banchi storti e a gruppi, vicoli irregolari, carretti di traverso, mucchi, asini, bambini


def _gn_moto(cv, nome):
    """istanze su punti che si spostano col tempo: posizione + mv * secondi"""
    ng = bpy.data.node_groups.new(nome, 'GeometryNodeTree')
    ng.interface.new_socket('Geometry', in_out='INPUT', socket_type='NodeSocketGeometry')
    ng.interface.new_socket('Geometry', in_out='OUTPUT', socket_type='NodeSocketGeometry')
    N = ng.nodes; L = ng.links
    gi = N.new('NodeGroupInput'); go = N.new('NodeGroupOutput')

    def attr(name, typ):
        a = N.new('GeometryNodeInputNamedAttribute'); a.data_type = typ; a.inputs['Name'].default_value = name
        return a.outputs['Attribute']
    tm = N.new('GeometryNodeInputSceneTime')
    sc = N.new('ShaderNodeVectorMath'); sc.operation = 'SCALE'
    L.new(attr('mv', 'FLOAT_VECTOR'), sc.inputs[0]); L.new(tm.outputs['Seconds'], sc.inputs['Scale'])
    sp = N.new('GeometryNodeSetPosition'); L.new(gi.outputs[0], sp.inputs['Geometry']); L.new(sc.outputs[0], sp.inputs['Offset'])
    ci = N.new('GeometryNodeCollectionInfo'); ci.inputs['Collection'].default_value = cv
    ci.inputs['Separate Children'].default_value = True; ci.inputs['Reset Children'].default_value = True
    ip = N.new('GeometryNodeInstanceOnPoints'); ip.inputs['Pick Instance'].default_value = True
    L.new(sp.outputs[0], ip.inputs['Points']); L.new(ci.outputs[0], ip.inputs['Instance'])
    L.new(attr('var', 'INT'), ip.inputs['Instance Index'])
    e2r = N.new('FunctionNodeEulerToRotation'); L.new(attr('rot', 'FLOAT_VECTOR'), e2r.inputs[0]); L.new(e2r.outputs[0], ip.inputs['Rotation'])
    L.new(attr('scl', 'FLOAT'), ip.inputs['Scale'])
    L.new(ip.outputs[0], go.inputs[0])
    return ng


def nuvola(nome, P, coll, ng):
    """P: (x, y, z, rotz, var, col, scl, mvx, mvy)"""
    me = bpy.data.meshes.new(nome)
    me.vertices.add(len(P))
    arr = np.array([p if len(p) == 9 else tuple(p) + (0.0, 0.0) for p in P], dtype=np.float32)
    me.vertices.foreach_set('co', arr[:, :3].ravel())
    rot = np.zeros((len(P), 3), np.float32); rot[:, 2] = arr[:, 3]
    a = me.attributes.new('rot', 'FLOAT_VECTOR', 'POINT'); a.data.foreach_set('vector', rot.ravel())
    a = me.attributes.new('var', 'INT', 'POINT'); a.data.foreach_set('value', arr[:, 4].astype(np.int32))
    a = me.attributes.new('col', 'FLOAT', 'POINT'); a.data.foreach_set('value', arr[:, 5])
    a = me.attributes.new('scl', 'FLOAT', 'POINT'); a.data.foreach_set('value', arr[:, 6])
    mv = np.zeros((len(P), 3), np.float32); mv[:, 0] = arr[:, 7]; mv[:, 1] = arr[:, 8]
    a = me.attributes.new('mv', 'FLOAT_VECTOR', 'POINT'); a.data.foreach_set('vector', mv.ravel())
    ob = bpy.data.objects.new(nome, me); coll.objects.link(ob)
    mod = ob.modifiers.new('istanze', 'NODES'); mod.node_group = ng
    return ob


def _rot_verso(vx, vy):
    return math.atan2(-vx, vy)


def costruisci(scn, MAT, coll, AVd, leggero, durata_s=33.0):
    """da chiamare dopo folla.costruisci (usa la collezione 'Varianti' delle persone) e dopo roma.citta (botteghe)"""
    _mats(MAT)
    rnd = random.Random(1980)
    dens = 0.35 if leggero else 1.0
    pc, nc, tc = AVd['pc'], AVd['nc'], AVd['tc']
    col = pc + nc * 125 + tc * 48                               # Colosso
    Tc = np.array([0.0, -330.0]); Te = np.array([177.0, 190.0])
    cvb = bpy.data.collections.new('VariantiMercato'); scn.collection.children.link(cvb)
    for i, t in enumerate(TIPI):
        cvb.objects.link(_variante(f'm{i}_{t}', t, MAT, rnd))
    if DISORDINE:
        cvb.objects.link(_mucchio('m8_mucchio', MAT, rnd))
        cvb.objects.link(_asino('m9_asino', MAT))
    scn.view_layers[0].layer_collection.children['VariantiMercato'].exclude = True
    ng_b = _gn_moto(cvb, 'mercato_istanze')
    ng_p = _gn_moto(bpy.data.collections['Varianti'], 'gente_istanze')
    B = []          # bancarelle, carri
    G = []          # persone (ferme e in moto)
    CASE = []       # botteghe lungo il viale (varianti della città)

    def rel(p):
        r = p - pc; return r @ nc, r @ tc

    def libero(p, viale=13.5):
        al, lt = rel(p)
        if al > -12 and abs(lt) < viale:
            return False
        if np.linalg.norm(p - col) < 20 or np.linalg.norm(p - Tc) < 130 or np.linalg.norm(p - Te) < 92:
            return False
        return True

    def cammina(p, d, v):
        return (float(d[0] * v), float(d[1] * v))

    # 1) PIAZZA lastricata (17,5-62 m dalla facciata): gente che va e viene, niente banchi
    for i in range(int(5200 * dens)):
        s = rnd.uniform(0, PERIM); o = rnd.uniform(18.5, 61.0)
        p, nn = frame(s); q = p + nn * o
        if not libero(q, 9.0):
            continue
        t_ = np.array([-nn[1], nn[0]])
        ang = rnd.uniform(0, 2 * math.pi); d = math.cos(ang) * t_ + math.sin(ang) * nn * 0.6; d = d / np.linalg.norm(d)
        v = rnd.uniform(0.55, 1.35) if rnd.random() < 0.7 else 0.0
        ok = True
        for k in range(7):
            w = q + d * v * durata_s * k / 6
            rho = math.hypot(w[0] / 94.0, w[1] / 78.0)
            if not (1.22 < rho < 1.62) or not libero(w, 10.5):
                ok = False; break
        if not ok:
            continue
        mvx, mvy = cammina(q, d, v)
        G.append((q[0], q[1], 0.0, _rot_verso(*d), rnd.choice((4, 4, 4, 5, 6, 7)), rnd.random(), rnd.uniform(0.9, 1.1), mvx, mvy))
    # 2) MERCATO ad anello fuori dalla piazza: corsie, banchi schiena contro schiena, gente nelle corsie
    o = 62.6
    while o < 190:
        corsia = o + 2.2                                                   # centro corsia
        for faccia, oo in ((1, o + 0.0), (-1, o + 4.4)):                     # banco prima della corsia (guarda fuori) e dopo (guarda dentro)
            s = rnd.uniform(0, 3)
            while s < PERIM:
                s += 3.3 + (4.0 if rnd.random() < 0.08 else 0.0)
                p, nn = frame(s); q = p + nn * (oo + faccia * -1.2)
                if math.hypot(q[0] / 1.2, q[1]) > 182 or not libero(q) or roma.quota(*q) > 6.0:
                    continue
                if rnd.random() > dens:
                    continue
                tipo = rnd.choices(range(len(TIPI)), weights=(5, 5, 4, 5, 5, 4, 2, 1))[0]
                dv = nn * faccia                                           # il banco guarda la corsia
                scl_b = 1.0
                if DISORDINE:
                    if rnd.random() < 0.13:
                        continue
                    da = rnd.gauss(0, 0.32); ca_, sa_ = math.cos(da), math.sin(da)
                    dv = np.array([dv[0] * ca_ - dv[1] * sa_, dv[0] * sa_ + dv[1] * ca_])
                    q = q + np.array([-nn[1], nn[0]]) * rnd.uniform(-1.3, 1.3) + nn * rnd.uniform(-0.7, 0.7)
                    scl_b = rnd.uniform(0.82, 1.25)
                    if rnd.random() < 0.08:
                        tipo = 7
                dvx, dvy = dv
                B.append((q[0], q[1], roma.quota(*q), _rot_verso(dvx, dvy) + (rnd.uniform(-1.2, 1.2) if DISORDINE and tipo == 7 else 0.0), tipo, rnd.random(), scl_b, 0.0, 0.0))
                if DISORDINE and rnd.random() < 0.35:              # mucchi di ceste, anfore e sacchi a terra
                    c = q + dv * rnd.uniform(1.4, 2.0) + np.array([-dv[1], dv[0]]) * rnd.uniform(-1.6, 1.6)
                    B.append((c[0], c[1], roma.quota(*c), rnd.uniform(0, 6.28), 8, rnd.random(), rnd.uniform(0.7, 1.2), 0.0, 0.0))
                if DISORDINE and rnd.random() < 0.06:              # asino legato al banco
                    c = q - dv * 0.6 + np.array([-dv[1], dv[0]]) * rnd.choice((-2.2, 2.2))
                    B.append((c[0], c[1], roma.quota(*c), rnd.uniform(0, 6.28), 9, rnd.random(), 0.72, 0.0, 0.0))
                # mercante dietro il banco e clienti davanti
                nn = dv * faccia
                m = q - nn * faccia * 0.35
                G.append((m[0], m[1], roma.quota(*m), _rot_verso(dvx, dvy), rnd.choice((5, 6, 4)), rnd.random(), 1.0, 0.0, 0.0))
                for k in range(rnd.choice((0, 1, 1, 2))):
                    c = q + nn * faccia * rnd.uniform(1.6, 2.3) + np.array([-nn[1], nn[0]]) * rnd.uniform(-1.2, 1.2)
                    G.append((c[0], c[1], roma.quota(*c), _rot_verso(-dvx, -dvy) + rnd.uniform(-0.4, 0.4), rnd.choice((4, 5, 6)), rnd.random(), rnd.uniform(0.9, 1.08), 0.0, 0.0))
        # gente che cammina lungo la corsia
        for k in range(int(PERIM / 6 * dens)):
            s = rnd.uniform(0, PERIM); p, nn = frame(s); q = p + nn * (corsia + rnd.uniform(-1.0, 1.0))
            if math.hypot(q[0] / 1.2, q[1]) > 182 or not libero(q) or roma.quota(*q) > 6.0:
                continue
            t_ = np.array([-nn[1], nn[0]]) * rnd.choice((-1, 1))
            v = rnd.uniform(0.5, 1.2)
            bimbo = DISORDINE and rnd.random() < 0.12
            G.append((q[0], q[1], roma.quota(*q), _rot_verso(*t_), rnd.choice((4, 4, 5, 6)), rnd.random(), rnd.uniform(0.58, 0.68) if bimbo else rnd.uniform(0.9, 1.1), float(t_[0] * v), float(t_[1] * v)))
        o += 8.8
    # 3) VIALE: palazzi, portici e balconi li fa viale.py; qui solo i passanti sul bordo del marciapiede
    rotv = math.atan2(nc[1], nc[0])
    for side in (-1, 1):
        for k in range(int(900 * dens)):
            a = rnd.uniform(18, 430); lt = side * rnd.uniform(12.1, 12.5)
            q = pc + nc * a + tc * lt; d = nc * rnd.choice((-1, 1)); v = rnd.uniform(0.6, 1.2)
            G.append((float(q[0]), float(q[1]), roma.quota(*q), _rot_verso(*d), rnd.choice((4, 4, 5, 6)), rnd.random(), rnd.uniform(0.9, 1.1), float(d[0] * v), float(d[1] * v)))
    nuvola('mercato_banchi', B, coll, ng_b)
    nuvola('mercato_gente', G, coll, ng_p)
    if CASE and 'citta_istanze' in bpy.data.node_groups:
        import folla
        folla.nuvola('viale_botteghe', CASE, coll, bpy.data.node_groups['citta_istanze'])
    roma.STATS['edifici_citta'] += len(CASE)
    print('MERCATO banchi', len(B), 'gente', len(G), 'botteghe', len(CASE))
    return len(B), len(G), len(CASE)
