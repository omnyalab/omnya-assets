import bpy, sys, os
a = sys.argv[sys.argv.index('--') + 1:]
D = a[0]; os.makedirs(D, exist_ok=True)
scn = bpy.context.scene
for e in ('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE'):
    try: scn.render.engine = e; break
    except Exception: pass
scn.eevee.taa_render_samples = 8
scn.render.resolution_x = 640; scn.render.resolution_y = 360
scn.render.image_settings.file_format = 'JPEG'
for item in a[1].split(','):
    cam, f = item.split(':')
    scn.camera = bpy.data.objects[cam]; scn.frame_set(int(f))
    scn.render.filepath = os.path.join(D, f'{cam}_{int(f):04d}.jpg'); bpy.ops.render.render(write_still=True)
