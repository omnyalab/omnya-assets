// Biglietti aereo del reel FLIGHT. Tre versioni da far scegliere a Nico: A pass orizzontale, B wallet verticale, C wallet con mappa dei posti.
// Tutte centrate sullo schermo, testi centrati sull'altezza delle maiuscole (niente scritte storte nelle pill).
const TKV = (window.TK || new URLSearchParams(location.search).get('tk') || 'A').toUpperCase();
const TK_C = { paper: '#fbfaf7', ink: '#121317', mute: '#8a8f99', line: '#d6d8dd', or: '#ff7a12', ok: '#1f9d57', few: '#e07a00', no: '#d23b3b',
  d0: '#141417', d1: '#2a241f', gold: '#d8b27a', cream: '#f3e7d6', dline: '#4a443d' };
const TOFF = document.createElement('canvas'); TOFF.width = 1600; TOFF.height = 1000; const tc = TOFF.getContext('2d');
const FL = { dep: FLIGHT.departs, arr: FLIGHT.arrives, dur: FLIGHT.duration, no: FLIGHT.number };

// ---------- testo centrato davvero ----------
function tFont(c, fam, px) { c.font = `${Math.round(px)}px ${fam}`; }
function tCap(c) { c.textBaseline = 'alphabetic'; return c.measureText('H').actualBoundingBoxAscent; }   // misura sempre sulla linea di base (con 'top' le scritte venivano alte)
// disegna t con il centro delle maiuscole su cy; align left|center|right; track = spaziatura in em (maiuscoletto)
function tText(c, t, x, cy, fam, px, col, align = 'left', track = 0, upper = false) {
  if (upper) t = t.toUpperCase();
  tFont(c, fam, px); const sp = track * px; c.letterSpacing = `${sp.toFixed(2)}px`;
  const w = c.measureText(t).width - (track ? sp : 0), h = tCap(c);
  const x0 = align === 'center' ? x - w / 2 : align === 'right' ? x - w : x;
  c.textAlign = 'left'; c.textBaseline = 'alphabetic'; c.fillStyle = col; c.fillText(t, x0, cy + h / 2);
  c.letterSpacing = '0px'; return w;
}
function tW(c, t, fam, px, track = 0, upper = false) { if (upper) t = t.toUpperCase(); tFont(c, fam, px); const sp = track * px; c.letterSpacing = `${sp.toFixed(2)}px`; const w = c.measureText(t).width - (track ? sp : 0); c.letterSpacing = '0px'; return w; }
function tPlane(c, x, y, s, col, rot = 0) {   // aeroplanino che punta a destra
  c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s); c.fillStyle = col; c.beginPath();
  c.roundRect(-0.9, -0.085, 1.85, 0.17, 0.085);
  c.moveTo(0.18, -0.07); c.lineTo(-0.22, -0.78); c.lineTo(-0.4, -0.78); c.lineTo(-0.2, -0.07);
  c.moveTo(0.18, 0.07); c.lineTo(-0.22, 0.78); c.lineTo(-0.4, 0.78); c.lineTo(-0.2, 0.07);
  c.moveTo(-0.66, -0.07); c.lineTo(-0.86, -0.36); c.lineTo(-0.97, -0.36); c.lineTo(-0.9, -0.07);
  c.moveTo(-0.66, 0.07); c.lineTo(-0.86, 0.36); c.lineTo(-0.97, 0.36); c.lineTo(-0.9, 0.07);
  c.fill(); c.restore();
}
function tDash(c, x0, y0, x1, y1, col, w = 2, d = [8, 7]) { c.save(); c.strokeStyle = col; c.lineWidth = w; c.setLineDash(d); c.beginPath(); c.moveTo(x0, y0); c.lineTo(x1, y1); c.stroke(); c.restore(); }
function tBars(c, x, y, w, h, col) { const n = 46, ws = []; for (let i = 1; i <= n; i++) ws.push(i % 3 === 0 ? 3 : i % 5 === 0 ? 1 : i % 7 === 0 ? 2.4 : 1.6); const tot = ws.reduce((a, b) => a + b, 0) + 1.4 * (n - 1), k = w / tot; let p = x; c.fillStyle = col; for (const b of ws) { c.fillRect(p, y, b * k, h); p += (b + 1.4) * k; } }
function tQR(c, x, y, s, col) {   // finto QR deterministico
  const N = 25, m = s / N; c.fillStyle = col;
  const fin = (i, j) => { c.fillRect(x + i * m, y + j * m, 7 * m, 7 * m); c.clearRect(x + (i + 1) * m, y + (j + 1) * m, 5 * m, 5 * m); c.fillRect(x + (i + 2) * m, y + (j + 2) * m, 3 * m, 3 * m); };
  for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) { const inF = (i < 8 && j < 8) || (i > 16 && j < 8) || (i < 8 && j > 16); if (inF) continue; const r = ((i * 73856093) ^ (j * 19349663) ^ 0x5bd1e995) >>> 0; if (r % 100 < 47) c.fillRect(x + i * m, y + j * m, m + 0.3, m + 0.3); }
  fin(0, 0); fin(18, 0); fin(0, 18);
}
function tPill(c, cx, cy, text, fam, px, bg, fg, padX, h, scale = 1) {   // pill col testo centrato; ritorna [w,h]
  const w = (tW(c, text, fam, px) + padX * 2) * scale, hh = h * scale;
  c.fillStyle = bg; c.beginPath(); c.roundRect(cx - w / 2, cy - hh / 2, w, hh, hh / 2); c.fill();
  tText(c, text, cx, cy, fam, px * scale, fg, 'center'); return [w, hh];
}
function tStatus(c, cx, cy, text, col, dark) {   // pallino + testo, centrati insieme
  const px = 19, w = tW(c, text, 'SFTB', px) + 22;
  c.fillStyle = dark ? 'rgba(255,255,255,0.07)' : col + '1f'; c.beginPath(); c.roundRect(cx - w / 2 - 16, cy - 19, w + 32, 38, 19); c.fill();
  c.fillStyle = col; c.beginPath(); c.arc(cx - w / 2 + 6, cy, 6, 0, 7); c.fill(); tText(c, text, cx - w / 2 + 22, cy, 'SFTB', px, col);
}
function tCut(c, pts, r) { c.save(); c.globalCompositeOperation = 'destination-out'; for (const [x, y] of pts) { c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); } c.restore(); }

// ---------- mini mappa dei posti (versione C) ----------
const TK_MAP = { E: { g: [3, 4, 3], rows: 6, me: [2, 0] }, P: { g: [2, 3, 2], rows: 5, me: [1, 0] }, F: { g: [1, 1, 1], rows: 2, me: [0, 0] }, R: { g: [1], rows: 1, me: [0, 0] } };
function tMap(c, x, y, w, h, cls, dark) {
  const M = TK_MAP[cls], cols = M.g.reduce((a, b) => a + b, 0), gaps = M.g.length - 1, aisle = cls === 'R' ? 0 : 0.9;
  const cw = w / (cols + gaps * aisle), ch = Math.min(h / M.rows, cw * (cls === 'F' ? 1.6 : 1.0)), sw = cw * 0.78, sh = ch * 0.74;
  const y0 = y + (h - ch * M.rows) / 2; let k = 0;
  for (let r = 0; r < M.rows; r++) { let xx = x;
    for (let gi = 0; gi < M.g.length; gi++) { for (let s = 0; s < M.g[gi]; s++) {
      const me = r === M.me[0] && k % cols === 0 && gi === 0 && s === 0, rnd = ((r * 31 + gi * 7 + s * 13 + cls.charCodeAt(0)) * 2654435761 >>> 0) % 100, taken = !me && rnd < (cls === 'E' ? 62 : cls === 'P' ? 70 : 60);
      c.fillStyle = me ? TK_C.or : taken ? (dark ? '#3a3631' : '#c3c6cc') : (dark ? '#5d564d' : '#ffffff');
      c.beginPath(); c.roundRect(xx + (cw - sw) / 2, y0 + r * ch + (ch - sh) / 2, sw, sh, Math.min(sw, sh) * 0.22); c.fill();
      if (!me && !taken) { c.strokeStyle = dark ? '#7a7166' : '#c9ccd3'; c.lineWidth = 1.5; c.stroke(); }
      xx += cw; k++; }
      xx += cw * aisle; }
    k = 0; }
}

// ---------- i tre biglietti ----------
// o = { theme:'light'|'dark', cls:'E'|'P'|'F'|'R', clsName, seat, seatLab, zone, gate, boards, price, status:[testo, colore], q1, btn }
// palette per classe: economy/premium arancio (come prima), first avorio-grafite-champagne, residence nero e oro metallico
function metal(c, x0, y0, x1, y1) { const g = c.createLinearGradient(x0, y0, x1, y1); g.addColorStop(0, '#f7e7bf'); g.addColorStop(0.45, '#d9b170'); g.addColorStop(0.7, '#b8894a'); g.addColorStop(1, '#ecd29b'); return g; }
const PAL = {
  light: { bg: () => TK_C.paper, head: () => TK_C.or, headTxt: '#ffffff', ink: TK_C.ink, mute: TK_C.mute, acc: () => TK_C.or, line: TK_C.line, bars: TK_C.ink, perf: '#cfd2d8', frame: null, stDark: false },
  first: { bg: c => { const g = c.createLinearGradient(0, 0, 1180, 470); g.addColorStop(0, '#fbf7f0'); g.addColorStop(1, '#efe5d5'); return g; },
    head: c => { const g = c.createLinearGradient(0, 0, 1180, 0); g.addColorStop(0, '#18181b'); g.addColorStop(1, '#2d2b29'); return g; },
    headTxt: '#e2cba0', ink: '#1d1a16', mute: '#9b8f7d', acc: () => '#a67c42', line: '#ddd1bd', bars: '#1d1a16', perf: '#cbbca3', frame: 'rgba(166,124,66,0.55)', stDark: false },
  gold: { bg: c => { const g = c.createLinearGradient(0, 0, 1180, 470); g.addColorStop(0, '#0b0b0d'); g.addColorStop(0.6, '#151311'); g.addColorStop(1, '#231c14'); return g; },
    head: c => metal(c, 0, 0, 1180, 86), headTxt: '#17120a', ink: '#f4e8d2', mute: '#a8957a', acc: (c, x0, y0, x1, y1) => metal(c, x0, y0, x1, y1), line: '#3f362a', bars: '#e3c88f', perf: '#6d5a3c', frame: 'rgba(217,177,112,0.75)', stDark: true },
};
function passA(o, press) {
  const pal = PAL[o.theme] || PAL.light, TW = 1180, TH = 470, SW = 330, HB = 86, MW = TW - SW, c = tc;
  const ink = pal.ink, mute = pal.mute, acc = (x0 = 0, y0 = 0, x1 = 0, y1 = 100) => pal.acc(c, x0, y0, x1, y1);
  c.clearRect(0, 0, TOFF.width, TOFF.height); c.save();
  c.beginPath(); c.roundRect(0, 0, TW, TH, 30); c.clip();
  c.fillStyle = pal.bg(c); c.fillRect(0, 0, TW, TH);
  c.fillStyle = pal.head(c); c.fillRect(0, 0, TW, HB);   // fascia in alto
  if (o.theme === 'gold') { c.fillStyle = 'rgba(255,255,255,0.18)'; c.fillRect(0, 0, TW, 2); }
  const hc = pal.headTxt;
  tPlane(c, 60, HB / 2, 17, hc); tText(c, 'Boarding pass', 92, HB / 2, 'SFTB', 21, hc, 'left', 0.16, true);
  tText(c, o.clsName, MW - 48, HB / 2, 'SFTB', 21, hc, 'right', 0.16, true);
  tText(c, FL.no, MW + SW / 2, HB / 2, 'SFTB', 19, hc, 'center', 0.16, true);
  // rotta
  const cy = HB + 88, L = 56;
  const big = o.theme === 'gold' ? acc(0, cy - 40, 0, cy + 40) : ink;
  const wA = tText(c, ROUTE.from, L, cy, 'SFD', 100, big), wB = tW(c, ROUTE.to, 'SFD', 100); tText(c, ROUTE.to, MW - L, cy, 'SFD', 100, big, 'right');
  const lx0 = L + wA + 36, lx1 = MW - L - wB - 36, mx = (lx0 + lx1) / 2, ac = acc(lx0, cy - 20, lx1, cy + 20);
  tDash(c, lx0, cy, mx - 34, cy, ac, 2.5, [7, 7]); tDash(c, mx + 34, cy, lx1, cy, ac, 2.5, [7, 7]);
  tPlane(c, mx, cy, 22, ac); tText(c, 'Non-stop · ' + FL.dur, mx, cy + 42, 'SFTS', 16, mute, 'center', 0.12, true);
  tText(c, ROUTE.fromN, L, HB + 168, 'SFTS', 23, mute); tText(c, ROUTE.toN, MW - L, HB + 168, 'SFTS', 23, mute, 'right');
  tText(c, FL.dep, L, HB + 206, 'SFD', 34, ink); tText(c, FL.arr, MW - L, HB + 206, 'SFD', 34, ink, 'right');
  tDash(c, L, HB + 248, MW - L, HB + 248, pal.line, 2, [6, 6]);
  const F = [['Passenger', 'You'], [o.seatLab || 'Seat', o.seat], ['Gate', o.gate], ['Boards', o.boards]], colW = (MW - 2 * L) / F.length;
  F.forEach(([k, v], i) => { const x = L + i * colW; tText(c, k, x, HB + 292, 'SFTS', 16, mute, 'left', 0.14, true); tText(c, v, x, HB + 336, 'SFD', 40, i === 1 ? acc(x, HB + 316, x, HB + 356) : ink); });
  // talloncino
  const sx = MW + SW / 2;
  tText(c, o.seatLab || 'Seat', sx, HB + 52, 'SFTS', 16, mute, 'center', 0.14, true);
  tText(c, o.seat, sx, HB + 122, 'SFD', o.seat.length > 4 ? 64 : 92, acc(sx, HB + 86, sx, HB + 158), 'center');
  const stc = o.status[1] === 'no' ? (o.theme === 'gold' ? '#e2c48a' : TK_C.no) : o.status[1] === 'few' ? (o.theme === 'first' ? '#a67c42' : TK_C.few) : TK_C.ok;
  tStatus(c, sx, HB + 196, o.status[0], stc, pal.stDark);
  tBars(c, sx - 120, HB + 236, 240, 62, pal.bars);
  const pw = tW(c, o.price, 'SFD', 38), uw = tW(c, ROUTE.cur, 'SFTS', 16, 0.14, true), gx = sx - (uw + 12 + pw) / 2;
  tText(c, ROUTE.cur, gx, HB + 340, 'SFTS', 16, mute, 'left', 0.14, true); tText(c, o.price, gx + uw + 12, HB + 340, 'SFD', 38, ink);
  c.restore();
  if (pal.frame) { c.save(); c.strokeStyle = pal.frame; c.lineWidth = 1.6; c.beginPath(); c.roundRect(9, 9, TW - 18, TH - 18, 22); c.stroke(); c.restore(); }
  tDash(c, MW, 16, MW, TH - 16, pal.perf, 2.5, [9, 8]); tCut(c, [[MW, 0], [MW, TH]], 17);
  return { w: TW, h: TH };
}
function passB(o, press, withMap) {
  const dark = o.theme === 'dark', CW = 600, CH = 760, c = tc, P = 46;
  const ink = dark ? TK_C.cream : TK_C.ink, mute = dark ? '#a59a8b' : TK_C.mute, acc = dark ? TK_C.gold : TK_C.or, lineC = dark ? TK_C.dline : TK_C.line;
  c.clearRect(0, 0, TOFF.width, TOFF.height); c.save();
  c.beginPath(); c.roundRect(0, 0, CW, CH, 38); c.clip();
  if (dark) { const g = c.createLinearGradient(0, 0, CW, CH); g.addColorStop(0, TK_C.d0); g.addColorStop(1, TK_C.d1); c.fillStyle = g; } else c.fillStyle = TK_C.paper;
  c.fillRect(0, 0, CW, CH);
  // testa
  tPlane(c, P + 14, 62, 16, acc); tText(c, 'Boarding pass', P + 42, 62, 'SFTB', 19, ink, 'left', 0.16, true);
  tText(c, o.clsName, CW - P, 62, 'SFTB', 19, acc, 'right', 0.16, true);
  // rotta
  const cy = 162; const wA = tText(c, ROUTE.from, P, cy, 'SFD', 92, ink), wB = tW(c, ROUTE.to, 'SFD', 92); tText(c, ROUTE.to, CW - P, cy, 'SFD', 92, ink, 'right');
  const mx = (P + wA + CW - P - wB) / 2; tDash(c, P + wA + 22, cy, mx - 26, cy, acc, 2.5, [6, 6]); tDash(c, mx + 26, cy, CW - P - wB - 22, cy, acc, 2.5, [6, 6]); tPlane(c, mx, cy, 18, acc);
  tText(c, ROUTE.fromN + ' · ' + FL.dep, P, 226, 'SFTS', 21, mute); tText(c, FL.arr + ' · ' + ROUTE.toN, CW - P, 226, 'SFTS', 21, mute, 'right');
  tDash(c, P, 270, CW - P, 270, lineC, 2, [6, 6]);
  // campi 2x2
  const F = [[o.seatLab || 'Seat', o.seat, true], ['Gate', o.gate], ['Boards', o.boards], ['Zone', o.zone]], cw2 = (CW - 2 * P) / 2;
  F.forEach(([k, v, big], i) => { const x = P + (i % 2) * cw2, y = 318 + Math.floor(i / 2) * 104; tText(c, k, x, y, 'SFTS', 16, mute, 'left', 0.14, true); tText(c, v, x, y + 46, 'SFD', big ? 48 : 38, big ? acc : ink); });
  tStatus(c, CW - P - 110, 318 + 104 + 46, o.status[0], o.status[1] === 'no' ? TK_C.no : o.status[1] === 'few' ? (dark ? TK_C.gold : TK_C.few) : TK_C.ok, dark);
  // perforazione
  const yp = 540; c.restore(); tDash(c, 26, yp, CW - 26, yp, lineC, 2.5, [9, 8]); tCut(c, [[0, yp], [CW, yp]], 18); c.save();
  if (withMap) {
    tText(c, 'Seat map', P, yp + 40, 'SFTS', 16, mute, 'left', 0.14, true); tText(c, 'Taken', CW - P - 150, yp + 40, 'SFTS', 16, mute, 'left', 0.14, true);
    c.fillStyle = dark ? '#3a3631' : '#c3c6cc'; c.beginPath(); c.roundRect(CW - P - 176, yp + 32, 16, 16, 4); c.fill();
    tText(c, 'You', CW - P - 40, yp + 40, 'SFTS', 16, mute, 'left', 0.14, true); c.fillStyle = TK_C.or; c.beginPath(); c.roundRect(CW - P - 66, yp + 32, 16, 16, 4); c.fill();
    tMap(c, P, yp + 66, CW - 2 * P - 150, CH - yp - 96, o.cls, dark);
    tText(c, ROUTE.cur, CW - P, CH - 104, 'SFTS', 16, mute, 'right', 0.14, true); tText(c, o.price, CW - P, CH - 62, 'SFD', 40, ink, 'right');
  } else {
    const qs = 150; tQR(c, P, yp + 46, qs, ink);
    tText(c, 'Scan at gate', P + qs + 34, yp + 76, 'SFTS', 16, mute, 'left', 0.14, true);
    tText(c, ROUTE.cur, P + qs + 34, yp + 130, 'SFTS', 16, mute, 'left', 0.14, true); tText(c, o.price, P + qs + 34, yp + 172, 'SFD', 46, ink);
  }
  c.restore(); return { w: CW, h: CH };
}
// mette il biglietto al centro dello schermo con il bottone sotto; t = secondi dall'entrata, out 0..1 uscita; ritorna il centro del bottone
function drawPass(ctx, o, t, out, press) {
  const sz = TKV === 'A' ? passA(o, press) : passB(o, press, TKV === 'C');
  const gap = 36, bh = 70, total = sz.h + gap + bh + 18, x = (1920 - sz.w) / 2, y0 = (1080 - total) / 2;
  const e = t <= 0 ? 0 : t >= 1 ? 1 : 1 - Math.exp(-6 * t) * Math.cos(7 * t), op = (x => x * x * (3 - 2 * x))(Math.max(0, Math.min(1, t / 0.45))) * (1 - out * out * (3 - 2 * out));
  const dy = (1 - e) * 70 + out * 40;
  ctx.save(); ctx.globalAlpha = op;
  ctx.shadowColor = 'rgba(0,0,0,0.45)'; ctx.shadowBlur = 50; ctx.shadowOffsetY = 18;
  ctx.drawImage(TOFF, 0, 0, sz.w, sz.h, x, y0 + dy, sz.w, sz.h); ctx.shadowColor = 'transparent';
  // barra centrata sullo schermo: [Book this seat] (principale) + domanda + [upgrade] (secondario a contorno); per la Residence un solo bottone
  const th = o.theme, qpx = 19, bpx = 27, pad = 34, inL = 9, inR = 9, gapQ = 22, barH = bh + 18;
  const prim = th === 'gold' ? null : th === 'first' ? '#f7f2ea' : TK_C.or, primTxt = th === 'first' ? '#1d1a16' : '#ffffff';   // First: bottone champagne, si legge sulla barra scura
  const wq = tW(ctx, o.q1, 'SFTB', qpx, 0.14, true), wb = tW(ctx, o.btn, 'SFTB', bpx) + pad * 2, wk = o.book ? tW(ctx, o.book, 'SFTB', bpx) + pad * 2 : 0;
  const L0 = o.book ? inL + wk + gapQ + 6 : 34, barW = L0 + wq + gapQ + wb + inR, bx0 = 960 - barW / 2, by = y0 + sz.h + gap + barH / 2 + dy * 1.15;
  ctx.fillStyle = 'rgba(12,12,14,0.66)'; ctx.beginPath(); ctx.roundRect(bx0, by - barH / 2, barW, barH, barH / 2); ctx.fill();
  if (th === 'gold') { ctx.strokeStyle = 'rgba(217,177,112,0.55)'; ctx.lineWidth = 1.4; ctx.stroke(); }
  tFont(ctx, 'SFTB', bpx); const base = by + tCap(ctx) / 2;   // linea di base comune a tutti i testi della barra
  const pill = (cx, w, sc, fill, stroke, txt, col) => {
    const pw = w * sc, ph = bh * sc; ctx.save();
    if (fill) { ctx.shadowColor = 'rgba(0,0,0,0.3)'; ctx.shadowBlur = 12; ctx.shadowOffsetY = 4; ctx.fillStyle = fill; ctx.beginPath(); ctx.roundRect(cx - pw / 2, by - ph / 2, pw, ph, ph / 2); ctx.fill(); ctx.shadowColor = 'transparent'; }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 2; ctx.beginPath(); ctx.roundRect(cx - pw / 2 + 1, by - ph / 2 + 1, pw - 2, ph - 2, ph / 2); ctx.stroke(); }
    tFont(ctx, 'SFTB', bpx * sc); ctx.textBaseline = 'alphabetic'; ctx.fillStyle = col; ctx.fillText(txt, cx - tW(ctx, txt, 'SFTB', bpx * sc) / 2, base + (sc - 1) * 0); ctx.restore();
  };
  let kcx = 0;
  if (o.book) { kcx = bx0 + inL + wk / 2; const hov = o.hoverBook ? 1.035 : 1; pill(kcx, wk, hov, o.hoverBook ? (th === 'first' ? '#ffffff' : '#ff8a2e') : prim, null, o.book, primTxt); }
  tFont(ctx, 'SFTB', qpx); ctx.letterSpacing = `${(0.14 * qpx).toFixed(2)}px`; ctx.fillStyle = th === 'gold' ? '#e2c48a' : 'rgba(255,255,255,0.85)'; ctx.fillText(o.q1.toUpperCase(), bx0 + L0, base); ctx.letterSpacing = '0px';
  const bcx = bx0 + L0 + wq + gapQ + wb / 2, s = press ? 0.94 : 1;
  if (o.book) {   // il bottone dell'upgrade ha i colori della classe dove vai
    const up = o.up || 'light';
    if (up === 'gold') pill(bcx, wb, s, metal(ctx, bcx - wb / 2, by - bh / 2, bcx + wb / 2, by + bh / 2), null, o.btn, '#17120a');
    else if (up === 'first') pill(bcx, wb, s, '#1f1e1c', 'rgba(226,203,160,0.9)', o.btn, '#e2cba0');
    else pill(bcx, wb, s, press ? 'rgba(255,122,18,0.25)' : null, TK_C.or, o.btn, '#ffffff');
  }
  else pill(bcx, wb, s, th === 'gold' ? metal(ctx, bcx - wb / 2, by - bh / 2, bcx + wb / 2, by + bh / 2) : prim, null, o.btn, th === 'gold' ? '#17120a' : primTxt);
  window.__btn = { up: [bcx - wb / 2, by - bh / 2, bcx + wb / 2, by + bh / 2], book: o.book ? [kcx - wk / 2, by - bh / 2, kcx + wk / 2, by + bh / 2] : null };
  ctx.restore(); return [bcx, by, kcx, by];
}
window.drawPass = drawPass; window.tText = tText; window.tW = tW; window.tPill = tPill; window.TKV = TKV;
