STADIUM BUILDER · a skill for Claude
====================================

What it does
Claude builds you a complete website with a 3D stadium or arena where people choose their seat:
the stadium from above with the stands and their prices, a zoom into a stand, its blocks,
one single seat with the view from it, the offer to upgrade to a VIP box, and the ticket.
It works on phones and you can put it online for free.

What you need
- A paid Claude plan that includes Skills (Pro or above) on claude.ai or in the Claude app,
  or Claude Code on your computer.
- On claude.ai, "Code execution and file creation" switched on in Settings > Capabilities
  (Skills run on it).
- A browser. Internet the first time the page opens (it loads the 3D library, three.js, from a public CDN).


INSTALL ON CLAUDE.AI OR THE CLAUDE APP
1. Keep the file stadium-builder.zip as it is. Do not unzip it.
2. Open Settings > Capabilities and check that "Code execution and file creation" is on.
3. In the Skills section click "Upload skill" and choose stadium-builder.zip.
4. Make sure the switch next to Stadium Builder is on.
   (On Team and Enterprise plans an owner may need to allow skills first.)

INSTALL IN CLAUDE CODE
1. Unzip stadium-builder.zip. You get a folder called stadium-builder.
2. Move that folder into the skills folder of your user:
     macOS / Linux:  ~/.claude/skills/stadium-builder
     Windows:        %USERPROFILE%\.claude\skills\stadium-builder
   (or into .claude/skills/ inside one project, to use it only there).
3. Start a new Claude Code session. Type /skills to check it is listed.


YOUR FIRST MESSAGE
Copy this and change the parts in brackets:

  Build me a stadium where people choose their seat, for [club or venue name] in [city].
  It is for [football / basketball / tennis / padel / concerts], about [number] seats,
  colours [seat colour] and [second colour], prices in [currency] from [lowest] to [highest],
  VIP upgrade [price]. Page in [language].

Short works too, for example:
  "Build me a stadium for a padel club in Milan, green and white"
Claude asks what it needs, or picks sensible defaults and tells you which ones.


WHAT YOU GET
A folder with three files: index.html, stadium.js and ui.css. No installation, no build step.
To change prices, names, colours or capacity later, ask Claude, or edit the CONFIG part at the
top of stadium.js yourself (every field is explained in the skill, references/config.md).

To open it on your computer
- Claude Code: Claude starts a small local server and gives you the address.
- Otherwise: double click index.html (works in Chrome, needs internet for the 3D library).
  If a browser stays on the loading screen, open a terminal in the folder and run
      python3 -m http.server 8080
  then open http://localhost:8080 in your browser.


PUT IT ONLINE FOR FREE
Netlify Drop
  1. Go to app.netlify.com/drop
  2. Drag the folder with index.html inside onto the page.
  3. You get a link right away. Make a free account to keep it online and choose its name.
Vercel
  1. Make a free Hobby account at vercel.com
  2. Add New > Project, then drag the folder in (or import it from GitHub).
  3. Framework "Other", no build command. Deploy.
  (No folder upload in your dashboard? Put the folder on GitHub and import it, or ask Claude
  to run the Vercel command line for you.)
Both give you an https link that works on phones. To update, drag the new folder again.


GOOD TO KNOW
- Prices, free seats and sold-out blocks are sample data made from your settings, the same
  every time. The ticket says so in a small line; ask Claude to remove it if your data is real.
- There is no payment inside the page. If you have a payment link (from your payment provider),
  give it to Claude: the Confirm button will open it with the chosen seat.
- Big stadiums (around 100,000 seats) are heavy 3D. Phones automatically get a lighter version
  (simpler seats, fewer trees, smaller shadows). Try it on your own phone before you share it.
- Only use names and logos you own or have permission to use.
