#!/usr/bin/env python3
"""filter.py PHOTO [PHOTO ...] [--out FOLDER]  — the kit filter + 4K export, on your computer (0 credits, never a paid upscale).
Every photo of a project goes through the same filter, so the whole tour looks shot by one photographer on one evening:
soft S curve 0.12, blacks -1.5%, vibrance +30% on the less saturated pixels, saturation +8%, a touch of warmth (+2% red, -2% blue),
vignette 8%, unsharp mask radius 2 at 35%. First the photo is cropped to 16:9 (centre) and resized to 3840x2160 with Lanczos, then filtered.
Output: <name>-4k.jpg next to the photo, or <name>.jpg in --out (when it is another folder). The original is never touched.
Usage: python3 tools/filter.py photos/nano/1.png --out photos     → photos/1.jpg, 3840x2160 (the photo the page and Kling use)
       python3 tools/filter.py some/photo.png                    → some/photo-4k.jpg
Needs: pip install pillow numpy
"""
import sys, os
import numpy as np
from PIL import Image, ImageFilter

W, H = 3840, 2160

def to4k(im):
    im = im.convert('RGB'); w, h = im.size
    if abs(w / h - W / H) > 0.002:   # crop the centre to 16:9
        if w / h > W / H: nw = round(h * W / H); im = im.crop(((w - nw) // 2, 0, (w - nw) // 2 + nw, h))
        else: nh = round(w * H / W); im = im.crop((0, (h - nh) // 2, w, (h - nh) // 2 + nh))
    return im.resize((W, H), Image.LANCZOS)

def kit_filter(im):
    a = np.asarray(im).astype(np.float32) / 255.0
    a = a + 0.12 * (a - 0.5) * (1 - np.abs(2 * a - 1))                 # soft S curve
    a = np.clip((a - 0.015) / (1 - 0.015), 0, 1)                         # blacks
    mx, mn = a.max(2, keepdims=True), a.min(2, keepdims=True)
    sat = (mx - mn) / (mx + 1e-6); g = a.mean(2, keepdims=True)
    a = g + (a - g) * (1 + 0.30 * (1 - sat))                             # vibrance
    g = a.mean(2, keepdims=True); a = g + (a - g) * 1.08                 # saturation +8%
    a[..., 0] *= 1.02; a[..., 2] *= 0.98                                 # a touch of warmth
    h, w = a.shape[:2]; y, x = np.ogrid[:h, :w]
    r = np.sqrt(((x - w / 2) / (w / 2)) ** 2 + ((y - h / 2) / (h / 2)) ** 2) / np.sqrt(2)
    a = a * (1 - 0.08 * np.clip(r, 0, 1) ** 2)[..., None]                # vignette
    out = Image.fromarray((np.clip(a, 0, 1) * 255 + 0.5).astype(np.uint8))
    return out.filter(ImageFilter.UnsharpMask(radius=2, percent=35, threshold=2))

if __name__ == '__main__':
    args = sys.argv[1:]; out_dir = None
    if '--out' in args: i = args.index('--out'); out_dir = args[i + 1]; del args[i:i + 2]
    if not args: print(__doc__); sys.exit(1)
    for p in args:
        name = os.path.splitext(os.path.basename(p))[0]
        same = not out_dir or os.path.abspath(out_dir) == os.path.abspath(os.path.dirname(p) or '.')
        dst = os.path.join(os.path.dirname(p) or '.', name + '-4k.jpg') if same else os.path.join(out_dir, name + '.jpg')
        if out_dir: os.makedirs(out_dir, exist_ok=True)
        im = kit_filter(to4k(Image.open(p))); im.save(dst, quality=95)
        print(dst, f'{im.size[0]}x{im.size[1]}')
