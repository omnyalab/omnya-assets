# Changing the film

- **Another gate:** the camera enters at `CAM_BAY = 34` in `costruisci.py` (bay 34 is arch LII); change the bay to enter through another arch. Rebuild, re-run `verifica.py` and `smooth.py`.
- **Light and time of day:** the sun is `SUN_DIR` (from west-southwest) and `SUN_ELEV = 11` degrees in `ambiente.py`; the warm look of the photos comes from the prompts ("bright afternoon sun") and from the grade.
- **A lighter scene for tests:** `leggero` builds fewer buildings and people; use it for the camera, the full scene only for the final frames.
- **Another monument with the same method:** keep `regia.py` (one straight move per stretch) and the post tools; write the new monument's measures with their sources first (like `measures.md`), and anything no source gives as ESTIMATE.
- **The prompts:** keep the first sentence (it keeps the camera, the size and the place of everything) and change only what is in the picture.
- **The reels:** `tools/reel_916.py` makes the clean 9:16 versions; the hook (two lines) and the pills go on top in the editing app.
