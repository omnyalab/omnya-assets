# The data: OpenStreetMap through Overpass

`assets/fetch_city.py` downloads one square of a real city and writes `city-data.js`. It is free and needs no key: Nominatim finds a name when no `--center` is given, the public Overpass API returns the map data. Use it gently: one run per city, not loops.

## Command

```
python3 fetch_city.py "<name>" --center <lat>,<lon> --size <metres> --out <folder>
python3 fetch_city.py --bbox <south>,<west>,<north>,<east> --name "<name>" --out <folder>
```

| Option | Meaning |
|---|---|
| `--center` | The middle of the square. Best: your own choice of the iconic centre and waterfront. Without it the name is geocoded, which lands on the administrative centre, often not the best view. |
| `--size` | Side of the square in metres. Default 3000, min 600, capped at 6000. |
| `--bbox` | Exact box instead of centre + size. |
| `--name` | The name written into the data (defaults to the first argument). |
| `--save-raw` | Also keep the raw Overpass answer as `osm-raw.json` (for debugging). |
| `--raw file` | Rebuild `city-data.js` from a saved raw answer without downloading again. |

Good starting areas (centre, size):

| City | Centre | Size |
|---|---|---|
| Miami (Brickell, Downtown, the bay, South Beach) | 25.7700, -80.1650 | 5500 |
| Lisbon (Baixa, Chiado, Alfama, the river) | 38.7105, -9.1390 | 3200 |
| Monaco | 43.7395, 7.4255 | 2800 |
| Dubai Marina + Palm root | 25.0800, 55.1400 | 4500 |
| Manhattan Midtown | 40.7560, -73.9850 | 3500 |

## What is downloaded

One query, three outputs:

1. With full geometry (`out geom`):
   - `building=*` ways and multipolygon relations (outer rings; courtyards are filled).
   - `highway` motorway ... service and the `_link` roads, pedestrian and living streets. Tunnels and areas are left out.
   - Water: `natural=water`, `waterway=riverbank|dock`, `landuse=reservoir|basin`, `leisure=marina`, and `natural=coastline` lines.
   - Green: `leisure=park|garden|golf_course|nature_reserve|recreation_ground|pitch`, `landuse=grass|forest|meadow|village_green|recreation_ground|cemetery`, `natural=wood|scrub|grassland|heath`.
   - Beaches: `natural=beach|sand`.
2. Named places with their centre (`out center`): attractions, viewpoints, museums, squares, castles, monuments, palaces, forts, parks, marinas, lighthouses, towers. Ranked (squares, viewpoints, palaces, items with a Wikidata link first) and printed as suggestions for the "Go to" buttons.
3. Single trees (`natural=tree` nodes), up to 40,000.

## Heights

In this order:
1. `height` (or `building:height`) in metres; feet are converted.
2. `building:levels` x 3.2 m + 1 m (+ 2.2 m per `roof:levels`).
3. Small types by type: garage, shed, kiosk, carport 3-5 m; houses 4.5-9 m.
4. Everything else: the median of tagged buildings within about 240 m; if there are not enough, the type (church 22 m, cathedral 32 m, warehouse 9 m...) or the median of the whole area. Estimated heights are capped at 48 m (no invented skyscrapers), tiny footprints at 6-12 m, and get a small random variation so blocks do not look flat.

The script prints how many heights were estimated. In most European old towns 60-80% are estimated and look right; for skylines check that the famous towers are tagged (they almost always are).

## Coastline

OpenStreetMap draws the sea with `natural=coastline` lines that have the water on their right. The script joins the pieces and stretches every loose end that stops inside the area straight out past the border. The page then splits the area along those lines and lets every segment vote "right side water, left side land". This handles harbours, piers and rivers like the Tagus. Lakes and rivers drawn as polygons are filled directly.

## Size of the output

`city-data.js` is about 1 MB per 10,000 buildings (Lisbon 3.2 km: 12,300 buildings, 1.2 MB; Monaco 2.8 km: 5,000 buildings, 0.6 MB). The download itself is 5-30 MB and takes 20-90 s.

## Servers

The script tries, in order: overpass-api.de, overpass.private.coffee, overpass.kumi.systems, maps.mail.ru, twice. It uses `curl` when available (macOS, Linux and Windows 10+ have it) because the Python that ships with macOS cannot open some modern HTTPS servers. If all fail: wait a minute and run again, or use a smaller `--size`. A 504 or timeout means the server is busy, not that the city is wrong.

## Licence

OpenStreetMap data is © OpenStreetMap contributors, under the Open Database License. The page shows the credit line; keep it whenever the page is public. The data file says it in its first line too.
