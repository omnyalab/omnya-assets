# The config object

Everything about a venue lives in `window.STADIUM_CONFIG` at the top of `stadium.js`. Change these fields and nothing else for a normal build. The engine below the config line reads them once, when the page loads.

## The venue

| Field | Type | What it does |
|---|---|---|
| `name` | text | The venue or club name. Shown in the header, on the big screens and on the ticket. |
| `shortName` | text | A short, uppercase version for the LED boards around the field and the centre of a basketball court. Keep it under about 18 characters. |
| `event` | `{ title, date, time }` | The line at the top of the ticket and under the name on the screens. Use the user's real event, or leave a neutral one like `Opening night`. Any field can be an empty string. |
| `lang` | text | The page language code, e.g. `en`, `it`, `pt`. Goes into `<html lang>`. |
| `locale` | text | How prices and numbers are written, e.g. `it-IT` gives `95 €`, `en-US` gives `$95`, `pt-PT` gives `95 €`. |
| `currency` | ISO code | `EUR`, `USD`, `GBP`, `AED`, `CHF`, `BRL`... Prices are shown with no decimals. |

## The shape

| Field | Type | What it does |
|---|---|---|
| `field` | `football` / `basketball` / `tennis` / `padel` / `plain` | Picks the playing surface, the goals or hoops or nets, the LED boards and the size of the inner bowl. `plain` is a neutral floor for concerts, events or anything else. |
| `size` | `null` or `{ length, width, corner }` | Optional override of the inner bowl in metres (the line where the front wall stands, minus a few metres). Leave `null` to use the preset of the field. Use it for an unusual venue, e.g. a long velodrome-like oval `{ length: 150, width: 90, corner: 40 }`. The field drawing stays the preset size. |
| `tiers` | list | The rings of seats from the bottom up. Each one is `{ name, rows, priceFactor }` and can also take `depth` (metres per row, default 0.8 for the first tier and 0.85 above) and `rake: [first, last]` (step height in metres at the first and last row). 1 to 4 tiers work well, 2 to 80 rows each. |
| `tiers[].priceFactor` | number | Multiplies the price of the zone. Zone 95 with factor 1.2 gives 114 in that tier. |
| `seatWidth` | metres | Space for one seat along the row. 0.5 is a normal stadium seat, 0.55 a comfortable one. |
| `aisleEvery` | metres | Distance between aisles. Every gap between two aisles in one tier is a block with its own number. Smaller means more, narrower blocks. |

### Hitting a capacity

The seat count comes from the shape: the perimeter of every row divided by `seatWidth`, minus the aisles and the tunnel openings. After a change, open the page and run `stadium.info()` in the browser console (or read the `stadium ready` line it prints). Then adjust `rows` until `seats` is close to what the user asked for. Rough guide with the presets:

| `field` | `tiers` rows | Seats |
|---|---|---|
| `football` | 34 + 22 + 36 | 108,761 |
| `football` | 20 + 14 + 18 | 50,694 |
| `basketball` | 18 + 12 + 16 | 21,796 |
| `basketball` | 16 + 12 + 14 | 19,091 |
| `tennis` | 16 + 12 + 14 | 20,261 |
| `padel` | 10 + 8 | 5,143 |
| `padel` | 12 + 10 | 6,731 |

These are measured with this engine, but always check `stadium.info()` after your change rather than trusting the table.

## The look

| Field | Type | What it does |
|---|---|---|
| `colors.seat` | hex | Main seat colour. The engine adds light shade variations by itself. |
| `colors.seat2` | hex or `''` | Second seat colour, scattered. Empty string = one colour only. |
| `colors.seat2Share` | 0 to 1 | How many seats use `seat2`. 0.05 is a light sprinkle, 0.5 is half and half. |
| `colors.pattern` | `mixed` / `scatter` / `solid` | `mixed` puts more `seat2` in the first rows of the lower tier and in bands of the upper tier, like many real stadiums. `scatter` spreads it evenly. `solid` ignores `seat2`. |
| `colors.brand` | hex | Fascia bands in front of the tiers, LED lines, the facade glass, the screens, the basketball key and apron. |
| `colors.facade` | hex | The diagonal fins on the outside. |
| `colors.accent` | hex | What lights up when you choose a stand, a block or a seat, and the buttons. It must stand out from both seat colours and from grey. Text on the buttons turns black or white by itself. |
| `colors.taken` | hex | Taken seats inside a block. Keep it a neutral grey that reads against the seat colour. |
| `roof` | `ring` / `closed` / `none` | `ring` is a white membrane open over the field. `closed` adds a ceiling with rows of lights (arenas). The roof is hidden in the plan, zone and block views so people can see the seats, and shown from the seat and the VIP box. |
| `scoreboard` | `ends` / `center` / `none` | Two big screens over the ends, or a hanging cube over the middle (arenas), or nothing. |
| `surroundings` | `park` / `city` / `desert` | What is around the stadium: trees, ring road and parking; a street grid with buildings; or sand dunes and palms. |
| `look` | `day` / `sunset` / `night` | Sun and sky. Night switches on floodlights, lit windows and street lamps. Try `?look=night` in the address bar before changing the config. |

## What people buy

| Field | Type | What it does |
|---|---|---|
| `zones` | list | The stands. Each one is `{ name, price }` and can take `soldOut: true`. They go clockwise from the north long side. With 8 zones they are the 4 sides and the 4 corners, with 4 zones the 4 sides (each corner is split between its two sides), with any other number the bowl is cut into equal arcs starting from the middle of the north side. |
| `zones[].price` | number | Base price of that stand. Tier factors multiply it. |
| `occupancy` | 0 to 1 | Share of seats shown as taken. This is sample data, the same every time the page loads. |
| `soldOutBlocks` | 0 to 1 | Share of blocks shown fully sold out. |
| `vip.name` | text | Name of the boxes, followed by the box number. |
| `vip.upgrade` | number | Price added to the seat for the upgrade. |
| `vip.perks` | list of text | Up to 3 or 4 short lines shown on the upgrade card. |
| `boards` | list of text | Extra words that run on the LED boards after `shortName`, e.g. sponsors. |
| `checkoutUrl` | URL or `''` | When set, the Confirm button becomes "Continue to payment" and opens this link with `stand`, `block`, `row`, `seat`, `vip` and `price` added to the query. A payment link from any provider works. Empty = the ticket just shows a "Reserved" stamp. |
| `quality` | `auto` / `high` / `low` | `auto` uses lighter seats, fewer trees and smaller shadows on phones. `low` forces that everywhere. You can also add `?q=low` to the address. |

## Words

`text` holds every word on the page: step titles, hints, buttons, the ticket labels, the loading line and the small note under the ticket. Translate all of them when the user wants another language. Keep them short: they sit on a phone screen. Set `text.note` to `''` when the prices and availability are real.

## Address bar options (for testing and for clean frames)

| Option | What it does |
|---|---|
| `?step=plan` / `zone` / `block` / `pick` / `seat` / `upgrade` / `ticket` / `vip` | Opens straight on that step with a sensible stand, block and seat. `pick` is the block with a seat chosen, `vip` is the VIP ticket. |
| `&zone=3` | With `step`, which stand to use (0 = the first in `zones`). |
| `?shot=1` | No transitions, for screenshots. |
| `?clean=1` | Hides the whole interface, only the 3D. |
| `?look=night` | Try another light without editing the config. |
| `?q=low` | Force the light version. |
| key `P` | Saves a PNG of the 3D frame without the interface. |
| key `Esc` | One step back. |
