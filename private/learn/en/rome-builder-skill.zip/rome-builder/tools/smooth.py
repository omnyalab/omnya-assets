#!/usr/bin/env python3
"""smooth.py CLIP [CLIP ...]  — il giudice delle entrate e uscite (Nico 23/11: «entrate smooth e uscite smooth sempre,
mai cambi di vista destra-sinistra mentre si entra, niente video storti»).

Come lavora (lo stesso metodo della stabilizzazione video): segue ~300 punti da un fotogramma all'altro
(Lucas-Kanade), stima per ogni passo il movimento della camera (spostamento, zoom, rotazione) con RANSAC,
poi guarda la traiettoria:
  - DESTRA-SINISTRA: la camera gira/scivola da una parte e poi torna dall'altra (cambio di verso deciso);
  - STORTO: l'immagine ruota (rollio) o si inclina;
  - STRAPPI: accelerazioni improvvise (il movimento cambia di colpo invece di partire e fermarsi piano).
Voto 0-10 per clip; sotto 8 la clip non si manda a Nico.
Uso: python3 smooth.py clip.mp4 ...   (aggiungi --json per l'uscita macchina)
"""
import json, subprocess, sys
import numpy as np
import cv2

W = 480  # larghezza di analisi


def frames(path):
    cap = cv2.VideoCapture(path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 24
    out = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        h = int(f.shape[0] * W / f.shape[1])
        out.append(cv2.cvtColor(cv2.resize(f, (W, h), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY))
    cap.release()
    return out, fps


def motion(fr, banda=None):
    """per ogni passo: tx, ty (in % di larghezza), zoom (log scala), rot (gradi), inlier; + colonna 5: 1 se un'omografia spiega il passo senza parallasse.
    banda='orizzontale'/'verticale' (23/11): la rotazione si misura solo sulla fascia centrale (vedi judge)."""
    m = []
    for a, b in zip(fr[:-1], fr[1:]):
        p0 = cv2.goodFeaturesToTrack(a, 400, 0.01, 8)
        if p0 is None or len(p0) < 12:
            m.append((0, 0, 0, 0, 0, 0)); continue
        p1, st, _ = cv2.calcOpticalFlowPyrLK(a, b, p0, None, winSize=(21, 21), maxLevel=3)
        g = st.ravel() == 1
        if g.sum() < 12:
            m.append((0, 0, 0, 0, 0, 0)); continue
        M, inl = cv2.estimateAffinePartial2D(p0[g], p1[g], method=cv2.RANSAC, ransacReprojThreshold=2.0)
        if M is None:
            m.append((0, 0, 0, 0, 0, 0)); continue
        s = float(np.hypot(M[0, 0], M[1, 0])); r = float(np.degrees(np.arctan2(M[1, 0], M[0, 0])))
        Hh, hm = cv2.findHomography(p0[g], p1[g], cv2.RANSAC, 1.0); senza_parallasse = 0.0
        if Hh is not None:
            pr = cv2.perspectiveTransform(p0[g].reshape(-1, 1, 2).astype(np.float32), Hh).reshape(-1, 2); err = np.linalg.norm(pr - p1[g].reshape(-1, 2), axis=1)
            senza_parallasse = 1.0 if (np.median(err) < 0.35 and float(hm.mean()) > 0.9) else 0.0
        if banda:
            h0, w0 = a.shape; q = p0[g].reshape(-1, 2)
            c = (np.abs(q[:, 1] - h0 / 2) < h0 * 0.15) if banda == 'orizzontale' else (np.abs(q[:, 0] - w0 / 2) < w0 * 0.15)
            if c.sum() >= 10:
                Mb, _ = cv2.estimateAffinePartial2D(p0[g][c], p1[g][c], method=cv2.RANSAC, ransacReprojThreshold=2.0)
                if Mb is not None: r = float(np.degrees(np.arctan2(Mb[1, 0], Mb[0, 0])))
        # spostamento riferito al centro dell'immagine (lo zoom attorno al centro non deve sembrare una traslazione)
        cx, cy = a.shape[1] / 2, a.shape[0] / 2
        tx = M[0, 0] * cx + M[0, 1] * cy + M[0, 2] - cx
        ty = M[1, 0] * cx + M[1, 1] * cy + M[1, 2] - cy
        m.append((100 * tx / W, 100 * ty / W, float(np.log(max(s, 1e-6))) * 100, r, float(inl.mean()) if inl is not None else 0, senza_parallasse))
    return np.array(m, dtype=np.float64)


def smooth1(x, k=5):
    if len(x) < k:
        return x
    return np.convolve(np.pad(x, k // 2, mode='edge'), np.ones(k) / k, mode='valid')


def flips(v, thr):
    """cambi di verso decisi: prima almeno 4 passi oltre +thr, poi almeno 4 oltre -thr (o il contrario)."""
    seg = np.where(v > thr, 1, np.where(v < -thr, -1, 0))
    runs, cur, n = [], 0, 0
    for i, s in enumerate(seg):
        if s == cur:
            n += 1
        else:
            if cur != 0 and n >= 4:
                runs.append((cur, i - n, i))
            cur, n = s, 1
    if cur != 0 and n >= 4:
        runs.append((cur, len(seg) - n, len(seg)))
    out = []
    for (s1, a1, b1), (s2, a2, b2) in zip(runs, runs[1:]):
        if s1 != s2:
            out.append(a2)
    return out


def judge(path):
    fr, fps = frames(path)
    if len(fr) < 8:
        return {'clip': path, 'errore': 'troppo corta'}
    m = motion(fr)
    tx, ty, zm, rot = (smooth1(m[:, i]) for i in range(4))
    # 23/11 (villa sul lago): GIRATA o INCLINAZIONE DA FERMA (Nico: «le svolte si fanno a camera ferma»). Una camera che ruota senza spostarsi
    # non ha parallasse: un'omografia spiega ogni passo. Se succede quasi sempre e il movimento è quasi tutto orizzontale (girata) o verticale
    # (inclinazione), la prospettiva di un obiettivo largo farebbe sembrare rollio e scivolata quello che non lo è: solo in questo caso la rotazione
    # si rimisura sulla fascia centrale (dove quell'effetto è zero e il rollio vero resta) e la scivolata di lato non si applica (non è un'entrata).
    # Entrate, uscite, scivolate vere (che hanno parallasse) si giudicano come prima: controllato che le 31 clip di taratura danno gli stessi voti.
    rotazione_pura = float(np.mean(m[:, 5])) > 0.8
    mtx, mty = float(np.median(np.abs(m[:, 0]))), float(np.median(np.abs(m[:, 1])))
    girata = rotazione_pura and mtx > 2 * max(mty, 0.02); inclinata = rotazione_pura and not girata and mty > 2 * max(mtx, 0.02)
    if girata or inclinata:
        m = motion(fr, 'orizzontale' if girata else 'verticale'); rot = smooth1(m[:, 3])
    dur = len(fr) / fps
    # 1) destra-sinistra: soglia 0,15 % della larghezza a fotogramma (a 24 fps = 3,6 %/s)
    fl = flips(tx, 0.15)
    # 2) storto: rotazione accumulata e rollio a scatti
    roll_tot = float(np.abs(np.cumsum(m[:, 3])).max())
    roll_vel = float(np.percentile(np.abs(rot), 95))
    # 3) strappi: accelerazione del movimento contro il movimento medio
    vel = np.stack([tx, ty, zm], 1)
    acc = np.linalg.norm(np.diff(vel, axis=0), axis=1)
    base = max(float(np.median(np.linalg.norm(vel, axis=1))), 0.05)
    jerk = float(np.percentile(acc, 98) / base)
    jerk_at = int(np.argmax(acc)) + 1
    # entrata: quanto la camera scivola di lato mentre avanza
    zoom_mean = float(np.mean(np.abs(zm)))
    lat = float(np.mean(np.abs(tx)))
    side_ratio = lat / max(zoom_mean, 0.05) if zoom_mean > 0.15 else None
    pen = 0.0
    note = []
    if fl:
        pen += 2.5 * len(fl); note.append('DESTRA-SINISTRA a ' + ', '.join(f'{i / fps:.1f}s' for i in fl))
    if roll_tot > 1.5:
        pen += min(3, (roll_tot - 1.5) * 0.8); note.append(f'STORTO: ruota di {roll_tot:.1f}°')
    if roll_vel > 0.25:
        pen += min(2, (roll_vel - 0.25) * 6); note.append(f'rollio a scatti {roll_vel:.2f}°/fotogramma')
    if jerk > 0.9:
        pen += min(3, (jerk - 0.9) * 2); note.append(f'STRAPPO a {jerk_at / fps:.1f}s (x{jerk:.1f})')
    if girata or inclinata:
        side_ratio = None
    if side_ratio is not None and side_ratio > 0.6:
        pen += min(2, (side_ratio - 0.6) * 2); note.append(f'entra scivolando di lato (lato/avanti {side_ratio:.2f})')
    voto = max(0.0, round(10 - pen, 1))
    return {'clip': path, 'secondi': round(dur, 1), 'voto': voto, 'esito': 'OK' if voto >= 8 else 'DA RIFARE',
            'note': (note or ['liscia e dritta']) + (['girata da ferma'] if girata else ['inclinazione da ferma'] if inclinata else []), 'misure': {'cambi_verso': len(fl), 'rotazione_tot': round(roll_tot, 2),
            'rollio_p95': round(roll_vel, 3), 'strappo': round(jerk, 2), 'lato_avanti': None if side_ratio is None else round(side_ratio, 2)}}


if __name__ == '__main__':
    args = [a for a in sys.argv[1:] if a != '--json']
    res = [judge(a) for a in args]
    if '--json' in sys.argv:
        print(json.dumps(res, ensure_ascii=False, indent=1))
    else:
        for r in res:
            if 'errore' in r:
                print(r['clip'], r['errore']); continue
            print(f"{r['voto']:4.1f}  {r['esito']:9}  {r['clip'].split('/')[-1]:28} {r['secondi']:5.1f}s  " + ' · '.join(r['note']))
