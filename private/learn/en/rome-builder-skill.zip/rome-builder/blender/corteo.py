# Corteo del trionfo sul viale (colonne con aquile d'oro, bighe nella polvere, petali che cadono)
# e gladiatori che combattono nell'arena. Persone solo come sagome: niente visi.
import bpy, math, random
import numpy as np
from mathutils import Vector, Euler
import geo
from geo import Builder, M, frame, bay_s
import folla
from regia import fcurves_of

COL_LAT = 7.6        # colonne del corteo (Nico 25/11: niente cavalli in mezzo alla gente, corsie larghe e libere)


def _obj(name, b, MAT, coll):
    objs = []
    for mat, (V, F) in b.parts.items():
        me = bpy.data.meshes.new(f'{name}_{mat}'); me.from_pydata(V, [], F)
        o = bpy.data.objects.new(f'{name}_{mat}', me); coll.objects.link(o)
        o.data.materials.append(MAT[mat]); objs.append(o)
    return objs


def _box(b, mat, c, hx, hy, z0, z1, u):
    """scatola allineata alla direzione u (2D) sul piano"""
    v = np.array([-u[1], u[0]])
    V = []
    for zz in (z0, z1):
        for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            p = c + u * sx * hx + v * sy * hy; V.append((float(p[0]), float(p[1]), zz))
    b.raw(mat, V, [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)])


def _cil(b, mat, x, y, z0, z1, r, n=14, r1=None):
    r1 = r if r1 is None else r1
    V = [(x + rr * math.cos(2 * math.pi * i / n), y + rr * math.sin(2 * math.pi * i / n), zz) for zz, rr in ((z0, r), (z1, r1)) for i in range(n)]
    F = [(i, (i + 1) % n, n + (i + 1) % n, n + i) for i in range(n)] + [tuple(range(n - 1, -1, -1)), tuple(range(n, 2 * n))]
    b.raw(mat, V, F)


def _aquila(b, x, y, z, u):
    """aquila d'oro ad ali aperte sopra la colonna (u = direzione in cui guarda)"""
    u = np.array(u); v = np.array([-u[1], u[0]])
    c = np.array([x, y])
    _box(b, 'oro', c, 0.22, 0.28, z, z + 0.25, u)                 # zoccolo
    _box(b, 'oro', c + u * 0.05, 0.16, 0.2, z + 0.25, z + 0.95, u)  # corpo
    _box(b, 'oro', c + u * 0.22, 0.09, 0.1, z + 0.9, z + 1.18, u)   # testa
    for sg in (-1, 1):
        a0 = Vector((x, y, z + 0.75)); vv = Vector((v[0], v[1], 0)) * sg
        a1 = a0 + vv * 1.15 + Vector((0, 0, 0.75)); a2 = a0 + vv * 1.25 + Vector((0, 0, 0.2)); a3 = a0 + vv * 0.7 + Vector((0, 0, -0.15))
        nn = Vector((u[0], u[1], 0)) * 0.03
        P = [a0, a1, a2, a3]
        V = [tuple(p - nn) for p in P] + [tuple(p + nn) for p in P]
        b.raw('oro', V, [(0, 1, 2, 3), (7, 6, 5, 4), (0, 4, 5, 1), (1, 5, 6, 2), (2, 6, 7, 3), (3, 7, 4, 0)])


def colonne(scn, MAT, coll, pc, nc, tc):
    b = Builder()
    n = 0
    for side in (-1, 1):
        for k in range(10):
            o = 26 + k * 15
            c = pc + nc * o + tc * side * COL_LAT
            x, y = float(c[0]), float(c[1])
            _box(b, 'marmo', c, 0.95, 0.95, 0.0, 1.8, tc)
            _box(b, 'marmo', c, 1.05, 1.05, 1.8, 2.05, tc)
            _cil(b, 'marmo', x, y, 2.05, 11.2, 0.48, 18, 0.42)
            _cil(b, 'oro', x, y, 11.2, 11.75, 0.42, 18, 0.62)
            _box(b, 'marmo', c, 0.7, 0.7, 11.75, 12.0, tc)
            _aquila(b, x, y, 12.0, -nc)
            # festone verde tra le colonne dello stesso lato
            if k < 9:
                c2 = pc + nc * (o + 15) + tc * side * COL_LAT
                pts = []
                for i in range(13):
                    t = i / 12; p = c + (c2 - c) * t
                    pts.append(Vector((float(p[0]), float(p[1]), 9.6 - 2.2 * math.sin(math.pi * t))))
                for i in range(12):
                    a, bb = pts[i], pts[i + 1]
                    w = Vector((0, 0, 0.18))
                    b.raw('foglie', [tuple(a - w), tuple(bb - w), tuple(bb + w), tuple(a + w)], [(0, 1, 2, 3)])
            n += 1
    _obj('colonne_corteo', b, MAT, coll)
    return n


def _cavallo():
    """cavallo da skin modifier, origine a terra tra gli zoccoli, guarda +y"""
    P = [('dorso', (0, -0.6, 1.42), 0.27), ('petto', (0, 0.55, 1.45), 0.29), ('garrese', (0, 0.72, 1.7), 0.19), ('collo', (0, 0.95, 1.98), 0.12), ('testa', (0, 1.12, 2.2), 0.1),
         ('fronte', (0, 1.32, 2.05), 0.085), ('muso', (0, 1.5, 1.86), 0.065), ('orecchio', (0, 1.08, 2.36), 0.035), ('coda', (0, -1.0, 1.35), 0.06), ('codaf', (0, -1.12, 0.8), 0.045)]
    for nm, (x, y, z) in (('ant', (0.17, 0.6, 0)), ('pos', (0.17, -0.55, 0))):
        for sg, s in ((1, 'D'), (-1, 'S')):
            P += [(f'gin{nm}{s}', (sg * x, y + (0.1 if nm == 'ant' else -0.15), 0.62), 0.06), (f'zoc{nm}{s}', (sg * x, y + (0.02 if nm == 'ant' else 0.05), 0.05), 0.055)]
    names = [p[0] for p in P]
    E = [('dorso', 'petto'), ('petto', 'garrese'), ('garrese', 'collo'), ('collo', 'testa'), ('testa', 'fronte'), ('fronte', 'muso'), ('testa', 'orecchio'), ('dorso', 'coda'), ('coda', 'codaf')]
    for nm in ('ant', 'pos'):
        for s in ('D', 'S'):
            E += [('petto' if nm == 'ant' else 'dorso', f'gin{nm}{s}'), (f'gin{nm}{s}', f'zoc{nm}{s}')]
    me = bpy.data.meshes.new('cavallo_sk'); me.from_pydata([p[1] for p in P], [(names.index(a), names.index(b)) for a, b in E], [])
    ob = bpy.data.objects.new('cavallo_sk', me); bpy.context.scene.collection.objects.link(ob)
    ob.modifiers.new('skin', 'SKIN')
    if len(me.skin_vertices) == 0:
        me.skin_vertices.new()
    for i, p in enumerate(P):
        me.skin_vertices[0].data[i].radius = (p[2], p[2])
    me.skin_vertices[0].data[0].use_root = True
    ss = ob.modifiers.new('sub', 'SUBSURF'); ss.levels = 2; ss.render_levels = 2
    dg = bpy.context.evaluated_depsgraph_get()
    m2 = bpy.data.meshes.new_from_object(ob.evaluated_get(dg))
    bpy.data.objects.remove(ob, do_unlink=True)
    for p in m2.polygons:
        p.use_smooth = True
    return m2


def bighe(scn, MAT, coll, pc, nc, tc, fps, f0, f1, corse=None):
    """4 bighe nelle corsie laterali che vanno verso il Colosseo fra il fotogramma f0 e f1, si fermano prima del lastricato"""
    mcav = _cavallo()
    auriga = folla.figura('auriga', 'in_piedi', True)
    ma = auriga.data
    for c in auriga.users_collection:
        c.objects.unlink(auriga)
    out = []
    corse = corse or [(-2.9, 70, 26, f0, f1), (2.9, 82, 34, f0, f1)]
    for i, (lat, o0, o1, g0, g1) in enumerate(corse):
        root = bpy.data.objects.new(f'biga{i}', None); coll.objects.link(root)
        dvx, dvy = (nc if o1 > o0 else -nc)
        yaw = math.atan2(dvy, dvx) - math.pi / 2
        for sg in (-0.42, 0.42):
            h = bpy.data.objects.new(f'biga{i}_cav', mcav); coll.objects.link(h); h.parent = root
            h.location = (sg, 1.6, 0)
            if not h.data.materials:
                h.data.materials.append(MAT['cavallo'])
            if i % 2 == 0:
                h.data = h.data.copy(); h.data.materials.clear(); h.data.materials.append(MAT['cavallo_bianco'])
        bb = Builder()
        bx = lambda mat, cx, cy, z0, z1, hx, hy: bb.raw(mat, [(cx + sx * hx, cy + sy * hy, zz) for zz in (z0, z1) for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))],
                                                      [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)])
        bx('legno', 0, -0.3, 0.55, 0.65, 0.6, 0.45)                 # pianale
        bx('oro', 0, 0.12, 0.65, 1.45, 0.62, 0.05)                  # parapetto davanti, dorato
        bx('oro', -0.6, -0.3, 0.65, 1.1, 0.03, 0.45); bx('oro', 0.6, -0.3, 0.65, 1.1, 0.03, 0.45)
        bx('legno', 0, 1.0, 0.85, 0.92, 0.04, 1.3)                  # timone
        bx('legno', 0, 2.2, 1.55, 1.65, 0.75, 0.06)                 # giogo sul collo dei cavalli
        bx('oro', -0.42, 2.0, 1.25, 1.75, 0.2, 0.04); bx('oro', 0.42, 2.0, 1.25, 1.75, 0.2, 0.04)   # pettorali
        for sxr in (-0.5, 0.5):                                     # redini
            bb.raw('corda', [(sxr * 0.2, -0.2, 1.35), (sxr * 0.2, -0.2, 1.39), (sxr * 0.84, 2.95, 2.0), (sxr * 0.84, 2.95, 1.96)], [(0, 1, 2, 3)])
        for sx in (-0.72, 0.72):                                    # ruote
            V = []; F = []
            for k in range(16):
                a = 2 * math.pi * k / 16
                for dx in (-0.04, 0.04):
                    V.append((sx + dx, -0.35 + 0.55 * math.cos(a), 0.55 + 0.55 * math.sin(a)))
            for k in range(16):
                kk = (k + 1) % 16
                F.append((2 * k, 2 * kk, 2 * kk + 1, 2 * k + 1))
            bb.raw('legno', V, F)
        for o in _obj(f'biga{i}_carro', bb, MAT, coll):
            o.parent = root
        a = bpy.data.objects.new(f'biga{i}_auriga', ma); coll.objects.link(a); a.parent = root
        a.location = (0, -0.35, 0.65)
        if len(a.data.materials) == 0:
            a.data.materials.append(MAT['stoffa']); a.data.materials.append(MAT['pelle']); a.data.materials.append(MAT['capelli'])
        root.rotation_euler = (0, 0, yaw)
        for f, o in ((g0, o0), (g1, o1)):
            p = pc + nc * o + tc * lat
            root.location = (float(p[0]), float(p[1]), 0.0); root.keyframe_insert('location', frame=f)
        # leggero sobbalzo
        for fc in fcurves_of(root):
            if fc.data_path == 'location' and fc.array_index == 2:
                m = fc.modifiers.new('NOISE'); m.scale = 6; m.strength = 0.06
        out.append(root)
    return out


def polvere_viale(scn, pc, nc, tc):
    m = bpy.data.materials.new('polvere_viale'); m.use_nodes = True
    nt = m.node_tree; N = nt.nodes; L = nt.links
    for n in list(N):
        N.remove(n)
    out = N.new('ShaderNodeOutputMaterial'); vol = N.new('ShaderNodeVolumePrincipled')
    g = N.new('ShaderNodeNewGeometry'); sep = N.new('ShaderNodeSeparateXYZ'); L.new(g.outputs['Position'], sep.inputs[0])
    m1 = N.new('ShaderNodeMath'); m1.operation = 'MULTIPLY'; m1.inputs[1].default_value = -1 / 2.2; L.new(sep.outputs[2], m1.inputs[0])
    ex = N.new('ShaderNodeMath'); ex.operation = 'EXPONENT'; L.new(m1.outputs[0], ex.inputs[0])
    no = N.new('ShaderNodeTexNoise'); no.inputs['Scale'].default_value = 0.12; no.inputs['Detail'].default_value = 4
    L.new(g.outputs['Position'], no.inputs['Vector'])
    mr = N.new('ShaderNodeMapRange'); mr.inputs['From Min'].default_value = 0.35; mr.inputs['From Max'].default_value = 0.75
    L.new(no.outputs['Fac'], mr.inputs['Value'])
    mu = N.new('ShaderNodeMath'); mu.operation = 'MULTIPLY'; L.new(ex.outputs[0], mu.inputs[0]); L.new(mr.outputs['Result'], mu.inputs[1])
    tco = N.new('ShaderNodeTexCoord'); so = N.new('ShaderNodeSeparateXYZ'); L.new(tco.outputs['Object'], so.inputs[0])
    fade = None
    for comp, a0, a1 in ((0, 0.30, 0.5), (1, 0.18, 0.5)):
        ab = N.new('ShaderNodeMath'); ab.operation = 'ABSOLUTE'; L.new(so.outputs[comp], ab.inputs[0])
        mr2 = N.new('ShaderNodeMapRange'); mr2.interpolation_type = 'SMOOTHSTEP'
        mr2.inputs['From Min'].default_value = a0; mr2.inputs['From Max'].default_value = a1; mr2.inputs['To Min'].default_value = 1.0; mr2.inputs['To Max'].default_value = 0.0
        L.new(ab.outputs[0], mr2.inputs['Value'])
        if fade is None:
            fade = mr2.outputs['Result']
        else:
            mf = N.new('ShaderNodeMath'); mf.operation = 'MULTIPLY'; L.new(fade, mf.inputs[0]); L.new(mr2.outputs['Result'], mf.inputs[1]); fade = mf.outputs[0]
    mu2 = N.new('ShaderNodeMath'); mu2.operation = 'MULTIPLY'; mu2.inputs[1].default_value = 0.08; L.new(mu.outputs[0], mu2.inputs[0])
    mu3 = N.new('ShaderNodeMath'); mu3.operation = 'MULTIPLY'; L.new(mu2.outputs[0], mu3.inputs[0]); L.new(fade, mu3.inputs[1])
    L.new(mu3.outputs[0], vol.inputs['Density'])
    vol.inputs['Color'].default_value = (1.0, 0.86, 0.66, 1); vol.inputs['Anisotropy'].default_value = 0.6
    L.new(vol.outputs[0], out.inputs['Volume'])
    me = bpy.data.meshes.new('polvere_viale')
    c = pc + nc * 160
    yaw = math.atan2(nc[1], nc[0])
    bpy.ops.mesh.primitive_cube_add(size=1)
    o = bpy.context.active_object; o.name = 'polvere_viale'
    o.scale = (330, 36, 7); o.location = (float(c[0]), float(c[1]), 3.4); o.rotation_euler = (0, 0, yaw)
    o.data.materials.append(m); o.visible_shadow = False


def polvere_arena(scn):
    """polvere sospesa nell'arena: il sole che entra dal velario disegna i raggi"""
    m = bpy.data.materials.new('polvere_arena'); m.use_nodes = True
    nt = m.node_tree; N = nt.nodes; L = nt.links
    for n in list(N):
        N.remove(n)
    out = N.new('ShaderNodeOutputMaterial'); vol = N.new('ShaderNodeVolumePrincipled')
    no = N.new('ShaderNodeTexNoise'); no.inputs['Scale'].default_value = 0.05
    g = N.new('ShaderNodeNewGeometry'); L.new(g.outputs['Position'], no.inputs['Vector'])
    vol.inputs['Density'].default_value = 0.0045   # omogenea: costa poco e disegna i raggi
    vol.inputs['Color'].default_value = (1.0, 0.86, 0.66, 1); vol.inputs['Anisotropy'].default_value = 0.7
    L.new(vol.outputs[0], out.inputs['Volume'])
    bpy.ops.mesh.primitive_cube_add(size=1)
    o = bpy.context.active_object; o.name = 'polvere_arena'; o.scale = (150, 120, 44); o.location = (0, 0, 22)
    o.data.materials.append(m); o.visible_shadow = False


def petali(scn, MAT, coll, pc, nc, tc, nf):
    """due nuvole di petali che cadono (si spostano in giù durante il giro), lontano dalla corsia della camera"""
    rnd = random.Random(5)
    for layer in range(2):
        b = Builder()
        for i in range(2600):
            o = rnd.uniform(6, 150); lat = rnd.uniform(-15, 15); z = rnd.uniform(4, 40)
            if abs(lat) < 2.6:
                continue
            q = pc + nc * o + tc * lat
            c = Vector((float(q[0]), float(q[1]), z))
            e = Euler((rnd.uniform(0, 6.3), rnd.uniform(0, 6.3), rnd.uniform(0, 6.3))).to_matrix()
            sz = rnd.uniform(0.018, 0.03)
            pts = [c + e @ Vector(v) * sz for v in ((-1, -0.6, 0), (1, -0.6, 0.15), (1, 0.6, 0), (-1, 0.6, 0.15))]
            b.raw('petalo', [tuple(p) for p in pts], [(0, 1, 2, 3)])
        for ob in _obj(f'petali{layer}', b, MAT, coll):
            ob.location = (0, 0, 0); ob.keyframe_insert('location', frame=1)
            ob.location = (0.6 * (layer - 0.5), 0.4, -(nf / 24.0) * (1.1 + 0.4 * layer)); ob.keyframe_insert('location', frame=nf)
            for fc in fcurves_of(ob):
                for kp in fc.keyframe_points:
                    kp.interpolation = 'LINEAR'


def gladiatori(scn, MAT, coll, centro_vista, fronte=None, duello=None):
    """6 coppie di gladiatori nell'arena: scudo, elmo, gladio; si muovono con un rumore lento (affondi e passi)"""
    rnd = random.Random(80)
    figs = [folla.figura('glad_a', 'in_piedi', True), folla.figura('glad_b', 'in_piedi', False, gesto='avanti'), folla.figura('glad_c', 'in_piedi', False, gesto='due')]
    for fg in figs:
        for c in fg.users_collection:
            c.objects.unlink(fg)
    me = figs[0].data
    out = []
    coppie = [(-14, 4), (6, -6), (20, 8), (-4, 14), (-26, -8), (30, -2), (-8, -12), (12, 16), (-20, 16), (0, 2), (16, -14), (-30, 8)]
    coppie = [(dx, dy) for dx, dy in coppie if ((centro_vista[0] + dx) / 40.0) ** 2 + ((centro_vista[1] + dy) / 24.0) ** 2 < 0.8]
    for i, (dx, dy) in enumerate(coppie):
        cx, cy = centro_vista[0] + dx, centro_vista[1] + dy
        ang = rnd.uniform(0, math.pi)
        duo = duello is not None and fronte is not None and i == 0
        if duello is not None and not duo and math.hypot(cx - duello[0], cy - duello[1]) < 6.0:
            continue
        if duo:   # 25/11 Nico: la coppia dove arriva la camera combatte di fronte, vista di lato
            cx, cy = duello
            ang = math.atan2(fronte[1], fronte[0])
        for sg in (-1, 1):
            root = bpy.data.objects.new(f'glad{i}{sg}', None); coll.objects.link(root)
            sep = 0.6 if duo else 1.1
            x = cx + sg * sep * math.cos(ang); y = cy + sg * sep * math.sin(ang)
            root.location = (x, y, 0.03)
            root.rotation_euler = (0, 0, ang + (-math.pi / 2 if sg < 0 else math.pi / 2))   # 25/11: uno di fronte all'altro (prima si davano le spalle)
            o = bpy.data.objects.new(f'glad{i}{sg}_corpo', (figs[1] if duo else figs[(i + (sg > 0)) % 3]).data); coll.objects.link(o); o.parent = root
            o.scale = (1.05, 1.05, 1.05)
            o.data = o.data.copy(); o.data.materials.clear()
            o.data.materials.append(MAT['scudo'] if sg < 0 else MAT['tunica_bianca']); o.data.materials.append(MAT['pelle_g']); o.data.materials.append(MAT['bronzo'])
            b = Builder()
            # scudo (scutum) sul braccio sinistro, elmo, gladio nella destra alzata
            sc = [(-0.42, 0.16, 0.62), (-0.42, 0.16, 1.5), (-0.14, 0.24, 1.5), (-0.14, 0.24, 0.62)]
            V = sc + [(x0, y0 - 0.05, z0) for x0, y0, z0 in sc]
            b.raw('scudo', V, [(0, 1, 2, 3), (7, 6, 5, 4), (0, 4, 5, 1), (1, 5, 6, 2), (2, 6, 7, 3), (3, 7, 4, 0)])
            _cil(b, 'bronzo', 0, 0.01, 1.52, 1.78, 0.13, 12, 0.11)
            _cil(b, 'stendardo', 0, 0.0, 1.78, 1.9, 0.03, 6, 0.03)
            V = [(0.33, 0.1, 1.95), (0.35, 0.12, 1.95), (0.35, 0.14, 2.6), (0.33, 0.12, 2.6)]
            b.raw('bronzo', V, [(0, 1, 2, 3)])
            for ob in _obj(f'glad{i}{sg}_armi', b, MAT, coll):
                ob.parent = root
            # movimento: rumore lento su posizione e rotazione (affondi, passi di lato)
            root.keyframe_insert('location', frame=1); root.keyframe_insert('rotation_euler', frame=1)
            for path, idx, st, scl in ((('location', 0, 0.08, 6), ('location', 1, 0.08, 6), ('rotation_euler', 2, 0.06, 5)) if duo else (('location', 0, 0.35, 18), ('location', 1, 0.35, 22), ('rotation_euler', 2, 0.25, 15))):
                for fc in fcurves_of(root):
                    if fc.data_path == path and fc.array_index == idx:
                        m = fc.modifiers.new('NOISE'); m.scale = scl; m.strength = st * 2; m.phase = rnd.uniform(0, 100)
            out.append(root)
    # inservienti in tunica bianca lungo il bordo e due caduti a terra
    for k in range(14):
        a = rnd.uniform(0, 2 * math.pi); r = rnd.uniform(0.75, 0.9)
        o = bpy.data.objects.new(f'inserviente{k}', figs[1].data); coll.objects.link(o)
        o.location = (41 * r * math.cos(a), 25 * r * math.sin(a), 0.03); o.rotation_euler = (0, 0, a + math.pi / 2)
    for k, (dx, dy) in enumerate(((-10, 10), (14, 2))):
        o = bpy.data.objects.new(f'caduto{k}', figs[0].data); coll.objects.link(o)
        o.location = (centro_vista[0] + dx, centro_vista[1] + dy, 0.18); o.rotation_euler = (math.pi / 2, 0, rnd.uniform(0, 6.28))
    return out


def bighe_film(scn, MAT, coll, pc, nc, tc, nf, corse, v=4.5, fps=24):
    """bighe che vanno verso il Colosseo al passo nella loro corsia; (lat, o_sorpasso, t_sorpasso, o_ferma):
    a t_sorpasso sono a o_sorpasso (la camera le supera lì), poi frenano dolci e si fermano a o_ferma"""
    roots = bighe(scn, MAT, coll, pc, nc, tc, fps, 1, 2, corse=[(lat, 100, 99, 1, 2) for lat, _, _, _ in corse])
    for root, (lat, o_s, t_s, o_f) in zip(roots, corse):
        yaw = math.atan2(-nc[1], -nc[0]) - math.pi / 2
        root.rotation_euler = (0, 0, yaw)
        if root.animation_data:
            root.animation_data_clear()
        o0 = o_s + v * t_s                           # posizione al fotogramma 1
        d_fr = 6.0                                   # metri di frenata
        t_b = (o0 - (o_f + d_fr)) / v                # inizio frenata
        for f in range(1, nf + 1, 3):
            t = (f - 1) / fps
            if t <= t_b:
                o = o0 - v * t
            else:
                tau = 2 * d_fr / v                   # frenata a decelerazione costante
                u = min(1.0, (t - t_b) / tau)
                o = (o_f + d_fr) - d_fr * (2 * u - u * u)
            p = pc + nc * o + tc * lat
            root.location = (float(p[0]), float(p[1]), 0.0); root.keyframe_insert('location', frame=f)
        for fc in fcurves_of(root):
            for kp in fc.keyframe_points:
                kp.interpolation = 'LINEAR'
            if fc.data_path == 'location' and fc.array_index == 2:
                m = fc.modifiers.new('NOISE'); m.scale = 6; m.strength = 0.05
    return roots
