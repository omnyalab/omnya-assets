# Choose your villa · Dubai Hills

The interactive villa page from the Omnya Lab reel. Built with Claude Code.

Open it: Mac `Start.command` (first time: right click > Open), `Start auto tour.command` for the automatic tour, `Stop.command` to stop.
Windows `Start.bat` (needs Python 3). Or `python3 server.py 5316` and open http://localhost:5316 (`?auto` = automatic tour).
It must run from a server. Best in Chrome or Edge. R starts again.

Change it: `config.js` (words, villa, prices, currency, booking link, colours), `dati.json` (streets, villa numbers, free or sold).
Villa numbers, availability and prices are EXAMPLES. The page takes no payments: "Book a private viewing" opens your link.

Map data © OpenStreetMap contributors (ODbL, openstreetmap.org/copyright). Fonts: Inter, SIL Open Font License (assets/fonts/OFL.txt).
