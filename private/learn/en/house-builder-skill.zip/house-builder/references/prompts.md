# The prompts

These are the prompts of our own Hold to build house (an American colonial in a forest clearing). Keep the structure, change only the parts about the house: its style, materials, the place and the light. Make the pictures yourself on Higgsfield (or any tool with the same models), then give them to Claude in order.

The order is always: one photo of the finished house, the same house in 3D with a camera that turns around it, one photo per phase made from the 3D screenshots with the camera locked, then (frames mode only) one clip between every two phases.

If you only want stills mode, you can skip the 3D: make the finished house first, then ask for every phase "keeping exactly the camera, the framing and the lens of Image 1", with the finished photo as Image 1. The 3D gives steadier lines, so the fades look cleaner.

## 1 · The finished house · Nano Banana Pro · 16:9

```
Architectural photograph taken from a slightly raised position, about three metres above the ground, with a 28mm lens: a three-quarter view of a finished two-storey American colonial house standing in a wide clearing deep in a tall American forest, with very tall oaks, maples and white pines surrounding the clearing on every side and rising well above the roofline behind the house. Timber-framed house with white horizontal lap siding, a steep dark charcoal shingle roof with gables and dormers, a tall red brick chimney on the left gable, white-trimmed windows with dark shutters, a white covered front porch, a garage wing on the right. Large open front lawn in the foreground, freshly finished: lush green grass with mowing stripes, a curved gravel driveway, boxwood hedges, hydrangeas and young dogwoods along the house. Soft early morning sunlight coming low through the trees from the right, light mist between the trunks, clear pale sky. Hyperrealistic photograph, natural colors, real texture of siding, shingles, brick and grass. No people, no cars, no text.
```

## 2 · The same house in 3D · Claude Code

Give Claude the photo above and this:

```
Copy the house in this photo in three.js, in real metres: a two-storey American colonial with white horizontal lap siding, a steep dark shingle roof with the central gable and two dormers, the brick chimney on the left, the white porch with columns, the garage wing on the right, in a clearing of tall oaks and pines.

Make the siding out of real boards, about 18 cm each, and give every material a texture measured in metres, so nothing looks stretched when the camera gets close.

Put the camera where the photo was taken from, about three metres up with a 28mm lens, then make it go all the way around the house from left to right, one stop every 22.5 degrees, and save a 16:9 screenshot at every stop.

Put a ring of tall trees all around the clearing, beyond the path of the camera, and a deeper forest behind them, so every screenshot has trees behind the house and never an empty horizon.
```

## 3 · One photo per phase · Nano Banana Pro · 16:9

Image 1 = the 3D screenshot of that stop (the first phase uses the first stop, the second the next one, and so on, so the camera turns while the house rises). Change only the stage line.

```
Image 1 is a 3D screenshot. CAMERA LOCK: keep exactly the camera, the framing, the lens and every line of the building from Image 1, do not move anything.

Turn it into a real photograph of the same house at this stage: [the stage line from the table below]

Same clearing in a tall American forest, bare dirt with tyre tracks all around, soft early morning sun coming low through the trees from the right, light mist between the trunks. Hyperrealistic, natural colours. No people, no machines, no text.
```

| # | Phase | Stage line |
|---|---|---|
| 01 | Staked on | the cleared lot only, wooden stakes and string marking the footprint, and the outline of the house drawn in thin glowing lines of light where it will stand. |
| 02 | Foundation | the poured concrete foundation and slab, cured and clean, nothing built above it yet. |
| 03 | The walls go up | the floor deck down and the first-floor stud walls standing in fresh yellow pine, the second floor just started. |
| 04 | Fully framed | the full timber frame up on the foundation, second floor, rafters, roof trusses and dormers in fresh yellow pine, no sheathing yet. |
| 05 | Closed in | every wall and the whole roof covered in OSB structural panels, window and door openings cut, no wrap yet. |
| 06 | Dried in | white house wrap on every wall, the windows set, the roof shingled in dark charcoal. |
| 07 | Brick by brick | the red brick chimney going up on the left gable and a pallet of bricks on the dirt, the rest of the house dried in. |
| 08 | Exterior complete | white lap siding, trim and dark shutters finished, porch columns in, the lot still bare dirt. |
| 09 | Final touches | the finished house with a green lawn, a curved gravel drive, boxwood hedges, hydrangeas and young dogwoods, the dirt gone. |

Phase 00 is the blueprint: a photo of the drawings of the same house on a desk, or a top view of the plan. It is the first picture of the page.

Check every photo next to the one before: same house, same proportions, same light. Make it again if a window, the chimney or the roof line moved.

## 4 · One clip between every two phases · Kling (frames mode only) · 1080p · 5 s

Image 1 = the phase you start from, image 2 = the next phase.

```
Image 1 is the start frame and image 2 is the end frame. The camera keeps orbiting slowly to the right around the house at the same height and the same distance, one smooth continuous move with no cuts, while the build goes from [phase A] to [phase B]. The trees behind the house slide from left to right. Same morning light and mist from start to end. No people, no machines, no text.
```

Nine clips for ten phases. Check that the last frame of each clip is the photo of the next phase; if the clip drifts, make it again before cutting the frames.

## 5 · Optional · the walk inside · Kling video edit

After the last phase you can add one more clip that walks from the lawn through the front door into the living room. Give it the 3D video of that walk and:

```
Follow the camera of the video exactly: from the lawn to the front door, through the door and into the house, one continuous move. The start frame is the first frame, the end frame is the wide photo of the living room. Keep the house, the light and every material of the two photos. No people, no text.
```

Add it as the last clip in `tools/make_frames.py frames ...` and one more entry in `phases` (e.g. "Step inside").
