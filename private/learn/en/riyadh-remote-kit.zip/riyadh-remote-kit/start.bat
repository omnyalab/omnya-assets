@echo off
REM Double-click to start the Remote Kit on Windows.
REM It starts the server and opens the big screen in your browser. Keep this window open while you use it.
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 server.py %*
  goto end
)
where python >nul 2>nul
if %errorlevel%==0 (
  python server.py %*
  goto end
)
echo.
echo   Python 3 is not installed. Install it from https://www.python.org/downloads/
echo   and tick "Add python.exe to PATH" during the install, then double-click start.bat again.
echo.
:end
pause
