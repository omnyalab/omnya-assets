#!/usr/bin/env python3
"""silhouette.py MASK_3D [--photo-mask P] [--photo P] [--color 3D.jpg] [--board OUT.png] [--above ROWS]
How well the 3D tower matches the main photo, from the same camera: IoU of the two silhouettes, 0-1 (1 = identical). Aim for >= 0.90.
  MASK_3D      a 1920x1080 still of the engine with ?maschera=1&clean=1 (tower and podium grey, everything else black):
               node tools/photo.mjs mask-3d.png "http://127.0.0.1:5320/?s=samar&maschera=1&clean=1"
  --photo-mask the silhouette of the tower on the main photo, white on black, 1920x1080 (SAMAR: references/samar/mask-tower.png;
               for your tower ask Claude to trace it on your main photo)
  --photo      the main photo (default references/samar/main-photo.jpg), for the board
  --color      the same 3D view in colour (?clean=1), laid at 50% on the photo in the board
  --board      writes a 1920x1080 board: left photo + 3D at 50%, right the map of mistakes (red = only in the photo, blue = only in the 3D, white = both)
  --above      only the rows above this one count (default 800 for SAMAR: the tower above the podium; use 1080 for the whole frame)
Needs: pip install pillow numpy"""
import sys, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
args = sys.argv[1:]
def opt(n, d):
    if n in args: i = args.index(n); v = args[i + 1]; del args[i:i + 2]; return v
    return d
pm = opt('--photo-mask', os.path.join(KIT, 'references/samar/mask-tower.png'))
ph = opt('--photo', os.path.join(KIT, 'references/samar/main-photo.jpg'))
col = opt('--color', None); board = opt('--board', None); Y = int(opt('--above', 800))
if not args: print(__doc__); sys.exit(1)
A = np.asarray(Image.open(pm).convert('L').resize((1920, 1080))) > 127
m3 = np.asarray(Image.open(args[0]).convert('L').resize((1920, 1080))).astype(float) > 40
iou = (A[:Y] & m3[:Y]).sum() / max(1, (A[:Y] | m3[:Y]).sum())
print(f'Silhouette match (IoU): {iou:.3f}  ' + ('OK (>= 0.90)' if iou >= 0.9 else 'fix one thing at a time and run it again'))
if board:
    r = np.asarray(Image.open(ph).convert('RGB').resize((1920, 1080)))
    sov = (r * 0.5 + np.asarray(Image.open(col).convert('RGB').resize((1920, 1080))) * 0.5).astype(np.uint8) if col else r
    vis = (r * 0.3).astype(np.uint8); AA, MM = A.copy(), m3.copy(); AA[Y:] = MM[Y:] = False
    vis[AA & ~MM] = (235, 70, 60); vis[MM & ~AA] = (70, 140, 255); vis[AA & MM] = (236, 236, 236)
    T = Image.new('RGB', (1920, 1080), (14, 14, 16)); T.paste(Image.fromarray(sov).resize((944, 531)), (16, 200)); T.paste(Image.fromarray(vis).resize((944, 531)), (960, 200))
    d = ImageDraw.Draw(T)
    def font(s):
        for f in [os.path.join(KIT, 'assets/fonts/InterDisplay-SemiBold.ttf'), '/Library/Fonts/SF-Pro-Display-Semibold.otf']:
            try: return ImageFont.truetype(f, s)
            except Exception: pass
        return ImageFont.load_default()
    d.text((16, 120), 'Main photo + 3D at 50%', font=font(34), fill=(255, 255, 255)); d.text((960, 120), f'Silhouette match {iou:.3f}', font=font(34), fill=(255, 255, 255))
    d.text((960, 750), 'red = only in the photo · blue = only in the 3D · white = both', font=font(24), fill=(200, 200, 200))
    T.save(board); print('board', board)
