# How the tour works

The whole page is one 1920x1080 canvas (`<canvas id="c">`), scaled to the window and drawn at the real screen resolution (up to 1.6x).
Under the UI there is either a still photo or a frame of `film.mp4`. The film is loaded whole into memory (a blob) so it can jump to
any frame; if the browser refuses, it plays the file directly and `server.py` answers byte ranges so jumps still work.

## Tour seconds (the clock everything uses)

The tour runs from second 0 to 48. `film.mp4` holds seconds 7 to 48 (`dati.json` film.da = 7), 24 fps, 985 frames.

| Step (fase) | What you see | Background | Leaves when |
|---|---|---|---|
| `pin` | from above (second 7), streets light up under the mouse, "Choose your street" card, click a street = the pin drops, click again or "Fly down to the street" | photo `F07.jpg` | click on the chosen street (only the street with `attiva: true` flies down; the others say "Street view coming soon") |
| `scendi` | the camera lands in the street (7 to 9.6 s, plays by itself), then you scroll 9.6 to 13.04 s (STOP) with the wheel, back and forth; villa tags follow their houses | film | click on the chosen villa's tag (it appears after the villa next door, around 12.1 s) |
| `volo` | the film plays from one second to another | film | end second reached |
| `villa` | villa label + villa card, "Enter the villa" | photo `F16.jpg` | Enter the villa: flies 16 to 26 s |
| `stanza` 0/1/2 | Living room (26 s), Dining room (29 s), Kitchen (31.5 s), each with a "View ..." button | film (stopped) | View: flies to the next stop; after the kitchen flies 31.5 to 36 s |
| `burj` | by the pool, Burj Khalifa label, "Private garden" | photo `F36.jpg` | after 2.6 s flies 36 to 41.5 s (the camera turns, the screen darkens) |
| `domanda` | "Is this your home?" Yes / No | film (stopped at 41.5) | Yes: plays 41.5 to 48 darker and blurred, the final card comes in; No: start again |
| `fine` | final card: photo, info, price, "Book a private viewing", "Start again" | film (48, dark) | Start again |

Fixed seconds in `app.js`: `LAND = 9.6`, `STOP` (dati.json, 13.04), `FERMATE` t = 26 / 29 / 31.5, `DOM = 41.5`, and 16, 36, 48 in the code.
The villa label at 16 s (`tag27_16`) and the Burj point at 36 s (`burj_36`) are pixel positions on those frames.

## Modes (address bar)

- no parameter: with the mouse. Wheel or trackpad scrolls the street. R starts again.
- `?auto`: the whole tour plays by itself with a drawn cursor (GIRO in app.js), about 60 s. R starts it again.
- `?auto&rec`: the same tour, but time only moves when you call `await __motore.step(n, fps)`: for frame-perfect recording.
- `__motore.scena(name)` in the console jumps to a still moment for screenshots: `strade`, `strada`, `scendi`, `via10.6`, `scegli`,
  `villa`, `stanza0`, `stanza1`, `stanza2`, `burj`, `gira`, `domanda`, `si`, `fine`.

## Files

- `app.js` steps, drawing, clicks, automatic tour. Italian names are explained at the top of the file.
- `engine/kit/quartiere-ui2.js` the glass UI pieces (cards, pin, labels, question, Burj label, chip). `quartiere-ui.js` small helpers and
  the price format. `tinta.js` colours from config.
- `config.js` words, villa, prices, link, colours. `dati.json` streets and villa tags.
