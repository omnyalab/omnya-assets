# Troubleshooting

## The download

| Problem | Fix |
|---|---|
| `All Overpass servers failed` | The public servers are busy. Wait a minute, run again. Try a smaller `--size`. |
| `SSL: ... HANDSHAKE_FAILURE` or `CERTIFICATE_VERIFY_FAILED` | Old Python TLS. The script uses `curl` first; if curl is missing, install Python from python.org (on a Mac run its "Install Certificates.command") or `pip3 install certifi`. |
| `very few buildings` | The centre is off (in the sea, in a park) or the place is poorly mapped. Check the centre on openstreetmap.org. |
| claude.ai sandbox has no internet | Give the user the exact command to run on their computer and ask them to put `city-data.js` next to `index.html`. |

## The page

| Problem | Fix |
|---|---|
| Stays on "Building ..." | Open the console. `city-data.js is missing` = it is not in the folder. A network error = three.js could not load from jsDelivr (needs internet the first time). |
| Water missing where the sea is | The console says `coastline: water everywhere, ignored`, or the area has no coastline. Make the area a bit bigger or move it so the coast crosses the square from border to border. Rivers and lakes drawn as polygons always work. |
| Land where the sea should be, or sea on land | A coastline piece is missing in OpenStreetMap inside the box. Move or enlarge the area slightly; re-run the script. |
| Streaks on the ground or water beyond the area | The ground outside the data is the stretched border of the map, blurred. Keep the camera mostly inside the area; lower `dist` / `height` for "View the full city", or make the area bigger. |
| The district button builds nothing | `city.info().inDistrict` is 0: wrong lat/lon or radius too small. Set `minHeight: 0` for districts without towers. |
| A view shows a field, a forest or the edge of the data | Change that button's shot (press K on a better view). For "Bring the nature", look at a park inside the city. |
| Facades all dark | The camera looks into the sun. Turn `heading` or move `sun.azimuth` so the sun is to the side. |
| Buildings look pink or purple | Check `walls` and `roofs*`: real colours only. Tagged OSM colours are calmed automatically; if one building is still loud, it is tagged that colour in OpenStreetMap. |
| Flicker on roofs | Two OSM outlines on top of each other with the same height. Usually invisible; heights already get a tiny offset per building. |
| Night windows too bright / too dim | In the engine, `wNear * 2.6 + wFar * 2.0` sets the glow, `wGain` halves it on glass towers. |
| Night too dark | Raise `NITE.hemiI` (0.55) or `NITE.exp` (1.2) in the engine. |
| Slow on a laptop | Smaller area, `?q=low`, or `quality: 'low'`. Check `city.info()`: over 2 million triangles is heavy. |
| Panel covers the subject | On wide screens the 3D is already shifted left to the free space. On phones (portrait) the panel is a sheet at the bottom; frame the shots slightly higher. |
| Label too long | Shorten it. Long labels are cut with an ellipsis. |

## Known limits

- The ground is flat: hills (Lisbon, Monaco, San Francisco) are not modelled, buildings stand on one level.
- Bridges lie flat on the water; tunnels are left out.
- `building:part` details (towers made of several stacked parts) are not used; each building is one prism with its outline and height.
- Roof shapes are flat (pitched roofs are only a colour).
- Heights without tags are estimates (see `overpass.md`).
- Cars at night are moving light dots on the main roads, not models.
