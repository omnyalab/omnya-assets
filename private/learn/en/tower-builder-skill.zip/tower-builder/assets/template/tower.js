/* =====================================================================
   Tower Builder · tower.js
   Part 1 is CONFIG, the only part you normally edit (every field is in references/config.md).
   Part 2 is the ENGINE: it builds the 3D tower in three.js and runs the floor picker.
   ===================================================================== */

window.TOWER_CONFIG = {
  // ---- the building ----
  name: 'Your Tower',                   // shown in the header and on the reservation card
  shortName: 'YT',                      // 1 to 3 letters for the round monogram on the card
  city: 'Waterfront City',              // shown next to the name
  lang: 'en',                           // <html lang>
  locale: 'en-IE',                      // number and price format, e.g. 'it-IT', 'pt-PT', 'en-US'
  currency: 'EUR',                      // ISO code: EUR, USD, GBP, AED, CHF...

  // ---- the shape ----
  floors: 40,                           // all levels above ground, lobby and penthouse included
  floorHeight: 4.2,                     // metres per level (set null and fill height to derive it)
  height: null,                         // optional total height in metres, used only when floorHeight is null
  podiumFloors: 2,                      // lobby and amenity levels at the base, not for sale
  footprint: { shape: 'rounded', width: 38, depth: 28, corner: 8 },   // shape: rect | rounded | oval | tapered (+ taper: 0.4)
  crown: 'flat',                        // flat | slanted | spire
  facade: 'bands',                      // bands (white slab edges, balconies) | glass (flush curtain wall) | fins (vertical fins)
  colors: {
    glass: '#2c3642',                   // the glass between the floors
    frame: '#f3efe6',                   // slab edges, balconies, fins, roof
    accent: '#ffc95c',                  // the light on the chosen floor and residence, and the buttons
    taken: '#7d828a',                   // sold residences and sold-out floors
  },
  surroundings: 'sea',                  // sea | river | city | desert | park
  look: 'golden',                       // day | golden | night

  // ---- what people buy ----
  zones: [                              // groups of levels, from the bottom up. price = the cheapest residence on the lowest level
    { name: 'Garden residences', from: 3, to: 12, price: 650000 },
    { name: 'Residences', from: 13, to: 26, price: 890000 },
    { name: 'Sky residences', from: 27, to: 39, price: 1250000 },
  ],
  floorPremium: 0.006,                  // every level up inside a zone adds this share to the price (0.006 = +0.6%)
  unitsPerFloor: 6,                     // residences on one level, 2 to 12
  unitTypes: [                          // the sizes on offer; bigger ones go to the corners and the view side
    { name: '1 bedroom', size: 72, bedrooms: 1 },
    { name: '2 bedrooms', size: 118, bedrooms: 2 },
    { name: '3 bedrooms', size: 165, bedrooms: 3 },
  ],
  occupancy: 0.35,                      // share of residences shown as sold (sample data)
  soldOutFloors: [9, 22],               // levels shown fully sold (sample data)
  penthouse: {                          // the top level; set to null for no penthouse
    name: 'The Penthouse',
    floors: 1,
    size: 460, bedrooms: 4,
    upgrade: 1800000,                   // price added to the chosen residence
    perks: ['Private terrace with pool', 'Double-height living room', 'Views on every side'],
  },
  checkoutUrl: '',                      // optional payment link; Reserve opens it with the choice in the query
  quality: 'auto',                      // auto | high | low (low = lighter for old phones)

  // ---- every word on the page (translate here) ----
  text: {
    stepTower: 'Choose your floor', stepFloor: 'Choose your residence', stepUnit: 'Your view', stepUpgrade: 'Upgrade',
    stepPenthouse: 'The penthouse', stepCard: 'Your reservation',
    towerHint: 'Tap a floor to see its residences.',
    floorHint: 'Tap a residence to see its view. Grey ones are sold.',
    level: 'Level', levels: 'Levels', from: 'from', soldOut: 'Sold out', sold: 'Sold', of: 'of', available: 'available',
    residence: 'Residence', bedroom: 'bedroom', bedrooms: 'bedrooms', size: 'Size', view: 'View', total: 'Total', m2: 'm²',
    seeUnits: 'See the residences', seeView: 'See the view', continue: 'Continue', changeUnit: 'Change residence',
    up: 'One floor up', down: 'One floor down',
    viewFront: 'Sea view', viewSide: 'Coast view', viewBack: 'City view', viewAll: 'Views on every side',
    compass: ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'],
    lobby: 'Lobby and amenities', byUpgrade: 'as an upgrade',
    penthouseOnly: 'The penthouse is offered as an upgrade once you choose a residence.',
    upgradeTitle: 'Want the penthouse?', upgradeYes: 'Yes, upgrade', upgradeNo: 'No thanks, keep my residence', inclUpgrade: 'incl. penthouse upgrade',
    yourView: 'Your view', penthouseView: 'Your view from the penthouse',
    reserve: 'Reserve', pay: 'Continue to payment', reserved: 'Reserved', anotherFloor: 'Choose another floor', back: 'Back',
    loading: 'Building the tower…', loadError: 'The 3D library did not load. Check the internet connection and reload.',
    note: 'Prices and availability shown are examples.',
  },
};

/* =====================================================================
   ENGINE · you rarely need to edit below this line
   ===================================================================== */
window.buildTower = function (THREE, { Sky, RoundedBoxGeometry }) {
  const C = window.TOWER_CONFIG, COL = C.colors || {}, TX = C.text || {};
  const $ = id => document.getElementById(id);
  const Q = new URLSearchParams(location.search);
  const PHONE = matchMedia('(pointer: coarse)').matches || Math.min(innerWidth, innerHeight) < 600;
  const QUAL = Q.get('q') || C.quality || 'auto';
  const LOW = QUAL === 'low' || (QUAL === 'auto' && PHONE);
  const REDUCED = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const SHOT = Q.get('shot') === '1';

  let seed = 7;
  const rnd = () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  const hash = n => { let x = (n | 0) ^ 0x9e3779b9; x = Math.imul(x ^ x >>> 16, 0x85ebca6b); x = Math.imul(x ^ x >>> 13, 0xc2b2ae35); return ((x ^ x >>> 16) >>> 0) / 4294967296; };
  const V = (x, y, z) => new THREE.Vector3(x, y, z);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const smooth = x => x * x * x * (x * (x * 6 - 15) + 10);          // ease in-out with no jolt at start, middle or end
  const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const LOC = C.locale || C.lang || 'en', CUR = C.currency || 'EUR';
  const money = new Intl.NumberFormat(LOC, { style: 'currency', currency: CUR, maximumFractionDigits: 0 });
  let short = money; try { short = new Intl.NumberFormat(LOC, { style: 'currency', currency: CUR, notation: 'compact', maximumSignificantDigits: 3 }); } catch (e) { /* old browsers */ }
  const fmt = v => money.format(v), fmtS = v => (v >= 100000 ? short : money).format(v);
  const num = new Intl.NumberFormat(LOC);
  const nice = v => { if (!(v > 0)) return 0; const p = Math.pow(10, Math.max(0, Math.floor(Math.log10(v)) - 2)); return Math.round(v / p) * p; };
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
  const canvas = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
  const tex = (c, rx = 1, ry = rx) => { const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry); t.anisotropy = 8; return t; };

  // ---------------- levels: 1 = ground, podium at the base, penthouse on top ----------------
  const NF = clamp(Math.round(C.floors || 40), 6, 120);
  const PH = C.penthouse || null, PEN = PH ? clamp(Math.round(PH.floors || 1), 1, 2) : 0;
  const POD = clamp(Math.round(C.podiumFloors != null ? C.podiumFloors : 2), 0, Math.min(6, NF - PEN - 3));
  const FH = clamp(+C.floorHeight || (C.height ? C.height / (POD * 1.25 + (NF - POD - PEN) + PEN * 1.5) : 4.2), 2.9, 6.5);
  const LY = [0], LH = [0];
  { let y = 0; for (let L = 1; L <= NF; L++) { const h = L <= POD ? FH * 1.25 : L > NF - PEN ? FH * 1.5 : FH; LY[L] = y; LH[L] = h; y += h; } LY[NF + 1] = y; LH[NF + 1] = 0; }
  const TOP = LY[NF + 1];
  const isPod = L => L <= POD, isPen = L => L > NF - PEN, isRes = L => L > POD && L <= NF - PEN;
  const FIRST = POD + 1, LAST = NF - PEN, PENL = NF - PEN + 1;

  // ---------------- facade ----------------
  const FAC = ['bands', 'glass', 'fins'].includes(C.facade) ? C.facade : 'bands';
  const BAL = FAC === 'bands' ? clamp(+C.balcony || 1.8, 0.8, 4) : FAC === 'fins' ? 0.55 : 0.16;   // how far the slab edge sticks out
  const SLAB = FAC === 'bands' ? 0.68 : FAC === 'fins' ? 0.48 : 0.36;                               // height of the white band
  const PIN = 3.2, PANEL = 1.6;                                                                     // penthouse glass set back, glass panel width
  const dG = L => isPen(L) ? -PIN : isPod(L) ? -1.4 : 0;                                            // glass line of a level
  const dS = L => L === POD + 1 && POD ? BAL + 4 : isPod(L) ? 0.7 : BAL;                            // slab edge under a level

  // ---------------- footprint: a convex outline around the centre, x = north, z = east, the sea is at -z (west) ----------------
  const FP = C.footprint || {};
  const SHAPE = ['rect', 'rounded', 'oval', 'tapered'].includes(FP.shape) ? FP.shape : 'rounded';
  const HW = clamp(+FP.width || 38, 12, 140) / 2, HD = clamp(+FP.depth || 28, 12, 140) / 2;
  const CORNER = SHAPE === 'rect' ? clamp(FP.corner != null ? +FP.corner : 0.6, 0.2, Math.min(HW, HD) - 0.5) : clamp(FP.corner != null ? +FP.corner : 8, 0.5, Math.min(HW, HD) - 0.2);
  const TAPER = SHAPE === 'tapered' ? clamp(FP.taper != null ? +FP.taper : 0.4, 0, 0.75) : 0;
  const BASE = (() => {
    const out = [];
    if (SHAPE === 'oval') { const n = LOW ? 56 : 84; for (let k = 0; k < n; k++) { const t = k / n * Math.PI * 2, c = Math.cos(t), s = Math.sin(t), nx = c / HW, nz = s / HD, l = Math.hypot(nx, nz); out.push({ x: HW * c, z: HD * s, nx: nx / l, nz: nz / l }); } return out; }
    const nc = CORNER < 1.5 ? 2 : LOW ? 6 : 10, a = HW - CORNER, b = HD - CORNER;
    [[a, b], [-a, b], [-a, -b], [a, -b]].forEach(([cx, cz], q) => { for (let j = 0; j <= nc; j++) { const t = (q + j / nc) * Math.PI / 2, c = Math.cos(t), s = Math.sin(t); out.push({ x: cx + CORNER * c, z: cz + CORNER * s, nx: c, nz: s }); } });
    return out;
  })();
  const NB = BASE.length;
  const scaleOf = L => 1 - TAPER * Math.pow(clamp(LY[clamp(L, 1, NF)] / TOP, 0, 1), 1.15);
  const polyAt = (s, d) => BASE.map(p => ({ x: p.x * s + p.nx * d, z: p.z * s + p.nz * d, nx: p.nx, nz: p.nz }));
  const R0 = Math.hypot(HW, HD) + BAL;
  function rayHit(poly, th) {   // where the ray from the centre at angle th (x = sin, z = cos) leaves the outline
    const dx = Math.sin(th), dz = Math.cos(th); let best = null, bt = 1e9;
    for (let i = 0; i < poly.length; i++) {
      const a = poly[i], b = poly[(i + 1) % poly.length], ex = b.x - a.x, ez = b.z - a.z, den = dx * ez - dz * ex; if (Math.abs(den) < 1e-9) continue;
      const t = (a.x * ez - a.z * ex) / den, u = (a.x * dz - a.z * dx) / den;
      if (t > 0 && u >= -1e-6 && u <= 1 + 1e-6 && t < bt) { bt = t; const nx = lerp(a.nx, b.nx, u), nz = lerp(a.nz, b.nz, u), l = Math.hypot(nx, nz) || 1; best = { x: dx * t, z: dz * t, nx: nx / l, nz: nz / l, r: t }; }
    }
    return best || { x: 0, z: 0, nx: dx, nz: dz, r: 0 };
  }
  function along(poly, step, off = 0.5) {   // points every `step` metres along an outline
    const out = [], n = poly.length, seg = []; let per = 0;
    for (let i = 0; i < n; i++) { const a = poly[i], b = poly[(i + 1) % n], l = Math.hypot(b.x - a.x, b.z - a.z); seg.push(l); per += l; }
    const cnt = Math.max(4, Math.round(per / step)), st = per / cnt; let i = 0, acc = 0;
    for (let k = 0; k < cnt; k++) {
      const t = (k + off) * st; while (i < n - 1 && acc + seg[i] < t) { acc += seg[i]; i++; }
      const a = poly[i], b = poly[(i + 1) % n], u = seg[i] > 0 ? clamp((t - acc) / seg[i], 0, 1) : 0, nx = lerp(a.nx, b.nx, u), nz = lerp(a.nz, b.nz, u), l = Math.hypot(nx, nz) || 1;
      out.push({ x: lerp(a.x, b.x, u), z: lerp(a.z, b.z, u), nx: nx / l, nz: nz / l });
    }
    return out;
  }

  // geometry builder: plain triangle lists with smooth horizontal normals on the facades
  function GB() {
    const P = [], N = [], U = [];
    const v = (x, y, z, nx, ny, nz, u, w) => { P.push(x, y, z); N.push(nx, ny, nz); U.push(u, w); };
    return { v,
      band(poly, y0, y1, uS = 1, v0 = 0, v1 = 1) { let acc = 0; const n = poly.length;
        for (let i = 0; i < n; i++) { const a = poly[i], b = poly[(i + 1) % n], l = Math.hypot(b.x - a.x, b.z - a.z), u0 = acc / uS, u1 = (acc + l) / uS; acc += l;
          v(a.x, y0, a.z, a.nx, 0, a.nz, u0, v0); v(b.x, y0, b.z, b.nx, 0, b.nz, u1, v0); v(b.x, y1, b.z, b.nx, 0, b.nz, u1, v1);
          v(a.x, y0, a.z, a.nx, 0, a.nz, u0, v0); v(b.x, y1, b.z, b.nx, 0, b.nz, u1, v1); v(a.x, y1, a.z, a.nx, 0, a.nz, u0, v1); } },
      cap(poly, y, ny = 1, uvS = 0) { const n = poly.length, uu = p => uvS ? p / uvS : 0;
        for (let i = 0; i < n; i++) { const a = poly[i], b = poly[(i + 1) % n]; v(0, y, 0, 0, ny, 0, 0, 0); v(a.x, y, a.z, 0, ny, 0, uu(a.x), uu(a.z)); v(b.x, y, b.z, 0, ny, 0, uu(b.x), uu(b.z)); } },
      ring(pIn, pOut, y, ny = 1) { const n = pIn.length;
        for (let i = 0; i < n; i++) { const a = pIn[i], b = pIn[(i + 1) % n], c = pOut[(i + 1) % n], d = pOut[i];
          for (const q of [a, b, c, a, c, d]) v(q.x, y, q.z, 0, ny, 0, q.x / 2, q.z / 2); } },
      quad(a, b, c, d, y, uvS = 0) { for (const q of [a, b, c, a, c, d]) v(q.x, y, q.z, 0, 1, 0, uvS ? q.x / uvS : 0, uvS ? q.z / uvS : 0); },
      empty() { return P.length === 0; },
      geo() { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(N, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(U, 2)); return g; } };
  }
  const slab = (B, poly, yTop, th) => { B.cap(poly, yTop, 1); B.cap(poly, yTop - th, -1); B.band(poly, yTop - th, yTop); };

  // ---------------- renderer, scene, light ----------------
  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance', logarithmicDepthBuffer: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, LOW ? 1.5 : 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.localClippingEnabled = true;
  $('scene').appendChild(renderer.domElement);
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(30, innerWidth / innerHeight, 0.2, 80000);

  const LOOKS = {
    day: { el: 46, off: -140, exp: 0.5, turb: 2.2, ray: 0.9, mie: 0.004, mieG: 0.8, sunI: 3.6, sunC: 0xfff4e4, hemi: [0xdbe6ff, 0x8f8270, 0.9], fog: 0xd2dde8, fogD: 0.00013, win: 0.25, lit: 0.1, night: 0, water: 0x2f6f8e, roomI: 0.8, gEnv: 0.2, fEnv: 0.55 },
    golden: { el: 2.6, off: 17, exp: 0.5, turb: 8, ray: 2.6, mie: 0.005, mieG: 0.88, sunI: 2.8, sunC: 0xffa45c, hemi: [0xb4c2e4, 0x5c4839, 0.95], fog: 0xa7a8b2, fogD: 0.00019, win: 1.15, lit: 0.22, night: 0.35, water: 0x1a4560, roomI: 1, gEnv: 0.8, fEnv: 1.25 },
    night: { el: 30, off: 115, exp: 0.78, sunI: 0.25, sunC: 0xa6b8ff, hemi: [0x26365e, 0x0c0b0a, 0.32], fog: 0x0b1222, fogD: 0.00016, win: 2.2, lit: 0.5, night: 1, dark: true, water: 0x0e1c2c, roomI: 1.7, gEnv: 1, fEnv: 1 },
  };
  const LKN = Q.get('look') || C.look || 'golden', LK = LOOKS[{ sunset: 'golden', dusk: 'golden' }[LKN] || LKN] || LOOKS.golden;
  renderer.toneMappingExposure = LK.exp;
  const AZ = 0.42;                                                   // the hero camera stands east of the tower, a little to the north
  const dirAE = (az, el) => V(Math.sin(az) * Math.cos(el), Math.sin(el), Math.cos(az) * Math.cos(el));
  const sunDir = (() => { const fx = -Math.sin(AZ), fz = -Math.cos(AZ), rx = -fz, rz = fx, o = THREE.MathUtils.degToRad(LK.off), hx = fx * Math.cos(o) + rx * Math.sin(o), hz = fz * Math.cos(o) + rz * Math.sin(o), el = THREE.MathUtils.degToRad(LK.el);
    return V(hx * Math.cos(el), Math.sin(el), hz * Math.cos(el)).normalize(); })();
  { const pm = new THREE.PMREMGenerator(renderer), sc = new THREE.Scene();
    if (!LK.dark) {
      const sky = new Sky(); sky.scale.setScalar(60000); const su = sky.material.uniforms;
      su.turbidity.value = LK.turb; su.rayleigh.value = LK.ray; su.mieCoefficient.value = LK.mie; su.mieDirectionalG.value = LK.mieG; su.sunPosition.value.copy(sunDir); scene.add(sky);
      const s2 = new Sky(); s2.scale.setScalar(1000); for (const k of ['turbidity', 'rayleigh', 'mieCoefficient', 'mieDirectionalG']) s2.material.uniforms[k].value = su[k].value; s2.material.uniforms.sunPosition.value.copy(sunDir); sc.add(s2);
    } else {   // night: a deep blue dome with a few stars
      const domeM = () => new THREE.ShaderMaterial({ side: THREE.BackSide, depthWrite: false, uniforms: {}, vertexShader: 'varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
        fragmentShader: 'varying vec3 vP; void main(){ float h = clamp(vP.y, -0.1, 1.0); vec3 c = mix(vec3(0.10, 0.14, 0.26), vec3(0.012, 0.018, 0.045), pow(max(h, 0.0), 0.55)); c += vec3(0.16, 0.10, 0.06) * exp(-max(h, 0.0) * 18.0); gl_FragColor = vec4(c, 1.0); }' });
      const dome = new THREE.Mesh(new THREE.SphereGeometry(60000, 32, 16), domeM()); scene.add(dome); sc.add(new THREE.Mesh(new THREE.SphereGeometry(1000, 32, 16), domeM()));
      const st = []; for (let i = 0; i < 900; i++) { const a = rnd() * 6.283, e = Math.asin(0.08 + rnd() * 0.92); st.push(Math.cos(a) * Math.cos(e) * 50000, Math.sin(e) * 50000, Math.sin(a) * Math.cos(e) * 50000); }
      const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.Float32BufferAttribute(st, 3));
      scene.add(new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xdfe6ff, size: 1.6, sizeAttenuation: false, transparent: true, opacity: 0.8, depthWrite: false })));
    }
    scene.environment = pm.fromScene(sc, 0, 1, 3000).texture; }
  scene.fog = new THREE.FogExp2(LK.fog, LK.fogD);
  const sun = new THREE.DirectionalLight(LK.sunC, LK.sunI);
  const TC = V(0, TOP * 0.5, 0); sun.target.position.copy(TC); sun.position.copy(TC).addScaledVector(sunDir, 3000);
  sun.castShadow = true; sun.shadow.mapSize.set(LOW ? 2048 : 4096, LOW ? 2048 : 4096);
  { const sx = R0 + 46, sy = TOP * 0.5 + 60; Object.assign(sun.shadow.camera, { left: -sx, right: sx, top: sy, bottom: -sy, near: 100, far: 9500 }); }
  sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.04;
  scene.add(sun, sun.target);
  scene.add(new THREE.HemisphereLight(LK.hemi[0], LK.hemi[1], LK.hemi[2]));

  // ---------------- materials of the tower (all clipped by CUT, which opens a floor in the floor view) ----------------
  const CUT = new THREE.Plane(V(0, -1, 0), 1e6);
  const clipM = m => { m.clippingPlanes = [CUT]; m.clipShadows = true; return m; };
  const M = (c, r = 0.8, m = 0, extra = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...extra });
  const FRAME = new THREE.Color(COL.frame || '#f3efe6'), GLASS = new THREE.Color(COL.glass || '#2c3642');
  const ACCENT = new THREE.Color(COL.accent || '#ffc95c'), TAKEN = new THREE.Color(COL.taken || '#7d828a');
  const PAPER = new THREE.Color('#e9e3d8'), HOVER = ACCENT.clone().lerp(new THREE.Color(0xffffff), 0.45);
  const DS = THREE.DoubleSide;

  function glassTextures() {   // 32 panels x 8 levels: dark glass, mullion lines, curtains and lit rooms
    const W = 1024, H = 512, cw = 32, ch = 64, c = canvas(W, H), g = c.getContext('2d'), e = canvas(W, H), ge = e.getContext('2d');
    ge.fillStyle = '#000'; ge.fillRect(0, 0, W, H);
    for (let r = 0; r < 8; r++) { let run = 0, lit = false, cur = false;
      for (let k = 0; k < 32; k++) {
        if (run <= 0) { run = 2 + (rnd() * 5 | 0); lit = rnd() < LK.lit; cur = rnd() < 0.3; } run--;
        const x = k * cw, y = r * ch, sh = 0.85 + rnd() * 0.3, gr = g.createLinearGradient(0, y, 0, y + ch);
        gr.addColorStop(0, `rgb(${150 * sh | 0},${158 * sh | 0},${168 * sh | 0})`); gr.addColorStop(0.14, `rgb(${112 * sh | 0},${121 * sh | 0},${132 * sh | 0})`); gr.addColorStop(1, `rgb(${86 * sh | 0},${95 * sh | 0},${106 * sh | 0})`);
        g.fillStyle = gr; g.fillRect(x, y, cw, ch);
        if (cur) { g.fillStyle = 'rgba(232,222,204,0.42)'; g.fillRect(x + 2, y + ch * 0.12, cw - 4, ch * 0.88); }
        g.fillStyle = '#c4cbd2'; g.fillRect(x, y, 2, ch);
        if (lit) { const q = ge.createLinearGradient(0, y, 0, y + ch); q.addColorStop(0, '#fff0d6'); q.addColorStop(0.18, '#ffcf96'); q.addColorStop(1, cur ? '#a87a4c' : '#5a3418'); ge.fillStyle = q; ge.fillRect(x + 2, y + 1, cw - 2, ch - 1); }
      } }
    const t1 = tex(c), t2 = tex(e); return [t1, t2];
  }
  function lobbyTexture() {
    const c = canvas(512, 128), g = c.getContext('2d'), gr = g.createLinearGradient(0, 0, 0, 128);
    gr.addColorStop(0, '#fff3dc'); gr.addColorStop(0.3, '#ffd9a6'); gr.addColorStop(1, '#a5774c'); g.fillStyle = gr; g.fillRect(0, 0, 512, 128);
    g.fillStyle = 'rgba(70,52,36,0.55)'; for (let x = 0; x < 512; x += 64) g.fillRect(x, 0, 3, 128);
    return tex(c);
  }
  const [gTex, eTex] = glassTextures(), lTex = lobbyTexture();
  const mFrame = clipM(M(FRAME, 0.45, 0.02, { envMapIntensity: LK.fEnv, side: DS }));
  const mGlass = clipM(M(GLASS, 0.07, 0.3, { map: gTex, emissive: 0xffc68c, emissiveMap: eTex, emissiveIntensity: LK.win, envMapIntensity: LK.gEnv, side: DS }));
  const mLobby = clipM(M(0xffffff, 0.2, 0.2, { map: lTex, emissive: 0xffd3a0, emissiveMap: lTex, emissiveIntensity: 0.35 + LK.night * 0.9, side: DS }));
  const mRail = clipM(new THREE.MeshStandardMaterial({ color: 0xdce8f0, roughness: 0.05, metalness: 0.3, transparent: true, opacity: 0.26, depthWrite: false, side: DS }));
  const mMull = clipM(M(0x8e979f, 0.35, 0.6, { side: DS }));
  const mCrown = clipM(M(GLASS.clone().multiplyScalar(1.4), 0.1, 0.7, { envMapIntensity: 1.4 * LK.gEnv, emissive: 0xffc68c, emissiveIntensity: LK.night * 0.25, side: DS }));
  const mPool = clipM(M(0x4fc0d8, 0.04, 0.1, { emissive: 0x1f86a6, emissiveIntensity: 0.25 + LK.night * 0.6, envMapIntensity: 1.2, side: DS }));
  const mHi = new THREE.MeshBasicMaterial({ color: ACCENT, transparent: true, opacity: 0.8, toneMapped: false, depthWrite: false, side: DS, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });

  // ---------------- the tower: glass of every level, slab edges, balconies, roof ----------------
  const bF = GB(), bG = GB(), bL = GB(), bR = GB(), bP = GB(), bPool = GB(), bC = GB();
  for (let L = 1; L <= NF; L++) {
    const s = scaleOf(L), y0 = LY[L], y1 = LY[L] + LH[L] - SLAB;
    if (isPod(L)) bL.band(polyAt(s, dG(L)), y0, y1, 3.2 * 8, 0, 1);
    else bG.band(polyAt(s, dG(L)), y0, y1, PANEL * 32, (L % 8) / 8, (L % 8 + 1) / 8);
    if (L > 1) slab(bF, polyAt(L === POD + 1 ? scaleOf(L - 1) : s, dS(L)), y0, L === POD + 1 && POD ? SLAB + 0.35 : SLAB);
    if (!isPod(L) && (FAC === 'bands' || isPen(L))) {   // glass balustrade and a slim handrail on every slab edge
      const d = dS(L); bR.band(polyAt(s, d - 0.09), y0, y0 + 1.1);
      bF.band(polyAt(s, d - 0.05), y0 + 1.08, y0 + 1.14); bF.ring(polyAt(s, d - 0.13), polyAt(s, d - 0.05), y0 + 1.14);
    }
    bP.band(polyAt(s, (L === 1 ? 1 : dS(L)) + 0.3), L === 1 ? 0 : y0 - SLAB, LY[L + 1] - SLAB);
  }
  if (POD) slab(bF, polyAt(1, dS(1) + 2.2), 0.42, 0.5);                       // plinth
  const sTop = scaleOf(NF);
  slab(bF, polyAt(sTop, BAL + (PEN ? 1.6 : 0.6)), TOP + 0.55, SLAB + 0.55);  // roof slab
  let CROWN_H = 0.55;
  const CROWN = ['flat', 'slanted', 'spire'].includes(C.crown) ? C.crown : 'flat';
  if (CROWN === 'slanted') {   // a glass crown that rises towards the sea
    const pc = polyAt(sTop, 0), z0 = Math.min(...pc.map(p => p.z)), z1 = Math.max(...pc.map(p => p.z)), hLo = 3, hHi = clamp(TOP * 0.09, 9, 28), yb = TOP + 0.55;
    const hAt = z => yb + hLo + (hHi - hLo) * Math.pow((z1 - z) / (z1 - z0), 1.1);
    for (let i = 0; i < NB; i++) { const a = pc[i], b = pc[(i + 1) % NB], ha = hAt(a.z), hb = hAt(b.z);
      for (const [q, y, n] of [[a, yb, a], [b, yb, b], [b, hb, b], [a, yb, a], [b, hb, b], [a, ha, a]]) bC.v(q.x, y, q.z, n.nx, 0, n.nz, 0, 0);
      for (const [q, y] of [[a, ha - 0.5], [b, hb - 0.5], [b, hb + 0.05], [a, ha - 0.5], [b, hb + 0.05], [a, ha + 0.05]]) bF.v(q.x * 1.004, y, q.z * 1.004, q.nx, 0, q.nz, 0, 0); }
    const hc = hAt(0), nrm = V(0, z1 - z0, hHi - hLo).normalize();
    for (let i = 0; i < NB; i++) { const a = pc[i], b = pc[(i + 1) % NB]; bC.v(0, hc, 0, 0, nrm.y, nrm.z, 0, 0); bC.v(a.x, hAt(a.z), a.z, 0, nrm.y, nrm.z, 0, 0); bC.v(b.x, hAt(b.z), b.z, 0, nrm.y, nrm.z, 0, 0); }
    CROWN_H = 0.55 + hHi;
  } else {   // a set-back plant room, and the spire on top of it
    slab(bF, polyAt(sTop * 0.5, 0), TOP + 4.4, 3.85); CROWN_H = 4.4;
  }
  const SPIRE_H = CROWN === 'spire' ? clamp(TOP * 0.22, 22, 95) : 0;
  if (PEN) {   // infinity pool on the penthouse terrace, on the sea side
    const s = scaleOf(PENL), y = LY[PENL] + 0.05, pi = polyAt(s, BAL - 2.7), po = polyAt(s, BAL - 0.55);
    for (let i = 0; i < NB; i++) { const j = (i + 1) % NB; if (BASE[i].nz < -0.5 && BASE[j].nz < -0.5) bPool.quad(pi[i], pi[j], po[j], po[i], y); }
  }
  const addMesh = (g, m, cast = true, rec = true) => { const o = new THREE.Mesh(g, m); o.castShadow = cast; o.receiveShadow = rec; scene.add(o); return o; };
  const inst = (geo, mat, list, cast = false, rec = true, parent = scene) => { const im = new THREE.InstancedMesh(geo, mat, Math.max(1, list.length)); list.forEach((m, i) => im.setMatrixAt(i, m)); im.count = list.length; im.castShadow = cast; im.receiveShadow = rec; parent.add(im); return im; };
  addMesh(bF.geo(), mFrame);
  const glassMesh = addMesh(bG.geo(), mGlass);
  const lobbyMesh = bL.empty() ? null : addMesh(bL.geo(), mLobby, false, true);
  const railMesh = bR.empty() ? null : addMesh(bR.geo(), mRail, false, false); if (railMesh) railMesh.renderOrder = 2;
  if (!bPool.empty()) addMesh(bPool.geo(), mPool, false, true);
  if (!bC.empty()) addMesh(bC.geo(), mCrown);
  if (SPIRE_H) {
    const sp = addMesh(new THREE.CylinderGeometry(0.16, 1.5, SPIRE_H, 16), clipM(M(0xd9dde2, 0.3, 0.7))); sp.position.y = TOP + CROWN_H + SPIRE_H / 2;
    const ring = addMesh(new THREE.CylinderGeometry(3.4, 4.2, 2.2, 24), mFrame); ring.position.y = TOP + CROWN_H + 1.1;
    const tip = addMesh(new THREE.SphereGeometry(0.55, 12, 8), new THREE.MeshBasicMaterial({ color: LK.dark ? 0xff4636 : 0xffffff, toneMapped: false }), false, false); tip.position.y = TOP + CROWN_H + SPIRE_H + 0.3;
  }
  const CROWN_TOP = TOP + CROWN_H + SPIRE_H;
  if (FAC !== 'bands') {   // vertical fins (fins) or slim mullions (glass), one box per panel and level
    const step = FAC === 'fins' ? 2.4 : PANEL, wd = FAC === 'fins' ? 0.32 : 0.1, dp = FAC === 'fins' ? 0.95 : 0.22, list = [];
    for (let L = FIRST; L <= LAST; L++) { const s = scaleOf(L), y0 = LY[L], y1 = LY[L] + LH[L] - SLAB;
      for (const p of along(polyAt(s, dp / 2 + 0.03), step)) { const m = new THREE.Matrix4().makeRotationY(Math.atan2(p.nx, p.nz)); m.scale(V(wd, y1 - y0 + 0.04, dp)); m.setPosition(p.x, (y0 + y1) / 2, p.z); list.push(m); } }
    inst(new THREE.BoxGeometry(1, 1, 1), FAC === 'fins' ? mFrame : mMull, list, !LOW);
  }
  const pickMesh = new THREE.Mesh(bP.geo(), new THREE.MeshBasicMaterial({ side: DS })); pickMesh.updateMatrixWorld();
  const levelOfY = y => { for (let L = 1; L <= NF; L++) if (y < LY[L + 1] - SLAB + 1e-3) return L; return NF; };

  // the light on exactly one floor: a glowing band over that level's glass only
  const hiCache = new Map(), hiMesh = new THREE.Mesh(new THREE.BufferGeometry(), mHi); hiMesh.renderOrder = 3; hiMesh.visible = false; scene.add(hiMesh);
  let hiL = -1, hiOff = 0;
  const bandMid = L => LY[L] + (LH[L] - SLAB) / 2;
  function showHi(L, grey) {
    if (!(L >= 1)) { hiMesh.visible = false; hiL = -1; hiOff = 0; return; }
    hiOff = hiMesh.visible && hiL >= 1 && L !== hiL && !SHOT && !REDUCED ? bandMid(hiL) + hiOff - bandMid(L) : 0; hiL = L; hiMesh.position.y = hiOff;   // the light slides to the new floor
    if (!hiCache.has(L)) { const b = GB(); b.band(polyAt(scaleOf(L), dG(L) + 0.08), LY[L] + 0.05, LY[L] + LH[L] - SLAB - 0.05); hiCache.set(L, b.geo()); }
    hiMesh.geometry = hiCache.get(L); mHi.color.copy(grey ? TAKEN : ACCENT); mHi.opacity = grey ? 0.62 : 0.82; hiMesh.visible = true;
  }

  // ---------------- residences: positions, sizes, prices (sample data, the same on every load) ----------------
  const UPF = clamp(Math.round(C.unitsPerFloor || 6), 2, 12), WEDGE = 2 * Math.PI / UPF, LETTERS = 'ABCDEFGHJKLM';
  const thetaOf = k => Math.PI + (k - (UPF - 1) / 2) * WEDGE;            // angle of a residence; PI = facing the sea
  const VIEWK = [], BEAR = [], ARC = [];
  for (let k = 0; k < UPF; k++) {
    const th = thetaOf(k), cz = Math.cos(th); VIEWK.push(cz < -0.45 ? 0 : cz > 0.45 ? 2 : 1);
    BEAR.push(Math.round(((Math.atan2(Math.cos(th), Math.sin(th)) * 180 / Math.PI + 360) % 360) / 45) % 8);
    let a = 0, prev = null; for (let j = 0; j <= 16; j++) { const h = rayHit(BASE, th - WEDGE / 2 + WEDGE * j / 16); if (prev) a += Math.hypot(h.x - prev.x, h.z - prev.z); prev = h; } ARC.push(a);
  }
  const TYPES = (C.unitTypes && C.unitTypes.length ? C.unitTypes : [{ name: '2 bedrooms', size: 110, bedrooms: 2 }])
    .map(t => ({ name: t.name || '', size: +t.size || 100, bedrooms: t.bedrooms != null ? +t.bedrooms : 2 })).sort((a, b) => a.size - b.size);
  const MIN_SIZE = TYPES[0].size, UTYPE = [];
  [...Array(UPF).keys()].sort((a, b) => (ARC[a] + (VIEWK[a] === 0 ? 3 : VIEWK[a] === 2 ? 1 : 0)) - (ARC[b] + (VIEWK[b] === 0 ? 3 : VIEWK[b] === 2 ? 1 : 0)))
    .forEach((k, r) => { UTYPE[k] = Math.min(TYPES.length - 1, Math.floor(r * TYPES.length / UPF)); });
  const ZONES = (C.zones && C.zones.length ? C.zones : [{ name: 'Residences', from: FIRST, to: LAST, price: 500000 }]).map((z, i) => ({
    name: z.name || '', from: clamp(Math.round(z.from != null ? z.from : FIRST), FIRST, LAST), to: clamp(Math.round(z.to != null ? z.to : LAST), FIRST, LAST), price: +z.price || 0, perM2: +z.pricePerM2 || 0, soldOut: !!z.soldOut, i }));
  const ZOF = [];
  for (let L = FIRST; L <= LAST; L++) { let best = 0, bd = 1e9; ZONES.forEach((z, i) => { const d = L < z.from ? z.from - L : L > z.to ? L - z.to : 0; if (d < bd) { bd = d; best = i; } }); ZOF[L] = best; }
  const SOLD_FLOORS = new Set((C.soldOutFloors || []).map(Number)), PREM = C.floorPremium != null ? +C.floorPremium : 0.006, OCC = C.occupancy != null ? +C.occupancy : 0.35;
  function unitPrice(L, k) {
    const z = ZONES[ZOF[L]], t = TYPES[UTYPE[k]], vf = [1.08, 1.03, 1][VIEWK[k]], up = 1 + PREM * (L - z.from);
    return nice(z.perM2 ? z.perM2 * t.size * up * vf : (z.price || 500000) * Math.pow(t.size / MIN_SIZE, 0.92) * up * vf);
  }
  const UNIT = [];
  for (let L = FIRST; L <= LAST; L++) { const sold = SOLD_FLOORS.has(L) || ZONES[ZOF[L]].soldOut; UNIT[L] = [];
    for (let k = 0; k < UPF; k++) UNIT[L].push({ k, t: TYPES[UTYPE[k]], price: unitPrice(L, k), taken: sold || hash(L * 131 + k * 17 + 7) < OCC }); }
  const freeOn = L => UNIT[L] ? UNIT[L].filter(u => !u.taken).length : 0;
  const fromOn = L => { const f = UNIT[L].filter(u => !u.taken); return Math.min(...(f.length ? f : UNIT[L]).map(u => u.price)); };
  const ZINFO = ZONES.map((z, i) => { const lv = []; for (let L = FIRST; L <= LAST; L++) if (ZOF[L] === i) lv.push(L);
    const us = lv.flatMap(L => UNIT[L]), fr = us.filter(u => !u.taken); return { levels: lv, units: us.length, free: fr.length, from: us.length ? Math.min(...(fr.length ? fr : us).map(u => u.price)) : 0 }; });
  const PENT = PH ? { name: PH.name || 'Penthouse', size: +PH.size || 460, bedrooms: PH.bedrooms != null ? +PH.bedrooms : 4, upgrade: +PH.upgrade || 0, perks: PH.perks || [] } : null;
  const unitName = (L, k) => `${L}${LETTERS[k]}`;
  const beds = n => `${n} ${n === 1 ? TX.bedroom : TX.bedrooms}`, m2 = v => `${num.format(v)} ${TX.m2 || 'm²'}`;
  const viewTxt = k => `${[TX.viewFront, TX.viewSide, TX.viewBack][VIEWK[k]]} · ${(TX.compass || [])[BEAR[k]] || ''}`;

  // ---------------- surroundings: sea | river | city | desert | park ----------------
  const SURR = ['sea', 'river', 'city', 'desert', 'park'].includes(C.surroundings) ? C.surroundings : 'sea';
  const WET = SURR === 'sea' || SURR === 'river', S1 = clamp(TOP / 170, 0.8, 1.6);
  const SHORE0 = -(HD + BAL + 80 * S1);
  const shoreZ = x => SHORE0 + (16 * Math.sin(x / 170 + 0.7) + 34 * Math.sin(x / 560 - 0.4)) * sstep(160, 700, Math.abs(x)) - Math.max(0, -x - 1500) * 0.2;
  const farBankZ = x => SHORE0 - 1450 * S1 + 90 * Math.sin(x / 380 + 1) + 170 * Math.sin(x / 1300);
  const BAY = { x: -2300 * S1, z: -3650 * S1, a: 1900 * S1, b: 700 * S1 };
  const LAKES = SURR === 'park' ? [{ x: -60 * S1, z: -(HD + 190 * S1), a: 170 * S1, b: 85 * S1 }, { x: 560 * S1, z: 420 * S1, a: 150 * S1, b: 80 * S1 }, { x: -700 * S1, z: -650 * S1, a: 220 * S1, b: 120 * S1 }] : [];
  const inEll = (x, z, e, k = 1) => { const dx = (x - e.x) / e.a, dz = (z - e.z) / e.b, a = Math.atan2(dz, dx), r = 1 + 0.07 * Math.sin(5 * a + 1) + 0.04 * Math.sin(11 * a); return dx * dx + dz * dz < r * r * k; };
  function landAt(x, z) {
    if (SURR === 'sea') return z > shoreZ(x) || inEll(x, z, BAY);
    if (SURR === 'river') return z > shoreZ(x) || z < farBankZ(x);
    if (SURR === 'park') return !LAKES.some(l => inEll(x, z, l));
    return true;
  }
  const hAt = (x, z) => {   // gentle relief far away: dunes in the desert, hills on the far river bank
    if (SURR === 'desert') { const r = Math.hypot(x, z); return sstep(650 * S1, 1500 * S1, r) * (9 * Math.sin(x / 140 + Math.sin(z / 260) * 2) + 6 * Math.sin(z / 95 + x / 300) + 3 * Math.sin((x + z) / 47) + 12); }
    if (SURR === 'river') return sstep(0, 900, farBankZ(x) - z - 60) * (30 + 26 * Math.sin(x / 620) + 12 * Math.sin(x / 210 + z / 300));
    return 0;
  };
  const SPAN = 9200 * S1, CZ = -1200 * S1, TEXN = LOW ? 1024 : 2048;
  const LANDC = { sea: '#cbbfa9', river: '#c9bba3', city: '#aaa49b', desert: '#d6b688', park: '#6f9150' }[SURR];
  { // ground: one big textured plane, water cut out by the texture alpha
    const c = canvas(TEXN, TEXN), g = c.getContext('2d'), k = TEXN / SPAN, X = x => (x + SPAN / 2) * k, Z = z => (z - CZ + SPAN / 2) * k;
    const shorePath = (f, side) => { g.beginPath(); for (let x = -SPAN / 2; x <= SPAN / 2; x += 20) { const px = X(x), pz = Z(f(x)); x === -SPAN / 2 ? g.moveTo(px, pz) : g.lineTo(px, pz); } if (side) { g.lineTo(X(SPAN / 2), side > 0 ? TEXN : 0); g.lineTo(X(-SPAN / 2), side > 0 ? TEXN : 0); g.closePath(); } };
    const ellPath = e => { g.beginPath(); for (let i = 0; i <= 96; i++) { const a = i / 96 * Math.PI * 2, r = 1 + 0.07 * Math.sin(5 * a + 1) + 0.04 * Math.sin(11 * a); const px = X(e.x + Math.cos(a) * e.a * r), pz = Z(e.z + Math.sin(a) * e.b * r); i ? g.lineTo(px, pz) : g.moveTo(px, pz); } g.closePath(); };
    g.fillStyle = LANDC;
    if (SURR === 'sea') { shorePath(shoreZ, 1); g.fill(); ellPath(BAY); g.fill(); }
    else if (SURR === 'river') { shorePath(shoreZ, 1); g.fill(); shorePath(farBankZ, -1); g.fill(); }
    else g.fillRect(0, 0, TEXN, TEXN);
    g.globalCompositeOperation = 'source-atop';
    // texture of the land: blotches of green and light paving, then roads
    const blot = SURR === 'desert' ? ['rgba(255,235,200,0.25)', 'rgba(150,110,60,0.18)'] : SURR === 'park' ? ['rgba(40,80,30,0.35)', 'rgba(170,190,110,0.25)'] : ['rgba(110,140,80,0.5)', 'rgba(240,232,215,0.35)'];
    for (let i = 0; i < (LOW ? 1600 : 3600); i++) { const x = (rnd() - 0.5) * SPAN, z = CZ + (rnd() - 0.5) * SPAN, r = (12 + rnd() * 60) * k; g.fillStyle = blot[rnd() < 0.5 ? 0 : 1]; g.beginPath(); g.arc(X(x), Z(z), r, 0, 7); g.fill(); }
    if (SURR !== 'desert' && SURR !== 'park') { g.strokeStyle = SURR === 'city' ? 'rgba(60,60,62,0.4)' : 'rgba(110,104,96,0.22)'; g.lineWidth = Math.max(1, 12 * k);
      const cell = SURR === 'city' ? 70 : 90; for (let v = -SPAN / 2; v < SPAN / 2; v += cell) { g.beginPath(); g.moveTo(X(v), 0); g.lineTo(X(v), TEXN); g.stroke(); g.beginPath(); g.moveTo(0, Z(v + CZ)); g.lineTo(TEXN, Z(v + CZ)); g.stroke(); } }
    if (SURR === 'park') { g.strokeStyle = 'rgba(222,208,180,0.8)'; g.lineWidth = Math.max(1, 5 * k); for (let i = 0; i < 40; i++) { g.beginPath(); let x = (rnd() - 0.5) * 3000, z = (rnd() - 0.5) * 3000; g.moveTo(X(x), Z(z)); for (let j = 0; j < 8; j++) { x += (rnd() - 0.5) * 400; z += (rnd() - 0.5) * 400; g.lineTo(X(x), Z(z)); } g.stroke(); } }
    if (WET) {   // beach and promenade along the near shore
      g.lineCap = 'round'; g.strokeStyle = '#e4d4b2'; g.lineWidth = 30 * k; shorePath(shoreZ, 0); g.stroke();
      g.strokeStyle = '#ddd5c6'; g.lineWidth = 9 * k; shorePath(x => shoreZ(x) + 22, 0); g.stroke();
      if (SURR === 'sea') { g.strokeStyle = '#e4d4b2'; g.lineWidth = 26 * k; ellPath(BAY); g.stroke(); }
    }
    g.globalCompositeOperation = 'source-over';
    const segs = SURR === 'desert' || SURR === 'river' ? (LOW ? 140 : 220) : 1;
    const gg = new THREE.PlaneGeometry(SPAN, SPAN, segs, segs); gg.rotateX(-Math.PI / 2); gg.translate(0, 0, CZ);
    if (segs > 1) { const pa = gg.attributes.position; for (let i = 0; i < pa.count; i++) pa.setY(i, hAt(pa.getX(i), pa.getZ(i))); gg.computeVertexNormals(); }
    const land = new THREE.Mesh(gg, M(0xffffff, 0.95, 0, { map: tex(c), alphaTest: 0.5 })); land.material.map.wrapS = land.material.map.wrapT = THREE.ClampToEdgeWrapping; land.position.y = 0.3; land.receiveShadow = true; scene.add(land);
    // far land beyond the texture, so the horizon away from the water is land
    const far = (z0, z1) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(80000, Math.abs(z1 - z0)), M(new THREE.Color(LANDC).multiplyScalar(0.92), 1)); m.rotation.x = -Math.PI / 2; m.position.set(0, 0.15, (z0 + z1) / 2); scene.add(m); };
    if (SURR === 'sea') far(CZ + SPAN / 2 - 40, 40000);
    else if (SURR === 'river') { far(CZ + SPAN / 2 - 40, 40000); far(CZ - SPAN / 2 + 40, -40000); }
    else { far(CZ + SPAN / 2 - 40, 40000); far(CZ - SPAN / 2 + 40, -40000); const m = new THREE.Mesh(new THREE.PlaneGeometry(80000, SPAN), M(new THREE.Color(LANDC).multiplyScalar(0.92), 1)); m.rotation.x = -Math.PI / 2; m.position.set(0, 0.1, CZ); scene.add(m); }
  }
  if (WET || LAKES.length) {   // water with small waves and the sky in it
    const N = 512, c = canvas(N, N), g = c.getContext('2d'), im = g.createImageData(N, N), H = new Float32Array(N * N), waves = [];
    for (let i = 0; i < 34; i++) { const kx = (1 + (rnd() * 22 | 0)) * (rnd() < 0.5 ? -1 : 1), kz = (rnd() * 31 | 0) - 15; waves.push([kx, kz, rnd() * 6.283, 1 / Math.hypot(kx, kz)]); }
    for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) { let h = 0; for (const [kx, kz, p, a] of waves) h += a * Math.sin(6.2832 * (kx * x + kz * y) / N + p); H[y * N + x] = h; }
    for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
      const dx = H[y * N + (x + 1) % N] - H[y * N + (x + N - 1) % N], dy = H[((y + 1) % N) * N + x] - H[((y + N - 1) % N) * N + x], n = V(-dx * 2.2, -dy * 2.2, 1).normalize(), o = (y * N + x) * 4;
      im.data[o] = (n.x * 0.5 + 0.5) * 255; im.data[o + 1] = (n.y * 0.5 + 0.5) * 255; im.data[o + 2] = (n.z * 0.5 + 0.5) * 255; im.data[o + 3] = 255; }
    g.putImageData(im, 0, 0);
    const wn = new THREE.CanvasTexture(c); wn.wrapS = wn.wrapT = THREE.RepeatWrapping; wn.repeat.set(1300, 1300); wn.anisotropy = 8;
    const water = new THREE.Mesh(new THREE.PlaneGeometry(80000, 80000), M(LK.water, 0.05, 0.02, { normalMap: wn, normalScale: new THREE.Vector2(0.16, 0.16), envMapIntensity: 0.85 }));
    water.rotation.x = -Math.PI / 2; water.position.y = 0; water.receiveShadow = true; scene.add(water);
  }
  { // the plaza around the tower: light stone, a lawn ring, a drop-off road
    const c = canvas(512, 512), g = c.getContext('2d'); g.fillStyle = '#e2dbcd'; g.fillRect(0, 0, 512, 512);
    for (let i = 0; i < 5000; i++) { g.fillStyle = rnd() < 0.5 ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.08)'; g.fillRect(rnd() * 512, rnd() * 512, 2, 2); }
    g.strokeStyle = 'rgba(120,110,95,0.3)'; g.lineWidth = 2; for (let v = 0; v <= 512; v += 64) { g.beginPath(); g.moveTo(v, 0); g.lineTo(v, 512); g.stroke(); g.beginPath(); g.moveTo(0, v); g.lineTo(512, v); g.stroke(); }
    const stone = tex(c), pz = polyAt(1, BAL + 14 * S1), lawn = polyAt(1, BAL + 26 * S1), r0 = polyAt(1, BAL + 30 * S1), r1 = polyAt(1, BAL + 39 * S1);
    const b1 = GB(); b1.cap(pz, 0.46, 1, 6); addMesh(b1.geo(), M(0xffffff, 0.75, 0, { map: stone, side: DS }), false, true);
    const b2 = GB(); b2.ring(pz, lawn, 0.44); addMesh(b2.geo(), M(SURR === 'desert' ? 0xd2b384 : 0x6e9a4a, 0.95, 0, { side: DS }), false, true);
    const b3 = GB(); b3.ring(lawn, r0, 0.45); addMesh(b3.geo(), M(0xd9d2c4, 0.8, 0, { side: DS }), false, true);
    const b4 = GB(); b4.ring(r0, r1, 0.43); addMesh(b4.geo(), M(0xcfc7b8, 0.85, 0, { side: DS }), false, true);
  }
  // buildings around, with windows drawn in the shader so they keep their size at any height
  const winMat = (() => { const bm = M(0xffffff, 0.65, 0.12);
    bm.onBeforeCompile = sh => {
      sh.uniforms.uNight = { value: LK.night };
      sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWP; varying vec3 vWN;')
        .replace('#include <project_vertex>', '#include <project_vertex>\n vec4 wp4 = vec4(transformed, 1.0);\n#ifdef USE_INSTANCING\n wp4 = instanceMatrix * wp4;\n#endif\n vWP = (modelMatrix * wp4).xyz; vWN = normalize(objectNormal);');
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vWP; varying vec3 vWN; uniform float uNight;\nfloat hh(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }')
        .replace('#include <color_fragment>', '#include <color_fragment>\n float side = step(abs(vWN.y), 0.5);\n vec2 gq = vec2((abs(vWN.x) > 0.5 ? vWP.z : vWP.x) / 3.2, vWP.y / 3.4);\n vec2 fq = fract(gq);\n float win = step(0.16, fq.x) * step(fq.x, 0.84) * step(0.24, fq.y) * step(fq.y, 0.8) * side * step(3.0, vWP.y);\n float aa = 1.0 - smoothstep(0.18, 0.5, max(fwidth(gq.x), fwidth(gq.y))); win *= aa;\n float lit = step(0.5, hh(floor(gq) + floor(vWP.xz / 40.0)));\n diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.12, 0.15, 0.19), win * 0.78);')
        .replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\n totalEmissiveRadiance += win * lit * uNight * vec3(1.0, 0.76, 0.48) * 1.5;');
    }; return bm; })();
  const trees = [], palms = [];
  { const bl = [], bc = [], BC = SURR === 'desert' ? [0xe6dccb, 0xd9cbb2, 0xefe7da] : [0xe9e5dd, 0xd9d3c8, 0xcfc6b6, 0xbfc5cb, 0xa9b2ba, 0xe3d6c1, 0x939ca6];
    const cell = SURR === 'city' ? 70 : 90, clear = R0 + (SURR === 'city' ? 70 : 62) * S1, maxR = 3300 * S1, max = LOW ? 1000 : 2600;
    const dens = { sea: 0.55, river: 0.55, city: 0.8, desert: 0.05, park: 0.16 }[SURR];
    for (let gx = -maxR; gx < maxR && bl.length < max * 4; gx += cell) for (let gz = -maxR; gz < maxR; gz += cell) for (const [ox, oz] of [[0.28, 0.28], [0.72, 0.28], [0.28, 0.72], [0.72, 0.72]]) {
      const x = gx + ox * cell, z = gz + oz * cell, r = Math.hypot(x, z); if (r < clear || r > maxR || rnd() > dens) continue;
      { let da = Math.atan2(x, z) - AZ; da = Math.atan2(Math.sin(da), Math.cos(da)); if (Math.abs(da) < 0.62 && r < 1100 * S1) continue; }
      if (!landAt(x, z) || (WET && (z < shoreZ(x) + 70 && z > shoreZ(x) - 10))) continue;
      if (SURR === 'river' && z < farBankZ(x) && z > farBankZ(x) - 40) continue;
      const far = clamp((r - clear) / 1400, 0, 1), w = (SURR === 'city' ? 20 : 15) + rnd() * 16, d = (SURR === 'city' ? 20 : 15) + rnd() * 16;
      let h = SURR === 'city' ? 14 + rnd() * 34 : SURR === 'desert' || SURR === 'park' ? 6 + rnd() * 8 : 8 + rnd() * 20;
      if (rnd() < (SURR === 'city' ? 0.16 : SURR === 'park' ? 0.03 : 0.06) * (0.4 + far)) h = (SURR === 'city' ? 70 : 40) + rnd() * (SURR === 'city' ? 150 : 80);
      bl.push(new THREE.Matrix4().compose(V(x, hAt(x, z) + h / 2, z), new THREE.Quaternion().setFromAxisAngle(V(0, 1, 0), SURR === 'park' || SURR === 'desert' ? rnd() * 3 : 0), V(w, h, d))); bc.push(BC[(rnd() * BC.length) | 0]);
      if (rnd() < 0.35) (SURR === 'desert' || WET ? palms : trees).push([x + cell * 0.3, z, 2.6 + rnd()]);
    }
    // a far skyline across the water or the sand, in the haze
    const cl = SURR === 'sea' ? { x: BAY.x + 300, z: BAY.z + 140 * S1, rx: 1250 * S1, rz: 330 * S1, n: 52 } : SURR === 'desert' ? { x: -1900 * S1, z: -2900 * S1, rx: 900, rz: 420, n: 40 } : SURR === 'city' ? { x: -600, z: -2400, rx: 1800, rz: 600, n: 60 } : SURR === 'park' ? { x: -1500, z: -2600, rx: 1300, rz: 500, n: 30 } : null;
    if (cl) for (let i = 0; i < cl.n; i++) { const a = rnd() * 6.283, rr = Math.sqrt(rnd()), x = cl.x + Math.cos(a) * cl.rx * rr, z = cl.z + Math.sin(a) * cl.rz * rr, h = (70 + rnd() * 240) * (1.2 - rr * 0.5), w = 22 + rnd() * 22;
      bl.push(new THREE.Matrix4().compose(V(x, h / 2, z), new THREE.Quaternion(), V(w, h, w * (0.8 + rnd() * 0.5)))); bc.push([0xb7c1cb, 0xc9d0d6, 0x9aa6b2, 0xd8dde2][(rnd() * 4) | 0]); }
    const bi = inst(new THREE.BoxGeometry(1, 1, 1), winMat, bl, false, true); bc.forEach((c, i) => bi.setColorAt(i, new THREE.Color(c)));
  }
  { // palms and trees: around the plaza, along the promenade, in the park
    for (const p of along(polyAt(1, BAL + 20 * S1), 13)) (SURR === 'city' || SURR === 'park' ? trees : palms).push(SURR === 'city' || SURR === 'park' ? [p.x, p.z, 3.4] : [p.x, p.z]);
    if (WET) for (let x = -1300; x <= 1300; x += 15) palms.push([x + (rnd() - 0.5) * 4, shoreZ(x) + 30 + (rnd() - 0.5) * 3]);
    if (SURR === 'park') { const maxT = LOW ? 1800 : 4200; for (let i = 0; i < 30000 && trees.length < maxT; i++) { const x = (rnd() - 0.5) * 3000, z = (rnd() - 0.5) * 3000, r = Math.hypot(x / (HW + BAL + 46 * S1), z / (HD + BAL + 46 * S1));
      if (r < 1.05 || !landAt(x, z) || LAKES.some(l => inEll(x, z, l, 1.25)) || Math.sin(x / 61 + 1.3) * Math.cos(z / 47 - 0.7) + 0.6 * Math.sin((x + z) / 33) < -0.2 + 0.5 * rnd()) continue; trees.push([x, z, 3 + rnd() * 3]); } }
    if (SURR === 'desert') for (let i = 0; i < 160; i++) { const a = rnd() * 6.283, r = 70 * S1 + rnd() * 250; palms.push([Math.cos(a) * r, Math.sin(a) * r]); }
    const GC = [0x3f6b2e, 0x4a7a34, 0x365f2a, 0x55853a];
    if (trees.length) { const cn = inst(new THREE.IcosahedronGeometry(1, 1), M(0xffffff, 0.9), trees.map(([x, z, r]) => new THREE.Matrix4().compose(V(x, r * 2.1, z), new THREE.Quaternion(), V(r, r * 0.9, r))), !LOW);
      trees.forEach((_, i) => cn.setColorAt(i, new THREE.Color(GC[(rnd() * 4) | 0])));
      inst(new THREE.CylinderGeometry(0.18, 0.28, 1, 6), M(0x6b5844, 0.9), trees.map(([x, z, r]) => new THREE.Matrix4().compose(V(x, r * 0.6, z), new THREE.Quaternion(), V(1, r * 1.2, 1)))); }
    if (palms.length) { const leaves = []; for (let k = 0; k < 9; k++) { const l = new THREE.BoxGeometry(0.5, 0.06, 4.2).translate(0, 0, 2.1); l.rotateX(0.38); l.rotateY(k / 9 * Math.PI * 2); leaves.push(l); }
      const lg = new THREE.BufferGeometry(), arrs = leaves.map(l => l.toNonIndexed()), pos = []; arrs.forEach(a => pos.push(...a.attributes.position.array)); lg.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); lg.computeVertexNormals();
      const ph = palms.map(() => 8 + rnd() * 4);
      inst(lg, M(0x4f7d32, 0.85, 0, { side: DS }), palms.map(([x, z], i) => new THREE.Matrix4().compose(V(x, ph[i], z), new THREE.Quaternion().setFromAxisAngle(V(0, 1, 0), rnd() * 6), V(1, 1, 1))), !LOW);
      inst(new THREE.CylinderGeometry(0.22, 0.32, 1, 7), M(0x8a7458, 0.9), palms.map(([x, z], i) => new THREE.Matrix4().compose(V(x, ph[i] / 2, z), new THREE.Quaternion(), V(1, ph[i], 1))), !LOW); }
    if (WET) { const hull = new THREE.BoxGeometry(3.4, 1.3, 12).translate(0, 0.65, 0), cab = new THREE.BoxGeometry(2.6, 1.2, 5).translate(0, 1.9, -0.8), boats = [];
      for (let i = 0; i < (LOW ? 8 : 18); i++) { const x = (rnd() - 0.5) * 2600, z = shoreZ(x) - 120 - rnd() * 900; boats.push(new THREE.Matrix4().compose(V(x, 0, z), new THREE.Quaternion().setFromAxisAngle(V(0, 1, 0), rnd() * 6.28), V(1, 1, 1))); }
      const bm = M(0xf4f4f2, 0.35, 0.1); inst(hull, bm, boats); inst(cab, M(0x2b3138, 0.2, 0.5), boats); }
    if (LK.dark) { const lamps = []; for (const p of along(polyAt(1, BAL + 29 * S1), 16)) lamps.push(new THREE.Matrix4().makeTranslation(p.x, 5.5, p.z));
      if (WET) for (let x = -1300; x <= 1300; x += 30) lamps.push(new THREE.Matrix4().makeTranslation(x, 5, shoreZ(x) + 24));
      inst(new THREE.SphereGeometry(0.5, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffc98a, toneMapped: false }), lamps, false, false); }
  }

  /* =====================================================================
     FLOOR PLAN (the open floor in the floor view) and ROOM (the view from inside)
     ===================================================================== */
  let plan = null, room = null;
  function clearGroup(G) { if (!G) return; scene.remove(G); G.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material && o.material.userData.own) o.material.dispose(); }); }
  function buildPlan(L) {
    clearGroup(plan && plan.G); const G = new THREE.Group(), s = scaleOf(L), y = LY[L] + 0.05, outer = polyAt(s, dG(L) - 0.2), core = polyAt(s * 0.34, 0), tiles = [], centres = [];
    for (let k = 0; k < UPF; k++) {
      const b = GB(), th0 = thetaOf(k) - WEDGE / 2 + 0.018, span = WEDGE - 0.036, n = 22; let pi = null, po = null;
      for (let j = 0; j <= n; j++) { const th = th0 + span * j / n, ci = rayHit(core, th), co = rayHit(outer, th); if (pi) b.quad(pi, ci, co, po, y); pi = ci; po = co; }
      const mat = new THREE.MeshBasicMaterial({ color: PAPER, toneMapped: false, side: DS }); mat.userData.own = true;
      const m = new THREE.Mesh(b.geo(), mat); m.receiveShadow = true; G.add(m); tiles.push(m);
      const ci = rayHit(core, thetaOf(k)), co = rayHit(outer, thetaOf(k)); centres.push(V(lerp(ci.x, co.x, 0.55), y + 1.4, lerp(ci.z, co.z, 0.55)));
    }
    const mw = M(0xf6f3ee, 0.7, 0, { side: DS }); mw.userData.own = true; const walls = [];
    for (let k = 0; k < UPF; k++) { const th = thetaOf(k) + WEDGE / 2, a = rayHit(core, th), b = rayHit(outer, th), len = Math.hypot(b.x - a.x, b.z - a.z);
      walls.push(new THREE.Matrix4().compose(V((a.x + b.x) / 2, y + 0.4, (a.z + b.z) / 2), new THREE.Quaternion().setFromAxisAngle(V(0, 1, 0), Math.atan2(b.x - a.x, b.z - a.z)), V(0.14, 0.8, len))); }
    inst(new THREE.BoxGeometry(1, 1, 1), mw, walls, true, true, G);
    const bc = GB(); slab(bc, core, y + 0.8, 0.8); const mc = M(0x8a8178, 0.8, 0, { side: DS }); mc.userData.own = true; const cm = new THREE.Mesh(bc.geo(), mc); cm.castShadow = cm.receiveShadow = true; G.add(cm);
    scene.add(G); plan = { L, G, tiles, centres }; paintPlan();
  }
  function paintPlan() {
    if (!plan) return;
    plan.tiles.forEach((m, k) => { const u = UNIT[plan.L][k]; m.userData.to = u.taken ? TAKEN : k === S.unit ? ACCENT : k === S.hoverUnit ? HOVER : PAPER; if (!m.userData.set || SHOT || REDUCED) { m.material.color.copy(m.userData.to); m.userData.set = true; } });
  }
  function clearPlan() { clearGroup(plan && plan.G); plan = null; }

  // textures of the rooms, made once
  let RT = null;
  function roomTextures() {
    if (RT) return RT;
    const f = canvas(1024, 1024), g = f.getContext('2d');   // light oak planks
    g.fillStyle = '#c8a682'; g.fillRect(0, 0, 1024, 1024);
    for (let y = 0; y < 1024; y += 64) { let x = -((y / 64) % 3) * 140; while (x < 1024) { const w = 300 + rnd() * 260, sh = rnd() * 0.14 - 0.07; g.fillStyle = `rgba(${sh > 0 ? '255,240,220' : '90,60,30'},${Math.abs(sh)})`; g.fillRect(x, y, w, 64); g.fillStyle = 'rgba(70,45,25,0.35)'; g.fillRect(x, y, 2, 64); x += w; } g.fillStyle = 'rgba(70,45,25,0.3)'; g.fillRect(0, y, 1024, 2); }
    for (let i = 0; i < 9000; i++) { g.fillStyle = rnd() < 0.5 ? 'rgba(80,50,25,0.07)' : 'rgba(255,245,230,0.07)'; g.fillRect(rnd() * 1024, rnd() * 1024, 18 + rnd() * 50, 1.5); }
    const t = canvas(1024, 1024), q = t.getContext('2d');   // travertine slabs for the penthouse
    q.fillStyle = '#ddd2c0'; q.fillRect(0, 0, 1024, 1024);
    for (let i = 0; i < 700; i++) { q.fillStyle = rnd() < 0.5 ? 'rgba(160,140,110,0.12)' : 'rgba(255,250,240,0.16)'; q.fillRect(0, rnd() * 1024, 1024, 1 + rnd() * 5); }
    q.strokeStyle = 'rgba(140,125,100,0.35)'; q.lineWidth = 2; for (let v = 0; v <= 1024; v += 512) { q.beginPath(); q.moveTo(v, 0); q.lineTo(v, 1024); q.stroke(); } for (let v = 0; v <= 1024; v += 256) { q.beginPath(); q.moveTo(0, v); q.lineTo(1024, v); q.stroke(); }
    const s = canvas(256, 256), w = s.getContext('2d');   // wood slats for the penthouse ceiling
    w.fillStyle = '#8a6646'; w.fillRect(0, 0, 256, 256); for (let x = 0; x < 256; x += 32) { w.fillStyle = '#b48a60'; w.fillRect(x + 4, 0, 22, 256); w.fillStyle = 'rgba(255,230,200,0.2)'; w.fillRect(x + 4, 0, 4, 256); }
    RT = { oak: tex(f), trav: tex(t), slat: tex(s) }; return RT;
  }
  const roomLight = new THREE.PointLight(0xffd2a0, 0, 0, 2); roomLight.visible = false; scene.add(roomLight);
  function roomFrame(L, pent, k) {   // where the camera stands inside, and the facade in front of it
    const s = scaleOf(L), gl = polyAt(s, dG(L)), th = pent ? Math.PI : thetaOf(k), F = rayHit(gl, th), n = V(F.nx, 0, F.nz).normalize(), t = V(-n.z, 0, n.x);
    const coreR = rayHit(polyAt(s * 0.34, 0), th).r, back = clamp(F.r - coreR - 1.0, 3, pent ? 9.5 : 6.4);
    const E = V(F.x, LY[L], F.z).addScaledVector(n, -back);
    return { s, gl, th, F, n, t, back, E, y: LY[L], h: LH[L] - SLAB };
  }
  function buildRoom(L, k, pent) {
    clearGroup(room); const R = roomTextures(), G = new THREE.Group(), f = roomFrame(L, pent, k), { gl, F, n, t, y, h } = f;
    const own = m => { m.userData.own = true; return m; };
    const add = (geo, mat, cast = true) => { const m = new THREE.Mesh(geo, mat); m.castShadow = cast; m.receiveShadow = true; G.add(m); return m; };
    // floor and ceiling follow the real outline of the level
    const fl = GB(); fl.cap(polyAt(f.s, dG(L) - 0.02), y + 0.012, 1, pent ? 4 : 3.2);
    add(fl.geo(), own(M(0xffffff, 0.32, 0, { map: pent ? R.trav : R.oak, envMapIntensity: 0.8, side: DS })), false);
    const ce = GB(); ce.cap(polyAt(f.s, dG(L) - 0.02), y + h - 0.03, -1, 2.4); add(ce.geo(), own(pent ? M(0xffffff, 0.7, 0, { map: R.slat, side: DS }) : M(0xf1ece4, 0.9, 0, { side: DS })), false);
    // walls between residences
    if (!pent) for (const th of [thetaOf(k) - WEDGE / 2, thetaOf(k) + WEDGE / 2]) { const a = rayHit(polyAt(f.s * 0.34, 0), th), b = rayHit(gl, th), len = Math.hypot(b.x - a.x, b.z - a.z) - 0.1;
      const w = add(new THREE.BoxGeometry(0.16, h, len), own(M(0xe9e3d8, 0.9))); w.position.set((a.x + b.x) / 2, y + h / 2, (a.z + b.z) / 2); w.rotation.y = Math.atan2(b.x - a.x, b.z - a.z); }
    // slim mullions, head and sill along the glass of this residence (the whole floor for the penthouse)
    const mm = own(M(0x5a4a3a, 0.35, 0.7)), mulls = [], spanA = pent ? Math.PI * 2 : WEDGE, th0 = f.th - spanA / 2, pts = [];
    for (let j = 0; j <= 160; j++) pts.push(rayHit(gl, th0 + spanA * j / 160));
    let acc = 0.8; for (let j = 1; j < pts.length; j++) { const a = pts[j - 1], b = pts[j], l = Math.hypot(b.x - a.x, b.z - a.z); acc += l; if (acc >= 1.7) { acc = 0; mulls.push(new THREE.Matrix4().compose(V(b.x - b.nx * 0.05, y + h / 2, b.z - b.nz * 0.05), new THREE.Quaternion().setFromAxisAngle(V(0, 1, 0), Math.atan2(b.nx, b.nz)), V(0.05, h, 0.1))); } }
    inst(new THREE.BoxGeometry(1, 1, 1), mm, mulls, true, true, G);
    const hs = GB(); for (let j = 1; j < pts.length; j++) { const a = pts[j - 1], b = pts[j];
      for (const [y0, y1] of [[y, y + 0.06], [y + h - 0.14, y + h]]) for (const [q, yy] of [[a, y0], [b, y0], [b, y1], [a, y0], [b, y1], [a, y1]]) hs.v(q.x - q.nx * 0.05, yy, q.z - q.nz * 0.05, -q.nx, 0, -q.nz, 0, 0); }
    add(hs.geo(), mm, false);
    const gp = GB(); for (let j = 1; j < pts.length; j++) { const a = pts[j - 1], b = pts[j]; for (const [q, yy] of [[a, y], [b, y], [b, y + h], [a, y], [b, y + h], [a, y + h]]) gp.v(q.x, yy, q.z, q.nx, 0, q.nz, 0, 0); }
    const pane = add(gp.geo(), own(new THREE.MeshStandardMaterial({ color: 0xcfdde6, roughness: 0.02, metalness: 0.1, transparent: true, opacity: 0.06, depthWrite: false, side: DS })), false); pane.renderOrder = 2;
    // a warm cove light along the glass in the ceiling
    const cv = GB(); for (let j = 1; j < pts.length; j++) { const a = pts[j - 1], b = pts[j], a2 = { x: a.x - a.nx * 0.55, z: a.z - a.nz * 0.55 }, b2 = { x: b.x - b.nx * 0.55, z: b.z - b.nz * 0.55 }, a3 = { x: a.x - a.nx * 0.7, z: a.z - a.nz * 0.7 }, b3 = { x: b.x - b.nx * 0.7, z: b.z - b.nz * 0.7 };
      for (const q of [a2, b2, b3, a2, b3, a3]) cv.v(q.x, y + h - 0.05, q.z, 0, -1, 0, 0, 0); }
    add(cv.geo(), own(new THREE.MeshBasicMaterial({ color: 0xffd9a8, toneMapped: false })), false);
    // furniture: a light sofa facing the view, a walnut and stone table, a rug, a lounge chair, a floor lamp
    const at = (a, b, hh = 0) => V(F.x + n.x * a + t.x * b, y + hh, F.z + n.z * a + t.z * b), yaw = Math.atan2(n.x, n.z);
    const rb = (w, hh, d, r = 0.07) => new RoundedBoxGeometry(w, hh, d, 3, r);
    const fab = own(M(0x8f877d, 0.95)), cush = own(M(0xc9b79c, 0.95)), stone = own(M(0xe4dacb, 0.3)), walnut = own(M(0x4b3424, 0.5)), leather = own(M(0x5b3a26, 0.55));
    const rugM = own(M(0x8c8276, 1)), metal = own(M(0x2b2723, 0.35, 0.7)), shade = own(new THREE.MeshStandardMaterial({ color: 0xfff1dc, emissive: 0xffd6a0, emissiveIntensity: 1.8 }));
    const put = (geo, mat, a, b, hh, rot = 0) => { const m = add(geo, mat); m.position.copy(at(a, b, hh)); m.rotation.y = yaw + rot; return m; };
    const sofaAt = (a, b, w, rot = 0) => { const c = Math.cos(rot), sn = Math.sin(rot), off = (da, db) => [a + da * c + db * sn, b - da * sn + db * c];
      put(rb(w, 0.4, 1.0), fab, ...off(0, 0), 0.2, rot); put(rb(w, 0.48, 0.24), fab, ...off(-0.42, 0), 0.62, rot);
      for (const sd of [-1, 1]) put(rb(0.24, 0.58, 1.0), fab, ...off(0, sd * (w / 2 - 0.12)), 0.29, rot);
      for (const sd of [-0.28, 0.28]) put(rb(0.5, 0.4, 0.14, 0.06), cush, ...off(-0.26, sd * w), 0.62, rot); };
    const lamp = (a, b) => { put(new THREE.CylinderGeometry(0.018, 0.018, 1.45, 8), metal, a, b, 0.73); put(new THREE.CylinderGeometry(0.17, 0.24, 0.3, 24, 1, true), shade, a, b, 1.5); put(new THREE.CylinderGeometry(0.2, 0.2, 0.03, 20), metal, a, b, 0.015); };
    const back = f.back;
    if (!pent) {   // seating on the side, the middle open towards the glass
      put(new THREE.BoxGeometry(3.6, 0.02, 2.8), rugM, -back * 0.4, -0.9, 0.012);
      sofaAt(-back * 0.42, -2.5, 2.5, -Math.PI / 2);
      put(rb(1.0, 0.28, 0.62, 0.03), walnut, -back * 0.4, -0.9, 0.14); put(rb(1.1, 0.05, 0.7, 0.02), stone, -back * 0.4, -0.9, 0.3);
      put(rb(0.8, 0.36, 0.85), leather, -back * 0.36, 1.0, 0.2, -Math.PI / 2 - 0.6); put(rb(0.8, 0.5, 0.18), leather, -back * 0.36 - 0.33 * Math.sin(0.6), 1.0 + 0.33 * Math.cos(0.6), 0.55, -Math.PI / 2 - 0.6);
      lamp(-0.9, -3.0);
    } else {
      put(new THREE.BoxGeometry(5.0, 0.02, 4.6), rugM, -back * 0.42, 0, 0.012);
      sofaAt(-back * 0.42, -3.1, 3.2, -Math.PI / 2); sofaAt(-back * 0.42, 3.1, 3.2, Math.PI / 2);
      put(rb(1.6, 0.28, 0.9, 0.03), walnut, -back * 0.42, 0, 0.14); put(rb(1.7, 0.05, 1.0, 0.02), stone, -back * 0.42, 0, 0.3);
      for (const b of [-3.6, 3.6]) put(rb(0.7, 0.26, 1.9, 0.05), own(M(0xf1ede6, 0.8)), PIN * 0.4, b, 0.16);
      lamp(-back * 0.7, 4.4); lamp(-back * 0.7, -4.4);
    }
    scene.add(G); room = G;
    roomLight.position.copy(f.E).addScaledVector(n, back * 0.5); roomLight.position.y = y + h - 1.1; roomLight.intensity = (pent ? 110 : 60) * LK.roomI; roomLight.visible = true;
  }
  function setInside(kind) {   // null | 'unit' | 'pent'
    if (!kind) { clearGroup(room); room = null; roomLight.visible = false; }
    glassMesh.visible = !kind; if (lobbyMesh) lobbyMesh.visible = !kind;
    if (kind === 'unit') buildRoom(S.level, S.unit, false); else if (kind === 'pent') buildRoom(PENL, 0, true);
    S.inside = kind || '';
  }
  function setCut(L) { CUT.constant = L ? LY[L] + 1.05 : 1e6; if (L) buildPlan(L); else clearPlan(); }

  /* =====================================================================
     FLOOR PICKER: tower > floor > residence (view) > upgrade > reservation
     ===================================================================== */
  const ui = { top: $('top'), sheet: $('sheet'), chips: $('chips'), tip: $('tip'), toast: $('toast'), card: $('card'), title: $('stepTitle'), fl: $('flabel') };
  document.documentElement.lang = C.lang || 'en';
  document.title = (C.name || 'Tower') + ' · ' + (TX.stepTower || 'Choose your floor');
  $('venue').textContent = [C.name, C.city].filter(Boolean).join(' · ');
  const root = document.documentElement.style;
  root.setProperty('--accent', '#' + ACCENT.getHexString());
  { const c = ACCENT, l = 0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b; root.setProperty('--on-accent', l > 0.3 ? '#1b1408' : '#fff'); }

  const S = { step: 'tower', level: -1, unit: -1, hoverLevel: -1, hoverUnit: -1, pent: false, inside: '', thumb: '', pentThumb: '' };
  const STEPS = ['tower', 'floor', 'unit', 'upgrade', 'card'];
  const TITLES = { tower: TX.stepTower, floor: TX.stepFloor, unit: TX.stepUnit, upgrade: TX.stepUpgrade, travel: TX.stepUpgrade, pent: TX.stepPenthouse, card: TX.stepCard };
  const avail = L => { const f = freeOn(L); return f <= 0 ? [TX.soldOut, 'no'] : [`${f} ${TX.of} ${UPF} ${TX.available}`, f <= 2 ? 'few' : 'ok']; };
  const selectable = L => isRes(L) && freeOn(L) > 0;

  // ---- cameras: fit points in the free part of the screen ----
  const fitCam = new THREE.PerspectiveCamera();
  function pads(side) {
    const w = innerWidth, wide = w >= 760, top = ui.top.offsetHeight + 10, sh = ui.sheet.classList.contains('on') ? ui.sheet.offsetHeight : 0;
    if (wide) return { top, bottom: 28, left: side ? parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--sheet-w')) + 56 : 28, right: 28 };
    return { top, bottom: (sh ? sh + 16 : 0) + 18, left: 12, right: 12 };
  }
  function fit(points, dir, fov, mx, side) {
    const w = innerWidth, h = innerHeight, pd = pads(side), ox = 0, oy = (pd.bottom - pd.top) / 2;   // never shift sideways: a sideways shift makes moves swing
    const tgt = V(0, 0, 0); points.forEach(p => tgt.add(p)); tgt.multiplyScalar(1 / points.length);
    fitCam.fov = fov; fitCam.aspect = w / h; fitCam.near = 0.3; fitCam.far = 80000; fitCam.setViewOffset(w, h, -ox, oy, w, h); fitCam.updateProjectionMatrix();
    const x0 = -1 + 2 * pd.left / w, x1 = 1 - 2 * pd.right / w, y0 = -1 + 2 * pd.bottom / h, y1 = 1 - 2 * pd.top / h, cx = 0, cy = (y0 + y1) / 2, hx = Math.min(-x0, x1) * mx, hy = (y1 - y0) / 2 * mx;
    const d = dir.clone().normalize(), p = V(0, 0, 0);
    const ok = dist => { fitCam.position.copy(tgt).addScaledVector(d, dist); fitCam.lookAt(tgt); fitCam.updateMatrixWorld();
      for (const q of points) { p.copy(q).project(fitCam); if (p.z > 1 || Math.abs(p.x - cx) > hx || Math.abs(p.y - cy) > hy) return false; } return true; };
    let lo = 2, hi = 30000; for (let k = 0; k < 44; k++) { const m = (lo + hi) / 2; if (ok(m)) hi = m; else lo = m; }
    return { p: tgt.clone().addScaledVector(d, hi), q: tgt, fov, ox, oy };
  }
  function viewOf(step, L = S.level, mx = 0.5) {
    const portrait = innerWidth < innerHeight;
    if (step === 'tower') { const pts = []; for (const p of polyAt(1, BAL + 3)) pts.push(V(p.x, 0, p.z)); for (const p of polyAt(sTop, BAL + 1)) pts.push(V(p.x, CROWN_TOP, p.z));
      return fit(pts, dirAE(AZ, 0.15), portrait ? 36 : 28, 0.93, false); }
    if (step === 'floor') { const s = scaleOf(L), pts = []; for (const p of polyAt(s, dS(L) + 0.6)) { pts.push(V(p.x, LY[L], p.z)); pts.push(V(p.x, LY[L] + 1.7, p.z)); }
      return fit(pts, dirAE(AZ, 0.68), portrait ? 42 : 32, 0.94, true); }
    if (step === 'approach') { const s = scaleOf(L), pts = []; for (const p of polyAt(s, dS(L) + 1)) { pts.push(V(p.x, LY[L] - LH[L] * 2, p.z)); pts.push(V(p.x, LY[L] + LH[L] * 3, p.z)); }
      return fit(pts, dirAE(AZ, 0.15), portrait ? 36 : 28, mx, false); }
    if (step === 'ext') { const s = scaleOf(L), pts = []; for (const p of polyAt(s, dS(L) + 1)) { pts.push(V(p.x, LY[L] - 2, p.z)); pts.push(V(p.x, LY[L] + LH[L] + 2, p.z)); }
      return fit(pts, dirAE(AZ, 0.05), portrait ? 40 : 32, 0.55, false); }
    const pent = step === 'pent' || (step === 'card' && S.pent), f = roomFrame(pent ? PENL : L, pent, S.unit), pd = pads(false);
    const p = f.E.clone(); p.y += pent ? 1.65 : 1.55;
    return { p, q: p.clone().addScaledVector(f.n, 60).add(V(0, -3.6, 0)), fov: portrait ? (pent ? 78 : 74) : (pent ? 62 : 58), ox: 0, oy: (pd.bottom - pd.top) / 2 * 0.6 };
  }

  // ---- camera moves: straight lines, smooth start and stop, no roll ----
  let tw = null, curOX = 0, curOY = 0, base = null, idle0 = 0; const MOVES = [];
  const curQ = V(0, TOP / 2, 0);
  function applyCam(p, q, fov, ox, oy) { camera.position.copy(p); curQ.copy(q); camera.fov = fov; curOX = ox; curOY = oy; camera.setViewOffset(innerWidth, innerHeight, -ox, oy, innerWidth, innerHeight); camera.updateProjectionMatrix(); camera.lookAt(q); }
  function setView(v) { tw = null; base = { p: v.p.clone(), q: v.q.clone(), fov: v.fov, ox: v.ox, oy: v.oy }; idle0 = performance.now(); applyCam(v.p, v.q, v.fov, v.ox, v.oy); }
  function moveTo(v, opt = {}) {
    if (opt.instant || REDUCED || SHOT) { setView(v); if (opt.done) opt.done(); return; }
    const p0 = camera.position.clone(), q0 = curQ.clone(), d0 = p0.distanceTo(q0), d1 = v.p.distanceTo(v.q);
    const dur = opt.dur || clamp(1000 + 420 * Math.abs(Math.log(d1 / d0)) + 4 * q0.distanceTo(v.q), 1300, 2600);
    base = null; tw = { t0: performance.now(), dur, p0, q0, f0: camera.fov, ox0: curOX, oy0: curOY, v, done: opt.done }; MOVES.push({ step: S.step, t0: Math.round(tw.t0), dur: Math.round(dur) });
  }
  function stepTween(now) {
    if (!tw) return; const k = clamp((now - tw.t0) / tw.dur, 0, 1), e = smooth(k), v = tw.v;
    const q = tw.q0.clone().lerp(v.q, e), a = tw.p0.clone().sub(tw.q0), b = v.p.clone().sub(v.q), da = a.length(), db = b.length();
    const dir = a.multiplyScalar(1 / da).lerp(b.multiplyScalar(1 / db), e).normalize(), d = Math.exp(lerp(Math.log(da), Math.log(db), e));
    applyCam(q.clone().addScaledVector(dir, d), q, lerp(tw.f0, v.fov, e), lerp(tw.ox0, v.ox, e), lerp(tw.oy0, v.oy, e));
    if (k >= 1) { const done = tw.done; setView(v); if (done) done(); }
  }
  // ---- soft fades between views (a picture of the last frame fading out over the new one) ----
  const fadeCv = $('fade'), fctx = fadeCv.getContext('2d'); let fade = null;
  function cut(fn, dur = 0.5) {
    if (SHOT || REDUCED) { fn(); return; }
    renderer.render(scene, camera); const k = Math.min(devicePixelRatio || 1, 1.5); fadeCv.width = Math.round(innerWidth * k); fadeCv.height = Math.round(innerHeight * k);
    fctx.drawImage(renderer.domElement, 0, 0, fadeCv.width, fadeCv.height); fadeCv.style.opacity = '1';
    fn(); fade = { t0: performance.now(), dur: dur * 1000 };
  }
  function stepFade(now) { if (!fade) return; const k = clamp((now - fade.t0) / fade.dur, 0, 1); fadeCv.style.opacity = String(1 - smooth(k)); if (k >= 1) { fade = null; fadeCv.style.opacity = '0'; } }
  const timers = []; const later = (s, fn) => timers.push({ at: performance.now() + s * 1000, fn });
  function runLater(now) { for (let i = timers.length - 1; i >= 0; i--) if (now >= timers[i].at) { const f = timers[i].fn; timers.splice(i, 1); f(); } }
  const busy = () => !!tw || !!fade || timers.length > 0;

  // ---- labels ----
  let chipList = [];
  function setChips(items) {
    for (const c of chipList) { const el = c.el; el.classList.remove('on'); el.style.pointerEvents = 'none'; setTimeout(() => el.remove(), 350); }
    chipList = items.map(it => { const b = document.createElement('button'); b.className = 'chip ' + (it.cls || ''); b.innerHTML = it.html; b.setAttribute('aria-label', it.label || b.textContent);
      b.onclick = e => { e.stopPropagation(); it.onClick(e); }; ui.chips.appendChild(b); requestAnimationFrame(() => b.classList.add('on')); return { el: b, pos: it.pos, k: it.k }; });
  }
  const tmpV = V(0, 0, 0);
  function placeChips() {
    const w = innerWidth, h = innerHeight;
    for (const c of chipList) { tmpV.copy(c.pos).project(camera); c.vis = tmpV.z < 1 && Math.abs(tmpV.x) < 1.05 && Math.abs(tmpV.y) < 1.05; c.x = (tmpV.x + 1) / 2 * w; c.y = (1 - tmpV.y) / 2 * h; if (!c.w) { c.w = c.el.offsetWidth; c.h = c.el.offsetHeight; } }
    const pd = { t: ui.top.offsetHeight + 4, b: h - (ui.sheet.classList.contains('on') && w < 760 ? ui.sheet.offsetHeight + 20 : 0) - 4 };
    for (let it = 0; it < 6; it++) for (let i = 0; i < chipList.length; i++) for (let j = i + 1; j < chipList.length; j++) {
      const a = chipList[i], b = chipList[j]; if (!a.vis || !b.vis) continue;
      const ox = (a.w + b.w) / 2 + 4 - Math.abs(a.x - b.x), oy = (a.h + b.h) / 2 + 4 - Math.abs(a.y - b.y);
      if (ox > 0 && oy > 0) { if (ox < oy) { const s = a.x < b.x ? -1 : 1; a.x += s * ox / 2; b.x -= s * ox / 2; } else { const s = a.y < b.y ? -1 : 1; a.y += s * oy / 2; b.y -= s * oy / 2; } }
    }
    for (const c of chipList) { const x = clamp(c.x, c.w / 2 + 4, w - c.w / 2 - 4), y = clamp(c.y, pd.t + c.h / 2, pd.b - c.h / 2);
      c.el.style.transform = `translate(${x}px, ${y}px) translate(-50%, -50%)`; c.el.style.visibility = c.vis && Math.abs(y - c.y) < 60 && !fade ? 'visible' : 'hidden'; }
    placeLabel();
  }
  // the label next to the lit floor: "Level 32 · from €1.3M"
  let labelL = -1;
  function setLabel(L, now) {   // now = hide at once (a label fading in place while the camera flies reads as a shake)
    labelL = L; const el = ui.fl; if (!(L >= 1)) { if (now) el.classList.add('now'); el.classList.remove('on'); return; }
    let a, b, cls = '';
    if (isPod(L)) { a = TX.lobby; b = `${TX.level} ${L}`; cls = 'info'; }
    else if (isPen(L)) { a = PENT ? PENT.name : TX.level + ' ' + L; b = `${TX.level} ${L} · ${TX.byUpgrade}`; cls = 'info'; }
    else if (!freeOn(L)) { a = `${TX.level} ${L}`; b = TX.soldOut; cls = 'sold'; }
    else { a = `${TX.level} ${L}`; b = `${TX.from} ${fmtS(fromOn(L))}`; }
    el.className = cls; el.innerHTML = `<b>${esc(a)}</b><small>${esc(b)}</small>`; el.classList.add('on'); el._w = 0;
  }
  function placeLabel() {
    const el = ui.fl; if (labelL < 1 || S.step !== 'tower' || fade) { if (el.classList.contains('on') && (S.step !== 'tower')) el.classList.remove('on'); return; }
    const L = labelL, y = bandMid(L) + (L === hiL ? hiOff : 0), w = innerWidth; let mx = -1e9, my = 0;
    for (const p of polyAt(scaleOf(L), dS(L))) { tmpV.set(p.x, y, p.z).project(camera); const sx = (tmpV.x + 1) / 2 * w; if (sx > mx) { mx = sx; my = (1 - tmpV.y) / 2 * innerHeight; } }
    if (!el._w) el._w = el.offsetWidth; const lw = el._w, x = clamp(mx + 30, 8, w - lw - 8);
    el.style.transform = `translate(${x}px, ${my}px) translate(0, -50%)`;
  }
  function refreshHi() {
    if (S.step === 'floor' && !plan) { showHi(S.level); setLabel(-1, true); return; }
    if (S.step !== 'tower') { showHi(-1); setLabel(-1); return; }
    const L = S.hoverLevel >= 1 ? S.hoverLevel : S.level; showHi(L, L >= 1 && !selectable(L)); if (L !== labelL) setLabel(L);
  }

  // ---- the bottom sheet ----
  function sheet(html, actions = {}) {
    if (ui.sheet.classList.contains('on') && ui.sheet.innerHTML && !SHOT && !REDUCED && !document.body.classList.contains('boot')) {   // a soft crossfade, never a jump
      const r = ui.sheet.getBoundingClientRect(), g = ui.sheet.cloneNode(true); g.removeAttribute('id'); g.className = 'sheetbox sheet-ghost'; g.setAttribute('aria-hidden', 'true');
      Object.assign(g.style, { left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' }); document.body.appendChild(g); setTimeout(() => g.remove(), 400);
      if (html) { ui.sheet.classList.remove('swap'); void ui.sheet.offsetWidth; ui.sheet.classList.add('swap'); }
    }
    ui.sheet.innerHTML = html; ui.sheet.classList.toggle('on', !!html);
    ui.sheet.querySelectorAll('[data-a]').forEach(b => b.onclick = e => { e.stopPropagation(); const f = actions[b.dataset.a]; if (f) f(b); });
  }
  let toastT = 0;
  function toast(t) { ui.toast.textContent = t; ui.toast.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => ui.toast.classList.remove('on'), 2200); }
  function header() {
    ui.title.textContent = TITLES[S.step] || ''; $('back').hidden = S.step === 'tower';
    const idx = Math.max(0, STEPS.indexOf({ travel: 'upgrade', pent: 'upgrade' }[S.step] || S.step));
    document.querySelectorAll('#dots li').forEach((li, k) => li.classList.toggle('on', k <= idx));
  }

  // ---- the steps ----
  function towerSheet() {
    if (S.level < 1) {
      const rows = ZONES.map((z, i) => ({ z, i })).reverse().map(({ z, i }) => { const zi = ZINFO[i], lv = zi.levels, sold = !zi.free;
        return `<li><button class="zrow${sold ? ' sold' : ''}" data-a="z${i}"><b>${esc(z.name)}</b><span>${lv.length ? `${esc(TX.levels)} ${lv[0]}–${lv[lv.length - 1]} · ` : ''}${sold ? esc(TX.soldOut) : esc(TX.from) + ' ' + fmtS(zi.from)}</span></button></li>`; }).join('');
      const pent = PENT ? `<li><button class="zrow pent" data-a="pent"><b>${esc(PENT.name)}</b><span>${esc(TX.level)} ${PENL} · ${esc(TX.byUpgrade)}</span></button></li>` : '';
      const acts = { pent: () => { selectLevel(PENL); toast(TX.penthouseOnly); } };
      ZONES.forEach((z, i) => { acts['z' + i] = () => { const lv = ZINFO[i].levels.filter(selectable); if (!lv.length) { toast(`${z.name} · ${TX.soldOut}`); return; } selectLevel(lv[Math.floor(lv.length / 2)]); }; });
      sheet(`<h2>${esc(TX.stepTower)}</h2><p>${esc(TX.towerHint)}</p><ul class="zones">${pent}${rows}</ul>`, acts);
      return;
    }
    const L = S.level;
    if (!isRes(L)) { sheet(`<p class="kick">${esc(isPen(L) && PENT ? PENT.name : TX.lobby)}</p><h2>${esc(TX.level)} ${L}</h2><p>${esc(isPen(L) ? TX.penthouseOnly : TX.towerHint)}</p>
      <div class="row"><div class="nav">${navBtns(L)}</div></div>`, navActs()); return; }
    const [at, ac] = avail(L), z = ZONES[ZOF[L]];
    sheet(`<p class="kick">${esc(z.name)}</p><h2>${esc(TX.level)} ${L}</h2><p class="av ${ac}">${esc(at)}</p>
      <div class="row"><div class="nav">${navBtns(L)}</div><b class="price"><small>${esc(TX.from)}</small>${fmt(fromOn(L))}</b></div>
      <button class="btn wide" data-a="go"${freeOn(L) ? '' : ' disabled'}>${esc(TX.seeUnits)}</button>`, { ...navActs(), go: () => { if (selectable(L)) enterFloor(L); } });
  }
  const navBtns = L => `<button class="icon" data-a="down" aria-label="${esc(TX.down)}"${L <= FIRST ? ' disabled' : ''}>↓</button><button class="icon" data-a="up" aria-label="${esc(TX.up)}"${L >= NF ? ' disabled' : ''}>↑</button>`;
  const navActs = () => ({ down: () => nudge(-1), up: () => nudge(1) });
  function nudge(dir) {
    if (S.step === 'tower') { const L = clamp((S.level >= 1 ? S.level : Math.round((FIRST + LAST) / 2)) + dir, FIRST, NF); selectLevel(L); return; }
    if (S.step === 'floor' && !busy()) { let L = S.level + dir; while (L >= FIRST && L <= LAST && !selectable(L)) L += dir; if (L < FIRST || L > LAST) return; switchFloor(L); }
  }
  function selectLevel(L) { S.level = L; S.hoverLevel = -1; towerSheet(); refreshHi(); }
  function enterTower(instant) {
    S.step = 'tower'; S.unit = -1; S.pent = false; S.hoverUnit = -1; hideCard(); header(); setChips([]);
    const go = () => { setInside(null); setCut(0); towerSheet(); refreshHi(); };
    if (instant || S.inside || plan) {
      if (instant) { go(); setView(viewOf('tower')); return; }
      if (S.inside) { cut(() => { go(); setView(viewOf('tower')); }, 0.6); return; }
      const L = S.level; cut(() => { go(); setView(viewOf('approach', L)); }, 0.45); later(0.55, () => moveTo(viewOf('tower'))); return;
    }
    go(); moveTo(viewOf('tower'));
  }
  function floorSheet() {
    const L = S.level, z = ZONES[ZOF[L]], [at, ac] = avail(L);
    if (S.unit < 0) { sheet(`<p class="kick">${esc(TX.level)} ${L} · ${esc(z.name)}</p><h2>${esc(TX.stepFloor)}</h2><p>${esc(TX.floorHint)}</p>
      <div class="row"><div class="nav">${navBtns(L)}</div><span class="av ${ac}">${esc(at)}</span></div>`, navActs()); return; }
    const u = UNIT[L][S.unit];
    sheet(`<p class="kick">${esc(TX.level)} ${L} · ${esc(z.name)}</p><h2>${esc(TX.residence)} ${unitName(L, S.unit)}</h2>
      <div class="facts"><span>${esc(beds(u.t.bedrooms))}</span><span>${esc(m2(u.t.size))}</span><span>${esc(viewTxt(S.unit))}</span></div>
      <div class="row"><b class="price">${fmt(u.price)}</b><button class="btn" data-a="go">${esc(TX.seeView)}</button></div>`, { go: () => enterUnit(S.unit) });
  }
  function unitChips() {
    const L = S.level; setChips(UNIT[L].map((u, k) => ({ k, pos: plan.centres[k], cls: u.taken ? 'sold' : k === S.unit ? 'sel' : '', label: `${TX.residence} ${unitName(L, k)}`,
      html: `<b>${unitName(L, k)}</b><small>${u.taken ? esc(TX.sold) : fmtS(u.price)}</small>`, onClick: e => tapUnit(k, e && e.pointerType === 'mouse' ? 'mouse' : (e && e.detail === 0 ? 'key' : 'touch')) })));
  }
  function openFloor(L) { setInside(null); setCut(L); unitChips(); refreshHi(); }
  function enterFloor(L, instant) {
    if (!selectable(L)) return;
    S.step = 'floor'; S.level = L; S.unit = -1; S.hoverUnit = -1; S.pent = false; hideCard(); header(); setChips([]); refreshHi(); floorSheet();
    if (instant) { openFloor(L); setView(viewOf('floor')); return; }
    if (S.inside) { cut(() => { openFloor(L); setView(viewOf('floor')); }, 0.55); return; }
    moveTo(viewOf('approach', L), { done: () => later(0.12, () => cut(() => { openFloor(L); setView(viewOf('floor')); }, 0.5)) });
  }
  function switchFloor(L) { S.level = L; S.unit = -1; S.hoverUnit = -1; floorSheet(); cut(() => { openFloor(L); setView(viewOf('floor')); }, 0.4); }
  function tapUnit(k, type) {
    const u = UNIT[S.level][k]; if (u.taken) { toast(`${TX.residence} ${unitName(S.level, k)} · ${TX.sold}`); return; }
    if (type === 'mouse' || type === 'key' || S.unit === k) { S.unit = k; enterUnit(k); return; }
    S.unit = k; floorSheet(); paintPlan(); chipList.forEach(c => c.el.classList.toggle('sel', c.k === k));
  }
  function unitSheet() {
    const L = S.level, u = UNIT[L][S.unit];
    sheet(`<p class="kick">${esc(TX.yourView)} · ${esc(TX.level)} ${L}</p><h2>${esc(TX.residence)} ${unitName(L, S.unit)}</h2>
      <div class="facts"><span>${esc(beds(u.t.bedrooms))}</span><span>${esc(m2(u.t.size))}</span><span>${esc(viewTxt(S.unit))}</span></div>
      <div class="row"><b class="price">${fmt(u.price)}</b><button class="btn" data-a="go">${esc(TX.continue)}</button></div><button class="ghost wide" data-a="change">${esc(TX.changeUnit)}</button>`,
      { go: () => (PENT ? enterUpgrade() : enterCard()), change: () => enterFloor(L) });
  }
  function enterUnit(k, instant) {
    S.step = 'unit'; S.unit = k; S.pent = false; S.thumb = ''; hideCard(); header(); setChips([]); refreshHi(); unitSheet();
    const go = () => { setCut(0); setInside('unit'); setView(viewOf('unit')); };
    if (instant) { go(); S.thumb = snap(); return; }
    cut(go, 0.55); later(0.65, () => { S.thumb = snap(); });
  }
  function enterUpgrade() {
    S.step = 'upgrade'; S.pent = false; hideCard(); header(); setChips([]);
    if (S.inside !== 'unit') { setCut(0); setInside('unit'); setView(viewOf('unit')); if (!S.thumb) S.thumb = snap(); }
    const p = PENT, perks = (p.perks || []).map(x => `<li>${esc(x)}</li>`).join('');
    sheet(`<p class="kick">${esc(p.name)} · ${esc(TX.level)} ${PENL}</p><h2>${esc(TX.upgradeTitle)}</h2>${perks ? `<ul class="perks">${perks}</ul>` : ''}
      <div class="row"><b class="price">+${fmt(p.upgrade)}</b><button class="btn" data-a="yes">${esc(TX.upgradeYes)}</button></div><button class="ghost wide" data-a="no">${esc(TX.upgradeNo)}</button>`,
      { yes: () => goPenthouse(), no: () => { S.pent = false; enterCard(); } });
  }
  function pentSheet() {
    const u = UNIT[S.level][S.unit], p = PENT;
    sheet(`<p class="kick">${esc(TX.penthouseView)}</p><h2>${esc(p.name)}</h2>
      <div class="facts"><span>${esc(beds(p.bedrooms))}</span><span>${esc(m2(p.size))}</span><span>${esc(TX.level)} ${PENL}</span><span>${esc(TX.viewAll)}</span></div>
      <div class="row"><b class="price">${fmt(u.price + p.upgrade)}<small>${esc(TX.inclUpgrade)}</small></b><button class="btn" data-a="go">${esc(TX.continue)}</button></div>
      <button class="ghost wide" data-a="no">${esc(TX.upgradeNo)}</button>`, { go: () => enterCard(), no: () => { S.pent = false; cut(() => { setInside('unit'); setView(viewOf('unit')); }, 0.5); enterCard(); } });
  }
  function goPenthouse(instant) {   // out of the window, straight up the facade, into the penthouse
    S.pent = true; S.pentThumb = ''; hideCard();
    if (instant) { S.step = 'pent'; header(); setChips([]); setCut(0); setInside('pent'); setView(viewOf('pent')); S.pentThumb = snap(); pentSheet(); return; }
    S.step = 'travel'; header(); sheet('');
    cut(() => { setInside(null); setView(viewOf('approach', S.level, 0.32)); }, 0.45);   // outside that floor, then up the facade and in towards the penthouse
    later(0.6, () => moveTo(viewOf('approach', PENL, 0.8), { dur: clamp(1500 + (LY[PENL] - LY[S.level]) * 9, 1600, 3000),
      done: () => later(0.2, () => { S.step = 'pent'; header(); cut(() => { setInside('pent'); setView(viewOf('pent')); }, 0.55); pentSheet(); later(0.65, () => { S.pentThumb = snap(); }); }) }));
  }
  function enterCard(instant) {
    S.step = 'card'; header(); setChips([]); sheet('');
    const L = S.level, u = UNIT[L][S.unit], p = PENT, pent = S.pent && p, price = u.price + (pent ? p.upgrade : 0);
    const f = (k, v, w2) => `<div class="fld${w2 ? ' w2' : ''}"><span>${esc(k)}</span><b>${esc(v)}</b></div>`;
    const fields = pent ? [f(TX.level, PENL), f(TX.residence, p.name, true), f(TX.size, m2(p.size)), f(TX.bedrooms, p.bedrooms), f(TX.view, TX.viewAll)]
      : [f(TX.level, L), f(TX.residence, unitName(L, S.unit)), f(TX.size, m2(u.t.size)), f(TX.bedrooms, u.t.bedrooms), f(TX.view, viewTxt(S.unit), true)];
    const img = pent ? S.pentThumb : S.thumb;
    ui.card.innerHTML = `<div class="cd" role="dialog" aria-label="${esc(TX.stepCard)}">
      <div class="cd-view">${img ? `<img src="${img}" alt="">` : ''}<span class="tag"><i></i>${esc(pent ? TX.penthouseView : TX.yourView)}</span></div>
      <div class="cd-body"><p class="kick">${esc(C.city || '')}</p><h2>${esc(C.name || '')}</h2><div class="grid">${fields.join('')}</div></div>
      <div class="cd-stub"><div class="mono" aria-hidden="true">${esc((C.shortName || C.name || '').slice(0, 3))}</div><div class="tot"><span>${esc(TX.total)}</span><b>${fmt(price)}</b>${pent ? `<small>${esc(TX.inclUpgrade)}</small>` : ''}</div></div>
      <div class="cd-act"><button class="btn wide" data-t="ok">${esc(C.checkoutUrl ? TX.pay : TX.reserve)}</button><button class="ghost wide" data-t="again">${esc(TX.anotherFloor)}</button></div>
      ${TX.note ? `<p class="cd-note">${esc(TX.note)}</p>` : ''}<div class="stamp">${esc(TX.reserved)}</div></div>`;
    ui.card.hidden = false; if (instant || SHOT) ui.card.classList.add('on'); else requestAnimationFrame(() => requestAnimationFrame(() => ui.card.classList.add('on')));
    ui.card.querySelector('[data-t=ok]').onclick = () => {
      if (C.checkoutUrl) { const q = new URL(C.checkoutUrl, location.href); Object.entries({ tower: C.name || '', level: pent ? PENL : L, unit: pent ? p.name : unitName(L, S.unit), size: pent ? p.size : u.t.size, penthouse: pent ? 1 : 0, price }).forEach(([k, v]) => q.searchParams.set(k, v)); location.href = q.toString(); return; }
      ui.card.querySelector('.cd').classList.add('booked'); };
    ui.card.querySelector('[data-t=again]').onclick = () => enterTower();
  }
  function hideCard() { ui.card.classList.remove('on'); ui.card.hidden = true; ui.card.innerHTML = ''; }
  function back() {
    if (busy()) return;
    if (S.step === 'tower') { if (S.level >= 1) { S.level = -1; towerSheet(); refreshHi(); } }
    else if (S.step === 'floor') enterTower();
    else if (S.step === 'unit') enterFloor(S.level);
    else if (S.step === 'upgrade') { S.step = 'unit'; header(); unitSheet(); }
    else if (S.step === 'pent') { S.pent = false; cut(() => { setInside('unit'); setView(viewOf('unit')); }, 0.5); enterUpgrade(); }
    else if (S.step === 'card') { hideCard(); if (S.pent) { S.step = 'pent'; header(); pentSheet(); } else if (PENT) enterUpgrade(); else { S.step = 'unit'; header(); unitSheet(); } }
  }
  $('back').onclick = back;
  addEventListener('keydown', e => {
    if (e.key === 'Escape') back();
    if ((e.key === 'p' || e.key === 'P') && !e.metaKey && !e.ctrlKey) savePng();
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') { e.preventDefault(); nudge(e.key === 'ArrowUp' ? 1 : -1); }
  });

  // the view as a small picture for the card
  function snap() {
    renderer.render(scene, camera); const src = renderer.domElement, w = 720, h = 405, c = canvas(w, h), sw = src.width, sh = src.height, k = Math.min(sw / w, sh / h);
    const ty = (1 - tmpV.copy(curQ).project(camera).y) / 2 * sh;
    c.getContext('2d').drawImage(src, (sw - w * k) / 2, clamp(ty - h * k * 0.5, 0, sh - h * k), w * k, h * k, 0, 0, w, h);
    try { return c.toDataURL('image/jpeg', 0.85); } catch (e) { return ''; }
  }
  // P saves a clean frame of the 3D (no interface) for the photoreal step
  function savePng() { renderer.render(scene, camera); const a = document.createElement('a'); a.download = `tower-${S.step}.png`; a.href = renderer.domElement.toDataURL('image/png'); a.click(); }

  // ---- pointer: hover with the mouse, tap with the finger ----
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  function rayAt(x, y) { const r = renderer.domElement.getBoundingClientRect(); ndc.set((x - r.left) / r.width * 2 - 1, -(y - r.top) / r.height * 2 + 1); ray.setFromCamera(ndc, camera); return ray; }
  function levelAt(x, y) { const h = rayAt(x, y).intersectObject(pickMesh, false)[0]; return h ? levelOfY(h.point.y) : -1; }
  function unitAt(x, y) {
    if (!plan) return -1; const r = rayAt(x, y).ray, yy = LY[plan.L] + 0.05; if (Math.abs(r.direction.y) < 1e-4) return -1;
    const t = (yy - r.origin.y) / r.direction.y; if (t <= 0) return -1; const px = r.origin.x + r.direction.x * t, pz = r.origin.z + r.direction.z * t;
    const th = Math.atan2(px, pz), rr = Math.hypot(px, pz), s = scaleOf(plan.L); if (rr > rayHit(polyAt(s, dG(plan.L)), th).r + 0.3 || rr < rayHit(polyAt(s * 0.34, 0), th).r) return -1;
    return ((Math.floor((th - (thetaOf(0) - WEDGE / 2)) / WEDGE) % UPF) + UPF) % UPF;
  }
  let pend = null, down = null;
  const cvs = renderer.domElement;
  cvs.addEventListener('pointermove', e => { if (e.pointerType === 'mouse') pend = [e.clientX, e.clientY]; });
  cvs.addEventListener('pointerleave', () => { ui.tip.classList.remove('on'); if (S.hoverLevel >= 0 || S.hoverUnit >= 0) { S.hoverLevel = -1; S.hoverUnit = -1; refreshHi(); paintPlan(); } });
  cvs.addEventListener('pointerdown', e => { down = [e.clientX, e.clientY]; });
  cvs.addEventListener('pointerup', e => { if (!down || Math.hypot(e.clientX - down[0], e.clientY - down[1]) > 8 || busy()) return; tap(e.clientX, e.clientY, e.pointerType); });
  function showTip(x, y, a, b) { ui.tip.innerHTML = `<b>${esc(a)}</b><small>${esc(b)}</small>`; ui.tip.style.transform = `translate(${x}px, ${y}px) translate(-50%, calc(-100% - 18px))`; ui.tip.classList.add('on'); }
  function hover(x, y) {
    if (busy()) return; let tip = false, point = false;
    if (S.step === 'tower') { const L = levelAt(x, y); if (L !== S.hoverLevel) { S.hoverLevel = L; refreshHi(); } point = L >= 1 && selectable(L); }
    else if (S.step === 'floor') { const k = unitAt(x, y); if (k !== S.hoverUnit) { S.hoverUnit = k; paintPlan(); }
      if (k >= 0) { const u = UNIT[S.level][k]; tip = true; point = !u.taken; showTip(x, y, `${TX.residence} ${unitName(S.level, k)}`, u.taken ? TX.sold : `${beds(u.t.bedrooms)} · ${m2(u.t.size)} · ${fmt(u.price)}`); } }
    if (!tip) ui.tip.classList.remove('on');
    cvs.style.cursor = point ? 'pointer' : '';
  }
  function tap(x, y, type) {
    if (S.step === 'tower') { const L = levelAt(x, y); if (L < 1) return;
      if (isPod(L)) { selectLevel(L); toast(TX.lobby); return; }
      if (isPen(L)) { selectLevel(L); toast(TX.penthouseOnly); return; }
      if (!freeOn(L)) { selectLevel(L); toast(`${TX.level} ${L} · ${TX.soldOut}`); return; }
      if (type === 'mouse' || S.level === L) enterFloor(L); else selectLevel(L); }
    else if (S.step === 'floor') { const k = unitAt(x, y); if (k >= 0) tapUnit(k, type); }
  }

  // ---- render loop ----
  let lastNow = 0;
  function frame(now) {
    const dt = clamp((now - (lastNow || now)) / 1000, 0, 0.1); lastNow = now;
    runLater(now);
    if (bootFrames && --bootFrames === 0) document.body.classList.remove('boot');
    if (hiOff) { hiOff *= Math.exp(-dt / 0.07); if (Math.abs(hiOff) < 0.01) hiOff = 0; hiMesh.position.y = hiOff; }
    if (plan) for (const m of plan.tiles) if (m.userData.to) m.material.color.lerp(m.userData.to, 1 - Math.exp(-dt / 0.08));
    if (pend) { hover(pend[0], pend[1]); pend = null; }
    stepTween(now);
    renderer.render(scene, camera); stepFade(now); placeChips();
  }
  function resize() {
    renderer.setSize(innerWidth, innerHeight); camera.aspect = innerWidth / innerHeight;
    if (!tw && !timers.length) { const st = { tower: 'tower', floor: 'floor', unit: 'unit', upgrade: 'unit', card: S.pent ? 'pent' : 'unit', pent: 'pent' }[S.step]; if (st) setView(viewOf(st)); }
  }
  addEventListener('resize', resize); renderer.setSize(innerWidth, innerHeight);

  // ---- first step, or jump to one for tests: ?step=tower|floor|unit|upgrade|penthouse|card (+ &level=32 &unit=B &pent=1) ----
  function defaults() {
    let L = +Q.get('level');
    if (!(L >= FIRST && L <= LAST && selectable(L))) { const want = Math.round(FIRST + (LAST - FIRST) * 0.78), seaFree = c => UNIT[c].some(u => !u.taken && VIEWK[u.k] === 0); L = -1;
      for (const test of [seaFree, selectable]) for (let d = 0; d <= NF && L < 0; d++) for (const c of [want + d, want - d]) if (L < 0 && c >= FIRST && c <= LAST && selectable(c) && test(c)) L = c; }
    const uq = (Q.get('unit') || '').toUpperCase(), ui0 = !uq ? -1 : LETTERS.indexOf(uq) >= 0 ? LETTERS.indexOf(uq) : +uq;
    let k = Number.isInteger(ui0) && ui0 >= 0 && ui0 < UPF && L > 0 && !UNIT[L][ui0].taken ? ui0 : -1;
    if (k < 0 && L > 0) { const fr = UNIT[L].filter(u => !u.taken); k = (fr.find(u => VIEWK[u.k] === 0) || fr[0]).k; }
    return { L, k };
  }
  const startAt = Q.get('step') || 'tower';
  let bootFrames = 0; if (Q.get('step') || Q.get('level')) { document.body.classList.add('boot'); bootFrames = 3; }   // deep links land at once, with no half-finished animation
  enterTower(true);
  if (startAt === 'tower' && Q.get('level')) selectLevel(clamp(+Q.get('level'), 1, NF));
  else if (startAt !== 'tower') {
    const d = defaults();
    if (d.L > 0) {
      enterFloor(d.L, true);
      if (startAt !== 'floor') { S.unit = d.k; if (startAt === 'pick') { floorSheet(); paintPlan(); unitChips(); }
        else { enterUnit(d.k, true);
          if (startAt !== 'unit' && PENT) { enterUpgrade();
            if (startAt === 'penthouse' || (startAt === 'card' && Q.get('pent') === '1')) goPenthouse(true);
            if (startAt === 'card') enterCard(true); }
          else if (startAt === 'card') enterCard(true); } }
    }
  }
  if (Q.get('clean') === '1') document.body.classList.add('clean');
  if (SHOT) document.body.classList.add('shot');   // test screenshots: no transitions
  setTimeout(() => { const l = $('loader'); if (l) l.remove(); }, 700);
  renderer.setAnimationLoop(frame);
  document.body.classList.add('ready');

  const info = () => {
    const all = []; for (let L = FIRST; L <= LAST; L++) all.push(...UNIT[L]);
    return { name: C.name, floors: NF, levels: { podium: POD ? [1, POD] : null, residences: [FIRST, LAST], penthouse: PEN ? [PENL, NF] : null },
      height: Math.round(CROWN_TOP), roof: Math.round(TOP), floorHeight: +FH.toFixed(2), footprint: { shape: SHAPE, width: 2 * HW, depth: 2 * HD }, facade: FAC, crown: CROWN, surroundings: SURR,
      units: all.length, unitsPerFloor: UPF, free: all.filter(u => !u.taken).length,
      zones: ZONES.map((z, i) => ({ name: z.name, levels: ZINFO[i].levels.length ? [ZINFO[i].levels[0], ZINFO[i].levels[ZINFO[i].levels.length - 1]] : [], units: ZINFO[i].units, free: ZINFO[i].free, from: ZINFO[i].from })),
      priceRange: [Math.min(...all.map(u => u.price)), Math.max(...all.map(u => u.price))],
      penthouse: PENT ? { name: PENT.name, level: PENL, size: PENT.size, upgrade: PENT.upgrade } : null };
  };
  const screenOf = (L, k) => {   // screen point of a level (or of residence k on the open floor), for tests and recordings
    if (k != null && plan) { tmpV.copy(plan.centres[k]).project(camera); }
    else { const p = rayHit(polyAt(scaleOf(L), dS(L)), AZ); tmpV.set(p.x, LY[L] + (LH[L] - SLAB) / 2, p.z).project(camera); }
    return [Math.round((tmpV.x + 1) / 2 * innerWidth), Math.round((1 - tmpV.y) / 2 * innerHeight)];
  };
  window.tower = { info, screenOf, state: S, config: C, busy, moves: MOVES, go: s => { const d = defaults(); ({ tower: () => enterTower(), floor: () => enterFloor(d.L) })[s]?.(); } };
  console.log('tower ready', JSON.stringify(info()));
};
