@echo off
rem Choose Your Floor kit - double click to start the local server and open SAMAR in Chrome.
cd /d "%~dp0"
rem A real Python 3 answers "import sys". The Microsoft Store shortcut (WindowsApps\python.exe)
rem fails when it gets arguments, so it is skipped and the Store never opens.
set "PY="
where py >nul 2>nul || goto :trypython
py -3 -c "import sys; assert sys.version_info[0]==3" >nul 2>nul || goto :trypython
set "PY=py -3"
goto :run
:trypython
where python >nul 2>nul || goto :trypython3
python -c "import sys; assert sys.version_info[0]==3" >nul 2>nul || goto :trypython3
set "PY=python"
goto :run
:trypython3
where python3 >nul 2>nul || goto :missing
python3 -c "import sys; assert sys.version_info[0]==3" >nul 2>nul || goto :missing
set "PY=python3"
:run
%PY% tools\serve.py --open
if errorlevel 1 pause
goto :eof
:missing
echo.
echo Python 3 is missing.
echo Open Claude Code in this folder and send prompts/02-0-install.txt
echo (Claude checks what the kit needs and installs it), then double click Start again.
echo.
pause
exit /b 1
