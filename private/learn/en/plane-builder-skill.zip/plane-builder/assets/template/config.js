// THE ONE FILE TO CHANGE: your flight, your cities and your prices.
// Everything on the page (the intro card, the class tickets, the boarding passes) reads from here.
// Prices are written as text, the way they show on the tickets.
window.FLIGHT = {
  number: 'Flight 001', date: 'Tue 19 Nov',
  from: 'DXB', fromName: 'Dubai',
  to: 'LAX', toName: 'Los Angeles',
  departs: '08:40', arrives: '13:55', duration: '16h 15m',
  currency: 'USD',
  price: {
    E: '1,190',   // Economy, per seat
    P: '2,640',   // Premium economy, per seat
    F: '11,800',  // First, per suite
    R: '28,000',  // The Residence, one per flight
  },
}
