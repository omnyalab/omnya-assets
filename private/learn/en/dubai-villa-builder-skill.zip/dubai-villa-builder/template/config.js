// The Dubai Villa page: everything you are likely to change lives in this file.
// Words, the chosen villa, prices, currency, the booking link and the colours.
// The streets, the villa tags along the street and their sample numbers and prices are in dati.json (see references/data.md).
// The villa numbers, availability and prices on this page are EXAMPLES. Bedrooms, built-up area and the distance to the
// Burj Khalifa describe the real Golf Place Vistas villa type B2 (Emaar brochure). Map data © OpenStreetMap contributors (ODbL).

export default {
  // ---------------------------------------------------------------- brand
  pageTitle: 'Choose your villa · Dubai Hills',  // the browser tab
  loading: 'Dubai Hills · loading',               // shown while the film loads
  developer: '',                                  // e.g. 'Emerald Estates'. Empty = no signature (as in the reel). Set = small "Presented by …" on the last card
  mapCredit: 'Map data © OpenStreetMap contributors', // small line while choosing the street (the street shapes come from OpenStreetMap, ODbL). Keep it
  bookingUrl: 'https://example.com/book-a-viewing', // where "Book a private viewing" goes (a page, a WhatsApp link, or mailto:you@yourdomain.com)

  // ---------------------------------------------------------------- the place
  areaTitle: 'Dubai Hills Estate',   // small orange line above "Drop your pin"
  area: 'Dubai Hills',               // grey word next to the community on the cards

  // ---------------------------------------------------------------- prices
  currency: 'AED',                   // written before every price: AED 38.9M
  showPrices: false,                 // false = every price reads priceText (the reel); true = the sample prices from this file and dati.json
  priceText: 'On request',

  // ---------------------------------------------------------------- the villa you walk into
  villa: {
    number: 27,
    community: 'Golf Place',               // on the villa card, the chip and the last card
    street: 'Golf Place Vistas',           // last card: "Golf Place Vistas · Dubai Hills"
    type: 'Golf Place Vistas · B2',        // under the big number on the villa card
    urgency: '4 left on this street',      // orange line on the villa card (EXAMPLE)
    bedrooms: 6,
    builtUp: '8,531 ft²',
    view: 'Golf · Burj',                   // short, for the villa card
    viewLong: 'Golf · Burj Khalifa',       // long, for the last card
    price: 38900000,                       // EXAMPLE, only shown when showPrices is true
    status: 'Available',                   // next to the green dot on the last card
  },

  // ---------------------------------------------------------------- landmark seen from the pool
  landmark: { name: 'Burj Khalifa', line: '7.95 km from your pool', distance: '7.95 km', label: 'BURJ KHALIFA' },

  // ---------------------------------------------------------------- words, step by step
  text: {
    dropPin: 'Drop your pin',
    chooseStreet: 'Choose your street',
    yourStreet: 'YOUR STREET',
    allStreets: 'ALL STREETS',
    allStreetsName: 'Around the golf course',
    allStreetsLine: 'villas available here',
    allStreetsBedrooms: '4–7',
    leftOne: 'villa left on this street',
    leftMany: 'villas left on this street',
    dropHint: 'Drop your pin on a street',
    clickHint: 'Click the street to drop your pin',
    flyDown: 'Fly down to the street   →',
    comingSoon: 'Street view coming soon',
    scroll: 'Scroll down the street',
    sold: 'Sold',
    chooseVilla: 'Choose your villa',
    enter: 'Enter the villa   →',
    ground: 'Ground floor',               // "Villa 27 · Ground floor" above the room names
    garden: 'Private garden',
    gardenLine: 'Burj Khalifa view',
    question: 'Is this your home?',
    yes: 'Yes',
    no: 'No',
    welcome: 'WELCOME HOME',
    book: 'Book a private viewing',
    again: 'Start again',
    presented: 'Presented by',
    labels: { bedrooms: 'BEDROOMS', view: 'VIEW', price: 'PRICE', from: 'FROM', streets: 'STREETS', builtUp: 'BUILT-UP' },
  },

  // ---------------------------------------------------------------- the three stops inside (times are seconds of the tour, keep them)
  rooms: [
    { room: 'Living room', button: 'View the dining room' },
    { room: 'Dining room', button: 'View the kitchen' },
    { room: 'Kitchen', button: 'View outside' },
  ],

  // ---------------------------------------------------------------- colours: black page + ONE accent
  colors: {
    accent: '#ff7a12',       // pin, lines, dots, glow of the street
    accentLight: '#ffb27a',  // small coloured words on dark glass
    button: '#c24a00',       // filled buttons (white text on it: 4.9:1 contrast)
    buttonText: '#ffffff',
    accentOnWhite: '#c24a00', // coloured words on the white Burj label
    available: '#3ddc84',    // green dot "available"
  },
};
