# Optional: realistic stills from the 3D

The 3D page is the product. When the user also wants realistic pictures of the same stadium (for posts, a landing page or a pitch deck), use the 3D as the camera and the shapes, and let an image model only change the materials and the light. This works with any image model that accepts an input image and edits it (image-to-image or "edit" mode). Do not tell the user they need a specific paid service.

## 1. Take clean frames

1. Open the site with the interface hidden: `index.html?clean=1&step=seat` (or `plan`, `zone`, `block`, `upgrade`). Add `&roof=1` to keep the roof in the plan, zone and block views.
2. Set the browser window to the final format (for example 1920 x 1080 for 16:9, or 1080 x 1350 for a 4:5 post) and press **P**. The page saves a PNG of the 3D frame only.
3. Save one frame per picture you want. Name them by step (`plan.png`, `seat.png`, `vip.png`).

The frame is the only reference. Do not add photos of other stadiums as references: the model will copy their shapes and the result will no longer match the page.

## 2. The prompt

Give the model the frame and a prompt that locks the camera and lists what is in the frame. Change only materials, light and realism. Template:

```
Turn this 3D render into an ultra-photorealistic photograph of the same stadium, same camera, same framing and same geometry. Keep every element exactly where it is: [list what is in the frame: the tiers of seats, the aisles, the fascia bands, the roof, the screens, the field, the boxes]. Change only materials, light and realism, add nothing.
The stadium is empty, no people.
Seats: individual molded plastic stadium seats, [seat colour] with scattered [second colour] exactly as in the render, real plastic sheen, small gaps between seats, steel fixings on the concrete steps.
Concrete: precast concrete terracing with fine grain and lighter grey aisle steps.
[Field: natural grass with mowing stripes and crisp white lines | Court: polished maple wood with painted lines]
[Roof: translucent white membrane glowing with daylight, steel trusses with real metal highlights]
Light: [warm late afternoon sun with soft haze | arena floodlights at night], high dynamic range, physically correct exposure.
Camera: full-frame camera, [24 | 35] mm lens, f/8, crisp detail, natural colours, a true photograph.
No CGI look, no plastic toy look, no text, no logos, no people.
```

For the seat view add "seen from a seat in row [n], eye level", for the VIP view "inside a private box: [wall colour] walls, leather armchairs, wood floor, clear glass front".

## 3. Check before using

Put the result next to the frame and check, one by one:

- Same camera: horizon, field lines and the edge of the roof in the same place.
- Same number of tiers, same aisles, same boxes. Nothing added (no extra stands, screens, people, cars, flags).
- Seat colours as in the 3D.
- No text or logos invented by the model.

If one of these fails, run it again from the same frame with the failing item named in the prompt ("keep exactly three tiers", "no people"). Do not feed a generated picture back in as the new reference: always start again from the 3D frame.

## 4. Highlighting a seat or a stand in the stills

Keep the highlight out of the prompt. Take two frames from the same camera: one with `?clean=1`, and one where the choice is lit. With the mouse, hover a stand in the plan (it turns the accent colour) and press P; or use `?clean=1&step=pick`, where the chosen seat is lit and the rest of the stadium is darker. Use the lit frame as a mask in any photo editor to colour the same seats on the realistic picture. The shapes match because both come from the same 3D.
