# blender -b scena.blend --python rendi_frames.py -- <dir> <CAM:frame,...|CAM:a-b> <campioni> <larghezza> [blur]
import bpy, sys, os, time
a = sys.argv[sys.argv.index('--') + 1:]
D, L, S, Wd = a[0], a[1], int(a[2]), int(a[3]); blur = len(a) > 4
scn = bpy.context.scene; os.makedirs(D, exist_ok=True)
scn.render.engine = 'CYCLES'
pr = bpy.context.preferences.addons['cycles'].preferences
for t in ('OPTIX', 'CUDA'):
    try: pr.compute_device_type = t; break
    except Exception: pass
pr.refresh_devices()
for d in pr.devices: d.use = d.type != 'CPU'
scn.cycles.device = 'GPU'; scn.cycles.samples = S; scn.cycles.use_denoising = True; scn.cycles.denoiser = 'OPENIMAGEDENOISE'
scn.cycles.max_bounces = 6; scn.cycles.volume_bounces = 1; scn.cycles.use_adaptive_sampling = True; scn.cycles.adaptive_threshold = 0.01
scn.cycles.volume_step_rate = 4.0; scn.render.use_persistent_data = True
scn.render.resolution_x = Wd; scn.render.resolution_y = Wd * 9 // 16; scn.render.resolution_percentage = 100
scn.render.image_settings.file_format = 'JPEG'; scn.render.image_settings.quality = 92
scn.render.use_motion_blur = blur; scn.render.motion_blur_shutter = 0.5
items = []
for it in L.split(','):
    cam, f = it.split(':')
    if '-' in f:
        x, y = map(int, f.split('-')); items += [(cam, k) for k in range(x, y + 1)]
    else:
        items.append((cam, int(f)))
for cam, f in items:
    out = os.path.join(D, f'{cam}_{f:04d}.jpg')
    if os.path.exists(out): continue
    t = time.time(); scn.camera = bpy.data.objects[cam]; scn.frame_set(f); scn.render.filepath = out
    bpy.ops.render.render(write_still=True); print('FRAME', cam, f, round(time.time() - t, 1), flush=True)
