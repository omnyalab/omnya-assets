# Your own plane (optional)

The template ships with our plane: a white jet with no logo, four classes, 334 seats. Most users keep it and change brand, flight and prices. If the user wants their own aircraft, cabin or livery, this is the method, step by step.

## 1. Build the plane in 3D with Claude
Ask Claude to build the airliner in three.js in one HTML file: the fuselage with a glass roof you can see through from above, every seat as one instance per class, the wings and engines, a cloud floor and a sun. Use the plane from above as the first frame (`K1`), then one camera per move: into Economy (`EA`), down to the window (`EB`), then Premium, First, The Residence and the shower (`K3` to `K8`). Keep 1920x1080 and the same camera at the end of a move and the start of the next.

## 2. Turn the 3D frames into real photos
Take a clean frame of each camera (no interface). Give each frame to an image model in edit mode with a prompt that locks camera and geometry and changes only materials and light: "Turn this 3D render into an ultra-photorealistic photograph of the same airliner, same camera, same framing, same geometry. Change only materials, light and realism, add nothing." Never use photos of other planes as references: the shapes would change and stop matching the seat map.

## 3. Turn the moves into clips
For each move give a video model the start photo and the end photo of that move, 3 to 4 seconds, camera only moving straight in. Check the first and last frame of every clip against its start and end photo before using it.

## 4. Put them in
Save them with the template names: `s_<move>.jpg` (start), `f_<move>.jpg` (end), `<move>.mp4`, all 1920x1080. Make the class glow layers (`K1_E.png`...) by colouring the seats of that class on a transparent copy of the plan frame. Re-export `seats.json` from the 3D: each seat's label, its place on the plan frame from 0 to 1, and booked 1 or 0.
