#!/usr/bin/env python3
"""allineamento.py 3D.jpg FOTO.png [...]  — la foto rispetta forma e posizione del 3D?
Contorni (Canny) di 3D e foto a 480x270, distanza media in pixel da ogni contorno della foto al contorno più vicino del 3D
e viceversa (chamfer simmetrico), più lo spostamento/zoom migliore trovato con la correlazione di fase.
Sotto ~3 px = stessa forma; sopra ~5 px = la camera o le proporzioni sono cambiate (Kling poi deforma)."""
import sys, cv2, numpy as np
W, H = 480, 270
def bordi(p):
    im = cv2.imread(p, cv2.IMREAD_GRAYSCALE); im = cv2.resize(im, (W, H), interpolation=cv2.INTER_AREA)
    im = cv2.GaussianBlur(im, (3, 3), 0); v = np.median(im)
    return im, cv2.Canny(im, int(max(0, 0.66 * v)), int(min(255, 1.33 * v)))
def chamfer(a, b):
    dt = cv2.distanceTransform(255 - b, cv2.DIST_L2, 3); ys, xs = np.nonzero(a)
    return float(np.mean(np.minimum(dt[ys, xs], 20))) if len(xs) else 99
g3, e3 = bordi(sys.argv[1])
for p in sys.argv[2:]:
    gf, ef = bordi(p)
    c = (chamfer(ef, e3) + chamfer(e3, ef)) / 2
    (dx, dy), _ = cv2.phaseCorrelate(np.float32(cv2.Canny(g3, 50, 150)), np.float32(cv2.Canny(gf, 50, 150)))
    print(f"{p.split('/')[-1]:28} contorni {c:5.2f} px   spostamento {dx:+5.1f},{dy:+5.1f} px   {'OK' if c < 3.2 else 'SPOSTATA'}")
