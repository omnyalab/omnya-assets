#!/bin/zsh
# Choose your villa · the automatic tour (about 60 seconds, with a drawn cursor). Good for screen recordings.
cd "$(dirname "$0")" && exec ./Start.command "?auto"
