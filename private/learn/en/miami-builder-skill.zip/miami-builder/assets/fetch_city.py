#!/usr/bin/env python3
"""
fetch_city.py - downloads a real city from OpenStreetMap and writes city-data.js
for the Miami Builder page (assets/template/index.html).

Free and keyless: Nominatim (to find the city) + the public Overpass API (the data).
Python 3.8+ standard library only. No pip install needed.

  python3 fetch_city.py "Lisbon" --center 38.7095,-9.1370 --size 3000 --out ./build-lisbon
  python3 fetch_city.py "Monaco" --size 2600 --out ./build-monaco
  python3 fetch_city.py --bbox 43.722,7.405,43.750,7.440 --name Monaco --out ./build-monaco

What it writes:  <out>/city-data.js  (window.CITY_DATA = {...}), metres, x = east, z = south,
origin = the centre. It also prints suggestions for the CONFIG (district, places, parks).
Data (c) OpenStreetMap contributors, ODbL. The page shows the credit line.
"""
import argparse, json, math, os, random, re, ssl, sys, time, urllib.parse, urllib.request

UA = 'miami-builder-skill/1.0 (city 3D page generator; one request per run)'
OVERPASS = [
    'https://overpass-api.de/api/interpreter',
    'https://overpass.private.coffee/api/interpreter',
    'https://overpass.kumi.systems/api/interpreter',
    'https://maps.mail.ru/osm/tools/overpass/api/interpreter',
]

# ------------------------------------------------------------------ network
def _ctx():
    try:
        import certifi  # optional, fixes "certificate verify failed" on some Macs
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()

def _curl(url, data, timeout):
    """curl is on every Mac, Windows 10+ and Linux, and its TLS works where an old Python's does not."""
    import shutil, subprocess, tempfile
    exe = shutil.which('curl')
    if not exe:
        return None
    cmd = [exe, '-sS', '-L', '--fail', '--compressed', '-m', str(int(timeout)), '-A', UA, '-H', 'Accept: application/json']
    tmp = None
    if data is not None:
        tmp = tempfile.NamedTemporaryFile('wb', delete=False, suffix='.txt'); tmp.write(data); tmp.close()
        cmd += ['--data-binary', '@' + tmp.name]
    try:
        r = subprocess.run(cmd + [url], capture_output=True, timeout=timeout + 15)
    finally:
        if tmp: os.unlink(tmp.name)
    if r.returncode != 0:
        raise RuntimeError('curl: ' + (r.stderr.decode(errors='replace').strip() or 'exit %d' % r.returncode)[:160])
    return r.stdout

def http(url, data=None, timeout=200):
    out = _curl(url, data, timeout)
    if out is not None:
        return out
    req = urllib.request.Request(url, data=data, headers={'User-Agent': UA, 'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.read()
    except urllib.error.URLError as e:
        if 'CERTIFICATE_VERIFY_FAILED' in str(e):
            print('  ! certificate check failed. On macOS run "Install Certificates.command" in the Python folder, '
                  'or "pip3 install certifi".', file=sys.stderr)
        raise

def geocode(q):
    url = 'https://nominatim.openstreetmap.org/search?' + urllib.parse.urlencode({'q': q, 'format': 'json', 'limit': 1})
    res = json.loads(http(url, timeout=40))
    if not res:
        sys.exit('Could not find "%s". Pass --center lat,lon instead.' % q)
    r = res[0]
    print('  found: %s (%s, %s)' % (r.get('display_name', q)[:90], r['lat'], r['lon']))
    return float(r['lat']), float(r['lon'])

def overpass(query):
    last = None
    for attempt in range(2):
        for url in OVERPASS:
            try:
                t0 = time.time()
                print('  asking %s ...' % url.split('/')[2], flush=True)
                raw = http(url, urllib.parse.urlencode({'data': query}).encode(), timeout=240)
                data = json.loads(raw)
                print('  got %.1f MB in %.0f s' % (len(raw) / 1e6, time.time() - t0))
                if data.get('remark') and 'runtime error' in data['remark']:
                    raise RuntimeError(data['remark'])
                return data
            except Exception as e:
                last = e
                print('    failed: %s' % str(e)[:140], file=sys.stderr)
        time.sleep(8)
    sys.exit('All Overpass servers failed (%s). Wait a minute and run again, or use a smaller --size.' % last)

# ------------------------------------------------------------------ geometry helpers
class Proj:
    def __init__(self, lat0, lon0):
        self.lat0, self.lon0 = lat0, lon0
        self.kx = 111320.0 * math.cos(math.radians(lat0))
        self.kz = 110540.0
    def xz(self, lat, lon):
        return ((lon - self.lon0) * self.kx, -(lat - self.lat0) * self.kz)

def dp(pts, tol):
    """Douglas-Peucker on a list of (x, z)."""
    if len(pts) < 3:
        return pts
    keep = [False] * len(pts); keep[0] = keep[-1] = True
    stack = [(0, len(pts) - 1)]
    while stack:
        a, b = stack.pop()
        ax, az = pts[a]; bx, bz = pts[b]; dx, dz = bx - ax, bz - az; L = math.hypot(dx, dz) or 1e-9
        best, bi = -1, -1
        for i in range(a + 1, b):
            px, pz = pts[i]
            d = abs(dx * (az - pz) - (ax - px) * dz) / L
            if d > best: best, bi = d, i
        if best > tol:
            keep[bi] = True; stack += [(a, bi), (bi, b)]
    return [p for p, k in zip(pts, keep) if k]

def clean_ring(pts, tol=0.6):
    if len(pts) > 1 and pts[0] == pts[-1]:
        pts = pts[:-1]
    out = []
    for p in pts:
        if not out or math.hypot(p[0] - out[-1][0], p[1] - out[-1][1]) > 0.4:
            out.append(p)
    if len(out) > 3:
        out = dp(out, tol)
    return out if len(out) >= 3 else None

def area(r):
    return 0.5 * sum(r[i][0] * r[(i + 1) % len(r)][1] - r[(i + 1) % len(r)][0] * r[i][1] for i in range(len(r)))

def join_rings(parts):
    """Join way fragments of a multipolygon into closed rings."""
    parts = [list(p) for p in parts if len(p) >= 2]
    rings = []
    while parts:
        cur = parts.pop(0)
        changed = True
        while cur[0] != cur[-1] and changed:
            changed = False
            for i, p in enumerate(parts):
                if p[0] == cur[-1]: cur += p[1:]
                elif p[-1] == cur[-1]: cur += p[::-1][1:]
                elif p[-1] == cur[0]: cur = p[:-1] + cur
                elif p[0] == cur[0]: cur = p[::-1][:-1] + cur
                else: continue
                parts.pop(i); changed = True; break
        if len(cur) >= 4 and cur[0] == cur[-1]:
            rings.append(cur)
    return rings

def q(v):  # metres -> decimetres int
    return int(round(v * 10))

def flat(r):
    o = []
    for x, z in r: o += [q(x), q(z)]
    return o


def coast_chains(lines, hx, hz):
    """Join coastline ways end to end (water stays on the right) and stretch every loose end that stops
    inside the area straight out past the border, so the water can be filled without leaking."""
    lines = [l[:] for l in lines if len(l) >= 2]
    chains = []
    while lines:
        cur = lines.pop(0); grown = True
        while grown and cur[0] != cur[-1]:
            grown = False
            for i, l in enumerate(lines):
                if l[0] == cur[-1]: cur = cur + l[1:]; lines.pop(i); grown = True; break
                if l[-1] == cur[0]: cur = l[:-1] + cur; lines.pop(i); grown = True; break
        chains.append(cur)
    far = 3.0 * max(hx, hz)
    def inside(p): return abs(p[0]) < hx - 1 and abs(p[1]) < hz - 1
    def back(ch, rev):
        pts = ch[::-1] if rev else ch
        e = pts[-1]; d = 0
        for k in range(len(pts) - 2, -1, -1):
            d += math.hypot(pts[k + 1][0] - pts[k][0], pts[k + 1][1] - pts[k][1])
            if d > 150: return pts[k], e
        return pts[0], e
    out = []
    for ch in chains:
        if ch[0] != ch[-1]:
            if inside(ch[-1]):
                a, e = back(ch, False); L = math.hypot(e[0] - a[0], e[1] - a[1]) or 1
                ch = ch + [(e[0] + (e[0] - a[0]) / L * far, e[1] + (e[1] - a[1]) / L * far)]
            if inside(ch[0]):
                a, e = back(ch, True); L = math.hypot(e[0] - a[0], e[1] - a[1]) or 1
                ch = [(e[0] + (e[0] - a[0]) / L * far, e[1] + (e[1] - a[1]) / L * far)] + ch
        out.append(ch)
    return out

# ------------------------------------------------------------------ heights
NUM = re.compile(r'[-+]?\d*\.?\d+')
def num(s):
    if s is None: return None
    s = str(s).replace(',', '.')
    m = NUM.search(s)
    if not m: return None
    v = float(m.group())
    if "'" in s or 'ft' in s or 'feet' in s: v *= 0.3048
    return v

LOW = {'garage': 3.2, 'garages': 3.2, 'shed': 3.0, 'hut': 3.0, 'kiosk': 3.2, 'carport': 3.0, 'roof': 5.0,
       'service': 4.0, 'toilets': 3.2, 'cabin': 3.5, 'container': 3.0, 'bunker': 3.0, 'greenhouse': 4.0,
       'transformer_tower': 6.0, 'gatehouse': 4.0}
HOUSE = {'house': 7.5, 'detached': 7.5, 'semidetached_house': 7.5, 'bungalow': 4.5, 'terrace': 9.0, 'farm': 7.0,
         'static_caravan': 3.0}
TALLER = {'church': 22.0, 'cathedral': 32.0, 'chapel': 9.0, 'mosque': 18.0, 'temple': 14.0, 'synagogue': 16.0,
          'industrial': 9.0, 'warehouse': 9.0, 'hangar': 12.0, 'parking': 12.0, 'stadium': 25.0, 'grandstand': 14.0,
          'train_station': 16.0, 'transportation': 9.0, 'supermarket': 7.0, 'retail': 8.0}

def tagged_height(t):
    h = num(t.get('height')) or num(t.get('building:height'))
    if h and 1.5 < h < 900: return h
    lv = num(t.get('building:levels'))
    if lv and 0 < lv < 250:
        rl = num(t.get('roof:levels')) or 0
        return lv * 3.2 + rl * 2.2 + 1.0
    return None

COLOR = re.compile(r'^#?[0-9a-fA-F]{6}$|^#?[0-9a-fA-F]{3}$')
NAMED = {'white': 'f2f0ea', 'grey': 'a9a9a4', 'gray': 'a9a9a4', 'beige': 'e2d5b8', 'cream': 'efe6cf', 'yellow': 'e9d38a',
         'brown': '8a6a52', 'red': 'b5523d', 'orange': 'd98a4e', 'black': '3a3a3a', 'blue': '7d97b5', 'green': '8aa37c',
         'tan': 'cdb48f', 'pink': 'dcae9f', 'silver': 'c2c5c8', 'darkgray': '6f6f6b', 'lightgray': 'cfcfcb', 'lightgrey': 'cfcfcb',
         'terracotta': 'b8613f', 'sandybrown': 'dba56c', 'maroon': '7d3a2c', 'ivory': 'f3efe2', 'khaki': 'cfc08f'}
def colour(s):
    if not s: return None
    s = s.strip().lower()
    if s in NAMED: return NAMED[s]
    if COLOR.match(s):
        s = s.lstrip('#')
        if len(s) == 3: s = ''.join(c * 2 for c in s)
        return s
    return None

# ------------------------------------------------------------------ main
ROADS = {'motorway': 0, 'trunk': 1, 'primary': 2, 'secondary': 3, 'tertiary': 4, 'unclassified': 5, 'residential': 5,
         'living_street': 6, 'pedestrian': 6, 'service': 7, 'motorway_link': 1, 'trunk_link': 2, 'primary_link': 3,
         'secondary_link': 4, 'tertiary_link': 5}
GREEN = {('leisure', 'park'), ('leisure', 'garden'), ('leisure', 'golf_course'), ('leisure', 'nature_reserve'),
         ('leisure', 'recreation_ground'), ('landuse', 'grass'), ('landuse', 'forest'), ('landuse', 'meadow'),
         ('landuse', 'village_green'), ('landuse', 'recreation_ground'), ('landuse', 'cemetery'), ('natural', 'wood'),
         ('natural', 'scrub'), ('natural', 'grassland'), ('natural', 'heath'), ('leisure', 'pitch')}
WOOD = {('landuse', 'forest'), ('natural', 'wood'), ('leisure', 'park'), ('leisure', 'garden'), ('leisure', 'nature_reserve'),
        ('natural', 'scrub'), ('landuse', 'cemetery')}

def classify(t):
    if t.get('building') and t.get('building') not in ('no',) : return 'b'
    if t.get('natural') == 'coastline': return 'coast'
    if t.get('natural') == 'water' or t.get('waterway') in ('riverbank', 'dock') or t.get('landuse') in ('reservoir', 'basin') \
            or t.get('leisure') == 'marina': return 'w'
    if t.get('natural') in ('beach', 'sand'): return 'sand'
    if t.get('highway') in ROADS and t.get('area') != 'yes': return 'r'
    for k, v in GREEN:
        if t.get(k) == v: return 'g'
    return None

def main():
    ap = argparse.ArgumentParser(description='Fetch a real city from OpenStreetMap for the Miami Builder page.')
    ap.add_argument('city', nargs='?', help='city or district name, e.g. "Lisbon" or "Monaco"')
    ap.add_argument('--center', help='lat,lon of the middle of the area (best: the iconic centre / waterfront)')
    ap.add_argument('--size', type=float, default=3000, help='side of the square area in metres (default 3000, max 6000)')
    ap.add_argument('--bbox', help='south,west,north,east instead of --center/--size')
    ap.add_argument('--name', help='name shown on the page (default: the city argument)')
    ap.add_argument('--out', default='.', help='folder where city-data.js is written')
    ap.add_argument('--raw', help='reuse a saved Overpass JSON instead of downloading (for testing)')
    ap.add_argument('--save-raw', action='store_true', help='also save the raw Overpass answer as osm-raw.json')
    a = ap.parse_args()
    name = a.name or a.city or 'City'

    if a.bbox:
        s, w, n, e = [float(v) for v in a.bbox.split(',')]
        lat0, lon0 = (s + n) / 2, (w + e) / 2
    else:
        if a.center:
            lat0, lon0 = [float(v) for v in a.center.split(',')]
        elif a.city:
            print('Finding %s ...' % a.city); lat0, lon0 = geocode(a.city)
        else:
            sys.exit('Give a city name, --center or --bbox.')
        size = max(600.0, min(a.size, 6000.0))
        if a.size > 6000: print('  size capped at 6000 m (bigger areas are too heavy for one page).')
        dlat = size / 2 / 110540.0; dlon = size / 2 / (111320.0 * math.cos(math.radians(lat0)))
        s, w, n, e = lat0 - dlat, lon0 - dlon, lat0 + dlat, lon0 + dlon
    P = Proj(lat0, lon0)
    bb = '%.6f,%.6f,%.6f,%.6f' % (s, w, n, e)
    half_x = (e - w) / 2 * P.kx; half_z = (n - s) / 2 * P.kz
    print('Area %s: %.0f x %.0f m around %.5f, %.5f' % (name, half_x * 2, half_z * 2, lat0, lon0))

    query = """[out:json][timeout:180][maxsize:536870912][bbox:%s];
(
  way["building"];
  relation["building"]["type"="multipolygon"];
  way["highway"~"^(motorway|trunk|primary|secondary|tertiary|unclassified|residential|living_street|pedestrian|service|motorway_link|trunk_link|primary_link|secondary_link|tertiary_link)$"]["tunnel"!~"yes|building_passage"]["area"!="yes"];
  way["natural"~"^(water|coastline|beach|sand|wood|scrub|grassland|heath)$"];
  relation["natural"~"^(water|beach|sand|wood|scrub)$"]["type"="multipolygon"];
  way["waterway"~"^(riverbank|dock)$"];
  relation["waterway"="riverbank"];
  way["landuse"~"^(reservoir|basin|grass|forest|meadow|village_green|recreation_ground|cemetery)$"];
  relation["landuse"~"^(reservoir|basin|grass|forest|meadow|cemetery)$"]["type"="multipolygon"];
  way["leisure"~"^(park|garden|golf_course|nature_reserve|recreation_ground|pitch|marina)$"];
  relation["leisure"~"^(park|garden|golf_course|nature_reserve)$"]["type"="multipolygon"];
);
out geom qt;
(
  nwr["tourism"~"^(attraction|viewpoint|museum)$"]["name"];
  nwr["place"="square"]["name"];
  nwr["historic"~"^(castle|monument|fort|palace)$"]["name"];
  nwr["leisure"~"^(park|marina)$"]["name"];
  nwr["man_made"~"^(lighthouse|tower)$"]["name"];
);
out center tags qt;
node["natural"="tree"];
out skel qt;
""" % bb

    if a.raw:
        data = json.load(open(a.raw))
    else:
        print('Downloading OpenStreetMap data (can take 20-90 s) ...')
        data = overpass(query)
        if a.save_raw:
            os.makedirs(a.out, exist_ok=True)
            json.dump(data, open(os.path.join(a.out, 'osm-raw.json'), 'w'))

    els = data.get('elements', [])
    def geom_xz(g):
        return [P.xz(p['lat'], p['lon']) for p in g if p]

    B, R, W, G, S, C, T, PL = [], [], [], [], [], [], [], []
    seen_parts = 0
    for el in els:
        t = el.get('tags', {})
        typ = el['type']
        if typ == 'node' and not t:
            T.append(P.xz(el['lat'], el['lon'])); continue
        if 'center' in el or (typ == 'node' and t.get('name')):
            c = el.get('center') or el
            if t.get('name'):
                x, z = P.xz(c['lat'], c['lon'])
                kind = t.get('tourism') or t.get('place') or t.get('historic') or t.get('leisure') or t.get('man_made') or ''
                rank = {'square': 3, 'castle': 2, 'viewpoint': 2.5, 'monument': 2, 'palace': 2.5, 'fort': 2, 'lighthouse': 2,
                        'marina': 2, 'park': 1.5, 'attraction': 1.5, 'tower': 1.5, 'museum': 1}.get(kind, 1) + (2 if t.get('wikidata') else 0)
                PL.append({'name': t.get('name:en') or t['name'], 'local': t['name'], 'kind': kind, 'rank': rank,
                           'lat': round(c['lat'], 6), 'lon': round(c['lon'], 6), 'x': round(x), 'z': round(z)})
            continue
        k = classify(t)
        if not k: continue
        rings = []
        if typ == 'way' and 'geometry' in el:
            pts = geom_xz(el['geometry'])
            if k in ('r', 'coast'):
                rings = [pts]
            elif len(pts) >= 4 and el['geometry'][0] == el['geometry'][-1]:
                rings = [('outer', pts)]
        elif typ == 'relation':
            outers = [geom_xz(m['geometry']) for m in el.get('members', []) if m.get('role') in ('outer', '') and m.get('geometry')]
            inners = [geom_xz(m['geometry']) for m in el.get('members', []) if m.get('role') == 'inner' and m.get('geometry')]
            rings = [('outer', r) for r in join_rings(outers)] + ([('inner', r) for r in join_rings(inners)] if k != 'b' else [])
        if not rings: continue

        if k == 'r':
            pts = dp(rings[0], 0.8)
            if len(pts) < 2: continue
            bridge = 1 if t.get('bridge') and t.get('bridge') != 'no' else 0
            R.append([ROADS[t['highway']], bridge] + flat(pts))
        elif k == 'coast':
            pts = dp(rings[0], 0.8)
            if len(pts) >= 2: C.append([(round(x, 1), round(z, 1)) for x, z in pts])
        elif k == 'b':
            if t.get('building') in ('construction',) and not tagged_height(t): pass
            for role, r in rings:
                r = clean_ring(r)
                if not r: continue
                ar = abs(area(r))
                if ar < 6: continue
                B.append({'r': r, 't': t, 'a': ar})
        else:
            polys = []
            for role, r in rings:
                r = clean_ring(r, 1.2)
                if r: polys.append((1 if role == 'outer' else 0, r))
            if not polys: continue
            target = {'w': W, 'g': G, 'sand': S}[k]
            if k == 'g':
                kind = 0
                for kk, vv in WOOD:
                    if t.get(kk) == vv: kind = 1
                if t.get('leisure') == 'pitch': kind = 2
                if t.get('leisure') == 'golf_course': kind = 3
                target.append([kind] + [[o] + flat(r) for o, r in polys])
            else:
                target.append([[o] + flat(r) for o, r in polys])

    C = [flat(ch) for ch in coast_chains(C, half_x, half_z)]

    # ---- heights: tags first, then the median of tagged neighbours, then the building type
    cell = 160.0
    grid = {}
    known = []
    for b in B:
        h = tagged_height(b['t'])
        cx = sum(p[0] for p in b['r']) / len(b['r']); cz = sum(p[1] for p in b['r']) / len(b['r'])
        b['c'] = (cx, cz); b['h'] = h; b['est'] = h is None
        if h:
            known.append(h); grid.setdefault((int(cx // cell), int(cz // cell)), []).append(h)
    known.sort()
    med_all = known[len(known) // 2] if len(known) >= 12 else 13.0
    rnd = random.Random(7)
    estimated = 0
    for b in B:
        if b['h']: continue
        t = b['t']; kind = t.get('building', 'yes')
        if kind in LOW: h = LOW[kind]
        elif kind in HOUSE: h = HOUSE[kind]
        else:
            gx, gz = int(b['c'][0] // cell), int(b['c'][1] // cell)
            near = []
            for dx in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    near += grid.get((gx + dx, gz + dz), [])
            if len(near) >= 4:
                near.sort(); h = near[len(near) // 2]
            elif kind in TALLER: h = TALLER[kind]
            else: h = med_all
            h = min(h, 48.0)
            if b['a'] < 40: h = min(h, 6.0)                # tiny footprints are sheds and kiosks
            elif b['a'] < 90: h = min(h, 12.0)
        b['h'] = h * (0.82 + 0.36 * rnd.random()); estimated += 1

    # ---- sort tallest first, write compact
    B.sort(key=lambda b: -b['h'])
    outB = []
    for b in B:
        t = b['t']
        wc = colour(t.get('building:colour')); rc = colour(t.get('roof:colour'))
        mh = num(t.get('min_height')) or 0
        nm = t.get('name:en') or t.get('name') if b['h'] > 40 or t.get('building') in TALLER else None
        kind = 1 if t.get('building') in HOUSE else 2 if t.get('building') in ('industrial', 'warehouse', 'hangar', 'roof', 'service') else 3 if t.get('building') in TALLER else 0
        outB.append([q(b['h']), q(mh) if mh < b['h'] - 2 else 0, kind, wc or 0, rc or 0, nm or 0] + flat(b['r']))

    # ---- suggestions: tallest cluster (district), largest park, named places
    cs = 350.0; score = {}
    for b in B:
        if b['h'] < 20: continue
        key = (int(b['c'][0] // cs), int(b['c'][1] // cs))
        score[key] = score.get(key, 0) + (b['h'] ** 2) * min(b['a'], 3000) / 1000
    district = None
    if score:
        (gx, gz), sc = max(score.items(), key=lambda kv: kv[1])
        dx, dz = (gx + .5) * cs, (gz + .5) * cs
        tall = [b for b in B if math.hypot(b['c'][0] - dx, b['c'][1] - dz) < 450 and b['h'] >= 20]
        if tall:
            dx = sum(b['c'][0] for b in tall) / len(tall); dz = sum(b['c'][1] for b in tall) / len(tall)
        district = {'x': round(dx), 'z': round(dz), 'lat': round(lat0 - dz / P.kz, 6), 'lon': round(lon0 + dx / P.kx, 6),
                    'tall': len(tall), 'maxHeight': round(max(b['h'] for b in tall)) if tall else 0}
    seen = set(); places = []
    PL.sort(key=lambda p: -p['rank'])
    for p in PL:
        if p['name'] in seen or abs(p['x']) > half_x or abs(p['z']) > half_z: continue
        seen.add(p['name']); places.append(p)

    out = {
        'meta': {'name': name, 'lat0': lat0, 'lon0': lon0, 'bbox': [s, w, n, e], 'half': [round(half_x), round(half_z)],
                 'kx': P.kx, 'kz': P.kz, 'made': time.strftime('%Y-%m-%d'), 'credit': '© OpenStreetMap contributors',
                 'counts': {'buildings': len(outB), 'estimated': estimated, 'roads': len(R), 'water': len(W),
                            'coast': len(C), 'green': len(G), 'sand': len(S), 'trees': len(T)},
                 'district': district, 'places': places[:60]},
        'b': outB, 'r': R, 'w': W, 'c': C, 'g': G, 's': S,
        't': [v for x, z in T[:40000] for v in (q(x), q(z))],
    }
    os.makedirs(a.out, exist_ok=True)
    path = os.path.join(a.out, 'city-data.js')
    with open(path, 'w', encoding='utf-8') as f:
        f.write('/* %s - data (c) OpenStreetMap contributors, ODbL. Made by fetch_city.py on %s. */\n' % (name, out['meta']['made']))
        f.write('window.CITY_DATA=')
        json.dump(out, f, separators=(',', ':'), ensure_ascii=False)
        f.write(';\n')
    mb = os.path.getsize(path) / 1e6

    print('\nWrote %s (%.1f MB)' % (path, mb))
    c = out['meta']['counts']
    print('  buildings %d (%d heights estimated), roads %d, water %d + coastline %d, green %d, beaches %d, trees %d'
          % (c['buildings'], c['estimated'], c['roads'], c['water'], c['coast'], c['green'], c['sand'], c['trees']))
    if c['buildings'] < 200: print('  ! very few buildings: check the centre, or this place is not mapped in detail.')
    if c['coast'] == 0 and c['water'] == 0: print('  no water in this area (fine for an inland city).')
    print('\nSuggestions for the CONFIG:')
    if district:
        print('  district (tallest cluster): lat %.5f lon %.5f, %d buildings over 20 m, max %d m'
              % (district['lat'], district['lon'], district['tall'], district['maxHeight']))
    tallest = [b for b in B[:15]]
    print('  tallest buildings: ' + ', '.join('%s %dm' % (b['t'].get('name', '?')[:28], b['h']) for b in tallest[:8]))
    print('  named places (pick two for the "Go to" buttons):')
    for p in places[:25]:
        print('    %-40s %-12s lat %.5f lon %.5f' % (p['name'][:40], p['kind'][:12], p['lat'], p['lon']))

if __name__ == '__main__':
    main()
