#!/bin/bash
# Choose Your Floor kit · double click to start the local server and open SAMAR in Chrome.
cd "$(dirname "$0")"
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

missing() {
  echo
  echo "Python 3 is missing."
  echo "Open Claude Code in this folder and send prompts/02-0-install.txt"
  echo "(Claude checks what the kit needs and installs it), then double click Start again."
  echo
  read -n 1 -s -r -p "Press any key to close."
  echo
  exit 1
}

PY=""
for c in python3 python; do
  p="$(command -v "$c" 2>/dev/null)" || continue
  # /usr/bin/python3 is only a stub until Apple's command line tools are installed:
  # running it would open Apple's install window, so skip it.
  if [ "$p" = "/usr/bin/python3" ]; then
    d="$(xcode-select -p 2>/dev/null)" && [ -x "$d/usr/bin/python3" ] || continue
  fi
  if "$p" -c 'import sys; assert sys.version_info[0] == 3' >/dev/null 2>&1; then PY="$p"; break; fi
done
[ -n "$PY" ] || missing

"$PY" tools/serve.py --open
