# Customising beyond the config

Read this only when the config in `references/config.md` cannot do what the user wants. All the places named here are in the engine part of `stadium.js` (below the `ENGINE` line). Make the smallest change that works, keep the seats in one `InstancedMesh`, and re-check all six steps on phone and desktop afterwards.

## How the stadium is drawn (so changes stay consistent)

- Everything is built around one **base curve**: a rounded rectangle around the field with half length `A0`, half width `B0` and corner radius `R0`. `t` is the distance in metres along that curve, starting on the east side and going clockwise seen from above (east, south-east corner, south, south-west, west, north-west, north, north-east).
- `off(t, d, y)` gives the point at distance `d` outside the curve and height `y`. Rings like the tiers, fascia bands, the skybox band, the roof and the facade are all `sweep(profile)` calls, where the profile is a list of `[d, y]` pairs.
- `TIERS` holds every row as `{ d, y, T }` (distance, height, depth). `TOP_D` / `TOP_Y` is the back of the last tier.
- Seats are arrays indexed by seat: `sX, sY, sZ` (position), `sTier`, `sRow`, `sSec` (sector between two aisles), `sNo` (number in the row), `seatZone`, `seatBlock`, `taken`. A block is one tier between two aisles; `BLOCKS` maps its id to its list of seats.
- `repaint()` sets the seat colours for the current step. `viewOf(step)` returns the camera for a step; `fit()` frames a set of points inside the part of the screen not covered by the header and the bottom sheet.

## Shape

- **Bigger or smaller bowl**: prefer `size: { length, width, corner }` in the config. `corner` near half the width gives an oval, a small corner a rectangle with rounded corners.
- **Steeper or flatter tiers**: `tiers[i].rake = [firstStep, lastStep]` in metres. Lower tiers 0.30 to 0.50, upper tiers up to 0.80. Arenas look right a bit steeper than football.
- **More space between field and first row**: change `row0` (first row distance and height) and `wall` in the `FIELDS` preset you use.
- **Only one tier**: works; the VIP band then sits at the back of that tier.
- **No corners (two straight stands only)**: not supported by the base curve. Use 4 zones and mark the two end zones `soldOut: true`, or raise `corner` to make an oval.

## Colours of parts that are not in the config

| Part | Where |
|---|---|
| Concrete of the steps | `mStep`, `mConcrete` |
| White back wall | `mWhite` |
| Roof membrane | `mMembrane` |
| Skybox floor, wall, ceiling | the three `addMesh(sweep(...))` lines under "the skybox band" |
| VIP armchairs | the `inst(geo, M(0x3b2a22 ...` line in "VIP boxes" |
| Grass, court, lines | the canvas drawing in "the field" (`fillR`, `line`) |
| Plaza paving, roads | `#ddd6c8` in "plaza", `roadTex` |

Colours are plain hex numbers (`0xc9c5bd`) or strings (`'#c9c5bd'`).

## Sponsor boards and names

- **Text on the LED boards**: `shortName` plus `boards: ['Name one', 'Name two']` in the config. The boards cycle the words on brand and seat colours.
- **A logo on the boards instead of text**: in `boardTex()`, load the image first (`const img = new Image(); img.src = 'logo.png'`), then in the loop `g.drawImage(img, x + 20, 6, 52 * img.width / img.height, 52)` and set `t.needsUpdate = true` inside `img.onload`. Put `logo.png` next to `index.html`.
- **The big screens**: `screenTex(w, h, text)` draws the venue name and the event title. Change the text there, or draw a logo the same way as above.
- **The centre of a basketball court**: the `fillText(C.shortName ...)` line in the basketball branch of "the field".
- Only use names and logos the user owns or has permission for.

## Zones and prices

- Zone names, prices and sold-out are in the config. A zone price is multiplied by the tier `priceFactor`.
- **Different prices per block** (e.g. the centre blocks cost more): change `priceOf(ti, z)` to also take the sector, e.g. `priceOf(ti, z, sec)` and add a bonus when `Math.abs(secMid(sec) - centreOfZone) < 12`. Update the three places that call it (zone sheet, block sheet, ticket).
- **Real availability**: replace the `taken[i] = ...` line with data from the user (for example a JSON file of taken seat keys `tier-sector-row-seat` loaded before `buildStadium` runs). Then set `text.note` to `''`.

## Cameras

- Plan: `viewOf('plan')`. On a portrait phone the long side runs top to bottom so the bowl fills the screen; change the `portrait ? V(0.16, 1, 0) : V(0, 1, 0.16)` directions to rotate it.
- Zone and block: the `dir` vectors in `viewOf` (`V(-n.x, 1.15, -n.z)` means from the field side, looking down at about 50 degrees; a bigger y looks more from above).
- Seat: eye height is `sY[i] + 1.15`, looking at a point near the middle of the field. Field of view 70 on phones, 58 on desktop.
- VIP box: position inside the box behind the armchairs, looking down at the field. If the armchairs fill too much of the frame, raise `p.y` (the ceiling is at `SKY_Y + 3.6`) or move `p` closer to the glass by lowering the `+ 5.6`.

## Steps and wording

- All words: `text` in the config.
- The sheet content of each step is built in `enterPlan`, `zoneSheet`, `blockSheet`, `enterSeat`, `enterUpgrade`, `enterTicket`.
- To skip the upgrade step, make the Continue button in `enterSeat` call `enterTicket()` instead of `enterUpgrade()`.
- Styles are all in `ui.css`: `--accent` and `--brand` are set from the config at load; the paper colour, ink, radius and fonts are variables at the top.

## Things not to do

- Do not create one mesh per seat or per block: keep the single `InstancedMesh`.
- Do not change the three.js version without testing every step: `Sky`, `OrbitControls` and `mergeGeometries` come from the same pinned version.
- Do not add a build step, a framework or a backend for the page itself.
