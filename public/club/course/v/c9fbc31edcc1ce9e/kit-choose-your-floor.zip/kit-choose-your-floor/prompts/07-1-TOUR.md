# My tour (stops = photos, moves = clips)
1. I see the tower at sunset
2. I choose [floor 15] and the camera zooms to its window
3. I fly in, into the living room
4. I turn to look at the living room
5. I walk to the bathroom
(the way back out = the way in, reversed)
