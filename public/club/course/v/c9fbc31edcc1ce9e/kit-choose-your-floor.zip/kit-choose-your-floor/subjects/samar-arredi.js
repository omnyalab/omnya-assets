// SAMAR · furniture of floor 15 (course, 26/11/2026). Copied from the real photos (references/samar/interiors/living.jpg and bath.jpg):
// divano angolare grigio antracite con rulli e cuscino di pelle cognac, due poltrone scure con telaio di noce, tavolino di marmo Emperador su gambe sottili,
// lampadario a rami d'ottone con le foglie accese, lampada da terra a cupola d'ottone, parete TV di marmo «legno» con mobile basso sospeso, opera materica scura,
// tappeto marrone a cerchi. Bagno: travertino, vasca freestanding di travertino, doppio lavabo sospeso, specchio retroilluminato.
// Misure in metri (STIMA da cataloghi: divano tipo Minotti, seduta 45; poltrona tipo Kristiansen 72 x 78 x 80; tavolo da pranzo 300 x 120 x 75; isola 90).
// Ogni pezzo è un gruppo con il pavimento a y = 0 e il davanti verso +z; userData.pezzo = nome, userData.tipo = terra | su | appeso | muro (per il controllo 06-4).
import * as THREE from 'three';
import { RoundedBoxGeometry } from '../vendor/addons/geometries/RoundedBoxGeometry.js';
import { canvasTex, rng } from '../engine/kit/forme.js';

export const rb = (w, h, d, r = 0.03, s = 3) => new RoundedBoxGeometry(w, h, d, s, Math.max(0.003, Math.min(r, w / 2 - 0.002, h / 2 - 0.002, d / 2 - 0.002)));
export function mesh(g, geo, mat, x, y, z, rx = 0, ry = 0, rz = 0) { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.rotation.set(rx, ry, rz); m.castShadow = m.receiveShadow = true; g.add(m); return m; }
const std = (c, r, m = 0, e = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...e });
const gruppo = (pezzo, tipo) => { const g = new THREE.Group(); g.userData = { pezzo, tipo }; return g; };
/* cilindro da A a B (rami del lampadario) */
function asta(g, A, B, r, mat) { const d = new THREE.Vector3().subVectors(B, A), l = d.length(), m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, l, 8), mat);
  m.position.copy(A).addScaledVector(d, 0.5); m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize()); m.castShadow = true; g.add(m); return m; }

// ---------------- materiali con le texture disegnate ----------------
export function texRep(t, rx, ry) { const c = t.clone(); c.repeat.set(rx, ry); c.needsUpdate = true; return c; }
export function materialiSamar() {
  const venaLegno = (c, w, h, base, r, k = 1) => { c.fillStyle = base; c.fillRect(0, 0, w, h);
    for (let i = 0; i < 140 * k; i++) { const x0 = r() * w, a = 2 + r() * 6, f = 0.004 + r() * 0.01, ph = r() * 6; c.strokeStyle = `rgba(${r() < 0.5 ? '60,35,18' : '235,200,150'},${0.05 + r() * 0.12})`; c.lineWidth = 0.6 + r() * 2.2;
      c.beginPath(); for (let y = 0; y <= h; y += 8) { const x = x0 + Math.sin(y * f + ph) * a; y ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); } };
  // rovere miele a pannelli verticali da 60 cm (pareti del salone), 1 ripetizione = 1,2 m x 3 m
  /* 07 (giudice): le venature fitte tutte verticali, quando il muro riempie il quadro (davanti alla porta del bagno), non si seguono e sembrano una rotazione → venatura più morbida
     e la fuga orizzontale all'altezza delle porte (2,10 m), come i pannelli veri: gli incroci delle fughe sono punti fermi da seguire */
  const rovere = canvasTex(512, 1024, (c, w, h) => { const r = rng(4); venaLegno(c, w, h, '#a87447', r, 0.7); c.fillStyle = 'rgba(30,16,8,0.55)'; c.fillRect(0, 0, 3, h); c.fillRect(w / 2, 0, 3, h); c.fillRect(0, Math.round(h * (1 - 2.1 / 3)), w, 3);
    const g = c.createLinearGradient(0, 0, w / 2, 0); g.addColorStop(0, 'rgba(255,230,190,0.05)'); g.addColorStop(1, 'rgba(0,0,0,0.05)'); c.fillStyle = g; c.fillRect(0, 0, w / 2, h); });
  // marmo «legno» della parete TV (palissandro: marrone con vene verticali ondulate), 1 ripetizione = 3 m x 3 m
  const palissandro = canvasTex(1024, 1024, (c, w, h) => { const r = rng(17); c.fillStyle = '#4e3426'; c.fillRect(0, 0, w, h);
    for (let i = 0; i < 34; i++) { const x0 = r() * w, bw = 20 + r() * 90, a = 8 + r() * 30, f = 0.002 + r() * 0.004, ph = r() * 6, chiaro = r() < 0.5;   // fasce larghe e morbide (la «venatura legno» del marmo)
      for (let y = 0; y <= h; y += 4) { const x = x0 + Math.sin(y * f + ph) * a; const gr = c.createLinearGradient(x - bw / 2, 0, x + bw / 2, 0); const col = chiaro ? '172,128,92' : '30,18,12', k = 0.16 + 0.1 * Math.abs(Math.sin(i * 1.7));
        gr.addColorStop(0, `rgba(${col},0)`); gr.addColorStop(0.5, `rgba(${col},${k})`); gr.addColorStop(1, `rgba(${col},0)`); c.fillStyle = gr; c.fillRect(x - bw / 2, y, bw, 4); } }
    for (let i = 0; i < 30; i++) { const x0 = r() * w, a = 6 + r() * 26, f = 0.002 + r() * 0.006, ph = r() * 6; c.strokeStyle = r() < 0.5 ? `rgba(196,156,118,${0.18 + r() * 0.25})` : `rgba(24,14,9,${0.18 + r() * 0.25})`; c.lineWidth = 0.8 + r() * 3;
      c.beginPath(); for (let y = 0; y <= h; y += 6) { const x = x0 + Math.sin(y * f + ph) * a; y ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); }
    c.fillStyle = 'rgba(20,12,8,0.5)'; c.fillRect(w / 2 - 1, 0, 2, h); });
  // doghe del soffitto: listelli di noce chiaro da 4 cm con fuga scura da 1 cm (corrono lungo x), 1 ripetizione = 1,2 m
  const doghe = canvasTex(1024, 1024, (c, w, h) => { const r = rng(9), n = 24, p = h / n; for (let i = 0; i < n; i++) { const k = 0.85 + r() * 0.3; c.fillStyle = `rgb(${165 * k | 0},${110 * k | 0},${68 * k | 0})`; c.fillRect(0, i * p, w, p);
      for (let j = 0; j < 6; j++) { c.fillStyle = `rgba(80,45,20,${0.05 + r() * 0.08})`; c.fillRect(0, i * p + r() * p, w, 1 + r() * 2); } c.fillStyle = 'rgba(25,14,8,0.92)'; c.fillRect(0, i * p + p * 0.8, w, p * 0.2); } });
  // travertino del bagno (vene orizzontali tabacco e rosa) e del pavimento
  const travertino = (base, vena, seme, n = 160) => canvasTex(1024, 1024, (c, w, h) => { const r = rng(seme); c.fillStyle = base; c.fillRect(0, 0, w, h);
    for (let i = 0; i < n; i++) { const y0 = r() * h, a = 6 + r() * 30, f = 0.003 + r() * 0.01, ph = r() * 6; c.strokeStyle = `rgba(${vena},${0.06 + r() * 0.22})`; c.lineWidth = 0.6 + r() * (n < 100 ? 9 : 4);
      c.beginPath(); for (let x = 0; x <= w; x += 8) { const y = y0 + Math.sin(x * f + ph) * a; x ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); }
    for (let i = 0; i < 500; i++) { c.fillStyle = `rgba(120,90,60,${r() * 0.12})`; c.fillRect(r() * w, r() * h, 2 + r() * 14, 1 + r() * 2); } });
  const travBagno = travertino('#c8a688', '118,68,48', 21, 70), travChiaro = travertino('#cdb9a2', '140,105,75', 23, 120);
  const pavimento = canvasTex(1024, 1024, (c, w, h) => { const r = rng(12); for (let y = 0; y < h; y += 256) for (let x = 0; x < w; x += 512) { const k = 0.92 + r() * 0.1; c.fillStyle = `rgb(${204 * k | 0},${180 * k | 0},${150 * k | 0})`; c.fillRect(x, y, 512, 256);
      for (let i = 0; i < 30; i++) { c.fillStyle = `rgba(140,115,90,${0.05 + r() * 0.08})`; c.fillRect(x + r() * 512, y + r() * 256, 40 + r() * 160, 1 + r() * 2); } c.fillStyle = 'rgba(70,55,40,0.35)'; c.fillRect(x, y, 2, 256); c.fillRect(x, y, 512, 2); } });
  // tessuto (bianco: il colore lo dà il materiale), pelle, emperador, tappeto a cerchi
  const tessuto = canvasTex(256, 256, (c, w, h) => { const r = rng(8); c.fillStyle = '#fff'; c.fillRect(0, 0, w, h); for (let y = 0; y < h; y += 2) { c.fillStyle = `rgba(0,0,0,${0.03 + r() * 0.04})`; c.fillRect(0, y, w, 1); }
    for (let i = 0; i < 2600; i++) { c.fillStyle = `rgba(${r() < 0.5 ? '0,0,0' : '255,255,255'},${0.03 + r() * 0.05})`; c.fillRect(r() * w, r() * h, 2, 1); } }, { repeat: [3, 3] });
  const emperador = canvasTex(512, 512, (c, w, h) => { const r = rng(33); c.fillStyle = '#3b271c'; c.fillRect(0, 0, w, h); for (let i = 0; i < 60; i++) { c.strokeStyle = `rgba(${r() < 0.6 ? '200,170,140' : '20,12,8'},${0.15 + r() * 0.4})`; c.lineWidth = 0.5 + r() * 2;
      c.beginPath(); let x = r() * w, y = r() * h; c.moveTo(x, y); for (let k = 0; k < 12; k++) { x += (r() - 0.5) * 60; y += (r() - 0.5) * 60; c.lineTo(x, y); } c.stroke(); } });
  const tappeto = canvasTex(1024, 1024, (c, w, h) => { c.fillStyle = '#3a2820'; c.fillRect(0, 0, w, h); const r = rng(5);
    for (let k = 0; k < 9; k++) { c.strokeStyle = k % 2 ? 'rgba(20,12,9,0.55)' : 'rgba(95,70,55,0.35)'; c.lineWidth = 10 + r() * 8; c.beginPath(); c.ellipse(w * 0.38, h * 0.62, 70 + k * 62, 50 + k * 50, 0.15, 0, 7); c.stroke(); }
    for (let i = 0; i < 9000; i++) { c.fillStyle = `rgba(${r() < 0.5 ? '0,0,0' : '120,90,70'},${0.05 + r() * 0.06})`; c.fillRect(r() * w, r() * h, 2, 2); } });
  const arte = canvasTex(256, 512, (c, w, h) => { const r = rng(61); c.fillStyle = '#1e1712'; c.fillRect(0, 0, w, h); for (let i = 0; i < 400; i++) { c.fillStyle = `rgba(${r() < 0.5 ? '70,52,38' : '8,6,5'},${0.2 + r() * 0.5})`; c.fillRect(r() * w, r() * h, 3 + r() * 20, 2 + r() * 14); } });
  return {
    rovere: std('#ffffff', 0.72, 0, { map: rovere }), palissandro: std('#ffffff', 0.55, 0.02, { map: palissandro }), doghe: std('#ffffff', 0.7, 0, { map: doghe }), trave: std('#3a2a20', 0.6),
    travBagno: std('#ffffff', 0.35, 0, { map: travBagno }), travChiaro: std('#ffffff', 0.4, 0, { map: travChiaro }), pavimento: std('#ffffff', 0.42, 0.01, { map: pavimento }),
    intonaco: std('#e7e0d6', 0.92), intonacoScuro: std('#cfc6ba', 0.95), grezzo: std('#b9ab98', 0.95),
    divano: std('#7a808a', 0.88, 0, { map: tessuto }), divanoScuro: std('#6a707a', 0.88, 0, { map: tessuto }), zoccolo: std('#1c1b1a', 0.6, 0.2),
    pelle: std('#8d4a1f', 0.45, 0, {}), cuscinoTaupe: std('#6d625a', 0.9, 0, { map: tessuto }), velluto: std('#1b1a1a', 0.85, 0, { map: tessuto }), boucle: std('#e6ddd0', 0.97, 0, { map: tessuto }),
    noce: std('#4a2d1c', 0.45, 0, {}), noceChiaro: std('#6b4329', 0.5), emperador: std('#ffffff', 0.12, 0.02, { map: emperador }), ottone: std('#b8904f', 0.28, 1), bronzo: std('#4a3a2b', 0.35, 0.85),
    tappeto: std('#ffffff', 0.98, 0, { map: tappeto }), tvVetro: std('#07080a', 0.08, 0.3), arte: std('#ffffff', 0.95, 0, { map: arte }), nero: std('#121212', 0.55, 0.1),
    ceramicaNera: std('#16130f', 0.35, 0.05), ceramicaBianca: std('#efeae2', 0.3), luce: std('#fff3dc', 0.3, 0, { emissive: new THREE.Color('#ffcf8f'), emissiveIntensity: 2.2 }), foglieLuce: std('#fff1d6', 0.35, 0, { emissive: new THREE.Color('#ffc77a'), emissiveIntensity: 2.4 }),
    paralume: std('#f4e7d0', 0.6, 0, { emissive: new THREE.Color('#ffd7a0'), emissiveIntensity: 0.9, side: THREE.DoubleSide }), foglia: std('#5f7148', 0.85), ramo: std('#4b3a2c', 0.9),
    fiore: std('#f8f4ec', 0.8), fiore2: std('#efd9cf', 0.8), cera: std('#f5efe4', 0.6), fiamma: std('#ffd28a', 0.3, 0, { emissive: new THREE.Color('#ffb24a'), emissiveIntensity: 3 }),
    tenda: std('#6e665e', 0.95, 0, { map: tessuto, side: THREE.DoubleSide }), velo: std('#efe8dc', 0.9, 0, { transparent: true, opacity: 0.5, side: THREE.DoubleSide }),
    specchio: std('#9aa3a8', 0.06, 1, { envMapIntensity: 0.35 }), aloneLed: std('#ffe2b8', 0.4, 0, { emissive: new THREE.Color('#ffcf91'), emissiveIntensity: 0.7 }),
    vetroDoccia: new THREE.MeshPhysicalMaterial({ color: '#e8f0f2', roughness: 0.03, transparent: true, opacity: 0.16, side: THREE.DoubleSide, depthWrite: false }),
    acqua: std('#a9c7cb', 0.05, 0.1, { transparent: true, opacity: 0.75 }), asciugamano: std('#b9afa4', 0.98, 0, { map: tessuto }), libri: [std('#e8e1d4', 0.7), std('#1d1d1f', 0.7), std('#9a6b3d', 0.7), std('#4f5a52', 0.7)],
    persona: std('#2a2c30', 0.85),
  };
}

// ---------------- SALONE ----------------
/* divano angolare (tipo Minotti, foto vera): lato lungo L con lo schienale dietro, ritorno sul lato +x che va avanti (schiena al muro di sinistra), chaise senza schienale sul lato -x.
   Seduta a 45 cm, schienale a 82 cm, profondità 105. Davanti verso +z. */
export function divanoAngolare(M, L = 3.4, Lr = 1.9, Lc = 1.3) {
  const g = gruppo('divano angolare', 'terra'), D = 1.05, sH = 0.45, t = M.divano;
  const base = (w, d, x, z) => { mesh(g, rb(w - 0.12, 0.06, d - 0.12, 0.01), M.zoccolo, x, 0.03, z); mesh(g, rb(w, 0.22, d, 0.035), t, x, 0.06 + 0.11, z); };
  base(L, D, 0, 0); base(D, Lr, L / 2 - D / 2, D / 2 + Lr / 2); base(0.95, Lc, -L / 2 + 0.475, D / 2 + Lc / 2);
  // cuscini di seduta (dal piano a 28 cm alla seduta a 45)
  const cus = (w, d, x, z) => mesh(g, rb(w - 0.02, sH - 0.28, d - 0.02, 0.07, 4), t, x, 0.28 + (sH - 0.28) / 2, z);
  const xs = L - 0.3, n = 3; for (let k = 0; k < n; k++) cus(xs / n, D - 0.3, -L / 2 + xs / n * (k + 0.5), 0.15);
  cus(D - 0.3, Lr / 2, L / 2 - 0.3 - (D - 0.3) / 2, D / 2 + Lr / 4); cus(D - 0.3, Lr / 2, L / 2 - 0.3 - (D - 0.3) / 2, D / 2 + Lr * 3 / 4);
  cus(0.95, Lc, -L / 2 + 0.475, D / 2 + Lc / 2);
  // schienale: telaio basso e cuscini morbidi inclinati
  mesh(g, rb(L, 0.34, 0.2, 0.05), t, 0, 0.28 + 0.17, -D / 2 + 0.1); mesh(g, rb(0.2, 0.34, D + Lr, 0.05), t, L / 2 - 0.1, 0.28 + 0.17, (D + Lr) / 2 - D / 2);
  const sch = (w, x, z, ry) => mesh(g, rb(w, 0.42, 0.2, 0.08, 4), M.divanoScuro, x, 0.62, z, -0.16, ry);
  for (let k = 0; k < 3; k++) sch((L - 0.35) / 3 - 0.03, -L / 2 + (L - 0.35) / 3 * (k + 0.5), -D / 2 + 0.26, 0);
  for (let k = 0; k < 2; k++) { const m = sch(Lr / 2 + 0.05, L / 2 - 0.26, D / 2 - 0.25 + (Lr / 2 + 0.25) * (k + 0.5), Math.PI / 2); m.rotation.set(0, Math.PI / 2, 0); m.rotateX(-0.16); }
  // rulli davanti agli schienali e cuscini (uno di pelle cognac, come la foto)
  const rullo = (l, x, z, ry) => { const m = mesh(g, new THREE.CapsuleGeometry(0.085, l, 6, 16), M.divanoScuro, x, sH + 0.08, z, 0, ry, Math.PI / 2); return m; };
  rullo(1.0, -L / 2 + 0.75, -D / 2 + 0.48, 0); rullo(1.0, 0.35, -D / 2 + 0.48, 0);
  { const m = new THREE.Mesh(new THREE.CapsuleGeometry(0.085, 0.9, 6, 16), M.divanoScuro); m.rotation.x = Math.PI / 2; m.position.set(L / 2 - 0.48, sH + 0.08, D / 2 + Lr * 0.55); m.castShadow = true; g.add(m); }
  mesh(g, rb(0.5, 0.46, 0.14, 0.07, 4), M.pelle, L / 2 - 0.62, sH + 0.25, -D / 2 + 0.52, -0.25, -0.5);
  mesh(g, rb(0.5, 0.46, 0.14, 0.07, 4), M.cuscinoTaupe, L / 2 - 0.42, sH + 0.25, -D / 2 + 0.85, -0.25, -1.1);
  mesh(g, rb(0.5, 0.46, 0.14, 0.07, 4), M.divanoScuro, -L / 2 + 0.45, sH + 0.25, -D / 2 + 0.5, -0.25, 0.15);
  // bracciolo basso in fondo al ritorno
  mesh(g, rb(D, 0.58, 0.18, 0.06), t, L / 2 - D / 2, 0.29, D / 2 + Lr - 0.09);
  return g;
}
/* poltrona scura (tipo Kai Kristiansen, foto vera): telaio di noce, seduta e schienale neri. 72 x 78 x 80, seduta 44. Davanti verso +z */
export function poltronaScura(M) {
  const g = gruppo('poltrona', 'terra'), W = 0.72, D = 0.78, n = M.noce;
  for (const s of [-1, 1]) { const x = s * (W / 2 - 0.035);
    mesh(g, rb(0.045, 0.6, 0.045, 0.012), n, x, 0.3, D / 2 - 0.08, 0.06);
    mesh(g, rb(0.045, 0.66, 0.045, 0.012), n, x, 0.33, -D / 2 + 0.12, -0.2);
    mesh(g, rb(0.065, 0.035, D - 0.04, 0.012), n, x, 0.6, -0.01, 0.06);
    mesh(g, rb(0.035, 0.05, D - 0.25, 0.01), n, x, 0.3, 0.02); }
  mesh(g, rb(W - 0.07, 0.05, 0.04, 0.01), n, 0, 0.3, D / 2 - 0.08); mesh(g, rb(W - 0.07, 0.05, 0.04, 0.01), n, 0, 0.3, -D / 2 + 0.14);
  mesh(g, rb(W - 0.13, 0.13, D - 0.2, 0.05, 4), M.velluto, 0, 0.375, 0.04);
  mesh(g, rb(W - 0.13, 0.46, 0.11, 0.05, 4), M.velluto, 0, 0.66, -D / 2 + 0.17, -0.26);
  mesh(g, rb(W - 0.07, 0.045, 0.035, 0.01), n, 0, 0.92, -D / 2 + 0.06, -0.26);
  return g;
}
/* tavolino di marmo Emperador 100 x 90 alto 38 su telaio sottile di bronzo */
export function tavolinoMarmo(M, w = 1.0, d = 0.9, h = 0.38) {
  const g = gruppo('tavolino', 'terra'); mesh(g, rb(w, 0.035, d, 0.006), M.emperador, 0, h - 0.0175, 0);
  for (const [x, z] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) mesh(g, rb(0.02, h - 0.035, 0.02, 0.004), M.bronzo, x * (w / 2 - 0.04), (h - 0.035) / 2, z * (d / 2 - 0.04));
  for (const s of [-1, 1]) { mesh(g, rb(w - 0.08, 0.02, 0.02, 0.004), M.bronzo, 0, h - 0.045, s * (d / 2 - 0.04)); mesh(g, rb(0.02, 0.02, d - 0.08, 0.004), M.bronzo, s * (w / 2 - 0.04), h - 0.045, 0); }
  return g;
}
/* TV 75" (166 x 95) di vetro nero con la cornice di bronzo, appesa al muro (dietro a z = 0) */
export function tv(M) { const g = gruppo('TV', 'muro'); mesh(g, rb(1.7, 0.99, 0.02, 0.004), M.bronzo, 0, 0, 0.01); mesh(g, rb(1.66, 0.95, 0.03, 0.004), M.tvVetro, 0, 0, 0.025); return g; }
/* mobile basso sospeso di rovere (foto vera): 360 x 42 x 42, da 22 a 64 cm da terra, cinque cassetti; dietro a z = 0 */
export function consolle(M, L = 3.6) {
  const g = gruppo('mobile TV sospeso', 'muro'), d = 0.42, y0 = 0.22, h = 0.42; mesh(g, rb(L, h, d - 0.02, 0.01), M.rovere, 0, y0 + h / 2, (d - 0.02) / 2);
  const n = 5, w = L / n; for (let k = 0; k < n; k++) mesh(g, rb(w - 0.006, h - 0.012, 0.02, 0.004), M.rovere, -L / 2 + w * (k + 0.5), y0 + h / 2, d - 0.01);
  return g;
}
/* lampadario a rami d'ottone con le foglie accese (foto vera), largo 1,3 m; l'origine è il soffitto, pende di «giu» */
export function lampadarioRami(M, giu = 1.0) {
  const g = gruppo('lampadario', 'appeso'), R = rng(14), hub = new THREE.Vector3(0, -giu + 0.25, 0);
  mesh(g, new THREE.CylinderGeometry(0.07, 0.07, 0.025, 24), M.ottone, 0, -0.0125, 0); asta(g, new THREE.Vector3(0, -0.02, 0), hub, 0.009, M.ottone);
  const lampade = [];
  for (let i = 0; i < 15; i++) { const a = i / 15 * Math.PI * 2 + R() * 0.3, e = -0.35 + R() * 0.55, l = 0.3 + R() * 0.32;
    const gom = hub.clone().add(new THREE.Vector3(Math.cos(a) * l * 0.55, e * 0.35 - 0.05, Math.sin(a) * l * 0.55)), tip = hub.clone().add(new THREE.Vector3(Math.cos(a + 0.4) * l, e * 0.5 + 0.08, Math.sin(a + 0.4) * l));
    asta(g, hub, gom, 0.011, M.ottone); asta(g, gom, tip, 0.008, M.ottone);
    const lama = mesh(g, rb(0.22, 0.012, 0.045, 0.004), M.ottone, (hub.x + gom.x) / 2, (hub.y + gom.y) / 2 + 0.03, (hub.z + gom.z) / 2, 0, -a, 0.3 * (R() - 0.5)); lama.castShadow = false;
    const f = new THREE.Mesh(new THREE.SphereGeometry(0.05, 16, 10, 0, Math.PI * 2, 0, Math.PI * 0.55), M.ottone); f.scale.set(1, 0.45, 1.8); f.position.copy(tip).add(new THREE.Vector3(0, 0.012, 0)); f.rotation.y = -a; f.castShadow = true; g.add(f);
    const bu = new THREE.Mesh(new THREE.SphereGeometry(0.022, 10, 8), M.foglieLuce); bu.position.copy(tip).add(new THREE.Vector3(0, -0.006, 0)); g.add(bu); lampade.push(tip); }
  g.userData.lampade = lampade; return g;
}
/* lampada da terra a cupola d'ottone (foto vera), alta 1,82 */
export function lampadaCupola(M) { const g = gruppo('lampada da terra', 'terra');
  mesh(g, new THREE.CylinderGeometry(0.17, 0.17, 0.02, 32), M.bronzo, 0, 0.01, 0); mesh(g, new THREE.CylinderGeometry(0.07, 0.11, 0.26, 32), M.bronzo, 0, 0.15, 0);
  mesh(g, new THREE.CylinderGeometry(0.009, 0.009, 1.3, 8), M.ottone, 0, 0.28 + 0.65, 0);
  const c = mesh(g, new THREE.SphereGeometry(0.27, 32, 12, 0, Math.PI * 2, 0, Math.PI / 2), M.ottone, 0, 1.55, 0); c.material = M.ottone; c.geometry.scale(1, 0.95, 1);
  const in2 = new THREE.Mesh(new THREE.SphereGeometry(0.265, 32, 12, 0, Math.PI * 2, 0, Math.PI / 2), M.paralume); in2.position.y = 1.549; in2.material = M.paralume; in2.material.side = THREE.BackSide; g.add(in2);
  return g; }
/* opera materica scura con la cornice nera (foto vera) 120 x 190, appesa (dietro a z = 0) */
export function operaMaterica(M, w = 1.2, h = 1.9) { const g = gruppo('opera', 'muro'), R = rng(71);
  mesh(g, rb(w + 0.08, h + 0.08, 0.05, 0.005), M.nero, 0, 0, 0.025); mesh(g, new THREE.PlaneGeometry(w, h), M.arte, 0, 0, 0.051);
  for (let i = 0; i < 11; i++) { const sw = 0.06 + R() * 0.07, sh = h * (0.45 + R() * 0.45), x = -w / 2 + 0.1 + (w - 0.2) * (i + 0.5) / 11; mesh(g, rb(sw, sh, 0.015 + R() * 0.03, 0.01), M.arte, x, (R() - 0.5) * 0.25, 0.06); }
  return g; }
/* tappeto marrone scuro a cerchi (foto vera), spesso 1,5 cm */
export function tappeto(M, w, d) { const g = gruppo('tappeto', 'terra'), m = mesh(g, new THREE.BoxGeometry(w, 0.015, d), M.tappeto, 0, 0.0075, 0); m.castShadow = false; g.userData.strato = true; return g; }
/* vaso nero panciuto (foto vera, sul mobile TV) */
export function vasoNero(M, k = 1) { const g = gruppo('vaso nero', 'su'), pts = []; for (let i = 0; i <= 20; i++) { const t = i / 20; pts.push(new THREE.Vector2(0.03 + Math.sin(t * Math.PI * 0.95) * 0.17 + (t > 0.85 ? (t - 0.85) * 0.4 : 0), t * 0.5)); }
  const m = new THREE.Mesh(new THREE.LatheGeometry(pts, 40), M.ceramicaNera); m.castShadow = true; g.add(m); g.scale.setScalar(k); return g; }

// ---------------- PRANZO E CUCINA ----------------
/* tavolo da pranzo di travertino 300 x 120 alto 75, due basamenti scolpiti (lungo x) */
export function tavoloPranzo(M, L = 3.0, W = 1.2) { const g = gruppo('tavolo da pranzo', 'terra');
  mesh(g, rb(L, 0.06, W, 0.012), M.travChiaro, 0, 0.72, 0);
  for (const s of [-1, 1]) { mesh(g, rb(0.5, 0.69, W * 0.55, 0.08, 4), M.travChiaro, s * L * 0.28, 0.345, 0); }
  g.userData.tavolo = true; return g; }
/* sedia da pranzo imbottita (bouclé avorio, gambe di noce), seduta 47, schienale 86. Davanti verso +z (lo schienale sta a -z) */
export function sediaPranzo(M) { const g = gruppo('sedia', 'terra'), W = 0.54, D = 0.58;
  for (const [x, z] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) mesh(g, rb(0.035, 0.4, 0.035, 0.01), M.noce, x * (W / 2 - 0.05), 0.2, z * (D / 2 - 0.05));
  mesh(g, rb(W, 0.08, D, 0.035, 4), M.boucle, 0, 0.43, 0.01);
  mesh(g, rb(W - 0.02, 0.46, 0.08, 0.04, 4), M.boucle, 0, 0.63, -D / 2 + 0.05, -0.1);
  g.userData.sedia = true; return g; }
/* cucina contro il muro (davanti verso +z): colonne di noce a tutta altezza, basi con il piano di travertino a 90 cm e la lastra dietro */
export function cucinaParete(M, L = 4.4, H = 3.0) { const g = gruppo('cucina a parete', 'terra');
  const lb = L - 1.2; mesh(g, rb(lb, 0.86, 0.62, 0.008), M.noce, 0, 0.43, 0.31); mesh(g, rb(lb + 0.02, 0.04, 0.65, 0.006), M.travChiaro, 0, 0.88, 0.325);
  mesh(g, rb(lb, 1.2, 0.02, 0.004), M.travChiaro, 0, 0.9 + 0.6 + 0.02, 0.012);
  for (const s of [-1, 1]) mesh(g, rb(0.6, H - 0.02, 0.62, 0.008), M.noce, s * (L / 2 - 0.3), (H - 0.02) / 2, 0.31);
  mesh(g, rb(lb, 0.6, 0.38, 0.008), M.noce, 0, H - 0.3 - 0.01, 0.19);   // pensili
  return g; }
/* isola 360 x 110 alta 90 (top di travertino con le teste a cascata) */
export function isola(M, L = 3.6, W = 1.1, h = 0.9) { const g = gruppo('isola', 'terra');
  mesh(g, rb(L - 0.12, h - 0.05, W - 0.12, 0.01), M.noce, 0, (h - 0.05) / 2, 0); mesh(g, rb(L, 0.05, W, 0.006), M.travChiaro, 0, h - 0.025, 0);
  for (const s of [-1, 1]) mesh(g, rb(0.05, h - 0.05, W, 0.006), M.travChiaro, s * (L / 2 - 0.025), (h - 0.05) / 2, 0);
  g.userData.tavolo = true; return g; }
/* sgabello da isola, seduta 65 (per il piano a 90), davanti verso +z */
export function sgabello(M) { const g = gruppo('sgabello', 'terra');
  for (const [x, z] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) mesh(g, rb(0.03, 0.6, 0.03, 0.008), M.bronzo, x * 0.17, 0.3, z * 0.17);
  mesh(g, rb(0.44, 0.06, 0.42, 0.025), M.boucle, 0, 0.62, 0.01); mesh(g, rb(0.42, 0.22, 0.05, 0.02), M.boucle, 0, 0.78, -0.19, -0.12);
  mesh(g, rb(0.36, 0.02, 0.02, 0.005), M.bronzo, 0, 0.22, 0.17); g.userData.sedia = true; return g; }
/* lampada a sospensione a cupola (isola) e barra lineare d'ottone (pranzo): origine al soffitto */
export function pendenteCupola(M, giu = 1.0) { const g = gruppo('sospensione', 'appeso'); asta(g, new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, -giu + 0.18, 0), 0.004, M.ottone);
  mesh(g, new THREE.SphereGeometry(0.19, 28, 10, 0, Math.PI * 2, 0, Math.PI / 2), M.ottone, 0, -giu, 0); const l = new THREE.Mesh(new THREE.CircleGeometry(0.17, 24), M.luce); l.rotation.x = Math.PI / 2; l.position.y = -giu - 0.001; g.add(l); return g; }
export function barraLuce(M, L = 2.2, giu = 1.15) { const g = gruppo('lampada del pranzo', 'appeso');
  for (const s of [-1, 1]) asta(g, new THREE.Vector3(s * L * 0.4, 0, 0), new THREE.Vector3(s * L * 0.4, -giu, 0), 0.004, M.ottone);
  mesh(g, rb(L, 0.04, 0.06, 0.01), M.ottone, 0, -giu - 0.02, 0); for (let k = 0; k < 7; k++) { const b = new THREE.Mesh(new THREE.SphereGeometry(0.06, 16, 12), M.luce); b.position.set(-L / 2 + 0.15 + (L - 0.3) * k / 6, -giu - 0.1, 0); g.add(b); } return g; }

// ---------------- OGGETTI (06-3) ----------------
export function fiori(M, k = 1) { const g = gruppo('fiori', 'su'), R = rng(31); mesh(g, new THREE.CylinderGeometry(0.1, 0.075, 0.2, 32), M.ceramicaBianca, 0, 0.1, 0);
  /* teste di ortensia e rose bianche: grappoli di petali piccoli, foglie lunghe che scendono dal bordo */
  const petalo = new THREE.IcosahedronGeometry(0.018, 1);
  for (let i = 0; i < 9; i++) { const a = i / 9 * 6.28 + R() * 0.4, r = i ? 0.07 + R() * 0.06 : 0, h = 0.27 + R() * 0.1, c = new THREE.Vector3(Math.cos(a) * r, h, Math.sin(a) * r);
    asta(g, new THREE.Vector3(Math.cos(a) * 0.02, 0.18, Math.sin(a) * 0.02), c, 0.003, M.foglia);
    for (let j = 0; j < 22; j++) { const d = new THREE.Vector3(R() - 0.5, R() * 0.8, R() - 0.5).normalize().multiplyScalar(0.035 + R() * 0.012), f = new THREE.Mesh(petalo, R() < 0.8 ? M.fiore : M.fiore2); f.position.copy(c).add(d); f.scale.setScalar(0.8 + R() * 0.5); g.add(f); } }
  for (let i = 0; i < 12; i++) { const a = R() * 6.28, l = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 6), M.foglia); l.position.set(Math.cos(a) * 0.12, 0.19 - R() * 0.03, Math.sin(a) * 0.12); l.scale.set(1.8, 0.22, 0.6); l.rotation.set(0, -a, -0.35); g.add(l); }
  g.scale.setScalar(k); return g; }
export function libriArte(M, n = 3, k = 0) { const g = gruppo('libri d\'arte', 'su'); let y = 0; for (let i = 0; i < n; i++) { const h = 0.035 + i * 0.006; mesh(g, rb(0.34 - i * 0.03, h, 0.27 - i * 0.02, 0.004), M.libri[(i + k) % 4], (i % 2 ? 0.015 : -0.01), y + h / 2, 0, 0, (i - 1) * 0.07); y += h; } g.userData.alto = y; return g; }
export function candele(M, alte = false) { const g = gruppo('candele', 'su'); const hh = alte ? [0.32, 0.4, 0.28] : [0.12, 0.18, 0.09];
  hh.forEach((h, i) => { const x = (i - 1) * 0.09; mesh(g, new THREE.CylinderGeometry(0.035, 0.04, alte ? 0.12 : 0.02, 20), M.ottone, x, alte ? 0.06 : 0.01, 0); const b = alte ? 0.12 : 0.02, r = alte ? 0.012 : 0.035;
    mesh(g, new THREE.CylinderGeometry(r, r, h, 16), M.cera, x, b + h / 2, 0); const f = new THREE.Mesh(new THREE.SphereGeometry(0.011, 8, 6), M.fiamma); f.position.set(x, b + h + 0.015, 0); f.scale.y = 1.8; g.add(f); }); return g; }
export function ciotolaOttone(M) { const g = gruppo('ciotola d\'ottone', 'su'), pts = []; for (let i = 0; i <= 16; i++) { const t = i / 16; pts.push(new THREE.Vector2(0.06 + Math.sin(t * Math.PI / 2) * 0.16, t * t * 0.07)); }
  const m = new THREE.Mesh(new THREE.LatheGeometry(pts, 48), M.ottone); m.material.side = THREE.DoubleSide; m.castShadow = true; g.add(m); return g; }
/* vaso alto da terra con i rami (06-3): vaso di ceramica scura 70 cm, rami fino a 2,1 m */
export function vasoRami(M, larg = 0.55) { const g = gruppo('vaso con i rami', 'terra'), R = rng(57), pts = []; for (let i = 0; i <= 20; i++) { const t = i / 20; pts.push(new THREE.Vector2(0.12 + Math.sin(t * Math.PI) * 0.1 - t * 0.04, t * 0.7)); }
  const v = new THREE.Mesh(new THREE.LatheGeometry(pts, 40), M.ceramicaNera); v.castShadow = true; g.add(v);
  for (let i = 0; i < 9; i++) { const a = R() * 6.28, A = new THREE.Vector3(Math.cos(a) * 0.03, 0.66, Math.sin(a) * 0.03), rr = (0.25 + R() * 0.3) * larg / 0.55, B = new THREE.Vector3(Math.cos(a) * rr, 1.5 + R() * 0.55, Math.sin(a) * rr); asta(g, A, B, 0.008, M.ramo);
    for (let j = 0; j < 6; j++) { const t = 0.4 + j * 0.1, P = A.clone().lerp(B, t), l = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 6), M.foglia); l.position.set(P.x + (R() - 0.5) * 0.12, P.y, P.z + (R() - 0.5) * 0.12); l.scale.set(1.4, 0.5, 0.8); g.add(l); } }
  return g; }
export function ulivo(M, k = 1) { const g = gruppo('ulivo in vaso', 'terra'), R = rng(7); mesh(g, new THREE.CylinderGeometry(0.45, 0.4, 0.6, 40), M.travChiaro, 0, 0.3, 0); mesh(g, new THREE.CylinderGeometry(0.42, 0.42, 0.02, 40), M.ramo, 0, 0.59, 0);
  asta(g, new THREE.Vector3(0, 0.6, 0), new THREE.Vector3(0.05, 1.5, 0.02), 0.06, M.ramo); asta(g, new THREE.Vector3(0.05, 1.4, 0.02), new THREE.Vector3(-0.25, 1.9, 0.1), 0.035, M.ramo); asta(g, new THREE.Vector3(0.05, 1.45, 0.02), new THREE.Vector3(0.3, 1.95, -0.1), 0.035, M.ramo);
  for (let i = 0; i < 26; i++) { const s = new THREE.Mesh(new THREE.IcosahedronGeometry(0.16 + R() * 0.12, 1), M.foglia); s.position.set((R() - 0.5) * 0.9, 1.75 + R() * 0.55, (R() - 0.5) * 0.9); s.scale.set(1, 0.65, 1); s.castShadow = true; g.add(s); }
  g.scale.setScalar(k); return g; }
/* poltrona lounge avvolgente in bouclé (06-3, angolo davanti al vetro), davanti verso +z */
export function poltronaLounge(M) { const g = gruppo('poltrona lounge', 'terra'); const s = mesh(g, new THREE.CylinderGeometry(0.46, 0.44, 0.4, 40), M.boucle, 0, 0.2, 0); s.scale.z = 0.92;
  const sch = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.46, 0.36, 40, 1, true, Math.PI * 0.62, Math.PI * 1.76), M.boucle); sch.material.side = THREE.DoubleSide; sch.position.y = 0.58; sch.scale.z = 0.92; sch.castShadow = true; g.add(sch);
  const bordo = new THREE.Mesh(new THREE.TorusGeometry(0.46, 0.06, 10, 48, Math.PI * 1.76), M.boucle); bordo.rotation.set(Math.PI / 2, 0, Math.PI * 0.62 - Math.PI / 2 + Math.PI); bordo.position.y = 0.76; bordo.scale.y = 0.92; g.add(bordo);
  mesh(g, new THREE.CylinderGeometry(0.4, 0.4, 0.08, 40), M.boucle, 0, 0.44, 0.03).scale.z = 0.9; return g; }
export function tavolinoTondo(M) { const g = gruppo('tavolino tondo', 'terra'); mesh(g, new THREE.CylinderGeometry(0.28, 0.28, 0.04, 40), M.travChiaro, 0, 0.5, 0); mesh(g, new THREE.CylinderGeometry(0.12, 0.16, 0.48, 32), M.travChiaro, 0, 0.24, 0); return g; }
/* tenda pesante raccolta (plissé), larga w, alta h, appesa al binario del soffitto */
export function tenda(M, w, h) { const g = gruppo('tenda', 'appeso'); const ge = new THREE.PlaneGeometry(w, h - 0.02, Math.round(w * 30), 1), pa = ge.attributes.position;
  for (let i = 0; i < pa.count; i++) pa.setZ(i, Math.sin(pa.getX(i) * 26) * 0.045); ge.computeVertexNormals(); const m = new THREE.Mesh(ge, M.tenda); m.position.y = -h / 2 - 0.01; m.castShadow = true; g.add(m);
  mesh(g, rb(w + 0.1, 0.02, 0.03, 0.005), M.bronzo, 0, -0.01, 0); return g; }   /* binario a soffitto */

// ---------------- BAGNO ----------------
/* vasca freestanding ovale di travertino 180 x 85 alta 58 (bagno vero), lungo x */
export function vascaTravertino(M) { const g = gruppo('vasca', 'terra'), pts = [];
  for (let i = 0; i <= 14; i++) { const t = i / 14; pts.push(new THREE.Vector2(0.3 + Math.sin(t * Math.PI / 2) * 0.125, t * 0.58)); }
  for (let i = 0; i <= 12; i++) { const t = i / 12; pts.push(new THREE.Vector2(0.4 - Math.sin(t * Math.PI / 2) * 0.12, 0.58 - t * 0.44)); } pts.push(new THREE.Vector2(0, 0.14));
  const v = new THREE.Mesh(new THREE.LatheGeometry(pts, 64), M.travBagno); v.scale.set(1.8 / 0.85, 1, 1); v.castShadow = v.receiveShadow = true; g.add(v);
  const ac = new THREE.Mesh(new THREE.CircleGeometry(0.39, 48), M.acqua); ac.rotation.x = -Math.PI / 2; ac.scale.set(1.8 / 0.85, 1, 1); ac.position.y = 0.42; g.add(ac);
  return g; }
export function rubinettoTerra(M) { const g = gruppo('rubinetto da terra', 'terra'); mesh(g, new THREE.CylinderGeometry(0.06, 0.06, 0.02, 20), M.bronzo, 0, 0.01, 0); mesh(g, new THREE.CylinderGeometry(0.016, 0.016, 0.95, 12), M.bronzo, 0, 0.48, 0);
  mesh(g, new THREE.CylinderGeometry(0.012, 0.012, 0.26, 10), M.bronzo, 0, 0.95, -0.12, Math.PI / 2); return g; }
/* doppio lavabo sospeso (davanti verso +z, dietro al muro a z = 0): piano di travertino spesso 12 cm a 88, cassetti di noce, due vasche, rubinetti di bronzo */
export function doppioLavabo(M, L = 2.6) { const g = gruppo('doppio lavabo', 'muro'), d = 0.56;
  mesh(g, rb(L - 0.04, 0.4, d - 0.04, 0.008), M.noce, 0, 0.55, (d - 0.04) / 2); mesh(g, rb(L, 0.12, d, 0.006), M.travBagno, 0, 0.82, d / 2);
  for (const s of [-1, 1]) { const b = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.17, 0.02, 32), M.ceramicaBianca); b.scale.set(1.3, 1, 0.9); b.position.set(s * L / 4, 0.885, d / 2 + 0.03); g.add(b);
    mesh(g, new THREE.CylinderGeometry(0.015, 0.015, 0.25, 10), M.bronzo, s * L / 4, 1.0, 0.07); mesh(g, new THREE.CylinderGeometry(0.012, 0.012, 0.18, 10), M.bronzo, s * L / 4, 1.12, 0.15, Math.PI / 2); }
  return g; }
export function specchioLed(M, w = 2.4, h = 1.0, attaccato = true) { const g = gruppo('specchio', 'muro'); mesh(g, new THREE.PlaneGeometry(w + 0.12, h + 0.12), M.aloneLed, 0, 0, 0.006);
  if (attaccato) mesh(g, rb(w, h, 0.024, 0.004), M.specchio, 0, 0, 0.012); else mesh(g, rb(w, h, 0.02, 0.004), M.specchio, 0, 0, 0.02); return g; }   /* 06-4: prima l'alone stava a 6 mm dal muro e niente toccava il muro */
export function portaSalviette(M) { const g = gruppo('porta salviette', 'muro'); mesh(g, new THREE.CylinderGeometry(0.01, 0.01, 0.7, 8), M.bronzo, 0, 0, 0.06, 0, 0, Math.PI / 2);
  for (const s of [-1, 1]) { mesh(g, rb(0.3, 0.5, 0.03, 0.01), M.asciugamano, s * 0.16, -0.24, 0.06); mesh(g, new THREE.CylinderGeometry(0.008, 0.008, 0.06, 8), M.bronzo, s * 0.35, 0, 0.03, Math.PI / 2); } return g; }

// ---------------- CAMERA ----------------
export function letto(M) { const g = gruppo('letto', 'terra'); mesh(g, rb(2.1, 0.3, 2.2, 0.04), M.noce, 0, 0.15, 0); mesh(g, rb(2.0, 0.26, 2.05, 0.08, 4), M.boucle, 0, 0.43, 0.04);
  mesh(g, rb(2.0, 0.06, 1.3, 0.03), M.cuscinoTaupe, 0, 0.58, 0.4); for (const s of [-1, 1]) mesh(g, rb(0.75, 0.22, 0.18, 0.07, 4), M.boucle, s * 0.45, 0.66, -0.78, -0.3);
  mesh(g, rb(2.5, 1.2, 0.1, 0.03), M.velluto, 0, 0.6, -1.15); return g; }
export function comodino(M) { const g = gruppo('comodino', 'terra'); mesh(g, rb(0.55, 0.5, 0.45, 0.01), M.noce, 0, 0.25, 0); return g; }

// ---------------- SAGOMA DI PERSONA (06-2): 1,80 m esatti, solo sagoma ----------------
export function sagomaPersona(M, H = 1.8) { const g = gruppo('persona 1,80 m', 'terra'), k = H / 1.8, m = M.persona;
  for (const s of [-1, 1]) { mesh(g, new THREE.CapsuleGeometry(0.065 * k, 0.72 * k, 6, 12), m, s * 0.1 * k, 0.065 * k + 0.36 * k + 0.02 * k, 0); mesh(g, rb(0.11 * k, 0.04 * k, 0.26 * k, 0.015), m, s * 0.1 * k, 0.02 * k, 0.05 * k); }
  const t = mesh(g, new THREE.CapsuleGeometry(0.17 * k, 0.42 * k, 6, 16), m, 0, 1.2 * k, 0); t.scale.z = 0.62;
  for (const s of [-1, 1]) mesh(g, new THREE.CapsuleGeometry(0.045 * k, 0.6 * k, 6, 12), m, s * 0.235 * k, 1.13 * k, 0, 0, 0, s * 0.05);
  mesh(g, new THREE.CylinderGeometry(0.05 * k, 0.055 * k, 0.1 * k, 12), m, 0, 1.56 * k, 0);
  const h = mesh(g, new THREE.SphereGeometry(0.105 * k, 24, 16), m, 0, H - 0.105 * k * 1.12, 0); h.scale.set(0.92, 1.12, 1);
  return g; }
