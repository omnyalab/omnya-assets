# anteprima veloce sul Mac (EEVEE, bassa risoluzione) del giro CAM_F: serve al giudice smooth.py, non è il render finale
# blender -b scena.blend --python anteprima.py -- <cartella> <larghezza> <campioni> [da-a] [passo]
import bpy, sys, os, time
a = sys.argv[sys.argv.index('--') + 1:]
D, Wd, S = a[0], int(a[1]), int(a[2])
scn = bpy.context.scene; os.makedirs(D, exist_ok=True)
for e in ('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE'):
    try:
        scn.render.engine = e; break
    except Exception:
        pass
ee = scn.eevee; ee.taa_render_samples = S
for k, v in (('use_volumetric_shadows', False), ('volumetric_tile_size', '16'), ('volumetric_end', 1500.0), ('use_raytracing', False)):
    try: setattr(ee, k, v)
    except Exception: pass
scn.render.resolution_x = Wd; scn.render.resolution_y = Wd * 9 // 16; scn.render.resolution_percentage = 100
scn.render.image_settings.file_format = 'JPEG'; scn.render.image_settings.quality = 88
scn.camera = bpy.data.objects['CAM_F']
x, y = map(int, a[3].split('-')) if len(a) > 3 else (scn.frame_start, scn.frame_end)
step = int(a[4]) if len(a) > 4 else 1
for f in range(x, y + 1, step):
    out = os.path.join(D, f'f_{f:04d}.jpg')
    if os.path.exists(out):
        continue
    t = time.time(); scn.frame_set(f); scn.render.filepath = out
    bpy.ops.render.render(write_still=True); print('FRAME', f, round(time.time() - t, 2), flush=True)
