// 'stills' mode: nothing here. tools/make_frames.py frames ... writes the frames of the clips here.
window.BUILD_FRAMES = null;
