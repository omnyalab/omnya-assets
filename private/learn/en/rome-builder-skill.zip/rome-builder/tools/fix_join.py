#!/usr/bin/env python3
"""fix_join.py FRAMES_DIR A B [--apply OUT_DIR]
Kling slows down at the end of a clip to land on the end photo, so the film seems to stop at the join.
Measures the camera speed (optical flow) on frames A..B (the braking end of a clip, numbered f_0001.jpg ...),
and picks fewer frames at the cruising speed of the frames before A. Prints the frames to keep and how many
seconds to cut from the sound at that point (at 24 fps). With --apply it writes the new numbered sequence.
Used on the Rome film: frames 176-193 of clip 2 (18 frames, 2.9 -> 0.26 px/frame) became 9 frames."""
import sys, os, shutil
import cv2, numpy as np
D, A, B = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
f = lambda i: os.path.join(D, 'f_%04d.jpg' % i)
def g(i): return cv2.cvtColor(cv2.resize(cv2.imread(f(i)), (480, 270)), cv2.COLOR_BGR2GRAY).astype(np.float32)
sp = {}; prev = g(A - 10)
for i in range(A - 9, B + 1):
    cur = g(i); sp[i] = float(np.linalg.norm(cv2.calcOpticalFlowFarneback(prev, cur, None, 0.5, 3, 15, 3, 5, 1.2, 0), axis=2).mean()); prev = cur
v = np.mean([sp[i] for i in range(A - 9, A)])
cum = np.cumsum([0] + [sp[i] for i in range(A + 1, B + 1)])
n = max(1, int(round(cum[-1] / v)))
pick = [A + int(np.argmin(np.abs(cum - t))) for t in np.linspace(0, cum[-1], n + 1)[1:]]
cut = (B - A) - len(pick)
print('cruising %.2f px/frame, frames %d-%d -> %s, %d frames fewer = cut %.3f s of sound at %.2f s' % (v, A + 1, B, pick, cut, cut / 24, (A + 1) / 24))
if '--apply' in sys.argv:
    out = sys.argv[sys.argv.index('--apply') + 1]; os.makedirs(out, exist_ok=True)
    total = len([x for x in os.listdir(D) if x.startswith('f_')])
    seq = list(range(1, A + 1)) + pick + list(range(B + 1, total + 1))
    for k, src in enumerate(seq, 1): shutil.copy(f(src), os.path.join(out, 'f_%04d.jpg' % k))
    print('written', len(seq), 'frames to', out)
