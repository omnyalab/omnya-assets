# The Towers Scene · Licence

Copyright © 2026 Omnya Lab. All rights reserved.

This licence covers the scene made by Omnya Lab: `index.html`, `scene/towers.js`, `README.md` and `preview.jpg`. One purchase is one licence for one person or one studio.

## You can

- Open, study and modify the scene.
- Use it, as it is or modified, in your personal projects.
- Use it, as it is or modified, in the work you make for your clients, such as videos, reels, images, presentations and websites. Your clients receive the finished work, not the scene files as a product of their own.
- Publish what you make with it, online and offline, with no credit required.

## You cannot

- Resell, sublicense, share or give away the scene files, as they are or modified, alone or together with other files.
- Include the scene files in a template, an asset pack, a course, a tool or any product whose value is the scene itself.
- Claim that you wrote the original scene.

## Third-party code

The `vendor` folder contains three.js r160 and three of its addons, copyright three.js authors, released under the MIT License. That code is not covered by the terms above and stays under its own licence, which you find in `vendor/THREE-LICENSE.txt`.

## No warranty

The scene is provided as it is, without warranty of any kind. Omnya Lab is not liable for any damage that comes from using it.

Questions about a use that is not listed here: info@omnyalab.com
